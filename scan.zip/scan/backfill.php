<?php
declare(strict_types=1);

require_once __DIR__ . '/lib/bootstrap.php';

// Same staff session as the intake app. Anyone not signed in goes to the login
// screen rather than seeing this tool exists.
if (!app_is_configured() || !app_is_authenticated()) {
    header('Location: ./');
    exit;
}

$csrf = app_csrf_token();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="theme-color" content="#0c0908">
  <meta name="csrf-token" content="<?= htmlspecialchars($csrf, ENT_QUOTES) ?>">
  <title>Lockett Labs · Catalogue Maintenance</title>
  <link rel="icon" href="assets/icon.svg" type="image/svg+xml">
  <link rel="stylesheet" href="assets/app.css?v=5.43-speed-and-log">
</head>
<body>
  <header class="topbar">
    <a class="brand-lockup brand-logo-only" href="./" aria-label="Back to Card Intake">
      <img class="brand-logo" src="https://lockett-labs.com/cdn/shop/files/Untitled-3_534574e2-c46f-4014-8f54-1f53bd0cc0b8_363x118.png?v=1761736343" width="363" height="118" decoding="async" alt="Lockett Labs">
    </a>
    <div class="top-actions">
      <a class="text-button" href="./">Back to Card Intake</a>
    </div>
  </header>

  <main class="app-shell">
    <section class="hero hero-compact">
      <div>
        <p class="eyebrow">Maintenance tools</p>
        <h1>CATALOGUE <span>MAINTENANCE</span></h1>
      </div>
    </section>

    <div id="app-message" class="message" role="status" hidden></div>

    <article class="panel">
      <div class="section-heading">
        <div><span class="step-number">01</span><div><p>Pokémon singles</p><h2>Fill custom.tcg_card_id</h2></div></div>
      </div>
      <p class="section-note">
        The product page reads <code>custom.tcg_card_id</code> before falling back to the image filename, and that
        fallback resolves the wrong card on some sets. This fills the metafield from TCGdex.
      </p>
      <p class="section-note">
        Each product's set comes from its own title, not from the tag below — that tag only chooses which products to
        process, so an era tag such as <code>Sword &amp; Shield</code> is fine and resolves every card to its own set.
        Three checks must all pass before an id is written: the set name matches TCGdex exactly, the printed
        denominator matches that set's card count, and the card at that number carries the expected name. Fail any one
        and the product is reported as unresolved and left alone.
      </p>

      <section class="form-section">
        <div class="field-grid">
          <div class="field">
            <label for="backfill-tag">Set tag <small>exactly as tagged in Shopify</small></label>
            <input id="backfill-tag" type="search" list="backfill-tags" placeholder="e.g. Ascended Heroes" autocomplete="off">
            <datalist id="backfill-tags"></datalist>
          </div>
          <div class="field">
            <label for="backfill-language">Catalogue</label>
            <select id="backfill-language">
              <option value="en">English</option>
              <option value="ja">Japanese</option>
            </select>
          </div>
          <div class="field span-two">
            <label class="confirm-row">
              <input id="backfill-force" type="checkbox">
              <span>Re-derive products that already have an id, and clear any that no longer resolve</span>
            </label>
          </div>
        </div>
        <div class="stock-candidate-buttons">
          <button id="backfill-dry-run" class="button primary" type="button">Dry run</button>
          <button id="backfill-apply" class="button secondary" type="button" disabled>Apply to Shopify</button>
          <button id="backfill-stop" class="text-button" type="button" hidden>Stop</button>
        </div>
        <p class="field-help">
          Dry run changes nothing. <strong>Apply</strong> only unlocks once a dry run has finished for the set in the
          box, and it writes exactly the ids that dry run listed.
        </p>
      </section>

      <section class="form-section">
        <div class="subheading"><div><span>Progress</span><h3 id="backfill-progress">No run yet</h3></div></div>
        <div id="backfill-counts" class="backfill-counts" hidden></div>
        <div id="backfill-results" class="backfill-results"></div>
      </section>
    </article>

    <article class="panel">
      <div class="section-heading">
        <div><span class="step-number">02</span><div><p>Catalogue safety</p><h2>Variant snapshots</h2></div></div>
      </div>
      <p class="section-note">
        Shopify has no undo for deleted variants. A <code>productSet</code> call without a variants array replaces a
        product wholesale — on 28 July 2026 one collapsed every multi-variant product in the catalogue to a single
        variant, and inventory quantities were gone for good because nothing had recorded them.
      </p>
      <p class="section-note">
        A snapshot stores every product's variants, SKUs, prices <strong>and quantities</strong>, so the next bad write
        is a restore from file. The scan also flags collapsed products: an option describing a range
        (<code>Style</code>, <code>Coin Type</code>, <code>Tin Type</code>) with only one variant left.
        <code>Title</code> and <code>Condition</code> are ignored — the first is Shopify's placeholder for
        single-variant products, the second is the intake app's own option, where one Near Mint variant is the normal
        state for a card single.
      </p>

      <section class="form-section">
        <div class="stock-candidate-buttons">
          <button id="vb-check" class="button secondary" type="button">Scan only</button>
          <button id="vb-snapshot" class="button primary" type="button">Take snapshot</button>
        </div>
        <p class="field-help">
          Both run a full catalogue export and take a couple of minutes. <strong>Scan only</strong> reports collapsed
          products and writes nothing. <strong>Take snapshot</strong> also saves the file for restoring from later.
          For an unattended nightly copy, run <code>tools/backup-variants.php --keep=30</code> from cron.
        </p>
      </section>

      <section class="form-section">
        <div class="subheading"><div><span>Result</span><h3 id="vb-progress">No scan yet</h3></div></div>
        <div id="vb-counts" class="backfill-counts" hidden></div>
        <div id="vb-results" class="backfill-results"></div>
      </section>

      <section class="form-section">
        <div class="subheading"><div><span>Stored</span><h3>Recent snapshots</h3></div><button id="vb-refresh" class="text-button" type="button">Refresh</button></div>
        <div id="vb-snapshots" class="backfill-results"></div>
      </section>
    </article>

    <article class="panel">
      <div class="section-heading">
        <div><span class="step-number">03</span><div><p>Search visibility</p><h2>Collection SEO</h2></div></div>
      </div>
      <p class="section-note">
        A page carries one title tag, so extra searches are captured by giving each collection its own title, not by
        stacking games into the homepage. This builds both strings from the collection itself: game, set name and
        range type come from its title and handle, so a Pokémon set page reads
        <code>Pitch Black Pokémon Cards UK | Lockett Labs</code> while the plush range reads
        <code>Pokémon Plushies UK | Lockett Labs</code>.
      </p>
      <p class="section-note">
        Lowestoft goes in the description rather than the title. A title has around 60 usable characters and the set
        name earns them; a town repeated across hundreds of titles reads as spam and Google tends to rewrite it.
        Local searches are won by the store page and its LocalBusiness schema instead.
      </p>

      <section class="form-section">
        <div class="field-grid">
          <div class="field span-two">
            <label class="confirm-row">
              <input id="cs-force" type="checkbox">
              <span>Also rewrite collections that already have an SEO title</span>
            </label>
          </div>
        </div>
        <div class="stock-candidate-buttons">
          <button id="cs-dry-run" class="button primary" type="button">Dry run</button>
          <button id="cs-apply" class="button secondary" type="button" disabled>Apply to Shopify</button>
        </div>
        <p class="field-help">
          Dry run lists every proposed title and description in full. Read them before applying: a set name is split
          out of the collection title, so an oddly named collection is worth spotting here rather than on 400 live
          pages. Without the checkbox above, anything already carrying a hand-written SEO title is left alone.
        </p>
      </section>

      <section class="form-section">
        <div class="subheading"><div><span>Result</span><h3 id="cs-progress">No run yet</h3></div></div>
        <div id="cs-results" class="backfill-results"></div>
      </section>
    </article>

    <article class="panel">
      <div class="section-heading">
        <div><span class="step-number">04</span><div><p>Deals deck</p><h2>Collection saving badges</h2></div></div>
      </div>
      <p class="section-note">
        Each collection card on the deals strip shows a <strong>Save up to X%</strong> badge. The theme cannot work
        that figure out honestly on its own: Liquid caps <code>collection.products</code> at 50 items, so on Pokémon
        (8,000+ products) the badge would read the best saving among an arbitrary first fifty.
      </p>
      <p class="section-note">
        This walks the whole catalogue in one export and writes the real figure to
        <code>custom.max_discount_pct</code> on every collection, which the theme reads in preference to counting.
        Percentages are rounded <em>down</em> and only purchasable variants count — a 60% saving on a sold-out variant
        is a promise the collection breaks the moment someone clicks in.
      </p>

      <section class="form-section">
        <div class="stock-candidate-buttons">
          <button id="cd-scan" class="button primary" type="button">Scan catalogue</button>
          <button id="cd-apply" class="button secondary" type="button" disabled>Write to Shopify</button>
        </div>
        <p class="field-help">
          The scan takes a couple of minutes and writes nothing. <strong>Write</strong> then saves the figures,
          including the zeroes — a collection whose sale has ended must be reset, or the badge advertises a discount
          that no longer exists. Worth re-running whenever prices change; nightly from cron is ideal.
        </p>
      </section>

      <section class="form-section">
        <div class="subheading"><div><span>Result</span><h3 id="cd-progress">No scan yet</h3></div></div>
        <div id="cd-counts" class="backfill-counts" hidden></div>
        <div id="cd-results" class="backfill-results"></div>
      </section>
    </article>

    <article class="panel">
      <div class="section-heading">
        <div><span class="step-number">04</span><div><p>Access</p><h2>Staff password hash</h2></div></div>
        <span class="pill"><?= app_password_is_hashed() ? 'Hashed' : 'Plain text' ?></span>
      </div>
      <p class="section-note">
        The staff password is stored in <code>config.php</code>. If it is stored as itself, anyone who can read that
        file has it: a backup, an FTP client, a stray copy sent to someone. A hash cannot be read back.
      </p>
      <p class="section-note">
        Type the password below and paste the line it gives you over the existing <code>admin_password</code> value.
        Staff keep signing in with the same password and the login screen does not change. The plain form keeps
        working until you make the change, so there is no moment where anyone is locked out.
      </p>

      <section class="form-section">
        <div class="field-grid">
          <div class="field span-two">
            <label for="hp-password">Staff password <small>at least 12 characters</small></label>
            <input id="hp-password" type="password" autocomplete="new-password" spellcheck="false">
          </div>
        </div>
        <div class="stock-candidate-buttons">
          <button id="hp-generate" class="button primary" type="button">Generate hash</button>
        </div>
        <p class="field-help">
          The password is sent to this server only, over the same session you are already signed in with, and is not
          written to the session, the cache or any log. The hash is shown once and not stored either.
        </p>
      </section>

      <section id="hp-result-section" class="form-section" hidden>
        <div class="subheading"><div><span>Paste this into config.php</span><h3 id="hp-algo"></h3></div></div>
        <pre id="hp-line" class="backfill-line"></pre>
        <div class="stock-candidate-buttons">
          <button id="hp-copy" class="button secondary" type="button">Copy line</button>
        </div>
        <p class="field-help">
          Then sign out and back in with the same password to confirm it works, before closing this page.
        </p>
      </section>
    </article>
  </main>

  <script src="assets/backfill.js?v=5.43-speed-and-log" defer></script>
</body>
</html>
