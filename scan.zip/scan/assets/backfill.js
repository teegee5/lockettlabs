(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const csrf = $('meta[name="csrf-token"]')?.content || '';

  const els = {
    message: $('#app-message'),
    tag: $('#backfill-tag'),
    tagList: $('#backfill-tags'),
    language: $('#backfill-language'),
    force: $('#backfill-force'),
    dryRun: $('#backfill-dry-run'),
    apply: $('#backfill-apply'),
    stop: $('#backfill-stop'),
    progress: $('#backfill-progress'),
    counts: $('#backfill-counts'),
    results: $('#backfill-results')
  };

  const state = {
    running: false,
    cancelled: false,
    // Apply is only offered for the exact set a dry run has completed for.
    dryRunTag: '',
    totals: { seen: 0, resolved: 0, skipped: 0, unresolved: 0, written: 0, cleared: 0, clearable: 0 }
  };

  function showMessage(text, type = '') {
    if (!els.message) return;
    els.message.textContent = text;
    els.message.className = `message${type ? ` ${type}` : ''}`;
    els.message.hidden = !text;
  }

  async function api(url, options = {}) {
    const response = await fetch(url, {
      credentials: 'same-origin',
      headers: { Accept: 'application/json', ...(options.headers || {}) },
      ...options
    });
    let data;
    try { data = await response.json(); } catch { data = { ok: false, error: `Server returned HTTP ${response.status}.` }; }
    if (!response.ok || !data.ok) throw new Error(data.error || `Request failed (${response.status}).`);
    return data;
  }

  async function loadTagSuggestions() {
    try {
      const data = await api('api/shopify-meta.php');
      els.tagList.replaceChildren();
      (data.tags || []).forEach(tag => {
        const option = document.createElement('option');
        option.value = tag;
        els.tagList.append(option);
      });
    } catch {
      // The tag box still accepts free text, so a failed lookup is not fatal.
    }
  }

  function resetTotals() {
    state.totals = { seen: 0, resolved: 0, skipped: 0, unresolved: 0, written: 0, cleared: 0, clearable: 0 };
    els.results.replaceChildren();
    els.counts.hidden = true;
  }

  function renderCounts(applied) {
    const { seen, resolved, skipped, unresolved, written, cleared, clearable } = state.totals;
    const tiles = [
      ['Products seen', seen],
      [applied ? 'Written' : 'Resolvable', applied ? written : resolved],
      ['Already set', skipped],
      ['Unresolved', unresolved]
    ];
    if (applied ? cleared : clearable) {
      tiles.push([applied ? 'Stale ids cleared' : 'Stale ids to clear', applied ? cleared : clearable]);
    }
    els.counts.replaceChildren();
    tiles.forEach(([label, value]) => {
      const tile = document.createElement('div');
      tile.className = 'backfill-count';
      const number = document.createElement('strong');
      number.textContent = String(value);
      const caption = document.createElement('span');
      caption.textContent = label;
      tile.append(number, caption);
      els.counts.append(tile);
    });
    els.counts.hidden = false;
  }

  function appendRows(rows, kind) {
    rows.forEach(row => {
      const line = document.createElement('div');
      line.className = `backfill-row ${kind}`;
      const title = document.createElement('span');
      title.textContent = row.title || 'Untitled product';
      const value = document.createElement('code');
      if (kind === 'resolved') {
        value.textContent = row.replaces ? `${row.replaces} → ${row.cardId}` : row.cardId;
      } else if (!row.number) {
        value.textContent = 'no printed number found';
      } else {
        value.textContent = `no match for ${row.set || 'unknown set'} ${row.number}`;
      }
      line.append(title, value);
      els.results.append(line);
    });
  }

  function setBusy(running) {
    state.running = running;
    els.dryRun.disabled = running;
    els.apply.disabled = running || state.dryRunTag !== els.tag.value.trim() || !state.totals.resolved;
    els.tag.disabled = running;
    els.language.disabled = running;
    els.force.disabled = running;
    els.stop.hidden = !running;
  }

  async function run(apply) {
    const tag = els.tag.value.trim();
    if (!tag) {
      showMessage('Enter the set tag first.', 'error');
      els.tag.focus();
      return;
    }
    if (apply && !window.confirm(`Write TCGdex ids to Shopify for “${tag}”? This changes live products.`)) return;

    state.cancelled = false;
    resetTotals();
    setBusy(true);
    showMessage(apply ? `Writing card ids for “${tag}”…` : `Dry run for “${tag}” — nothing will be changed.`);

    let cursor = '';
    let page = 0;
    try {
      do {
        const data = await api('api/backfill-card-ids.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
          body: JSON.stringify({
            tag,
            language: els.language.value,
            force: els.force.checked,
            apply: apply === true,
            cursor
          })
        });

        page += 1;
        Object.keys(state.totals).forEach(key => {
          state.totals[key] += Number(data.counts?.[key] || 0);
        });
        appendRows(data.resolved || [], 'resolved');
        appendRows(data.unresolved || [], 'unresolved');
        renderCounts(apply);
        els.progress.textContent = `${apply ? 'Writing' : 'Checking'} “${tag}” — ${state.totals.seen} products so far`;

        if ((data.errors || []).length) {
          showMessage(`Shopify reported: ${data.errors.join(' ')}`, 'warning');
        }
        cursor = data.hasNextPage ? (data.cursor || '') : '';
      } while (cursor && !state.cancelled);

      const { seen, resolved, skipped, unresolved, written, cleared, clearable } = state.totals;
      if (state.cancelled) {
        els.progress.textContent = `Stopped after ${seen} products`;
        showMessage(`Stopped. ${apply ? `${written} id${written === 1 ? '' : 's'} written before stopping.` : 'Nothing was changed.'}`, 'warning');
      } else if (apply) {
        state.dryRunTag = '';
        els.progress.textContent = `Finished “${tag}”`;
        const clearNote = cleared ? ` Cleared ${cleared} stale id${cleared === 1 ? '' : 's'} that no longer resolve.` : '';
        showMessage(`Wrote ${written} card id${written === 1 ? '' : 's'} across ${seen} product${seen === 1 ? '' : 's'}.${clearNote} ${unresolved} unresolved.`, 'success');
      } else {
        state.dryRunTag = tag;
        els.progress.textContent = `Dry run finished for “${tag}”`;
        const clearNote = clearable ? ` ${clearable} existing id${clearable === 1 ? '' : 's'} no longer resolve and will be cleared.` : '';
        showMessage(
          resolved
            ? `${resolved} product${resolved === 1 ? '' : 's'} ready to write, ${skipped} already set, ${unresolved} unresolved.${clearNote} Nothing has been changed — review the list, then Apply.`
            : `Nothing to write. ${skipped} already set, ${unresolved} unresolved.${clearNote}`,
          resolved ? 'success' : 'warning'
        );
      }
      if (page === 0) els.progress.textContent = 'No products matched that set tag';
    } catch (error) {
      showMessage(error.message || 'The backfill could not finish.', 'error');
      els.progress.textContent = 'Run failed';
      state.dryRunTag = '';
    } finally {
      setBusy(false);
    }
  }

  els.dryRun.addEventListener('click', () => run(false));
  els.apply.addEventListener('click', () => run(true));
  els.stop.addEventListener('click', () => {
    state.cancelled = true;
    showMessage('Stopping after the current page…');
  });
  // Changing the set invalidates the dry run that unlocked Apply.
  els.tag.addEventListener('input', () => setBusy(false));
  els.force.addEventListener('change', () => { state.dryRunTag = ''; setBusy(false); });
  els.language.addEventListener('change', () => { state.dryRunTag = ''; setBusy(false); });

  loadTagSuggestions();
  setBusy(false);

  /* ---- variant snapshots ---------------------------------------------- */

  const vb = {
    check: $('#vb-check'),
    snapshot: $('#vb-snapshot'),
    refresh: $('#vb-refresh'),
    progress: $('#vb-progress'),
    counts: $('#vb-counts'),
    results: $('#vb-results'),
    snapshots: $('#vb-snapshots')
  };

  // The catalogue export is a bulk operation taking minutes, so it is started
  // and then polled rather than waited on inside one request.
  const VB_POLL_MS = 5000;
  let vbRunning = false;

  function vbPost(payload) {
    return api('api/variant-backup.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify(payload)
    });
  }

  function vbTiles(counts) {
    vb.counts.replaceChildren();
    [['Products', counts.products], ['Variants', counts.variants], ['Collapsed', counts.collapsed],
      ['Addable at zero', counts.oversellable || 0]]
      .forEach(([label, value]) => {
        const tile = document.createElement('div');
        tile.className = 'backfill-count';
        const n = document.createElement('strong');
        n.textContent = String(value);
        const c = document.createElement('span');
        c.textContent = label;
        tile.append(n, c);
        vb.counts.append(tile);
      });
    vb.counts.hidden = false;
  }

  function vbBusy(on) {
    vbRunning = on;
    vb.check.disabled = on;
    vb.snapshot.disabled = on;
  }

  async function vbLoadSnapshots() {
    try {
      const data = await vbPost({ action: 'list' });
      vb.snapshots.replaceChildren();
      if (!(data.snapshots || []).length) {
        const row = document.createElement('div');
        row.className = 'backfill-row';
        row.textContent = 'No snapshots stored yet.';
        vb.snapshots.append(row);
        return;
      }
      data.snapshots.forEach(s => {
        const row = document.createElement('div');
        row.className = `backfill-row ${s.collapsed ? 'unresolved' : 'resolved'}`;
        const left = document.createElement('span');
        left.textContent = `${s.takenAt || s.name} — ${s.products} products, ${s.variants} variants`;
        const right = document.createElement('code');
        right.textContent = s.collapsed
          ? `${s.collapsed} collapsed · ${(s.bytes / 1048576).toFixed(1)} MB`
          : `clean · ${(s.bytes / 1048576).toFixed(1)} MB`;
        row.append(left, right);
        vb.snapshots.append(row);
      });
    } catch {
      // Listing is a convenience; a failure here must not block scanning.
    }
  }

  async function vbRun(save) {
    if (vbRunning) return;
    vbBusy(true);
    vb.results.replaceChildren();
    vb.counts.hidden = true;
    vb.progress.textContent = 'Starting catalogue export…';
    showMessage(save ? 'Exporting the catalogue and saving a snapshot…' : 'Exporting the catalogue to scan for collapsed products…');

    try {
      const start = await vbPost({ action: 'start' });
      if (start.started === false) vb.progress.textContent = 'An export was already running — watching it.';

      let done = null;
      while (!done) {
        await new Promise(r => setTimeout(r, VB_POLL_MS));
        const state = await vbPost({ action: 'status', save, keepDays: save ? 30 : 0 });
        if (state.done) { done = state; break; }
        vb.progress.textContent = `Exporting… ${Number(state.objectCount || 0).toLocaleString()} records so far`;
      }

      vbTiles(done.counts);
      const collapsed = done.collapsed || [];
      collapsed.forEach(c => {
        const row = document.createElement('div');
        row.className = 'backfill-row unresolved';
        const left = document.createElement('span');
        left.textContent = c.title;
        const right = document.createElement('code');
        right.textContent = `${c.option}: only "${c.survivor}" left`;
        row.append(left, right);
        vb.results.append(row);
      });

      if (!collapsed.length) {
        const row = document.createElement('div');
        row.className = 'backfill-row resolved';
        row.textContent = 'No collapsed products. Every multi-option product still has more than one variant.';
        vb.results.append(row);
      }

      // Variants a bot or console POST could add while out of stock. Hiding the
      // Add to basket button does not stop that; only Shopify's inventory gate
      // does, and it needs tracked inventory plus a DENY policy.
      const oversell = done.oversellable || [];
      const head = document.createElement('div');
      head.className = `backfill-row ${oversell.length ? 'unresolved' : 'resolved'}`;
      head.textContent = oversell.length
        ? `${done.counts.oversellable} variant${done.counts.oversellable === 1 ? '' : 's'} can be added to cart while out of stock — these need Tracked + DENY.`
        : 'No variant can be added to cart while out of stock. Every active variant is tracked with a DENY policy.';
      vb.results.append(head);

      oversell.forEach(o => {
        const row = document.createElement('div');
        row.className = 'backfill-row unresolved';
        const left = document.createElement('span');
        left.textContent = o.variant && o.variant !== 'Default Title' ? `${o.title} — ${o.variant}` : o.title;
        const right = document.createElement('code');
        right.textContent = `${o.policy}${o.tracked ? '' : ' · UNTRACKED'} · qty ${o.quantity}`;
        row.append(left, right);
        vb.results.append(row);
      });

      vb.progress.textContent = done.saved ? `Snapshot saved: ${done.file}` : 'Scan complete';
      showMessage(
        collapsed.length
          ? `${collapsed.length} product${collapsed.length === 1 ? '' : 's'} look collapsed — check them against a recent snapshot before anything else touches the store.`
          : `Catalogue clean: ${done.counts.products} products, ${done.counts.variants} variants.${done.saved ? ' Snapshot saved.' : ''}`,
        collapsed.length ? 'warning' : 'success'
      );
      if (done.saved) vbLoadSnapshots();
    } catch (error) {
      vb.progress.textContent = 'Export failed';
      showMessage(error.message || 'The catalogue export could not finish.', 'error');
    } finally {
      vbBusy(false);
    }
  }

  vb.check?.addEventListener('click', () => vbRun(false));
  vb.snapshot?.addEventListener('click', () => vbRun(true));
  vb.refresh?.addEventListener('click', vbLoadSnapshots);
  vbLoadSnapshots();

  // ---- Collection SEO ------------------------------------------------------

  const cs = {
    force: $('#cs-force'),
    dryRun: $('#cs-dry-run'),
    apply: $('#cs-apply'),
    progress: $('#cs-progress'),
    results: $('#cs-results')
  };
  let csPlanned = 0;

  async function csRun(mode) {
    cs.dryRun.disabled = true;
    cs.apply.disabled = true;
    cs.results.replaceChildren();
    cs.progress.textContent = mode === 'apply' ? 'Writing to Shopify…' : 'Reading collections…';

    const post = body => api('api/collection-seo.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify(body)
    });

    try {
      if (mode === 'apply') {
        // The server writes a slice per request; keep asking until it says
        // done. A chunk that fails stops the loop with its offset intact, so
        // retrying resumes rather than rewriting everything.
        let offset = 0, updated = 0, failed = [];
        for (;;) {
          const page = await post({ mode: 'apply', offset });
          updated += page.updated || 0;
          failed = failed.concat(page.errors || []);
          offset = page.offset;
          cs.progress.textContent = `Updated ${updated} of ${page.total}…`;
          if (page.done) break;
        }

        cs.progress.textContent = `Updated ${updated} collections`;
        failed.forEach(e => {
          const row = document.createElement('div');
          row.className = 'backfill-row unresolved';
          row.textContent = `${e.handle}: ${e.message}`;
          cs.results.append(row);
        });
        showMessage(`${updated} collections updated.`, failed.length ? 'error' : 'success');
        csPlanned = 0;
        return;
      }

      const data = await post({ mode, force: cs.force.checked });
      csPlanned = (data.planned || []).length;
      cs.progress.textContent = `${csPlanned} to update, ${data.skipped} left alone`;

      Object.entries(data.reasons || {}).forEach(([reason, info]) => {
        const row = document.createElement('div');
        row.className = 'backfill-row';
        const left = document.createElement('span');
        left.textContent = `Skipped — ${reason} (${info.count})`;
        const right = document.createElement('code');
        right.textContent = info.handles.join(', ');
        row.append(left, right);
        cs.results.append(row);
      });

      (data.planned || []).forEach(row => {
        const item = document.createElement('div');
        item.className = 'backfill-row resolved';
        const left = document.createElement('span');
        left.textContent = row.title;
        const right = document.createElement('code');
        // Both strings shown in full: the whole point of review is catching a
        // bad set-name split before it reaches 400 live pages.
        right.textContent = `${row.seo_title}  ·  ${row.seo_desc}`;
        item.append(left, right);
        cs.results.append(item);
      });

      cs.apply.disabled = csPlanned === 0;
    } catch (error) {
      cs.progress.textContent = 'Failed';
      showMessage(error.message || 'The collection SEO run could not finish.', 'error');
    } finally {
      cs.dryRun.disabled = false;
    }
  }

  // ---- Collection saving badges -------------------------------------------

  const cd = {
    scan: $('#cd-scan'),
    apply: $('#cd-apply'),
    progress: $('#cd-progress'),
    counts: $('#cd-counts'),
    results: $('#cd-results')
  };

  function cdPost(payload) {
    return api('api/collection-discount.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify(payload)
    });
  }

  async function cdScan() {
    cd.scan.disabled = true;
    cd.apply.disabled = true;
    cd.results.replaceChildren();
    cd.counts.hidden = true;
    cd.progress.textContent = 'Starting catalogue export…';

    try {
      const start = await cdPost({ action: 'start' });
      if (start.started === false) cd.progress.textContent = 'An export was already running — watching it.';

      let done = null;
      while (!done) {
        await new Promise(r => setTimeout(r, 5000));
        const state = await cdPost({ action: 'status' });
        if (state.done) { done = state; break; }
        cd.progress.textContent = `Exporting… ${state.objectCount || 0} records`;
      }

      cd.counts.replaceChildren();
      [['Products', done.products], ['On sale', done.discounted],
        ['Collections', done.collections], ['Earning a badge', done.withBadge]]
        .forEach(([label, value]) => {
          const tile = document.createElement('div');
          tile.className = 'backfill-count';
          const n = document.createElement('strong');
          n.textContent = String(value ?? 0);
          const c = document.createElement('span');
          c.textContent = label;
          tile.append(n, c);
          cd.counts.append(tile);
        });
      cd.counts.hidden = false;

      (done.preview || []).forEach(row => {
        const item = document.createElement('div');
        item.className = 'backfill-row resolved';
        const left = document.createElement('span');
        left.textContent = row.handle;
        const right = document.createElement('code');
        right.textContent = `Save up to ${row.pct}%`;
        item.append(left, right);
        cd.results.append(item);
      });

      cd.progress.textContent = `${done.withBadge} collections would show a badge`;
      cd.apply.disabled = done.collections === 0;
    } catch (error) {
      cd.progress.textContent = 'Scan failed';
      showMessage(error.message || 'The discount scan could not finish.', 'error');
    } finally {
      cd.scan.disabled = false;
    }
  }

  async function cdApply() {
    cd.scan.disabled = true;
    cd.apply.disabled = true;
    let offset = 0, written = 0, failed = [];

    try {
      for (;;) {
        const page = await cdPost({ action: 'apply', offset });
        written += page.written || 0;
        failed = failed.concat(page.errors || []);
        offset = page.offset;
        cd.progress.textContent = `Written ${written} of ${page.total}…`;
        if (page.done) break;
      }
      cd.progress.textContent = `Written to ${written} collections`;
      showMessage(`${written} collections updated.`, failed.length ? 'error' : 'success');
      failed.slice(0, 20).forEach(message => {
        const row = document.createElement('div');
        row.className = 'backfill-row unresolved';
        row.textContent = message;
        cd.results.append(row);
      });
    } catch (error) {
      cd.progress.textContent = 'Write failed';
      showMessage(error.message || 'The badge figures could not be written.', 'error');
    } finally {
      cd.scan.disabled = false;
    }
  }

  cd.scan?.addEventListener('click', cdScan);
  cd.apply?.addEventListener('click', cdApply);

  cs.dryRun?.addEventListener('click', () => csRun('dry-run'));
  cs.apply?.addEventListener('click', () => {
    if (csPlanned && confirm(`Write SEO titles and descriptions to ${csPlanned} collections?`)) csRun('apply');
  });

  // --- staff password hash ------------------------------------------------
  // The command line version of this is tools/hash-password.php. This exists
  // because IONOS shared hosting generally has no SSH, and every other job on
  // this page has both routes for the same reason.
  const hp = {
    password: $('#hp-password'),
    generate: $('#hp-generate'),
    section: $('#hp-result-section'),
    line: $('#hp-line'),
    algo: $('#hp-algo'),
    copy: $('#hp-copy')
  };

  async function hpGenerate() {
    const password = hp.password?.value || '';
    if (password.length < 12) {
      showMessage('Use at least 12 characters. This is the only thing guarding the tool.', 'error');
      hp.password?.focus();
      return;
    }

    hp.generate.disabled = true;
    hp.generate.textContent = 'Hashing…';
    try {
      const data = await api('api/hash-password.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
        body: JSON.stringify({ password })
      });
      hp.line.textContent = data.line || '';
      hp.algo.textContent = data.algo ? `${data.algo} hash` : 'Hash';
      hp.section.hidden = false;
      // Clear the field as soon as it has served its purpose, so the password
      // is not sitting in a form behind whoever walks up to this screen next.
      hp.password.value = '';
      showMessage('Paste the line below into config.php, then sign out and back in with the same password.', 'success');
    } catch (error) {
      showMessage(error.message, 'error');
    } finally {
      hp.generate.disabled = false;
      hp.generate.textContent = 'Generate hash';
    }
  }

  hp.generate?.addEventListener('click', hpGenerate);
  hp.password?.addEventListener('keydown', event => {
    if (event.key === 'Enter') { event.preventDefault(); hpGenerate(); }
  });
  hp.copy?.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(hp.line.textContent || '');
      hp.copy.textContent = 'Copied ✓';
      setTimeout(() => { hp.copy.textContent = 'Copy line'; }, 1500);
    } catch {
      // Clipboard access is refused on plain http and in some locked-down
      // browsers. Select it instead so it can be copied by hand.
      const range = document.createRange();
      range.selectNodeContents(hp.line);
      const selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      showMessage('Could not reach the clipboard. The line is selected, copy it manually.', 'warning');
    }
  });
})();
