/*
 * Lockett Labs scan station: the screens around the scan engine.
 *
 *   camera   live view with the card outlined as it is found, auto capture
 *            when it holds still, torch, camera picker for a document camera
 *   upload   files, drag and drop, paste, or an image address from any site
 *   editor   four corner handles with a magnifier, rotate, colour, a live
 *            preview, quality read-outs, and a tray for flatbed sheets
 *
 * Output is the store's final frame (1:1, card at 94%) as a WebP or JPEG Blob.
 * The page owns uploading it; this file only makes it.
 */
(function (root) {
  'use strict';

  const VERSION = '6.0.0';
  const MAX_SOURCE = 4096;

  function h(tag, attrs, children) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
      else if (k === 'hidden') el.hidden = true;
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const child of [].concat(children || [])) {
      if (child == null || child === false) continue;
      el.append(child.nodeType ? child : document.createTextNode(String(child)));
    }
    return el;
  }

  const ICON = {
    close: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    torch: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 2h8l-1 6H9zM9 8h6l-1 14h-4z"/></svg>',
    turn: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 12a8 8 0 1 1-2.3-5.6M20 4.5v5h-5"/></svg>',
    shutter: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"/></svg>'
  };

  function iconButton(label, icon, onclick, extra) {
    const b = h('button', { type: 'button', class: 'scan-icon' + (extra ? ' ' + extra : ''), 'aria-label': label, title: label, onclick });
    b.innerHTML = icon;
    return b;
  }

  // ---------------------------------------------------------------- worker

  class ScanWorker {
    constructor(url) {
      this.worker = new Worker(url);
      this.next = 1;
      this.pending = new Map();
      this.worker.onmessage = e => {
        const { id } = e.data || {};
        const p = this.pending.get(id);
        if (!p) return;
        this.pending.delete(id);
        if (e.data.ok) p.resolve(e.data); else p.reject(new Error(e.data.error || 'Scan failed.'));
      };
      this.worker.onerror = e => {
        for (const p of this.pending.values()) p.reject(new Error(e.message || 'The scan worker stopped.'));
        this.pending.clear();
      };
    }
    call(message, transfer) {
      const id = this.next++;
      return new Promise((resolve, reject) => {
        this.pending.set(id, { resolve, reject });
        this.worker.postMessage({ ...message, id }, transfer || []);
      });
    }
    get busy() { return this.pending.size > 0; }
  }

  // ---------------------------------------------------------------- pixels

  async function decode(blob) {
    let bitmap = null;
    try {
      bitmap = await createImageBitmap(blob, { imageOrientation: 'from-image' });
    } catch {
      bitmap = await new Promise((resolve, reject) => {
        const url = URL.createObjectURL(blob);
        const img = new Image();
        img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
        img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('That file is not an image this browser can open.')); };
        img.src = url;
      });
    }
    const w0 = bitmap.width || bitmap.naturalWidth, h0 = bitmap.height || bitmap.naturalHeight;
    const scale = Math.min(1, MAX_SOURCE / Math.max(w0, h0));
    const w = Math.round(w0 * scale), hgt = Math.round(h0 * scale);
    const canvas = h('canvas', { width: w, height: hgt });
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(bitmap, 0, 0, w, hgt);
    if (bitmap.close) bitmap.close();
    return { canvas, width: w, height: hgt, pixels: ctx.getImageData(0, 0, w, hgt) };
  }

  function toCanvas(packed) {
    const canvas = h('canvas', { width: packed.width, height: packed.height });
    canvas.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(packed.buffer), packed.width, packed.height), 0, 0);
    return canvas;
  }

  function canvasBlob(canvas) {
    return new Promise(resolve => {
      canvas.toBlob(webp => {
        if (webp && webp.type === 'image/webp') { resolve(webp); return; }
        canvas.toBlob(jpeg => resolve(jpeg), 'image/jpeg', 0.93);
      }, 'image/webp', 0.92);
    });
  }

  function qualityChips(q, sourceCardHeight) {
    const chips = [];
    if (!q) return chips;
    chips.push({ tone: q.sharp === 'sharp' ? 'good' : q.sharp === 'soft' ? 'warn' : 'bad', text: q.sharp === 'sharp' ? 'Sharp' : q.sharp === 'soft' ? 'Slightly soft' : 'Blurred, retake' });
    chips.push({ tone: q.glareLevel === 'none' ? 'good' : q.glareLevel === 'some' ? 'warn' : 'bad', text: q.glareLevel === 'none' ? 'No glare' : q.glareLevel === 'some' ? `Some glare (${q.glare}%)` : `Glare ${q.glare}%, tilt the card` });
    if (q.exposureLevel !== 'good') chips.push({ tone: 'warn', text: q.exposureLevel === 'dark' ? 'Dark, add light' : 'Very bright' });
    if (sourceCardHeight) {
      chips.push(sourceCardHeight >= 1100
        ? { tone: 'good', text: `Full detail (${Math.round(sourceCardHeight)}px card)` }
        : { tone: sourceCardHeight >= 750 ? 'warn' : 'bad', text: `Low detail (${Math.round(sourceCardHeight)}px). Move closer or scan at 600 dpi` });
    }
    return chips;
  }

  function renderChips(container, chips) {
    container.replaceChildren(...chips.map(c => h('span', { class: `scan-chip scan-chip--${c.tone}`, text: c.text })));
  }

  function cardHeightPx(corners) {
    if (!corners) return 0;
    const d = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
    const s = [d(corners[0], corners[1]), d(corners[1], corners[2]), d(corners[2], corners[3]), d(corners[3], corners[0])];
    return Math.max((s[1] + s[3]) / 2, (s[0] + s[2]) / 2);
  }

  // ---------------------------------------------------------------- station

  function create(options) {
    const opts = options || {};
    const worker = new ScanWorker(opts.worker || `assets/ll-scan-worker.js?v=${VERSION}`);
    const notify = opts.notify || (() => {});
    const tray = [];
    let trayListeners = [];
    let source = null;          // { key, canvas, width, height, origin }
    let cameraStream = null;

    // ---------- shared dialog shell
    const dialog = h('dialog', { class: 'scan-dialog', 'aria-label': 'Scan a card' });
    document.body.append(dialog);
    dialog.addEventListener('cancel', event => { event.preventDefault(); closeAll(); });
    dialog.addEventListener('close', () => stopCamera());

    function closeAll() {
      stopCamera();
      if (dialog.open) dialog.close();
      dialog.replaceChildren();
      document.documentElement.classList.remove('scan-open');
    }

    function openDialog(view) {
      dialog.replaceChildren(view);
      if (!dialog.open) dialog.showModal();
      document.documentElement.classList.add('scan-open');
    }

    // ---------- loading a source
    async function loadBlob(blob, origin) {
      if (!blob || !/^image\//.test(blob.type || 'image/')) throw new Error('Choose an image file: JPEG, PNG, WebP or HEIC.');
      if (blob.size > 40 * 1024 * 1024) throw new Error('That image is over 40 MB. Save it smaller and try again.');
      openDialog(busyView('Reading the photo…'));
      const decoded = await decode(blob);
      return loadPixels(decoded, origin);
    }

    async function loadPixels(decoded, origin) {
      const key = `src-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      const copy = new Uint8ClampedArray(decoded.pixels.data);
      await worker.call({ type: 'load', key, image: { width: decoded.width, height: decoded.height, buffer: copy.buffer } }, [copy.buffer]);
      source = { key, canvas: decoded.canvas, width: decoded.width, height: decoded.height, origin };
      const found = await worker.call({ type: 'detect', key, options: { multi: true } });
      const single = await worker.call({ type: 'detect', key, options: {} });
      const cards = found.cards && found.cards.length > 1 ? found.cards : (single.best ? [single.best] : []);
      openEditor(cards);
    }

    function busyView(text) {
      return h('div', { class: 'scan-busy' }, [h('span', { class: 'scan-spinner', 'aria-hidden': 'true' }), h('p', { text })]);
    }

    // ---------- editor
    function openEditor(cards) {
      const state = {
        cards: cards.length ? cards.map(c => ({ corners: c.corners.map(p => p.slice()), score: c.score, method: c.method })) : [{ corners: defaultCorners(), score: 0, method: 'manual' }],
        active: 0,
        turns: null,
        autoColour: source.origin === 'camera',
        trayOthers: true,
        dragging: -1
      };
      const found = cards.length;

      const stageCanvas = h('canvas', { class: 'scan-stage-image' });
      const overlay = h('canvas', { class: 'scan-stage-overlay', 'aria-hidden': 'true' });
      const loupe = h('canvas', { class: 'scan-loupe', width: 168, height: 168, 'aria-hidden': 'true', hidden: true });
      const handles = [0, 1, 2, 3].map(i => h('button', {
        type: 'button', class: 'scan-handle', 'data-corner': String(i),
        'aria-label': ['Top left corner', 'Top right corner', 'Bottom right corner', 'Bottom left corner'][i] + '. Drag, or use the arrow keys.'
      }));
      const stage = h('div', { class: 'scan-stage' }, [stageCanvas, overlay, ...handles, loupe]);
      const preview = h('canvas', { class: 'scan-preview', width: 378, height: 528, 'aria-label': 'Preview of the finished scan' });
      const chips = h('div', { class: 'scan-chips', 'aria-live': 'polite' });
      const note = h('p', { class: 'scan-note' });

      const cardPicker = found > 1 ? h('div', { class: 'scan-cardpick', role: 'tablist', 'aria-label': 'Cards found on this scan' },
        state.cards.map((_, i) => h('button', { type: 'button', role: 'tab', class: 'scan-pill', 'aria-selected': i === 0 ? 'true' : 'false', text: `Card ${i + 1}`, onclick: () => { state.active = i; syncPicker(); layout(); schedulePreview(); } }))) : null;
      const trayToggle = found > 1 ? h('label', { class: 'scan-toggle' }, [
        h('input', { type: 'checkbox', checked: true, onchange: e => { state.trayOthers = e.target.checked; } }),
        h('span', { text: `Put the other ${found - 1} in the tray for the next cards` })
      ]) : null;

      const colourToggle = h('label', { class: 'scan-toggle' }, [
        h('input', { type: 'checkbox', checked: state.autoColour || null, onchange: e => { state.autoColour = e.target.checked; schedulePreview(); } }),
        h('span', { text: 'Even out light and colour' })
      ]);
      const turnBtn = h('button', { type: 'button', class: 'button secondary small', onclick: () => { state.turns = ((state.turns || 0) + 2) % 4; schedulePreview(); } }, 'Turn upside down');
      const turnQuarter = h('button', { type: 'button', class: 'button secondary small', onclick: () => { state.turns = ((state.turns || 0) + 1) % 4; schedulePreview(); } }, 'Rotate 90°');
      const resetBtn = h('button', { type: 'button', class: 'text-button', onclick: () => { state.cards[state.active].corners = (cards[state.active] ? cards[state.active].corners : defaultCorners()).map(p => p.slice()); layout(); schedulePreview(); } }, 'Reset corners');
      const useBtn = h('button', { type: 'button', class: 'button primary', onclick: accept }, 'Use this scan');
      const cancelBtn = h('button', { type: 'button', class: 'text-button', onclick: closeAll }, 'Cancel');
      const retakeBtn = source.origin === 'camera' ? h('button', { type: 'button', class: 'button secondary', onclick: () => openCamera() }, 'Retake') : null;

      const view = h('div', { class: 'scan-editor' }, [
        h('header', { class: 'scan-head' }, [
          h('div', {}, [h('p', { class: 'scan-kicker', text: found > 1 ? `${found} cards found` : (found ? 'Card found' : 'Mark the card') }), h('h2', { class: 'scan-title', text: 'Check the corners' })]),
          iconButton('Close', ICON.close, closeAll)
        ]),
        cardPicker,
        h('div', { class: 'scan-body' }, [
          h('div', { class: 'scan-left' }, [stage, h('p', { class: 'scan-hint', text: found ? 'Each handle should sit on a card corner. Drag to adjust; the magnifier shows the edge.' : 'No edge was found automatically. Drag the four handles onto the card corners.' })]),
          h('div', { class: 'scan-right' }, [
            h('p', { class: 'scan-kicker', text: 'Finished image' }),
            h('div', { class: 'scan-preview-wrap' }, [preview]),
            chips,
            note,
            h('div', { class: 'scan-row' }, [turnBtn, turnQuarter]),
            colourToggle,
            trayToggle,
            resetBtn
          ])
        ]),
        h('footer', { class: 'scan-foot' }, [cancelBtn, retakeBtn, useBtn])
      ]);
      openDialog(view);

      const ctx = stageCanvas.getContext('2d');
      let fit = 1;
      function layout() {
        const maxW = Math.min(stage.parentElement.clientWidth || 600, 760);
        const maxH = Math.min(window.innerHeight * 0.62, 720);
        fit = Math.min(maxW / source.width, maxH / source.height);
        const w = Math.round(source.width * fit), hh = Math.round(source.height * fit);
        for (const c of [stageCanvas, overlay]) { c.width = w; c.height = hh; c.style.width = w + 'px'; c.style.height = hh + 'px'; }
        stage.style.width = w + 'px';
        stage.style.height = hh + 'px';
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(source.canvas, 0, 0, w, hh);
        drawOverlay();
      }
      function drawOverlay() {
        const o = overlay.getContext('2d');
        o.clearRect(0, 0, overlay.width, overlay.height);
        o.fillStyle = 'rgba(22,18,28,0.45)';
        o.fillRect(0, 0, overlay.width, overlay.height);
        state.cards.forEach((card, i) => {
          const q = card.corners.map(p => [p[0] * fit, p[1] * fit]);
          o.save();
          o.globalCompositeOperation = 'destination-out';
          o.beginPath(); q.forEach((p, k) => (k ? o.lineTo(p[0], p[1]) : o.moveTo(p[0], p[1]))); o.closePath(); o.fill();
          o.restore();
          o.lineWidth = i === state.active ? 2.5 : 1.5;
          o.strokeStyle = i === state.active ? '#ff6248' : 'rgba(255,255,255,0.75)';
          o.beginPath(); q.forEach((p, k) => (k ? o.lineTo(p[0], p[1]) : o.moveTo(p[0], p[1]))); o.closePath(); o.stroke();
          if (state.cards.length > 1) {
            const c = q.reduce((a, p) => [a[0] + p[0] / 4, a[1] + p[1] / 4], [0, 0]);
            o.fillStyle = i === state.active ? '#ff6248' : '#16121c';
            o.beginPath(); o.arc(c[0], c[1], 14, 0, Math.PI * 2); o.fill();
            o.fillStyle = '#fff'; o.font = '700 13px Inter, system-ui, sans-serif'; o.textAlign = 'center'; o.textBaseline = 'middle';
            o.fillText(String(i + 1), c[0], c[1] + 0.5);
          }
        });
        const active = state.cards[state.active].corners;
        handles.forEach((hd, i) => { hd.style.left = active[i][0] * fit + 'px'; hd.style.top = active[i][1] * fit + 'px'; });
      }
      function syncPicker() {
        if (!cardPicker) return;
        [...cardPicker.children].forEach((b, i) => b.setAttribute('aria-selected', i === state.active ? 'true' : 'false'));
      }
      function drawLoupe(i) {
        const p = state.cards[state.active].corners[i];
        const lctx = loupe.getContext('2d');
        const zoomSrc = 28;
        lctx.imageSmoothingEnabled = false;
        lctx.clearRect(0, 0, loupe.width, loupe.height);
        lctx.drawImage(source.canvas, p[0] - zoomSrc, p[1] - zoomSrc, zoomSrc * 2, zoomSrc * 2, 0, 0, loupe.width, loupe.height);
        lctx.strokeStyle = '#ff6248'; lctx.lineWidth = 1.5;
        lctx.beginPath(); lctx.moveTo(loupe.width / 2, 0); lctx.lineTo(loupe.width / 2, loupe.height); lctx.moveTo(0, loupe.height / 2); lctx.lineTo(loupe.width, loupe.height / 2); lctx.stroke();
        const sx = p[0] * fit, sy = p[1] * fit;
        loupe.style.left = (sx > stage.clientWidth / 2 ? sx - loupe.width - 24 : sx + 24) + 'px';
        loupe.style.top = Math.max(0, Math.min(stage.clientHeight - loupe.height, sy - loupe.height / 2)) + 'px';
        loupe.hidden = false;
      }
      handles.forEach((hd, i) => {
        hd.addEventListener('pointerdown', e => {
          e.preventDefault();
          hd.setPointerCapture(e.pointerId);
          state.dragging = i;
          hd.classList.add('is-dragging');
          drawLoupe(i);
        });
        hd.addEventListener('pointermove', e => {
          if (state.dragging !== i) return;
          const rect = stage.getBoundingClientRect();
          const x = Math.max(0, Math.min(source.width - 1, (e.clientX - rect.left) / fit));
          const y = Math.max(0, Math.min(source.height - 1, (e.clientY - rect.top) / fit));
          state.cards[state.active].corners[i] = [x, y];
          drawOverlay();
          drawLoupe(i);
          schedulePreview();
        });
        const end = () => { if (state.dragging === i) { state.dragging = -1; hd.classList.remove('is-dragging'); loupe.hidden = true; schedulePreview(true); } };
        hd.addEventListener('pointerup', end);
        hd.addEventListener('pointercancel', end);
        hd.addEventListener('keydown', e => {
          const step = e.shiftKey ? 10 : 1;
          const p = state.cards[state.active].corners[i];
          const moves = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] };
          if (!moves[e.key]) return;
          e.preventDefault();
          p[0] = Math.max(0, Math.min(source.width - 1, p[0] + moves[e.key][0]));
          p[1] = Math.max(0, Math.min(source.height - 1, p[1] + moves[e.key][1]));
          drawOverlay();
          drawLoupe(i);
          schedulePreview();
        });
        hd.addEventListener('blur', () => { if (state.dragging < 0) loupe.hidden = true; });
      });

      let previewTimer = 0, previewSeq = 0;
      function schedulePreview(now) {
        clearTimeout(previewTimer);
        previewTimer = setTimeout(renderPreview, now ? 0 : 90);
      }
      async function renderPreview() {
        const seq = ++previewSeq;
        try {
          const card = state.cards[state.active];
          const res = await worker.call({ type: 'preview', key: source.key, options: { corners: card.corners, quarterTurns: state.turns || 0, autoColour: state.autoColour } });
          if (seq !== previewSeq) return;
          const pctx = preview.getContext('2d');
          pctx.clearRect(0, 0, preview.width, preview.height);
          pctx.drawImage(toCanvas(res.image), 0, 0, preview.width, preview.height);
          const heightPx = cardHeightPx(card.corners);
          renderChips(chips, qualityChips(null, heightPx));
          note.textContent = '';
        } catch (error) {
          note.textContent = error.message;
        }
      }

      async function accept() {
        useBtn.disabled = true;
        useBtn.textContent = 'Finishing…';
        try {
          const active = state.cards[state.active];
          const reference = state.turns == null && opts.getReference ? await opts.getReference().catch(() => null) : null;
          if (reference) {
            const copy = new Uint8ClampedArray(reference.data);
            await worker.call({ type: 'reference', image: { width: reference.width, height: reference.height, buffer: copy.buffer } }, [copy.buffer]);
          }
          const result = await finish(active.corners, state.turns, state.autoColour, !!reference);
          if (state.trayOthers && state.cards.length > 1) {
            const others = state.cards.filter((_, i) => i !== state.active);
            for (const other of others) {
              finish(other.corners, null, state.autoColour, false).then(res => addToTray(res)).catch(() => {});
            }
          }
          closeAll();
          if (opts.onResult) opts.onResult(result);
        } catch (error) {
          useBtn.disabled = false;
          useBtn.textContent = 'Use this scan';
          note.textContent = error.message;
        }
      }

      requestAnimationFrame(() => { layout(); schedulePreview(true); });
      const onResize = () => { if (dialog.open && dialog.contains(view)) layout(); };
      window.addEventListener('resize', onResize, { passive: true });
      dialog.addEventListener('close', () => window.removeEventListener('resize', onResize), { once: true });
    }

    function defaultCorners() {
      const w = source.width, hh = source.height;
      const ch = Math.min(hh * 0.8, (w * 0.8) / (63 / 88));
      const cw = ch * (63 / 88);
      const x0 = (w - cw) / 2, y0 = (hh - ch) / 2;
      return [[x0, y0], [x0 + cw, y0], [x0 + cw, y0 + ch], [x0, y0 + ch]];
    }

    async function finish(corners, turns, autoColour, useReference) {
      const res = await worker.call({
        type: 'process',
        key: source.key,
        options: { corners, quarterTurns: turns == null ? undefined : turns, autoColour, useReference }
      });
      const canvas = toCanvas(res.image);
      const blob = await canvasBlob(canvas);
      return {
        blob,
        url: URL.createObjectURL(blob),
        width: res.image.width,
        height: res.image.height,
        quality: res.quality,
        chips: qualityChips(res.quality, cardHeightPx(corners)),
        turns: res.turns,
        orientation: res.orientation,
        origin: source.origin,
        autoColour
      };
    }

    // ---------- tray
    function addToTray(result) {
      tray.push({ ...result, used: false, addedAt: Date.now() });
      emitTray();
    }
    function emitTray() { for (const fn of trayListeners) fn(tray.slice()); }

    // ---------- camera
    async function openCamera(deviceId) {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        notify('This browser cannot use a camera here. Upload a photo or scan instead.', 'warning');
        return;
      }
      stopCamera();
      const video = h('video', { class: 'scan-video', playsinline: true, muted: true, autoplay: true });
      const overlay = h('canvas', { class: 'scan-video-overlay', 'aria-hidden': 'true' });
      const status = h('p', { class: 'scan-camera-status', 'aria-live': 'polite', text: 'Starting the camera…' });
      const autoToggle = h('input', { type: 'checkbox', checked: true });
      const shutter = iconButton('Take the photo', ICON.shutter, () => capture(), 'scan-shutter');
      const torchBtn = iconButton('Torch', ICON.torch, toggleTorch, 'scan-torch');
      torchBtn.hidden = true;
      const devicePick = h('select', { class: 'scan-device', 'aria-label': 'Camera' });
      devicePick.hidden = true;
      devicePick.addEventListener('change', () => openCamera(devicePick.value));
      const view = h('div', { class: 'scan-camera' }, [
        h('header', { class: 'scan-head scan-head--dark' }, [
          h('div', {}, [h('p', { class: 'scan-kicker', text: 'Camera' }), h('h2', { class: 'scan-title', text: 'Lay the card flat' })]),
          h('div', { class: 'scan-row' }, [devicePick, torchBtn, iconButton('Close', ICON.close, closeAll)])
        ]),
        h('div', { class: 'scan-video-wrap' }, [video, overlay, h('div', { class: 'scan-guide', 'aria-hidden': 'true' })]),
        h('footer', { class: 'scan-camera-foot' }, [
          h('label', { class: 'scan-toggle scan-toggle--dark' }, [autoToggle, h('span', { text: 'Take it when the card is still' })]),
          shutter,
          status
        ])
      ]);
      openDialog(view);

      try {
        cameraStream = await navigator.mediaDevices.getUserMedia({
          audio: false,
          video: deviceId ? { deviceId: { exact: deviceId }, width: { ideal: 3840 }, height: { ideal: 2160 } }
            : { facingMode: { ideal: 'environment' }, width: { ideal: 3840 }, height: { ideal: 2160 } }
        });
      } catch (error) {
        status.textContent = error && error.name === 'NotAllowedError'
          ? 'Camera permission was refused. Allow the camera for this site, or upload a photo instead.'
          : 'No camera could be opened. Upload a photo or a flatbed scan instead.';
        return;
      }
      video.srcObject = cameraStream;
      await video.play().catch(() => {});
      const track = cameraStream.getVideoTracks()[0];
      const caps = track && track.getCapabilities ? track.getCapabilities() : {};
      if (caps.torch) torchBtn.hidden = false;
      try {
        const devices = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === 'videoinput');
        if (devices.length > 1) {
          devicePick.replaceChildren(...devices.map((d, i) => h('option', { value: d.deviceId, text: d.label || `Camera ${i + 1}` })));
          devicePick.value = track.getSettings ? (track.getSettings().deviceId || '') : '';
          devicePick.hidden = false;
        }
      } catch { /* labels need permission; the picker simply stays hidden */ }

      status.textContent = 'Looking for the card…';
      let last = null, steady = 0, capturing = false, running = true;
      const frame = h('canvas');
      const loop = async () => {
        if (!running || !cameraStream) return;
        if (!worker.busy && video.videoWidth) {
          const scale = 640 / Math.max(video.videoWidth, video.videoHeight);
          frame.width = Math.round(video.videoWidth * scale);
          frame.height = Math.round(video.videoHeight * scale);
          const fctx = frame.getContext('2d', { willReadFrequently: true });
          fctx.drawImage(video, 0, 0, frame.width, frame.height);
          const data = fctx.getImageData(0, 0, frame.width, frame.height);
          try {
            const res = await worker.call({ type: 'detect', image: { width: frame.width, height: frame.height, buffer: data.data.buffer }, options: { work: 480, refine: false } }, [data.data.buffer]);
            drawLive(res.best, frame.width, frame.height);
            if (res.best && res.best.method !== 'full-frame' && res.best.score >= 0.7) {
              const moved = last ? Math.max(...res.best.corners.map((p, i) => Math.hypot(p[0] - last[i][0], p[1] - last[i][1]))) / frame.height : 1;
              steady = moved < 0.012 ? steady + 1 : 0;
              last = res.best.corners;
              status.textContent = steady >= 2 ? 'Hold still…' : 'Card found';
              if (autoToggle.checked && steady >= 4 && !capturing) { capturing = true; running = false; capture(); return; }
            } else {
              steady = 0; last = null;
              status.textContent = 'Looking for the card… Use a plain, contrasting surface.';
            }
          } catch { /* a dropped frame is harmless */ }
        }
        setTimeout(loop, 160);
      };
      loop();

      function drawLive(best, fw, fh) {
        const rect = video.getBoundingClientRect();
        overlay.width = rect.width; overlay.height = rect.height;
        const o = overlay.getContext('2d');
        o.clearRect(0, 0, overlay.width, overlay.height);
        if (!best || best.method === 'full-frame') return;
        // object-fit: cover mapping from frame to element.
        const s = Math.max(rect.width / fw, rect.height / fh);
        const ox = (rect.width - fw * s) / 2, oy = (rect.height - fh * s) / 2;
        o.lineWidth = 3; o.strokeStyle = steady >= 2 ? '#ff6248' : 'rgba(255,255,255,0.9)';
        o.beginPath();
        best.corners.forEach((p, k) => { const x = ox + p[0] * s, y = oy + p[1] * s; if (k) o.lineTo(x, y); else o.moveTo(x, y); });
        o.closePath(); o.stroke();
      }

      async function capture() {
        running = false;
        status.textContent = 'Capturing…';
        let blob = null;
        try {
          if (typeof ImageCapture !== 'undefined' && track) {
            const ic = new ImageCapture(track);
            blob = await ic.takePhoto().catch(() => null);
          }
        } catch { blob = null; }
        try {
          if (blob) {
            stopCamera();
            await loadBlob(blob, 'camera');
            return;
          }
          const c = h('canvas', { width: video.videoWidth, height: video.videoHeight });
          const cctx = c.getContext('2d', { willReadFrequently: true });
          cctx.drawImage(video, 0, 0);
          const pixels = cctx.getImageData(0, 0, c.width, c.height);
          stopCamera();
          openDialog(busyView('Reading the photo…'));
          await loadPixels({ canvas: c, width: c.width, height: c.height, pixels }, 'camera');
        } catch (error) {
          notify(error.message, 'error');
          closeAll();
        }
      }

      async function toggleTorch() {
        try {
          const on = !(track.getSettings && track.getSettings().torch);
          await track.applyConstraints({ advanced: [{ torch: on }] });
          torchBtn.classList.toggle('is-on', on);
        } catch { torchBtn.hidden = true; }
      }
    }

    function stopCamera() {
      if (cameraStream) {
        for (const t of cameraStream.getTracks()) t.stop();
        cameraStream = null;
      }
    }

    // ---------- public
    async function handleFiles(files, origin) {
      const file = [...(files || [])].find(f => /^image\//.test(f.type) || /\.(jpe?g|png|webp|heic|heif|tiff?)$/i.test(f.name || ''));
      if (!file) { notify('That was not an image. Drop a JPEG, PNG or WebP.', 'warning'); return; }
      try { await loadBlob(file, origin || 'file'); } catch (error) { closeAll(); notify(error.message, 'error'); }
    }

    function attachDropTarget(el, isEnabled) {
      if (!el) return;
      let depth = 0;
      el.addEventListener('dragenter', e => { if (isEnabled && !isEnabled()) return; if (![...e.dataTransfer.types].some(t => t === 'Files' || t === 'text/uri-list')) return; depth++; el.classList.add('is-drop'); e.preventDefault(); });
      el.addEventListener('dragover', e => { if (el.classList.contains('is-drop')) e.preventDefault(); });
      el.addEventListener('dragleave', () => { depth = Math.max(0, depth - 1); if (!depth) el.classList.remove('is-drop'); });
      el.addEventListener('drop', e => {
        if (!el.classList.contains('is-drop')) return;
        e.preventDefault();
        depth = 0;
        el.classList.remove('is-drop');
        if (e.dataTransfer.files && e.dataTransfer.files.length) { handleFiles(e.dataTransfer.files, 'file'); return; }
        // An image dragged from another tab arrives as its address.
        const uri = (e.dataTransfer.getData('text/uri-list') || e.dataTransfer.getData('text/plain') || '').split('\n').find(l => /^https:\/\//i.test(l.trim()));
        if (uri) importUrl(uri.trim());
      });
    }

    function attachPaste(isEnabled) {
      document.addEventListener('paste', e => {
        if (isEnabled && !isEnabled()) return;
        const tag = e.target && e.target.tagName;
        const items = [...(e.clipboardData ? e.clipboardData.items : [])];
        const image = items.find(i => i.kind === 'file' && /^image\//.test(i.type));
        if (image) { e.preventDefault(); handleFiles([image.getAsFile()], 'paste'); return; }
        if (tag === 'INPUT' || tag === 'TEXTAREA') return;
        const text = e.clipboardData ? e.clipboardData.getData('text/plain') : '';
        if (/^https:\/\/\S+$/i.test((text || '').trim())) { e.preventDefault(); importUrl(text.trim()); }
      });
    }

    async function importUrl(url) {
      if (!opts.fetchUrl) return;
      try {
        openDialog(busyView('Fetching the image…'));
        const blob = await opts.fetchUrl(url);
        await loadBlob(blob, 'url');
      } catch (error) {
        closeAll();
        notify(error.message, 'error');
      }
    }

    function takeFromTray(index) {
      const item = tray[index];
      if (!item) return null;
      item.used = true;
      emitTray();
      return item;
    }

    function clearTray() {
      for (const item of tray) URL.revokeObjectURL(item.url);
      tray.length = 0;
      emitTray();
    }

    return {
      openCamera: () => openCamera(),
      handleFiles,
      attachDropTarget,
      attachPaste,
      importUrl,
      tray: () => tray.slice(),
      takeFromTray,
      clearTray,
      onTray(fn) { trayListeners.push(fn); return () => { trayListeners = trayListeners.filter(f => f !== fn); }; },
      close: closeAll
    };
  }

  root.LLScanStation = { create, decode, VERSION };
})(typeof self !== 'undefined' ? self : this);
