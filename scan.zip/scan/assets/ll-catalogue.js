/*
 * Lockett Labs catalogue grammar.
 *
 * Everything the intake app writes into a product's identity comes from here:
 * the printed card number, the title, the store's set and era tags, the SEO
 * title and description, the image alt text and file name, and the product
 * description. It has no DOM and no network, so tests/catalogue.test.js runs
 * it in Node against the store's own conventions.
 *
 * The rules are taken from the live catalogue (16,825 products, 1 Oct 2026),
 * not from taste. research/derive_maps.py in the overhaul folder rebuilt the
 * set table below from the titles and tags the store already uses.
 *
 * Two rules matter more than the rest:
 *
 *  1. A card number is written exactly as it is printed. Older Pokemon sets
 *     print 25/111; Sword & Shield onward print 025/198. The provider pads
 *     everything to three digits, which is how "Sneasel 025/111" reached the
 *     store. Lorcana prints 35/204. Classic Collection reprints carry their
 *     original set's number (Sneasel 25/111 in 30th Celebration).
 *  2. A set is filed under the store's own tag ("30th ANNIVERSARY
 *     COLLECTION", "Scarlet & Violet (Base)"), never the provider's label
 *     ("ME: 30th Celebration Classic Collection"), because smart collections
 *     key on those exact tags.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LLCatalogue = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // ------------------------------------------------------------------ utils

  function normalize(value) {
    return String(value == null ? '' : value)
      .toLowerCase()
      .normalize('NFKD')
      .replace(/[̀-ͯ]/g, '')
      .replace(/&/g, ' and ')
      .replace(/[^a-z0-9]+/g, '');
  }

  function clean(value) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  }

  function titleCaseWord(word) {
    return word ? word.charAt(0).toUpperCase() + word.slice(1) : word;
  }

  const GAME = {
    pokemon: 'pokemon',
    'pokemon-japan': 'pokemon',
    'magic-the-gathering': 'mtg',
    'disney-lorcana': 'lorcana',
    'one-piece-card-game': 'onepiece',
    'digimon-card-game': 'digimon',
    'yu-gi-oh': 'yugioh',
    'star-wars-unlimited': 'swu'
  };

  /** Short game family for a JustTCG game id, tolerant of older spellings. */
  function family(game) {
    const g = String(game || '').toLowerCase();
    if (GAME[g]) return GAME[g];
    if (/pokemon|pokémon/.test(g)) return 'pokemon';
    if (/magic|mtg/.test(g)) return 'mtg';
    if (/lorcana|disney/.test(g)) return 'lorcana';
    if (/one.?piece/.test(g)) return 'onepiece';
    if (/digimon/.test(g)) return 'digimon';
    if (/yu.?gi.?oh/.test(g)) return 'yugioh';
    return g || 'tcg';
  }

  function isJapanese(card) {
    return String(card && card.game || '') === 'pokemon-japan' || String(card && card.languageCode || '') === 'ja';
  }

  // --------------------------------------------------------- Pokemon sets EN
  //
  // [store tag, title segment, era, JustTCG names..., options]
  // pad: true = printed 025/198, false = printed 25/111, null = mixed family,
  // decide per card. Unset means "by era".

  const PADDED_ERAS = new Set(['Sword & Shield', 'Scarlet & Violet', 'Mega Evolution']);

  const S = (tag, segment, era, aliases, opts) => ({ tag, segment, era, aliases: aliases || [], ...(opts || {}) });

  const POKEMON_SETS_EN = [
    // Base Set era (WotC)
    S('Base Set', 'BASE SET', 'Base Set', ['Base Set']),
    S('Base Set', 'BASE SET SHADOWLESS', 'Base Set', ['Base Set (Shadowless)']),
    S('Jungle', 'JUNGLE', 'Base Set', ['Jungle']),
    S('Fossil', 'FOSSIL', 'Base Set', ['Fossil']),
    S('Base Set 2', 'BASE SET 2', 'Base Set', ['Base Set 2']),
    S('Team Rocket', 'TEAM ROCKET', 'Base Set', ['Team Rocket']),
    S('Gym Heroes', 'GYM HEROES', 'Base Set', ['Gym Heroes']),
    S('Gym Challenge', 'GYM CHALLENGE', 'Base Set', ['Gym Challenge']),
    S('Promos', 'PROMO', 'Base Set', ['WoTC Promo', 'Wizards Black Star Promos'], { promo: 'plain' }),
    // Neo
    S('Neo Genesis', 'NEO GENESIS', 'Neo', ['Neo Genesis']),
    S('Neo Discovery', 'NEO DISCOVERY', 'Neo', ['Neo Discovery']),
    S('Neo Revelation', 'NEO REVELATION', 'Neo', ['Neo Revelation']),
    S('Neo Destiny', 'NEO DESTINY', 'Neo', ['Neo Destiny']),
    S('Legendary Collection', 'LEGENDARY COLLECTION', 'Neo', ['Legendary Collection']),
    S('Southern Islands', 'SOUTHERN ISLANDS', 'Neo', ['Southern Islands']),
    // e-Card
    S('Expedition Base Set', 'EXPEDITION', 'e-Card', ['Expedition', 'Expedition Base Set']),
    S('Aquapolis', 'AQUAPOLIS', 'e-Card', ['Aquapolis']),
    S('Skyridge', 'SKYRIDGE', 'e-Card', ['Skyridge']),
    S('Promos', 'PROMO', 'e-Card', ['Best of Promos', 'Best of Game'], { promo: 'plain' }),
    // EX
    S('EX Ruby & Sapphire', 'EX RUBY & SAPPHIRE', 'EX', ['EX Ruby and Sapphire', 'EX Ruby & Sapphire']),
    S('EX Sandstorm', 'EX SANDSTORM', 'EX', ['EX Sandstorm']),
    S('EX Dragon', 'EX DRAGON', 'EX', ['EX Dragon']),
    S('EX Team Magma vs Team Aqua', 'EX TEAM MAGMA VS TEAM AQUA', 'EX', ['EX Team Magma vs Team Aqua']),
    S('EX Hidden Legends', 'EX HIDDEN LEGENDS', 'EX', ['EX Hidden Legends']),
    S('EX FireRed & LeafGreen', 'EX FIRERED & LEAFGREEN', 'EX', ['EX FireRed & LeafGreen', 'EX FireRed and LeafGreen']),
    S('EX Team Rocket Returns', 'EX TEAM ROCKET RETURNS', 'EX', ['EX Team Rocket Returns']),
    S('EX Deoxys', 'EX DEOXYS', 'EX', ['EX Deoxys']),
    S('EX Emerald', 'EX EMERALD', 'EX', ['EX Emerald']),
    S('EX Unseen Forces', 'EX UNSEEN FORCES', 'EX', ['EX Unseen Forces']),
    S('EX Delta Species', 'EX DELTA SPECIES', 'EX', ['EX Delta Species']),
    S('EX Legend Maker', 'EX LEGEND MAKER', 'EX', ['EX Legend Maker']),
    S('EX Holon Phantoms', 'EX HOLON PHANTOMS', 'EX', ['EX Holon Phantoms']),
    S('EX Crystal Guardians', 'EX CRYSTAL GUARDIANS', 'EX', ['EX Crystal Guardians']),
    S('EX Dragon Frontiers', 'EX DRAGON FRONTIERS', 'EX', ['EX Dragon Frontiers']),
    S('EX Power Keepers', 'EX POWER KEEPERS', 'EX', ['EX Power Keepers']),
    // Diamond & Pearl
    S('Diamond & Pearl (Base)', 'DIAMOND & PEARL BASE', 'Diamond & Pearl', ['Diamond and Pearl', 'Diamond & Pearl']),
    S('Mysterious Treasures', 'MYSTERIOUS TREASURES', 'Diamond & Pearl', ['Mysterious Treasures']),
    S('Secret Wonders', 'SECRET WONDERS', 'Diamond & Pearl', ['Secret Wonders']),
    S('Great Encounters', 'GREAT ENCOUNTERS', 'Diamond & Pearl', ['Great Encounters']),
    S('Majestic Dawn', 'MAJESTIC DAWN', 'Diamond & Pearl', ['Majestic Dawn']),
    S('Legends Awakened', 'LEGENDS AWAKENED', 'Diamond & Pearl', ['Legends Awakened']),
    S('Stormfront', 'STORMFRONT', 'Diamond & Pearl', ['Stormfront']),
    S('Promos', 'PROMO', 'Diamond & Pearl', ['Diamond and Pearl Promos', 'DP Promos'], { promo: 'DP', promoWidth: 2 }),
    // Platinum
    S('Platinum (Base)', 'PLATINUM BASE', 'Platinum', ['Platinum']),
    S('Rising Rivals', 'RISING RIVALS', 'Platinum', ['Rising Rivals']),
    S('Supreme Victors', 'SUPREME VICTORS', 'Platinum', ['Supreme Victors']),
    S('Arceus', 'ARCEUS', 'Platinum', ['Arceus']),
    S('Rumble', 'RUMBLE', 'Platinum', ['Rumble']),
    // HeartGold & SoulSilver
    S('HeartGold & SoulSilver (Base)', 'HEARTGOLD & SOULSILVER BASE', 'HeartGold & SoulSilver', ['HeartGold SoulSilver', 'HeartGold & SoulSilver']),
    S('Unleashed', 'UNLEASHED', 'HeartGold & SoulSilver', ['Unleashed']),
    S('Undaunted', 'UNDAUNTED', 'HeartGold & SoulSilver', ['Undaunted']),
    S('Triumphant', 'TRIUMPHANT', 'HeartGold & SoulSilver', ['Triumphant']),
    S('Call of Legends', 'CALL OF LEGENDS', 'HeartGold & SoulSilver', ['Call of Legends']),
    S('Promos', 'PROMO', 'HeartGold & SoulSilver', ['HGSS Promos'], { promo: 'HGSS', promoWidth: 2 }),
    // Black & White
    S('Black & White (Base)', 'BLACK & WHITE BASE', 'Black & White', ['Black and White', 'Black & White']),
    S('Emerging Powers', 'EMERGING POWERS', 'Black & White', ['Emerging Powers']),
    S('Noble Victories', 'NOBLE VICTORIES', 'Black & White', ['Noble Victories']),
    S('Next Destinies', 'NEXT DESTINIES', 'Black & White', ['Next Destinies']),
    S('Dark Explorers', 'DARK EXPLORERS', 'Black & White', ['Dark Explorers']),
    S('Dragons Exalted', 'DRAGONS EXALTED', 'Black & White', ['Dragons Exalted']),
    S('Dragon Vault', 'DRAGON VAULT', 'Black & White', ['Dragon Vault']),
    S('Boundaries Crossed', 'BOUNDARIES CROSSED', 'Black & White', ['Boundaries Crossed']),
    S('Plasma Storm', 'PLASMA STORM', 'Black & White', ['Plasma Storm']),
    S('Plasma Freeze', 'PLASMA FREEZE', 'Black & White', ['Plasma Freeze']),
    S('Plasma Blast', 'PLASMA BLAST', 'Black & White', ['Plasma Blast']),
    S('Legendary Treasures', 'LEGENDARY TREASURES', 'Black & White', ['Legendary Treasures', 'Legendary Treasures: Radiant Collection']),
    S('Promos', 'PROMO', 'Black & White', ['Black and White Promos', 'BW Promos'], { promo: 'BW', promoWidth: 2 }),
    // XY
    S('XY (Base)', 'XY BASE', 'XY', ['XY Base Set', 'XY']),
    S('Kalos Starter Set', 'KALOS STARTER SET', 'XY', ['Kalos Starter Set']),
    S('Flashfire', 'FLASHFIRE', 'XY', ['Flashfire']),
    S('Furious Fists', 'FURIOUS FISTS', 'XY', ['Furious Fists']),
    S('Phantom Forces', 'PHANTOM FORCES', 'XY', ['Phantom Forces']),
    S('Primal Clash', 'PRIMAL CLASH', 'XY', ['Primal Clash']),
    S('Double Crisis', 'DOUBLE CRISIS', 'XY', ['Double Crisis']),
    S('Roaring Skies', 'ROARING SKIES', 'XY', ['Roaring Skies']),
    S('Ancient Origins', 'ANCIENT ORIGINS', 'XY', ['Ancient Origins']),
    S('BREAKthrough', 'BREAKTHROUGH', 'XY', ['BREAKthrough']),
    S('BREAKpoint', 'BREAKPOINT', 'XY', ['BREAKpoint']),
    S('Generations', 'GENERATIONS', 'XY', ['Generations', 'Generations: Radiant Collection']),
    S('Fates Collide', 'FATES COLLIDE', 'XY', ['Fates Collide']),
    S('Steam Siege', 'STEAM SIEGE', 'XY', ['Steam Siege']),
    S('Evolutions', 'EVOLUTIONS', 'XY', ['Evolutions']),
    S('Promos', 'PROMO', 'XY', ['XY Promos'], { promo: 'XY', promoWidth: 2 }),
    // Sun & Moon
    S('Sun & Moon (Base)', 'SUN & MOON BASE', 'Sun & Moon', ['SM Base Set', 'Sun & Moon', 'Sun and Moon']),
    S('Guardians Rising', 'GUARDIANS RISING', 'Sun & Moon', ['Guardians Rising']),
    S('Burning Shadows', 'BURNING SHADOWS', 'Sun & Moon', ['Burning Shadows']),
    S('Shining Legends', 'SHINING LEGENDS', 'Sun & Moon', ['Shining Legends']),
    S('Crimson Invasion', 'CRIMSON INVASION', 'Sun & Moon', ['Crimson Invasion']),
    S('Ultra Prism', 'ULTRA PRISM', 'Sun & Moon', ['Ultra Prism']),
    S('Forbidden Light', 'FORBIDDEN LIGHT', 'Sun & Moon', ['Forbidden Light']),
    S('Celestial Storm', 'CELESTIAL STORM', 'Sun & Moon', ['Celestial Storm']),
    S('Dragon Majesty', 'DRAGON MAJESTY', 'Sun & Moon', ['Dragon Majesty']),
    S('Lost Thunder', 'LOST THUNDER', 'Sun & Moon', ['Lost Thunder']),
    S('Team Up', 'TEAM UP', 'Sun & Moon', ['Team Up']),
    S('Detective Pikachu', 'DETECTIVE PIKACHU', 'Sun & Moon', ['Detective Pikachu']),
    S('Unbroken Bonds', 'UNBROKEN BONDS', 'Sun & Moon', ['Unbroken Bonds']),
    S('Unified Minds', 'UNIFIED MINDS', 'Sun & Moon', ['Unified Minds']),
    S('Hidden Fates', 'HIDDEN FATES', 'Sun & Moon', ['Hidden Fates', 'Hidden Fates: Shiny Vault']),
    S('Cosmic Eclipse', 'COSMIC ECLIPSE', 'Sun & Moon', ['Cosmic Eclipse']),
    S('Promos', 'PROMO', 'Sun & Moon', ['SM Promos', 'Sun & Moon Promos'], { promo: 'SM', promoWidth: 2 }),
    // Sword & Shield
    S('Sword & Shield (Base)', 'SWORD & SHIELD BASE', 'Sword & Shield', ['Sword & Shield Base Set', 'Sword & Shield']),
    S('Rebel Clash', 'REBEL CLASH', 'Sword & Shield', ['Rebel Clash']),
    S('Darkness Ablaze', 'DARKNESS ABLAZE', 'Sword & Shield', ['Darkness Ablaze']),
    S("Champion's Path", "CHAMPION'S PATH", 'Sword & Shield', ["Champion's Path"]),
    S('Vivid Voltage', 'VIVID VOLTAGE', 'Sword & Shield', ['Vivid Voltage']),
    S('Shining Fates', 'SHINING FATES', 'Sword & Shield', ['Shining Fates', 'Shining Fates: Shiny Vault']),
    S('Battle Styles', 'BATTLE STYLES', 'Sword & Shield', ['Battle Styles']),
    S('Chilling Reign', 'CHILLING REIGN', 'Sword & Shield', ['Chilling Reign']),
    S('Evolving Skies', 'EVOLVING SKIES', 'Sword & Shield', ['Evolving Skies']),
    S('Celebrations', 'CELEBRATIONS', 'Sword & Shield', ['Celebrations'], { totals: [25] }),
    S('Celebrations', 'CELEBRATIONS', 'Sword & Shield', ['Celebrations: Classic Collection', 'Celebrations Classic Collection'], { classic: true }),
    S('Fusion Strike', 'FUSION STRIKE', 'Sword & Shield', ['Fusion Strike']),
    S('Brilliant Stars', 'BRILLIANT STARS', 'Sword & Shield', ['Brilliant Stars', 'Brilliant Stars Trainer Gallery']),
    S('Astral Radiance', 'ASTRAL RADIANCE', 'Sword & Shield', ['Astral Radiance', 'Astral Radiance Trainer Gallery']),
    S('Pokemon Go', 'POKEMON GO!', 'Sword & Shield', ['Pokemon GO', 'Pokemon Go', 'Pokémon GO']),
    S('Lost Origin', 'LOST ORIGIN', 'Sword & Shield', ['Lost Origin', 'Lost Origin Trainer Gallery']),
    S('Silver Tempest', 'SILVER TEMPEST', 'Sword & Shield', ['Silver Tempest', 'Silver Tempest Trainer Gallery']),
    S('Crown Zenith', 'CROWN ZENITH', 'Sword & Shield', ['Crown Zenith', 'Crown Zenith: Galarian Gallery']),
    S('McDonalds 2021', '25TH ANNIVERSARY MCDONALDS 2021', 'Sword & Shield', ["McDonald's 25th Anniversary Promos"], { pad: false }),
    S('McDonalds 2022', 'MCDONALDS 2022', 'Sword & Shield', ["McDonald's Promos 2022"], { pad: false }),
    S('Trick or Trade', 'TRICK OR TRADE 2022', 'Sword & Shield', ['Trick or Trade BOOster Bundle']),
    S('Battle Academy', 'BATTLE ACADEMY', 'Sword & Shield', ['Battle Academy', 'Battle Academy 2022'], { pad: null }),
    S('Promos', 'PROMO', 'Sword & Shield', ['Sword & Shield Promo Cards', 'Sword & Shield Promos', 'SWSH Promos'], { promo: 'SWSH', promoWidth: 3 }),
    // Scarlet & Violet
    S('Scarlet & Violet (Base)', 'SCARLET & VIOLET BASE', 'Scarlet & Violet', ['Scarlet & Violet Base Set', 'Scarlet & Violet']),
    S('Paldea Evolved', 'PALDEA EVOLVED', 'Scarlet & Violet', ['Paldea Evolved']),
    S('Obsidian Flames', 'OBSIDIAN FLAMES', 'Scarlet & Violet', ['Obsidian Flames']),
    S('151', '151', 'Scarlet & Violet', ['Scarlet & Violet 151', 'Pokemon 151', '151']),
    S('Paradox Rift', 'PARADOX RIFT', 'Scarlet & Violet', ['Paradox Rift']),
    S('Paldean Fates', 'PALDEAN FATES', 'Scarlet & Violet', ['Paldean Fates']),
    S('Temporal Forces', 'TEMPORAL FORCES', 'Scarlet & Violet', ['Temporal Forces']),
    S('Twilight Masquerade', 'TWILIGHT MASQUERADE', 'Scarlet & Violet', ['Twilight Masquerade']),
    S('Shrouded Fable', 'SHROUDED FABLE', 'Scarlet & Violet', ['Shrouded Fable']),
    S('Stellar Crown', 'STELLAR CROWN', 'Scarlet & Violet', ['Stellar Crown']),
    S('Surging Sparks', 'SURGING SPARKS', 'Scarlet & Violet', ['Surging Sparks']),
    S('Prismatic Evolutions', 'PRISMATIC EVOLUTIONS', 'Scarlet & Violet', ['Prismatic Evolutions']),
    S('Journey Together', 'JOURNEY TOGETHER', 'Scarlet & Violet', ['Journey Together']),
    S('Destined Rivals', 'DESTINED RIVALS', 'Scarlet & Violet', ['Destined Rivals']),
    S('Black Bolt', 'BLACK BOLT', 'Scarlet & Violet', ['Black Bolt']),
    S('White Flare', 'WHITE FLARE', 'Scarlet & Violet', ['White Flare']),
    S('Black Bolt & White Flare', 'BLACK BOLT & WHITE FLARE', 'Scarlet & Violet', ['Black Bolt & White Flare']),
    S('Scarlet & Violet Energies', 'SCARLET & VIOLET ENERGIES', 'Scarlet & Violet', ['Scarlet & Violet Energies'], { promo: 'SVE', promoWidth: 3 }),
    S('Trick or Trade', 'TRICK OR TRADE 2023', 'Scarlet & Violet', ['Trick or Trade BOOster Bundle 2023']),
    S('Trick or Trade', 'TRICK OR TRADE 2024', 'Scarlet & Violet', ['Trick or Trade BOOster Bundle 2024']),
    S('McDonalds 2023', 'MCDONALDS 2023', 'Scarlet & Violet', ["McDonald's Promos 2023"]),
    S('McDonalds 2024', 'MCDONALDS 2024', 'Scarlet & Violet', ["McDonald's Promos 2024"]),
    S('Promos', 'PROMO', 'Scarlet & Violet', ['Scarlet & Violet Promo Cards', 'Scarlet & Violet Promos', 'SV Promos'], { promo: 'SVP', promoWidth: 3 }),
    // Mega Evolution
    S('Mega Evolution (Base)', 'MEGA EVOLUTION BASE', 'Mega Evolution', ['Mega Evolution']),
    S('Mega Evolution Energies', 'MEGA EVOLUTION ENERGIES', 'Mega Evolution', ['Mega Evolution Energies'], { promo: 'MEE', promoWidth: 3 }),
    S('Phantasmal Flames', 'PHANTASMAL FLAMES', 'Mega Evolution', ['Phantasmal Flames']),
    S('Ascended Heroes', 'ASCENDED HEROES', 'Mega Evolution', ['Ascended Heroes']),
    S('Perfect Order', 'PERFECT ORDER', 'Mega Evolution', ['Perfect Order']),
    S('Chaos Rising', 'CHAOS RISING', 'Mega Evolution', ['Chaos Rising']),
    S('Pitch Black', 'PITCH BLACK', 'Mega Evolution', ['Pitch Black']),
    S('Delta Reign', 'DELTA REIGN', 'Mega Evolution', ['Delta Reign']),
    S('30th ANNIVERSARY COLLECTION', '30TH CELEBRATION', 'Mega Evolution', ['30th Celebration'], { totals: [128] }),
    S('30th ANNIVERSARY COLLECTION', '30TH CELEBRATION', 'Mega Evolution', ['30th Celebration Classic Collection', '30th Celebration: Classic Collection'], { classic: true }),
    S('Promos', 'PROMO', 'Mega Evolution', ['Mega Evolution Promo', 'Mega Evolution Promos', 'ME Promos'], { promo: 'MEP', promoWidth: 3 }),
    // Mixed families: era and padding are decided per card
    S('Pokemon Play!', 'PLAY! PRIZE PACK LEAGUE PROMO', '', ['Prize Pack Series Cards', 'Play! Pokemon Prize Pack'], { promoTag: true }),
    S('Promos', 'LEAGUE PROMO', '', ['League & Championship Cards', 'League and Championship Cards'], { pad: null, promoTag: true }),
    S('Promos', 'ALTERNATE PROMO', '', ['Alternate Art Promos'], { pad: null, promoTag: true }),
    S('Promos', 'JUMBO PROMO', '', ['Jumbo Cards'], { pad: null, promoTag: true }),
    S('Promos', 'PROMO', '', ['Professor Program Promos', 'Nintendo Promos', 'Kids WB Promos', 'Burger King Promos',
      'Countdown Calendar Promos', 'Pikachu World Collection Promos', 'Player Placement Trainer Promos'], { pad: null, promoTag: true })
  ];

  const MCDONALDS_PAD = { 2011: false, 2012: false, 2014: false, 2015: false, 2016: false, 2017: false, 2018: false, 2019: false, 2021: false, 2022: false, 2023: true, 2024: true };

  // ------------------------------------------------------- Pokemon sets JA
  // Store tag first; JustTCG's Japanese titles differ a lot ("Transformation
  // Mask" is the store's "Mask Of Change"), so every alias is listed.

  const J = (tag, era, aliases) => ({ tag, segment: tag.toUpperCase(), era, aliases: [tag, ...(aliases || [])] });

  const POKEMON_SETS_JA = [
    J('Ultra Sun', 'Japanese Sun & Moon'), J('Ultra Moon', 'Japanese Sun & Moon'),
    J('Ultra Shiny GX', 'Japanese Sun & Moon', ['GX Ultra Shiny']),
    J('Tag Bolt', 'Japanese Sun & Moon'), J('Night Unison', 'Japanese Sun & Moon'),
    J('Full Metal Wall', 'Japanese Sun & Moon'), J('Double Blaze', 'Japanese Sun & Moon'),
    J('GG End', 'Japanese Sun & Moon'), J('Sky Legend', 'Japanese Sun & Moon'),
    J('Miracle Twins', 'Japanese Sun & Moon', ['Miracle Twin']),
    J('Remix Bout', 'Japanese Sun & Moon'), J('Dream League', 'Japanese Sun & Moon'),
    J('Alter Genesis', 'Japanese Sun & Moon'),
    J('Tag Team GX All Stars', 'Japanese Sun & Moon', ['TAG TEAM GX: Tag All Stars', 'Tag All Stars']),
    J('Fairy Rise', 'Japanese Sun & Moon'), J('Champion Road', 'Japanese Sun & Moon'),
    J('Dragon Storm', 'Japanese Sun & Moon'),
    J('Great Detective Pikachu', 'Japanese Sun & Moon'),
    J('Shining Legends JP', 'Japanese Sun & Moon', ['Shining Legends']),
    J('JP Sword', 'Japanese Sword & Shield', ['Sword']), J('JP Shield', 'Japanese Sword & Shield', ['Shield']),
    J('VMAX Rising', 'Japanese Sword & Shield'), J('Rebellion Crash', 'Japanese Sword & Shield'),
    J('Explosive Walker', 'Japanese Sword & Shield'), J('Infinity Zone', 'Japanese Sword & Shield'),
    J('Legendary Heartbeat', 'Japanese Sword & Shield'), J('Amazing Volt Tackle', 'Japanese Sword & Shield'),
    J('Shiny Star V', 'Japanese Sword & Shield'),
    J('Single Strike Master', 'Japanese Sword & Shield'), J('Rapid Strike Master', 'Japanese Sword & Shield'),
    J('Peerless Fighters', 'Japanese Sword & Shield'),
    J('Silver Lance', 'Japanese Sword & Shield'), J('Jet Black Spirit', 'Japanese Sword & Shield', ['Jet-Black Spirit']),
    J('Eevee Heroes', 'Japanese Sword & Shield'),
    J('Skyscraping Perfection', 'Japanese Sword & Shield'), J('Blue Sky Stream', 'Japanese Sword & Shield'),
    J('Fusion Arts', 'Japanese Sword & Shield'),
    J('25th ANNIVERSARY COLLECTION', 'Japanese Sword & Shield', ['25th Anniversary Collection']),
    J('VMAX Climax', 'Japanese Sword & Shield'), J('Star Birth', 'Japanese Sword & Shield'),
    J('Battle Region', 'Japanese Sword & Shield'), J('Time Gazer', 'Japanese Sword & Shield'),
    J('Space Juggler', 'Japanese Sword & Shield'), J('Dark Phantasma', 'Japanese Sword & Shield'),
    J('Pokemon GO Enhanced Expansion Pack', 'Japanese Sword & Shield', ['Pokemon GO']),
    J('Lost Abyss', 'Japanese Sword & Shield'), J('Incandescent Arcana', 'Japanese Sword & Shield'),
    J('Paradigm Trigger', 'Japanese Sword & Shield'), J('VStar Universe', 'Japanese Sword & Shield', ['VSTAR Universe']),
    J('Matchless Fighter', 'Japanese Sword & Shield'),
    J('Scarlet ex', 'Japanese Scarlet & Violet'), J('Violet ex', 'Japanese Scarlet & Violet'),
    J('Triple Beat', 'Japanese Scarlet & Violet', ['Triplet Beat']),
    J('Snow Hazard', 'Japanese Scarlet & Violet'), J('Clay Burst', 'Japanese Scarlet & Violet'),
    J('Pokemon 151', 'Japanese Scarlet & Violet', ['Pokemon Card 151', '151']),
    J('Ruler of the Black Flame', 'Japanese Scarlet & Violet'), J('Raging Surf', 'Japanese Scarlet & Violet'),
    J('Ancient Roar', 'Japanese Scarlet & Violet'), J('Future Flash', 'Japanese Scarlet & Violet'),
    J('Shiny Treasure ex', 'Japanese Scarlet & Violet'),
    J('Wild Force', 'Japanese Scarlet & Violet'), J('Cyber Judge', 'Japanese Scarlet & Violet'),
    J('Crimson Haze', 'Japanese Scarlet & Violet'),
    J('Mask Of Change', 'Japanese Scarlet & Violet', ['Transformation Mask', 'Mask of Change']),
    J('Night Wanderer', 'Japanese Scarlet & Violet'),
    J('Stella Miracle', 'Japanese Scarlet & Violet', ['Stellar Miracle']),
    J('Paradise Dragona', 'Japanese Scarlet & Violet'),
    J('Super Electric Breaker', 'Japanese Scarlet & Violet'),
    J('Terastal Festival', 'Japanese Scarlet & Violet', ['Terastal Fest ex', 'Terastal Festival ex']),
    J('Battle Partners', 'Japanese Scarlet & Violet'),
    J('Hot Air Arena', 'Japanese Scarlet & Violet', ['Heat Wave Arena']),
    J('Glory of Team Rocket', 'Japanese Scarlet & Violet', ['The Glory of Team Rocket']),
    J('Black Bolt JP', 'Japanese Scarlet & Violet', ['Black Bolt']),
    J('White Flare JP', 'Japanese Scarlet & Violet', ['White Flare']),
    J('Mega Brave', 'Japanese Mega Evolution'), J('Mega Symphonia', 'Japanese Mega Evolution'),
    J('Inferno X', 'Japanese Mega Evolution'),
    J('MEGA Dream ex', 'Japanese Mega Evolution', ['High Class Pack: MEGA Dream ex', 'MEGA Dream ex']),
    J('Munikis Zero', 'Japanese Mega Evolution', ['Nihil Zero']),
    J('Ninja Spinner', 'Japanese Mega Evolution'), J('Abyss Eye', 'Japanese Mega Evolution'),
    J('Storm Emeralda', 'Japanese Mega Evolution'),
    { tag: 'Japanese Promo', segment: 'PROMO', era: '', aliases: ['SV-P Promotional Cards', 'M-P Promotional Cards', 'Sword & Shield Promos', 'S-P'], promoTag: true }
  ];

  // ------------------------------------------------------- other games

  /** Lorcana keeps its set only in tags; the store's tag spellings win. */
  const LORCANA_TAGS = {
    'the first chapter': 'The First Chapter',
    'rise of the floodborn': 'Rise Of The Floodborn',
    'into the inklands': 'Into the Inklands',
    "ursula's return": "Ursula's Return",
    'shimmering skies': 'Shimmering Skies',
    'azurite sea': 'Azurite Sea',
    "archazia's island": "Archazia's Island",
    'reign of jafar': 'Reign of Jafar',
    fabled: 'Fabled',
    'whispers in the well': 'Whispers in the Well',
    winterspell: 'Winterspell',
    'wilds unknown': 'Wilds Unknown',
    'attack of the vine!': 'Attack of the Vine!',
    'attack of the vine': 'Attack of the Vine!',
    'hyperia city': 'Hyperia City',
    'disney lorcana promo cards': 'Disney Lorcana Promo Cards'
  };

  /** Magic: the title spells out the product line, the tag is the short name. */
  const MTG_SETS = {
    'adventures in the forgotten realms': { segment: 'DUNGEONS & DRAGONS: ADVENTURES IN THE FORGOTTEN REALMS', tag: 'Adventures in the Forgotten Realms' },
    'commander legends: battle for baldur\'s gate': { segment: "DUNGEONS & DRAGONS: BATTLE FOR BALDUR'S GATE", tag: "Battle for Baldur's Gate" },
    'innistrad: crimson vow': { segment: 'INNISTRAD CRIMSON VOW', tag: 'Crimson Vow' },
    'innistrad: midnight hunt': { segment: 'INNISTRAD MIDNIGHT HUNT', tag: 'Midnight Hunt' },
    'kamigawa: neon dynasty': { segment: 'KAMIGAWA NEON DYNASTY', tag: 'Kamigawa Neon Majesty' },
    'double masters 2022': { segment: 'DOUBLE MASTERS 2022', tag: 'Double Masters 2022' },
    'universes beyond: the lord of the rings: tales of middle-earth': { segment: 'THE LORD OF THE RINGS: TALES OF MIDDLE-EARTH', tag: 'The Lord of the Rings: Tales of Middle-Earth' },
    'universes beyond: assassin\'s creed': { segment: "ASSASSIN'S CREED", tag: 'Assassins Creed' },
    'the list reprints': { segment: 'THE LIST', tag: 'The List' }
  };

  // ------------------------------------------------------- set resolution

  /**
   * Strip the provider's set codes: "SWSH09: Brilliant Stars", "SM - Team Up",
   * "XY - Flashfire", "ME05: Pitch Black", "SV: Scarlet & Violet 151",
   * "SV10.5w: White Flare", "S12a: VSTAR Universe".
   */
  function cleanProviderSetName(name) {
    let s = clean(name);
    s = s.replace(/^(?:SM|XY|BW|DP|HGSS)\s+-\s+/i, '');
    s = s.replace(/^[A-Za-z]{1,5}\d{0,3}(?:\.\d+)?[A-Za-z+]{0,3}:\s+/, '');
    return s.trim();
  }

  let indexEn;
  let indexJa;
  function buildIndex(table) {
    const index = new Map();
    for (const entry of table) {
      for (const alias of [...entry.aliases, entry.tag, entry.segment]) {
        const key = normalize(alias);
        if (key && !index.has(key)) index.set(key, entry);
      }
    }
    // Aliases first: a later "tag" key must not displace an explicit alias.
    for (const entry of table) {
      for (const alias of entry.aliases) index.set(normalize(alias), entry);
    }
    return index;
  }

  function lookupPokemonSet(rawName, japanese) {
    const table = japanese ? POKEMON_SETS_JA : POKEMON_SETS_EN;
    const index = japanese ? (indexJa ||= buildIndex(table)) : (indexEn ||= buildIndex(table));
    const raw = clean(rawName);
    const stripped = cleanProviderSetName(raw);
    for (const candidate of [raw, stripped]) {
      const hit = index.get(normalize(candidate));
      if (hit) return hit;
    }
    // "Celebrations: Classic Collection" style subsets of a known set.
    const subset = stripped.replace(/[:\s-]+(Classic Collection|Trainer Gallery|Galarian Gallery|Shiny Vault|Radiant Collection)$/i, '');
    if (subset !== stripped) {
      const hit = index.get(normalize(subset));
      if (hit) return hit;
    }
    return null;
  }

  function eraTagFor(entry, japanese) {
    if (!entry || !entry.era) return '';
    return entry.era;
  }

  /**
   * Resolve where the store files a card's set.
   *
   * @returns {{
   *   game:string, known:boolean, tag:string, segment:string, era:string,
   *   seoName:string, pad:(boolean|null), promo:string, promoWidth:number,
   *   promoTag:boolean, classic:boolean, totals:number[]
   * }}
   */
  function resolveSet(card) {
    const fam = family(card && card.game);
    const rawSet = clean(card && (card.englishSetName || card.setName));
    const providerSet = clean(card && card.setName);
    const releaseDate = clean(card && card.setReleaseDate);
    const japanese = isJapanese(card);
    const base = {
      game: fam, known: false, tag: '', segment: '', era: '', seoName: '', pad: undefined,
      promo: '', promoWidth: 0, promoTag: false, classic: false, totals: [], releaseDate
    };

    if (fam === 'pokemon') {
      const entry = lookupPokemonSet(rawSet, japanese) || (rawSet !== providerSet ? lookupPokemonSet(providerSet, japanese) : null);
      const classic = /classic collection/i.test(rawSet + ' ' + providerSet + ' ' + (card && card.rarity || ''));
      if (entry) {
        return {
          ...base,
          known: true,
          tag: entry.tag,
          segment: entry.segment,
          era: eraTagFor(entry, japanese),
          seoName: seoSetName(entry),
          pad: japanese ? undefined : padFor(entry, rawSet),
          promo: entry.promo || '',
          promoWidth: entry.promoWidth || 0,
          promoTag: !!entry.promoTag || !!entry.promo,
          classic: classic || !!entry.classic,
          totals: entry.totals || []
        };
      }
      const name = cleanProviderSetName(rawSet) || rawSet;
      return { ...base, tag: name, segment: name.toUpperCase(), seoName: name, classic };
    }

    if (fam === 'lorcana') {
      const name = cleanProviderSetName(rawSet) || rawSet;
      const tag = LORCANA_TAGS[name.toLowerCase()] || name;
      return { ...base, known: !!LORCANA_TAGS[name.toLowerCase()], tag, segment: '', seoName: tag };
    }

    if (fam === 'mtg') {
      const hit = MTG_SETS[rawSet.toLowerCase()];
      if (hit) return { ...base, known: true, tag: hit.tag, segment: hit.segment, seoName: rawSet };
      return { ...base, tag: rawSet, segment: rawSet.toUpperCase(), seoName: rawSet };
    }

    const name = cleanProviderSetName(rawSet) || rawSet;
    return { ...base, tag: name, segment: name.toUpperCase(), seoName: name };
  }

  function padFor(entry, rawSet) {
    if (Object.prototype.hasOwnProperty.call(entry, 'pad')) return entry.pad;
    const mcd = rawSet.match(/McDonald'?s.*?(20\d\d)/i);
    if (mcd && Object.prototype.hasOwnProperty.call(MCDONALDS_PAD, mcd[1])) return MCDONALDS_PAD[mcd[1]];
    if (entry.era) return PADDED_ERAS.has(entry.era);
    return null;
  }

  /** The store's own casing for the set in prose (SEO lines, descriptions). */
  function seoSetName(entry) {
    if (!entry) return '';
    if (entry.tag === 'Promos' || entry.promoTag) {
      if (entry.segment === 'PROMO') return entry.era ? `${entry.era} Promo` : 'Promo';
      return entry.segment.toLowerCase().split(' ').map(titleCaseWord).join(' ').replace('Play!', 'Play!');
    }
    if (entry.tag === '30th ANNIVERSARY COLLECTION') return '30th Celebration';
    return entry.tag.replace(/ \(Base\)$/, '');
  }

  // ------------------------------------------------------- card numbers

  const NUMBER_RE = /^([A-Z]*)(\d+)([A-Za-z]?)\s*\/\s*([A-Z]*)(\d+)$/;

  function parseNumber(value) {
    const raw = clean(value).toUpperCase().replace(/[／⁄∕]/g, '/').replace(/\s*\/\s*/g, '/');
    const slash = raw.match(NUMBER_RE);
    if (slash) {
      return { kind: 'slash', prefix: slash[1], local: slash[2], suffix: slash[3].toLowerCase(), denomPrefix: slash[4], denom: slash[5], raw };
    }
    const code = raw.match(/^([A-Z]{1,6})\s*0*(\d{1,4})([A-Z]?)$/);
    if (code) return { kind: 'code', prefix: code[1], local: code[2], suffix: code[3], raw };
    const bare = raw.match(/^0*(\d{1,5})([A-Z]?)$/);
    if (bare) return { kind: 'bare', local: bare[1], suffix: bare[2], raw };
    return { kind: 'other', raw };
  }

  function stripZeros(digits) {
    const s = String(digits).replace(/^0+/, '');
    return s === '' ? '0' : s;
  }

  function pad(digits, width) {
    return stripZeros(digits).padStart(width, '0');
  }

  /** "Dusclops - 019/064 (Cosmos Holo)" carries the number as TCGplayer prints it. */
  function embeddedNumber(name) {
    const m = clean(name).match(/\s[-–]\s([A-Z]*\d+[a-z]?\/[A-Z]*\d+)\b/i);
    return m ? m[1] : '';
  }

  function sameNumber(a, b) {
    const x = parseNumber(a);
    const y = parseNumber(b);
    if (x.kind !== 'slash' || y.kind !== 'slash') return false;
    return x.prefix === y.prefix && stripZeros(x.local) === stripZeros(y.local)
      && x.suffix === y.suffix && stripZeros(x.denom) === stripZeros(y.denom);
  }

  /**
   * The card number exactly as printed on the card.
   *
   * Order of evidence, strongest first:
   *  1. Classic Collection reprints print their original number unpadded.
   *  2. A 30th Celebration or Celebrations card whose total is not the set's
   *     own total is a Classic Collection reprint, whatever the provider says.
   *  3. The set's era: Sword & Shield onward pads to three digits.
   *  4. For mixed promo families, the number embedded in the provider's
   *     product name, which TCGplayer writes as printed.
   *  5. The set's release date when the set is not in the table.
   *  6. The provider's string, untouched.
   */
  function printedNumber(card, set) {
    const fam = family(card && card.game);
    const provider = clean(card && card.cardNumber);
    if (!provider || /^(n\/a|none|null)$/i.test(provider)) return '';
    const info = set || resolveSet(card);
    const parsed = parseNumber(provider);

    if (fam === 'lorcana') {
      if (parsed.kind === 'slash') return `${parsed.prefix}${stripZeros(parsed.local)}${parsed.suffix}/${parsed.denomPrefix}${stripZeros(parsed.denom)}`;
      if (parsed.kind === 'bare') return stripZeros(parsed.local) + (parsed.suffix || '').toLowerCase();
      return provider;
    }

    if (fam === 'mtg') {
      if (parsed.kind === 'slash') return `${pad(parsed.local, 3)}${parsed.suffix}/${stripZeros(parsed.denom)}`;
      // Cards from Magic 2015 to the end of 2022 print "035/331". Scryfall
      // supplies the printed set size; without it the provider number stands.
      const total = Number(card && card.printedTotal);
      const released = clean(card && (card.releasedAt || card.setReleaseDate));
      if (parsed.kind === 'bare' && total > 0 && released >= '2014-07-18' && released < '2023-01-01') {
        return `${pad(parsed.local, 3)}${(parsed.suffix || '').toLowerCase()}/${total}`;
      }
      return provider;
    }

    if (fam !== 'pokemon') return provider.toUpperCase();

    if (isJapanese(card)) {
      if (parsed.kind === 'slash' && !parsed.prefix && !parsed.denomPrefix) {
        return `${pad(parsed.local, 3)}${parsed.suffix}/${pad(parsed.denom, 3)}`;
      }
      return provider;
    }

    // Promo codes: SWSH070, SVP093, MEP011, SM32.
    if (parsed.kind === 'code') {
      return `${parsed.prefix}${info.promoWidth ? pad(parsed.local, info.promoWidth) : stripZeros(parsed.local)}${parsed.suffix}`;
    }
    if (parsed.kind === 'bare') {
      if (info.promo && info.promo !== 'plain') return `${info.promo}${pad(parsed.local, info.promoWidth || 3)}${parsed.suffix}`;
      return info.pad === false ? stripZeros(parsed.local) + parsed.suffix : provider;
    }
    if (parsed.kind !== 'slash') return provider;

    // Lettered sub-sets (TG16/TG30, GG01/GG70, SV49/SV94, RC5/RC32) are kept
    // as the provider writes them; they already follow the print.
    if (parsed.prefix || parsed.denomPrefix) return `${parsed.prefix}${parsed.local}${parsed.suffix}/${parsed.denomPrefix}${parsed.denom}`;

    const unpadded = `${stripZeros(parsed.local)}${parsed.suffix}/${stripZeros(parsed.denom)}`;
    const padded = `${pad(parsed.local, 3)}${parsed.suffix}/${pad(parsed.denom, 3)}`;

    if (info.classic) return unpadded;
    if (info.totals && info.totals.length && !info.totals.includes(Number(stripZeros(parsed.denom)))) return unpadded;

    if (info.pad === true) return padded;
    if (info.pad === false) return unpadded;

    const embedded = embeddedNumber(card && card.name);
    if (embedded && sameNumber(embedded, provider)) {
      const e = parseNumber(embedded);
      return `${e.local}${e.suffix}/${e.denom}`;
    }
    if (info.pad === null) return provider;

    const date = clean(card && card.setReleaseDate);
    if (/^\d{4}-\d{2}-\d{2}/.test(date)) return date >= '2020-02-07' ? padded : unpadded;
    return provider;
  }

  // ------------------------------------------------------- names

  const NAME_TREATMENTS = [
    [/^cosmos\s*holo$/i, 'Cosmos Holo', 'finish'],
    [/^reverse\s*holo(?:foil)?$/i, 'Reverse holo', 'finish'],
    [/^holo(?:foil)?$/i, 'Holo', 'finish'],
    [/^foil$/i, 'Foil', 'finish'],
    [/^(?:poke\s*ball)\s*(?:pattern)?$/i, 'Pokeball Reverse holo', 'finish'],
    [/^(?:master\s*ball)\s*(?:pattern)?$/i, 'Masterball Reverse holo', 'finish'],
    [/^(?:energy\s*symbol)\s*(?:pattern)?$/i, 'Energy Reverse holo', 'finish'],
    [/^team\s*rocket\s*(?:pattern)?$/i, 'Rocket Reverse holo', 'finish'],
    // Specific stamps before the generic one, or "Pokemon Center Stamped"
    // and "Snowflake Stamp" collapse into a plain "Stamped".
    [/^(?:pokemon\s*center|pok[eé]mon\s*center)(?:\s*stamped?)?$/i, 'Pokemon Center Stamped', 'stamp'],
    [/^snowflake(?:\s*stamp(?:ed)?)?$/i, 'Snowflake Stamp', 'stamp'],
    [/^pre-?release(?:\s*stamp(?:ed)?)?$/i, 'Pre-release', 'stamp'],
    [/^staff(?:\s*stamp(?:ed)?)?$/i, 'Staff', 'stamp'],
    [/^(?:.*\s)?stamp(?:ed)?$/i, 'Stamped', 'stamp'],
    [/^1st\s*edition$/i, '1st Edition', 'edition'],
    [/^shadowless$/i, 'Shadowless', 'edition'],
    [/^(?:alternate|alt\.?)\s*art$/i, 'Alternate Art', 'art'],
    [/^extended\s*art$/i, 'Extended Art', 'art'],
    [/^showcase(?:\s*frame)?$/i, 'Showcase', 'art'],
    [/^borderless(?:\s*art)?$/i, 'Borderless', 'art'],
    [/^full\s*art$/i, 'Full Art', 'art'],
    [/^(?:sp|special)$/i, 'SP', 'art'],
    [/^(?:jumbo|oversized)$/i, 'Jumbo', 'size']
  ];

  /**
   * Split a provider name into the card's name and its qualifiers.
   *
   * "Dusclops - 019/064 (Cosmos Holo)" -> Dusclops, number 019/064, Cosmos Holo
   * "Kangaskhan (21)" / "Monkey.D.Luffy (ST31-004) (SP)" -> disambiguators drop
   * "Malamar - 51/131 (League Challenge) [1st Place]" -> event qualifiers kept
   */
  function parseName(rawName) {
    let name = clean(rawName);
    const out = { base: '', embeddedNumber: '', finish: '', stamps: [], edition: '', art: [], size: '', other: [] };
    if (!name) return out;
    const embedded = embeddedNumber(name);
    if (embedded) out.embeddedNumber = embedded;
    const groups = [];
    name = name.replace(/\s*[[(]([^)\]]*)[)\]]/g, (_, inner) => { groups.push(clean(inner)); return ' '; });
    name = name.replace(/\s[-–]\s[A-Z]*\d+[a-z]?\/[A-Z]*\d+\b/i, ' ');
    name = name.replace(/\s[-–]\s(?:SWSH|SVP|SM|XY|BW|MEP|ME|SV)\s?\d+\b/i, ' ');
    name = name.replace(/\s[-–]\s\d{1,3}\s*$/, ' ');
    for (const group of groups) {
      if (!group) continue;
      if (/^#?\d{1,4}[a-z]?$/i.test(group) || /^[A-Z]{1,5}\d{0,3}-\d{2,4}$/i.test(group) || /^\d{4}$/.test(group)) continue;
      let matched = false;
      for (const [re, label, kind] of NAME_TREATMENTS) {
        if (!re.test(group)) continue;
        matched = true;
        if (kind === 'finish') out.finish = label;
        else if (kind === 'stamp') out.stamps.push(label);
        else if (kind === 'edition') out.edition = label;
        else if (kind === 'art') out.art.push(label);
        else if (kind === 'size') out.size = label;
        break;
      }
      if (!matched) out.other.push(group);
    }
    out.base = clean(name).replace(/\s*[-–:]\s*$/, '');
    return out;
  }

  /** "Character - Version" from the provider; the store writes "Character : Version". */
  function splitLorcanaName(name) {
    const n = clean(name);
    const colon = n.match(/^(.+?)\s*:\s+(.+)$/);
    if (colon && !/^\d/.test(colon[2])) return { base: colon[1].trim(), version: colon[2].trim() };
    const dash = n.match(/^(.+?)\s+[-–]\s+(.+)$/);
    if (dash && !/^\d/.test(dash[2])) return { base: dash[1].trim(), version: dash[2].trim() };
    return { base: n, version: '' };
  }

  // ------------------------------------------------------- finishes

  /**
   * The store's finish wording. "Reverse holo" is written lower case 5,164
   * times against 19, so the generator never writes "Reverse Holo".
   */
  const HOUSE_FINISH = {
    '': '', standard: '', normal: '', 'non-foil': '', nonfoil: '',
    holo: 'Holo', holofoil: 'Holo', 'holo rare': 'Holo',
    'reverse holo': 'Reverse holo', 'reverse holofoil': 'Reverse holo', 'reverse foil': 'Reverse holo',
    foil: 'Foil', 'cold foil': 'Foil', 'rainbow foil': 'Foil',
    'pokeball reverse holo': 'Pokeball Reverse holo', 'poke ball reverse holo': 'Pokeball Reverse holo',
    'masterball reverse holo': 'Masterball Reverse holo', 'master ball reverse holo': 'Masterball Reverse holo',
    'energy reverse holo': 'Energy Reverse holo',
    'ball reverse holo': 'Ball Reverse holo',
    'rocket reverse holo': 'Rocket Reverse holo',
    'cosmos holo': 'Cosmos Holo',
    'non-holo': 'Non-Holo Exclusive', 'non-holo exclusive': 'Non-Holo Exclusive',
    'etched foil': 'Etched Foil'
  };

  function houseFinish(finish) {
    const key = clean(finish).toLowerCase();
    if (Object.prototype.hasOwnProperty.call(HOUSE_FINISH, key)) return HOUSE_FINISH[key];
    return clean(finish);
  }

  /** Finish choices offered for a game, house wording, most common first. */
  function finishChoices(game) {
    const fam = family(game);
    if (fam === 'lorcana') return ['Standard', 'Foil'];
    if (fam === 'mtg') return ['Standard', 'Foil', 'Etched Foil'];
    if (fam === 'onepiece' || fam === 'digimon') return ['Standard', 'Foil'];
    if (fam === 'yugioh') return ['Standard'];
    return ['Standard', 'Holo', 'Reverse Holo', 'Pokeball Reverse holo', 'Masterball Reverse holo',
      'Energy Reverse holo', 'Ball Reverse holo', 'Rocket Reverse holo', 'Cosmos Holo', 'Non-Holo Exclusive'];
  }

  /** Map a provider printing onto a finish choice. */
  function finishFromPrinting(printing, game) {
    const fam = family(game);
    const p = clean(printing).toLowerCase();
    if (!p || p === 'normal') return 'Standard';
    if (fam === 'lorcana' || fam === 'mtg') return /etched/.test(p) ? 'Etched Foil' : (/foil|holo/.test(p) ? 'Foil' : 'Standard');
    if (/master\s*ball/.test(p)) return 'Masterball Reverse holo';
    if (/poke\s*ball/.test(p)) return 'Pokeball Reverse holo';
    if (/reverse/.test(p)) return 'Reverse Holo';
    if (/holo|foil/.test(p)) return fam === 'pokemon' ? 'Holo' : 'Foil';
    return 'Standard';
  }

  // ------------------------------------------------------- titles

  /**
   * Build the product title in the store's house format for the card's game.
   *
   * @param {object} card    provider card (game, name, setName, cardNumber, rarity, languageCode, ...)
   * @param {object} options { finish, englishName, englishSetName, set }
   */
  function buildTitle(card, options) {
    const opts = options || {};
    const fam = family(card && card.game);
    const set = opts.set || resolveSet({ ...card, englishSetName: opts.englishSetName || (card && card.englishSetName) });
    const parsed = parseName(opts.englishName || (card && (card.englishName || card.name)));
    const number = printedNumber(card, set);
    const finish = houseFinish(opts.finish || parsed.finish);

    if (fam === 'lorcana') {
      const { base, version } = splitLorcanaName(parsed.base);
      const rarity = lorcanaRarityLabel(card && card.rarity);
      const bracket = rarity || (finish === 'Foil' ? 'Foil' : '');
      const art = parsed.art.length ? ` (${parsed.art.join(') (')})` : '';
      const left = `${base}${art}${bracket ? ` (${bracket})` : ''}${version ? ` : ${version}` : ''}`;
      return join(left, number);
    }

    if (fam === 'mtg') {
      const treatments = [...parsed.art, ...parsed.other.filter(x => !/^\d+$/.test(x))];
      const name = `${parsed.base}${treatments.length ? ` (${treatments.join(') (')})` : ''}${finish === 'Foil' || finish === 'Etched Foil' ? ` (${finish === 'Foil' ? 'FOIL' : 'ETCHED FOIL'})` : ''}`;
      const artCard = /art series/i.test(clean(card && card.setName)) ? ' (Art card)' : '';
      return join(`${name} : ${set.segment}${artCard}`, number);
    }

    if (fam === 'onepiece') {
      const brackets = [...parsed.art, finish].filter(Boolean);
      return join(`${parsed.base} : ${set.segment}${brackets.length ? ` (${brackets.join(') (')})` : ''}`, number);
    }

    if (fam === 'digimon') {
      const rarity = digimonRarityLabel(card && card.rarity);
      const brackets = [...parsed.art.map(a => (a === 'Alternate Art' ? 'Alternate art' : a)), rarity].filter(Boolean);
      return join(`${parsed.base} : ${set.segment}${brackets.length ? ` (${brackets.join(') (')})` : ''}`, number);
    }

    if (fam === 'yugioh') {
      const rarity = clean(card && card.rarity);
      const brackets = [/super|ultra|secret|starlight|ghost|collector/i.test(rarity) ? rarity : '', finish].filter(Boolean);
      return join(`${parsed.base} : ${set.segment}${brackets.length ? ` (${brackets.join(') (')})` : ''}`, number);
    }

    // Pokemon (English and Japanese).
    const segment = pokemonSegment(card, set, parsed);
    const brackets = [];
    if (parsed.edition) brackets.push(parsed.edition);
    for (const stamp of parsed.stamps) brackets.push(stamp);
    // Event qualifiers the segment already says are dropped; anything else
    // ("1st Place", "Cosmos Holo") distinguishes a different product.
    for (const other of parsed.other) {
      if (/^league\b|championship|prize pack/i.test(other) && /LEAGUE|PRIZE/.test(segment)) continue;
      if (/^(?:jumbo|oversized)$/i.test(other) && /JUMBO/.test(segment)) continue;
      brackets.push(other);
    }
    const showFinish = finish && !(set.classic && (finish === 'Holo' || finish === ''));
    if (showFinish) brackets.push(finish);
    const left = `${parsed.base} : ${segment}${brackets.length ? ` (${brackets.join(') (')})` : ''}`;
    return join(left, number);
  }

  function pokemonSegment(card, set, parsed) {
    let segment = set.segment || '';
    const stamped = parsed.stamps.some(s => /stamp/i.test(s));
    const prerelease = parsed.stamps.includes('Pre-release');
    if (parsed.size === 'Jumbo' && segment === 'PROMO') segment = 'JUMBO PROMO';
    if (prerelease && set.promoTag && segment === 'PROMO') {
      parsed.stamps.splice(parsed.stamps.indexOf('Pre-release'), 1);
      segment = 'PROMO PRE-RELEASE';
    }
    if (stamped && !set.promoTag && /league|championship|prize/i.test(parsed.other.join(' '))) segment = 'LEAGUE PROMO';
    return segment;
  }

  function lorcanaRarityLabel(rarity) {
    const r = clean(rarity).toLowerCase();
    if (r === 'epic') return 'Epic Rare';
    if (r === 'enchanted') return 'Enchanted';
    if (r === 'iconic') return 'Iconic';
    return '';
  }

  function digimonRarityLabel(rarity) {
    const r = clean(rarity).toUpperCase();
    if (['R', 'RARE'].includes(r)) return 'R';
    if (['SR', 'SUPER RARE'].includes(r)) return 'SR';
    if (['SEC', 'SECRET RARE', 'SECRET'].includes(r)) return 'SEC';
    return '';
  }

  function join(left, number) {
    return `${clean(left)}${number ? ` - ${number}` : ''}`.replace(/\s+/g, ' ').trim().slice(0, 255);
  }

  // ------------------------------------------------------- sealed

  const SEALED_WORDS = /\b(booster|box|bundle|blister|tin|pack|deck|collection|elite trainer|etb|display|case|kit|portfolio|binder|sleeves?|starter|trove|gift set|premium|build\s*&\s*battle|bundle|tech sticker|poster|figure|sealed)\b/i;

  /** A provider row is sealed when it has no collector number and reads like a product. */
  function isSealed(card) {
    const number = clean(card && card.cardNumber);
    const noNumber = !number || /^(n\/a|none|null)$/i.test(number);
    return noNumber && SEALED_WORDS.test(clean(card && card.name));
  }

  const GAME_PREFIX = { pokemon: 'Pokemon', lorcana: 'Disney Lorcana', mtg: 'Magic the Gathering', onepiece: 'One Piece', digimon: 'Digimon', yugioh: 'Yu-Gi-Oh!' };

  /**
   * "30th Celebration Figure Collection [Mewtwo]" in "ME: 30th Celebration"
   * becomes "Pokemon : 30th Celebration - Figure Collection - Mewtwo".
   * Single packs get "(x1)", which the store uses on every loose booster.
   */
  function sealedParts(card, options) {
    const opts = options || {};
    const fam = family(card && card.game);
    const set = opts.set || resolveSet(card);
    const setName = fam === 'pokemon' ? (set.seoName || cleanProviderSetName(card && card.setName)) : (cleanProviderSetName(card && card.setName) || set.seoName);
    let product = clean(opts.englishName || (card && card.name));
    const variants = [];
    product = product.replace(/\s*\[([^\]]+)\]/g, (_, v) => { variants.push(clean(v)); return ''; });
    const setWords = [setName, cleanProviderSetName(card && card.setName)].filter(Boolean);
    for (const words of setWords) {
      const re = new RegExp('^' + words.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*[:-]?\\s*', 'i');
      product = product.replace(re, '');
    }
    product = product.replace(/^(pokemon|pok[eé]mon|disney lorcana|magic the gathering|mtg)\s*[:-]?\s*/i, '');
    product = clean(product) || 'Sealed Product';
    if (/^(sleeved\s+)?booster pack$/i.test(product)) product = `${product} (x1)`;
    if (fam === 'lorcana' && /^booster box$/i.test(product)) product = 'Booster Box (24 Packs)';
    return { fam, setName, product, variants };
  }

  function buildSealedTitle(card, options) {
    const { fam, setName, product, variants } = sealedParts(card, options);
    const prefix = GAME_PREFIX[fam] || clean(card && card.gameName) || 'TCG';
    const head = isJapanese(card) && fam === 'pokemon' ? `${setName} : Japanese ${product}` : `${prefix} : ${setName} - ${product}`;
    return clean([head, ...variants].join(' - ')).slice(0, 255);
  }

  /** Just the product, without the game or set: "Elite Trainer Box", "Figure Collection Mewtwo". */
  function sealedProduct(card, options) {
    const { product, variants } = sealedParts(card, options);
    return clean([product.replace(/\s*\(x1\)$/i, ''), ...variants].join(' '));
  }

  /** The same product in prose, with no title punctuation: for SEO and alt text. */
  function sealedPhrase(card, options) {
    const { fam, setName, product, variants } = sealedParts(card, options);
    const words = [isJapanese(card) && fam === 'pokemon' ? 'Japanese' : '', setName, product.replace(/\s*\(x1\)$/i, ''), ...variants];
    return clean(words.filter(Boolean).join(' '));
  }

  // ------------------------------------------------------- tags

  const SINGLES_TAG = 'Single Cards';
  const SEALED_TAG = 'Sealed Product';
  const GAME_TAG = { lorcana: 'Disney Lorcana', mtg: 'Magic the Gathering', onepiece: 'One Piece Card Game', digimon: 'Digimon Card Game', yugioh: 'yu-gi-oh' };

  /**
   * Store tags for a card, from that card alone. Smart collections are keyed
   * on exactly these spellings.
   */
  function buildTags(card, options) {
    const opts = options || {};
    const fam = family(card && card.game);
    const set = opts.set || resolveSet(card);
    const sealed = !!opts.sealed;
    const tags = [sealed ? SEALED_TAG : SINGLES_TAG];
    if (fam === 'pokemon') {
      if (set.promoTag) tags.push('Promos');
      if (set.tag && set.tag !== 'Promos') tags.push(set.tag);
      if (set.era) tags.push(set.era);
      if (isJapanese(card)) tags.push('Japanese');
      if (!set.era && set.promoTag && opts.promoEra) tags.push(opts.promoEra);
    } else if (fam === 'onepiece') {
      tags.push(set.tag, GAME_TAG.onepiece);
      const code = onePieceCode(card);
      if (code) tags.push(code);
      tags.push(isJapanese(card) ? 'Japanese' : 'English');
    } else {
      if (set.tag) tags.push(set.tag);
      if (GAME_TAG[fam]) tags.push(GAME_TAG[fam]);
      if (isJapanese(card)) tags.push('Japanese');
    }
    if (!sealed && /foil/i.test(clean(opts.finish)) && fam !== 'pokemon') tags.push('Foil');
    if (!sealed && fam === 'lorcana' && lorcanaRarityLabel(card && card.rarity)) tags.push('Foil');
    if (sealed && opts.preOrder) tags.push('Pre-Order');
    return [...new Set(tags.map(clean).filter(Boolean))];
  }

  function onePieceCode(card) {
    const number = clean(card && card.cardNumber).toUpperCase();
    const m = number.match(/^([A-Z]{1,4}\d{1,3})-/);
    return m ? m[1] : clean(card && card.setCode).toUpperCase();
  }

  // ------------------------------------------------------- SEO

  const SEO_TITLE_MAX = 70;
  const SEO_DESCRIPTION_MAX = 160;
  const GAME_NOUN = { pokemon: 'Pokémon', lorcana: 'Disney Lorcana', mtg: 'Magic: The Gathering', onepiece: 'One Piece', digimon: 'Digimon', yugioh: 'Yu-Gi-Oh!' };

  function gameNoun(card) {
    const fam = family(card && card.game);
    if (fam === 'pokemon' && isJapanese(card)) return 'Japanese Pokémon';
    return GAME_NOUN[fam] || clean(card && card.gameName) || 'trading';
  }

  function displayName(card, options) {
    const opts = options || {};
    const parsed = parseName(opts.englishName || (card && (card.englishName || card.name)));
    if (family(card && card.game) === 'lorcana') {
      const { base, version } = splitLorcanaName(parsed.base);
      return version ? `${base} - ${version}` : base;
    }
    return parsed.base;
  }

  /**
   * "Sneasel 25/111 30th Celebration Holo | £9.95 In Stock UK". Google cuts
   * around 70 characters, so trailing detail goes first (finish, set, number)
   * rather than a word being cut in half.
   */
  function seoTitle(card, options) {
    const opts = options || {};
    const set = opts.set || resolveSet(card);
    const price = Number(opts.price);
    const suffix = ` | ${Number.isFinite(price) && price > 0 ? `£${price.toFixed(2)} ` : ''}In Stock UK`;
    const name = displayName(card, opts);
    if (opts.sealed) {
      const phrase = sealedPhrase(card, { ...opts, set });
      const { setName } = sealedParts(card, { ...opts, set });
      const short = phrase.startsWith(setName + ' ') ? phrase.slice(setName.length + 1) : phrase;
      for (const candidate of [phrase, short]) {
        if ((candidate + suffix).length <= SEO_TITLE_MAX) return candidate + suffix;
      }
      return (phrase.slice(0, SEO_TITLE_MAX - suffix.length).replace(/\s+\S*$/, '') + suffix).trim();
    }
    const finish = houseFinish(opts.finish);
    const parts = [printedNumber(card, set), set.seoName, finish && !(set.classic && finish === 'Holo') ? finish.replace('Reverse holo', 'Reverse Holo') : ''];
    for (let keep = parts.length; keep >= 0; keep -= 1) {
      const candidate = `${[name, ...parts.slice(0, keep)].filter(Boolean).join(' ')}${suffix}`;
      if (candidate.length <= SEO_TITLE_MAX) return candidate;
    }
    return `${name}${suffix}`.slice(0, SEO_TITLE_MAX).trim();
  }

  function seoDescription(card, options) {
    const opts = options || {};
    const set = opts.set || resolveSet(card);
    const name = displayName(card, opts);
    const noun = gameNoun(card);
    if (opts.sealed) {
      const product = sealedPhrase(card, { ...opts, set });
      const variants = [
        `Buy the ${product}, factory-sealed ${noun} product. Genuine stock, checked on arrival, securely packed and posted fast across the UK.`,
        `Buy the ${product}, factory-sealed ${noun} product. Genuine stock, securely packed and posted fast across the UK.`,
        `Buy the ${product}. Factory-sealed ${noun} stock, posted fast across the UK.`
      ];
      return fit(variants, SEO_DESCRIPTION_MAX);
    }
    const number = printedNumber(card, set);
    const finish = houseFinish(opts.finish);
    const finishWord = finish && !(set.classic && finish === 'Holo') ? ` ${finish.replace('Reverse holo', 'Reverse Holo')}` : '';
    const subset = set.classic ? ' Classic Collection' : '';
    const variants = [
      `Buy ${name}${finishWord}${number ? ` (${number})` : ''} from ${set.seoName}${subset}, a single ${noun} card with its condition checked by hand. Securely packed, fast UK delivery.`,
      `Buy ${name}${finishWord}${number ? ` (${number})` : ''} from ${set.seoName}${subset}, a single ${noun} card. Checked by hand, securely packed, fast UK delivery.`,
      `Buy ${name}${finishWord}${number ? ` (${number})` : ''}, a single ${noun} card. Securely packed, fast UK delivery.`,
      `Buy ${name}, a single ${noun} card. Securely packed, fast UK delivery.`
    ];
    return fit(variants, SEO_DESCRIPTION_MAX);
  }

  function fit(variants, max) {
    for (const v of variants) if (clean(v).length <= max) return clean(v);
    return clean(variants[variants.length - 1]).slice(0, max).replace(/\s+\S*$/, '').trim();
  }

  /** Image alt text: what the picture is, in words a search engine can use. */
  function imageAlt(card, options) {
    const opts = options || {};
    const set = opts.set || resolveSet(card);
    if (opts.sealed) return clean(`${sealedPhrase(card, { ...opts, set })}, factory-sealed ${gameNoun(card)} product`);
    const finish = houseFinish(opts.finish);
    const bits = [displayName(card, opts), printedNumber(card, set), set.seoName + (set.classic ? ' Classic Collection' : ''), finish && !(set.classic && finish === 'Holo') ? finish.toLowerCase() : ''];
    const what = opts.scan ? 'card, scanned front' : 'card';
    return clean(`${bits.filter(Boolean).join(' ')} ${gameNoun(card)} ${what}`);
  }

  /** SEO file name for an uploaded image: sneasel-25-111-30th-celebration-holo.jpg */
  function imageFilename(card, options) {
    const opts = options || {};
    const set = opts.set || resolveSet(card);
    const ext = opts.ext || 'jpg';
    const finish = houseFinish(opts.finish);
    const parts = opts.sealed
      ? [sealedPhrase(card, { ...opts, set }), 'lockett labs']
      :[displayName(card, opts), printedNumber(card, set).replace('/', '-'), set.seoName, set.classic ? 'classic collection' : '', finish && !(set.classic && finish === 'Holo') ? finish : '', 'lockett labs'];
    const slug = parts.filter(Boolean).join(' ')
      .toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '')
      .replace(/&/g, ' and ').replace(/['’]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')
      .slice(0, 90).replace(/-+$/, '');
    return `${slug || 'card'}.${ext}`;
  }

  // ------------------------------------------------------- description

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function formatDate(iso) {
    const m = clean(iso).match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (!m) return '';
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return `${Number(m[3])} ${months[Number(m[2]) - 1]} ${m[1]}`;
  }

  /**
   * Product description HTML. Every line is a fact from the catalogue or the
   * card database, never invented, so a field that is not known is left out
   * rather than guessed. Links to the set and era collections give each card
   * page a path back into the catalogue.
   *
   * @param {object} card
   * @param {object} options { finish, details, links:{set:{url,title}, era:{url,title}}, sealed, title, condition }
   */
  function descriptionHtml(card, options) {
    const opts = options || {};
    const set = opts.set || resolveSet(card);
    const d = opts.details || {};
    const name = displayName(card, opts);
    const noun = gameNoun(card);
    const finish = houseFinish(opts.finish);
    const parts = [];

    if (opts.sealed) {
      const product = sealedPhrase(card, { ...opts, set });
      const namesSet = set.seoName && product.toLowerCase().includes(set.seoName.toLowerCase());
      parts.push(`<p>The <strong>${escapeHtml(product)}</strong> is factory-sealed ${escapeHtml(noun)} product${set.seoName && !namesSet ? ` from <strong>${escapeHtml(set.seoName)}</strong>` : ''}${set.releaseDate ? `, released ${escapeHtml(formatDate(set.releaseDate))}` : ''}.</p>`);
      if (d.contents) parts.push(`<p>${escapeHtml(d.contents)}</p>`);
      parts.push('<ul>');
      parts.push(`<li><strong>Game:</strong> ${escapeHtml(noun)}</li>`);
      if (set.seoName) parts.push(`<li><strong>Set:</strong> ${escapeHtml(set.seoName)}</li>`);
      if (set.releaseDate) parts.push(`<li><strong>Released:</strong> ${escapeHtml(formatDate(set.releaseDate))}</li>`);
      parts.push('<li><strong>Condition:</strong> New, factory sealed</li>');
      parts.push('</ul>');
      parts.push('<p>Every sealed product is checked on arrival and packed with corner protection so it reaches you as it left the factory.</p>');
    } else {
      const number = printedNumber(card, set);
      const lead = [`<strong>${escapeHtml(name)}</strong>`];
      if (number) lead.push(` (${escapeHtml(number)})`);
      const finishWords = finish && !(set.classic && finish === 'Holo') ? finish.toLowerCase() : '';
      const nextWord = finishWords || noun;
      const article = /^[aeiou]/i.test(nextWord) && !/^one\b/i.test(nextWord) ? 'an' : 'a';
      parts.push(`<p>${lead.join('')} is ${article} ${finishWords ? `${escapeHtml(finishWords)} ` : ''}${escapeHtml(noun)} card from <strong>${escapeHtml(set.seoName)}${set.classic ? ' Classic Collection' : ''}</strong>${set.releaseDate ? `, released ${escapeHtml(formatDate(set.releaseDate))}` : ''}.${set.classic && d.originalSet ? ` It reprints the card from ${escapeHtml(d.originalSet)} with its original number.` : ''}</p>`);

      const facts = [];
      facts.push(['Game', noun]);
      facts.push(['Set', `${set.seoName}${set.classic ? ' Classic Collection' : ''}`]);
      if (number) facts.push(['Card number', number]);
      if (d.rarity || (card && card.rarity && !/^none$/i.test(card.rarity))) facts.push(['Rarity', d.rarity || card.rarity]);
      if (finish) facts.push(['Finish', finish]);
      if (d.category) facts.push(['Card type', d.category]);
      if (d.stage) facts.push(['Stage', d.stage]);
      if (d.hp) facts.push(['HP', String(d.hp)]);
      if (d.types && d.types.length) facts.push(['Type', d.types.join(', ')]);
      if (d.typeLine) facts.push(['Type line', d.typeLine]);
      if (d.cost != null && d.cost !== '') facts.push(['Cost', String(d.cost)]);
      if (d.ink) facts.push(['Ink', d.ink]);
      if (d.illustrator) facts.push(['Illustrator', d.illustrator]);
      if (d.regulationMark) facts.push(['Regulation mark', d.regulationMark]);
      if (isJapanese(card)) facts.push(['Language', 'Japanese']);
      const held = (opts.conditions || []).filter(Boolean);
      facts.push(['Condition', held.length ? `${held.join(', ')}, each copy checked by hand` : 'Checked by hand']);
      parts.push('<ul>' + facts.filter(([, v]) => clean(v)).map(([k, v]) => `<li><strong>${escapeHtml(k)}:</strong> ${escapeHtml(v)}</li>`).join('') + '</ul>');

      const text = [];
      for (const ability of d.abilities || []) {
        if (!ability || !ability.name) continue;
        text.push(`<li><strong>${escapeHtml(ability.type || 'Ability')}: ${escapeHtml(ability.name)}</strong>${ability.effect ? `. ${escapeHtml(stripTags(ability.effect))}` : ''}</li>`);
      }
      for (const attack of d.attacks || []) {
        if (!attack || !attack.name) continue;
        const cost = attack.cost && attack.cost.length ? ` (${attack.cost.join(', ')})` : '';
        const dmg = attack.damage ? ` ${escapeHtml(String(attack.damage))}` : '';
        text.push(`<li><strong>${escapeHtml(attack.name)}</strong>${escapeHtml(cost)}${dmg}${attack.effect ? `. ${escapeHtml(stripTags(attack.effect))}` : ''}</li>`);
      }
      if (text.length) parts.push(`<h3>Card text</h3><ul>${text.join('')}</ul>`);
      if (d.rulesText) parts.push(`<h3>Card text</h3><p>${escapeHtml(stripTags(d.rulesText)).replace(/\n/g, '<br>')}</p>`);
      if (d.flavor) parts.push(`<p><em>${escapeHtml(stripTags(d.flavor))}</em></p>`);
      parts.push('<p>Every single is checked by hand before it is listed, then sleeved, top-loaded and posted in a rigid mailer.</p>');
    }

    const links = opts.links || {};
    const linkBits = [];
    if (links.set && links.set.url) linkBits.push(`<a href="${escapeHtml(links.set.url)}">${escapeHtml(links.set.title || `Shop ${set.seoName}`)}</a>`);
    if (links.era && links.era.url && (!links.set || links.era.url !== links.set.url)) linkBits.push(`<a href="${escapeHtml(links.era.url)}">${escapeHtml(links.era.title || 'Shop the era')}</a>`);
    if (linkBits.length) parts.push(`<p>More from this range: ${linkBits.join(' · ')}</p>`);
    return parts.join('\n');
  }

  function stripTags(value) {
    return String(value == null ? '' : value).replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
  }

  // ------------------------------------------------------- plan

  /**
   * One call for everything the editor fills: title, tags, set, SEO and
   * image naming. Derived from this card only, so nothing from the previous
   * card can leak into the next listing.
   */
  function plan(card, options) {
    const opts = options || {};
    const sealed = opts.sealed != null ? !!opts.sealed : isSealed(card);
    const set = resolveSet({ ...card, englishSetName: opts.englishSetName || (card && card.englishSetName), setReleaseDate: opts.releaseDate || (card && card.setReleaseDate) });
    const common = { ...opts, set, sealed };
    const title = sealed ? buildSealedTitle(card, common) : buildTitle(card, common);
    return {
      sealed,
      set,
      number: sealed ? '' : printedNumber({ ...card, setReleaseDate: set.releaseDate }, set),
      title,
      tags: buildTags(card, common),
      seoTitle: seoTitle(card, { ...common, title }),
      seoDescription: seoDescription(card, { ...common, title }),
      imageAlt: imageAlt(card, { ...common, title }),
      imageFilename: imageFilename(card, { ...common, title }),
      displayName: sealed ? sealedPhrase(card, common) : displayName(card, opts)
    };
  }

  return {
    normalize,
    family,
    isJapanese,
    cleanProviderSetName,
    resolveSet,
    parseNumber,
    printedNumber,
    parseName,
    splitLorcanaName,
    houseFinish,
    finishChoices,
    finishFromPrinting,
    buildTitle,
    isSealed,
    buildSealedTitle,
    sealedPhrase,
    sealedProduct,
    buildTags,
    seoTitle,
    seoDescription,
    imageAlt,
    imageFilename,
    descriptionHtml,
    displayName,
    gameNoun,
    plan,
    SEO_TITLE_MAX,
    SEO_DESCRIPTION_MAX,
    _tables: { POKEMON_SETS_EN, POKEMON_SETS_JA, LORCANA_TAGS, MTG_SETS }
  };
});
