(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const csrf = $('meta[name="csrf-token"]')?.content || '';
  const C = window.LLCatalogue;
  const PREFS_KEY = 'll-intake-prefs-v1';
  const SHOPIFY_META_CACHE_KEY = 'll-shopify-meta-v7';
  const STORE_ORIGIN = 'https://lockett-labs.com';
  const SHOPIFY_META_CLIENT_TTL_MS = 45 * 60 * 1000;
  const gameNames = {
    pokemon: 'Pokémon',
    'pokemon-japan': 'Pokémon Japan',
    'one-piece-card-game': 'One Piece Card Game',
    'digimon-card-game': 'Digimon Card Game',
    'magic-the-gathering': 'Magic: The Gathering',
    'disney-lorcana': 'Disney Lorcana'
  };
  const categoryKeyAliases = {
    'color-pattern': 'colorPattern',
    'toy-game-material': 'toyGameMaterial',
    'card-attributes': 'cardAttributes',
    condition: 'condition',
    grading: 'grading',
    'product-use': 'productUse',
    rarity: 'rarity',
    'age-group': 'ageGroup',
    theme: 'theme',
    'trading-card-packaging': 'tradingCardPackaging'
  };
  const vendorDefaults = {
    pokemon: 'Pokémon',
    'pokemon-japan': 'Pokémon',
    'one-piece-card-game': 'Bandai',
    'digimon-card-game': 'Bandai',
    'magic-the-gathering': 'Wizards of the Coast',
    'disney-lorcana': 'Ravensburger Ltd',
    'gundam-card-game': 'Bandai',
    'dragon-ball-super-fusion-world': 'Bandai',
    'dragon-ball-super-masters': 'Bandai',
    'union-arena': 'Bandai',
    'yu-gi-oh': 'Konami',
    'flesh-and-blood-tcg': 'Legend Story Studios',
    'hololive-official-card-game': 'Bushiroad'
  };
  const conditions = ['Near Mint', 'Lightly Played', 'Moderately Played', 'Heavily Played', 'Damaged'];
  const languageNames = { en: 'English', ja: 'Japanese' };

  /** Shopify product type per game. Never "Single Card" — that is a tag, not a type. */
  const productTypeDefaults = {
    pokemon: 'Pokemon',
    'pokemon-japan': 'Pokemon',
    'magic-the-gathering': 'MTG',
    'disney-lorcana': 'Disney',
    'one-piece-card-game': 'One Piece',
    'digimon-card-game': 'Digimon',
    'yu-gi-oh': 'Yu-Gi-Oh!'
  };
  /** Store tag that identifies the game. Pokémon deliberately has none. */
  const gameTagDefaults = {
    'magic-the-gathering': 'Magic the Gathering',
    'disney-lorcana': 'Disney Lorcana',
    'one-piece-card-game': 'One Piece Card Game',
    'digimon-card-game': 'Digimon Card Game',
    'yu-gi-oh': 'Yu-Gi-Oh!'
  };
  const SINGLES_TAG = 'Single Cards';

  const state = {
    results: [],
    selected: null,
    shop: null,
    shopMeta: null,
    titleDirty: false,
    seoDirty: false,
    catalogueGames: [],
    setsByGame: {},
    setCodes: {},
    stockMode: '',
    stockMatches: new Map(),
    stockCandidates: [],
    existingProductId: '',
    forceCreateNew: false,
    // Set when staff reject a product that already owns this card's SKU. The
    // new listing cannot reuse that SKU, so makeSku() appends a disambiguator.
    skuSuffix: '',
    skuAttempt: 0,
    stockRequest: 0,
    operationId: '',
    submitting: false,
    totalCardsRequest: 0,
    competitorRequest: 0,
    competitorNmApplied: false,
    autofill: { plan: null, primaryCollection: null, setReleaseDate: '' },
    intake: { today: { cards: 0, units: 0 }, recent: [] },
    // 'single' or 'sealed': which catalogue is searched and how a listing is built.
    mode: 'single',
    // The picture that will go on the listing. kind: own (scanned here),
    // scan (a database scan of the printed card) or digital (a render).
    image: null,
    extras: null,
    extrasRequest: 0,
    extrasPromise: null,
    descriptionDirty: false,
    altDirty: false,
    station: null,
    referenceCache: new Map()
  };

  const els = {
    message: $('#app-message'), warnings: $('#setup-warnings'), game: $('#game'), language: $('#card-language'), providerBadge: $('#provider-badge'), apiUsageBadge: $('#api-usage-badge'), setSuggestions: $('#set-suggestions'),
    searchForm: $('#search-form'),
    query: $('#search-query'), setQuery: $('#search-set'), numberQuery: $('#search-number'), searchGuidance: $('#number-search-guidance'), reset: $('#reset-button'),
    resultsPanel: $('#results-panel'), results: $('#results'), resultCount: $('#result-count'), emptyEditor: $('#empty-editor'),
    productForm: $('#product-form'), editorState: $('#editor-state'), selectedImage: $('#selected-image'),
    selectedGame: $('#selected-game'), selectedName: $('#selected-name'), selectedMeta: $('#selected-meta'),
    selectedSource: $('#selected-source'), ebayLive: $('#ebay-live'), ebaySold: $('#ebay-sold'), totalCardsLink: $('#totalcards-link'), marketSummary: $('#market-summary'),
    autofillSummary: $('#autofill-summary'),
    translationPanel: $('#translation-panel'), englishName: $('#english-card-name'), englishSet: $('#english-set-name'),
    title: $('#product-title'), rebuildTitle: $('#rebuild-title'), finish: $('#finish'), vendor: $('#vendor'),
    seoTitle: $('#seo-title'), seoDescription: $('#seo-description'), rebuildSeo: $('#rebuild-seo'),
    seoTitleCount: $('#seo-title-count'), seoDescriptionCount: $('#seo-description-count'),
    productType: $('#product-type'), category: $('#product-category'), description: $('#description'), tags: $('#tags'),
    tagSearch: $('#tag-search'), tagChips: $('#tag-chips'), tagSuggestions: $('#tag-suggestions'),
    collections: $('#collections'), collectionSearch: $('#collection-search'), collectionChips: $('#collection-chips'),
    collectionSuggestions: $('#collection-suggestions'), location: $('#location'),
    status: $('#product-status'), publications: $('#publications'), selectAllPublications: $('#select-all-publications'),
    variants: $('#variants'), createButton: $('#create-button'), confirmed: $('#confirmed-match'), shopBadge: $('#shop-badge'),
    taxonomyState: $('#taxonomy-state'), stockCheck: $('#stock-check'), stockTitle: $('#stock-title'), stockDetail: $('#stock-detail'),
    stockCandidateActions: $('#stock-candidate-actions'), stockCandidateSelector: $('#stock-candidate-selector'), stockCandidate: $('#stock-candidate'),
    stockCandidateLink: $('#stock-candidate-link'), confirmStockCandidate: $('#confirm-stock-candidate'), rejectStockCandidates: $('#reject-stock-candidates'),
    shopifyPreview: $('#shopify-product-preview'), shopifyPreviewImage: $('#shopify-preview-image'), shopifyPreviewTitle: $('#shopify-preview-title'),
    shopifyPreviewMeta: $('#shopify-preview-meta'), shopifyPreviewVariants: $('#shopify-preview-variants'), shopifyPreviewStoreLink: $('#shopify-preview-store-link'),
    applyMarketPrices: $('#apply-market-prices'), applyCompetitorNm: $('#apply-competitor-nm'), nextCard: $('#next-card-button'), advancedDetails: $('#advanced-listing-details'),
    intakeTally: $('.intake-tally'), intakeTallyButton: $('#intake-tally-button'), intakeTallyText: $('#intake-tally-text'),
    intakeRecent: $('#intake-recent'), intakeRecentList: $('#intake-recent-list'), intakeRecentRefresh: $('#intake-recent-refresh'),
    modeSingle: $('#mode-single'), modeSealed: $('#mode-sealed'),
    searchKicker: $('#search-kicker'), searchTitle: $('#search-title'), searchQueryLabel: $('#search-query-label'), searchSubmit: $('#search-submit'),
    imagePanel: $('#image-panel'), imageBadge: $('#image-badge'), imageQuality: $('#image-quality'), imageNote: $('#image-note'),
    scanCamera: $('#scan-camera'), scanFile: $('#scan-file'), scanUrlToggle: $('#scan-url-toggle'), scanUrlForm: $('#scan-url-form'),
    scanUrl: $('#scan-url'), scanUrlGo: $('#scan-url-go'), imageCandidates: $('#image-candidates'), identityFacts: $('#identity-facts'),
    attachScanRow: $('#attach-scan-row'), attachScanExisting: $('#attach-scan-existing'), compareChecked: $('#compare-checked'),
    variantsKicker: $('#variants-kicker'), variantsTitle: $('#variants-title'), variantsHelp: $('#variants-help'),
    titleRule: $('#title-rule'), finishField: $('#finish-field'),
    serpUrl: $('#serp-url'), serpTitle: $('#serp-title'), serpDesc: $('#serp-desc'),
    strength: $('#listing-strength'), strengthScore: $('#strength-score'), strengthFill: $('#strength-fill'), strengthList: $('#strength-list'),
    descriptionPreview: $('#description-preview'), rebuildDescription: $('#rebuild-description'), imageAlt: $('#image-alt'),
    trayPanel: $('#tray-panel'), trayList: $('#tray-list'), trayClear: $('#tray-clear'), confirmText: $('#confirm-text')
  };

  const pickers = {
    tags: {
      select: () => els.tags,
      search: () => els.tagSearch,
      chips: () => els.tagChips,
      suggestions: () => els.tagSuggestions,
      allowCreate: true,
      emptyLabel: 'No matching tags',
      createLabel: query => `Add new tag “${query}”`,
      activeIndex: -1
    },
    collections: {
      select: () => els.collections,
      search: () => els.collectionSearch,
      chips: () => els.collectionChips,
      suggestions: () => els.collectionSuggestions,
      allowCreate: false,
      emptyLabel: 'No matching collections',
      activeIndex: -1
    }
  };

  function readPrefs() {
    try { return JSON.parse(localStorage.getItem(PREFS_KEY) || '{}') || {}; } catch { return {}; }
  }

  function writePrefs(patch = {}) {
    const next = { ...readPrefs(), ...patch, updatedAt: Date.now() };
    try { localStorage.setItem(PREFS_KEY, JSON.stringify(next)); } catch { /* ignore quota */ }
    return next;
  }

  /**
   * The product page description, from catalogue facts only. Card text comes
   * from TCGdex (Pokemon) or Scryfall (Magic) when they have the card, then the
   * catalogue's own details; links lead back to the set and era collections.
   */
  function buildListingDescription(card) {
    if (!card || !C) return '';
    const plan = state.autofill.plan || {};
    const details = { ...(state.extras?.details || {}) };
    if (!details.rulesText && !details.attacks && card.apiDescription) details.rulesText = String(card.apiDescription);
    const held = $$('.variant-row', els.variants)
      .filter(row => $('.variant-checkbox', row)?.checked)
      .map(row => row.dataset.condition)
      .filter(condition => condition && condition !== 'Default Title' && condition !== 'Sealed');
    return C.descriptionHtml(catalogueCard(card), {
      finish: els.finish?.value || '',
      sealed: state.mode === 'sealed',
      set: plan.set,
      details,
      conditions: held,
      links: collectionLinks(plan)
    });
  }

  /** Set and era collection links for the description, when the store has them. */
  function collectionLinks(plan) {
    const collections = state.shopMeta?.collections || [];
    const find = title => {
      const needle = normalize(title);
      return needle ? collections.find(collection => normalize(collection.title) === needle) : null;
    };
    const set = find(plan?.setTag);
    const era = find(plan?.eraTag);
    const label = state.mode === 'sealed' ? 'products' : 'singles';
    return {
      set: set?.handle ? { url: `/collections/${set.handle}`, title: `Shop all ${set.title} ${label}` } : null,
      era: era?.handle ? { url: `/collections/${era.handle}`, title: `Browse the ${era.title} era` } : null
    };
  }

  function rebuildDescription(force = false) {
    if (!els.description || !state.selected) return;
    if (state.descriptionDirty && !force) { renderDescriptionPreview(); return; }
    els.description.value = buildListingDescription(state.selected);
    state.descriptionDirty = false;
    renderDescriptionPreview();
  }

  /** The description exactly as the store will show it (our own HTML, escaped at build time). */
  function renderDescriptionPreview() {
    if (!els.descriptionPreview) return;
    const doc = new DOMParser().parseFromString(`<div>${els.description.value}</div>`, 'text/html');
    const allowed = new Set(['P', 'UL', 'OL', 'LI', 'STRONG', 'EM', 'H3', 'BR', 'A', 'DIV']);
    doc.body.querySelectorAll('*').forEach(node => {
      if (!allowed.has(node.tagName)) { node.replaceWith(...node.childNodes); return; }
      [...node.attributes].forEach(attr => { if (!(node.tagName === 'A' && attr.name === 'href')) node.removeAttribute(attr.name); });
      if (node.tagName === 'A') { node.setAttribute('target', '_blank'); node.setAttribute('rel', 'noopener'); const href = node.getAttribute('href') || ''; if (href.startsWith('/')) node.setAttribute('href', STORE_ORIGIN + href); }
    });
    els.descriptionPreview.replaceChildren(...doc.body.firstChild.childNodes);
    updateStrength();
  }

  function normalizeConditionKey(value) {
    const text = String(value || '').toLowerCase();
    if (/(near\s*mint|\bnm\b)/.test(text)) return 'Near Mint';
    if (/(lightly\s*played|\blp\b)/.test(text)) return 'Lightly Played';
    if (/(moderately\s*played|\bmp\b)/.test(text)) return 'Moderately Played';
    if (/(heavily\s*played|\bhp\b)/.test(text)) return 'Heavily Played';
    if (/(damaged|\bdmg\b)/.test(text)) return 'Damaged';
    return '';
  }

  function finishMatchesPrinting(finish, printing) {
    const wanted = String(finish || 'Standard').toLowerCase();
    const text = String(printing || '').toLowerCase();
    if (wanted === 'standard') return !text || text.includes('normal') || text === 'standard' || (!text.includes('holo') && !text.includes('foil') && !text.includes('etched'));
    if (wanted.includes('reverse')) return text.includes('reverse');
    if (wanted.includes('etched')) return text.includes('etched');
    if (wanted.includes('holo')) return text.includes('holo') && !text.includes('reverse');
    // Foil matches Foil / Holofoil / Cold Foil (Disney & MTG never use a separate Holo label).
    if (wanted.includes('foil')) {
      if (text.includes('reverse') || text.includes('etched')) return false;
      return text.includes('foil') || text.includes('holo');
    }
    return true;
  }

  function justTcgNmPrice(card) {
    const variants = (card?.marketVariants || []).filter(variant => variant.price != null);
    const finish = els.finish?.value || 'Standard';
    const exact = variants.find(variant =>
      normalizeConditionKey(variant.condition) === 'Near Mint' && finishMatchesPrinting(finish, variant.printing)
    );
    if (exact) return Number(exact.price);
    const byCondition = variants.find(variant => normalizeConditionKey(variant.condition) === 'Near Mint');
    if (byCondition) return Number(byCondition.price);
    if (card?.marketLowest != null) return Number(card.marketLowest);
    return null;
  }

  function marketPriceForCondition(card, condition) {
    if (condition === 'Default Title') {
      const lowest = Number(card?.marketLowest);
      return Number.isFinite(lowest) && lowest > 0 ? lowest : null;
    }
    if (condition === 'Near Mint' && card?.competitorNm?.priceGbp != null) {
      const suggested = Number(card.competitorNm.priceGbp);
      if (Number.isFinite(suggested) && suggested > 0) return suggested;
    }
    // Legacy Total Cards field (kept for older in-memory cards).
    if (condition === 'Near Mint' && card?.totalCardsNm?.priceGbp != null) {
      const tc = Number(card.totalCardsNm.priceGbp);
      if (Number.isFinite(tc) && tc > 0) return tc;
    }
    const variants = (card.marketVariants || []).filter(variant => variant.price != null);
    if (!variants.length) {
      if (condition === 'Near Mint' && card.marketLowest != null) return Number(card.marketLowest);
      return null;
    }
    const finish = els.finish.value || 'Standard';
    const exact = variants.find(variant =>
      normalizeConditionKey(variant.condition) === condition && finishMatchesPrinting(finish, variant.printing)
    );
    if (exact) return Number(exact.price);
    const byCondition = variants.find(variant => normalizeConditionKey(variant.condition) === condition);
    if (byCondition) return Number(byCondition.price);
    if (condition === 'Near Mint' && card.marketLowest != null) return Number(card.marketLowest);
    return null;
  }

  function applyMarketPrices(card = state.selected, { nearMintOnly = false } = {}) {
    if (!card) return 0;
    if (!card.marketPricingAvailable && card.competitorNm?.priceGbp == null && card.totalCardsNm?.priceGbp == null) return 0;
    let filled = 0;
    $$('.variant-row', els.variants).forEach(row => {
      const condition = row.dataset.condition;
      if (nearMintOnly && condition !== 'Near Mint') return;
      const price = marketPriceForCondition(card, condition);
      if (price == null || !Number.isFinite(price) || price <= 0) return;
      const input = $('.variant-price', row);
      input.value = price.toFixed(2);
      filled += 1;
    });
    return filled;
  }

  function shouldFetchCompetitorPrices(card) {
    return !!(card && String(card.cardNumber || '').trim());
  }

  function updateTotalCardsLink(info) {
    if (!els.totalCardsLink) return;
    if (!info?.url) {
      els.totalCardsLink.hidden = true;
      els.totalCardsLink.removeAttribute('href');
      return;
    }
    els.totalCardsLink.href = info.url;
    els.totalCardsLink.hidden = false;
  }

  function readNearMintInputPrice() {
    const row = $$('.variant-row', els.variants).find(item => item.dataset.condition === 'Near Mint' || item.dataset.condition === 'Default Title');
    if (!row) return null;
    const value = Number($('.variant-price', row)?.value);
    return Number.isFinite(value) && value > 0 ? value : null;
  }

  function setNearMintPrice(priceGbp) {
    const row = $$('.variant-row', els.variants).find(item => item.dataset.condition === 'Near Mint' || item.dataset.condition === 'Default Title');
    if (!row) return false;
    const input = $('.variant-price', row);
    if (!input) return false;
    input.value = Number(priceGbp).toFixed(2);
    // The SEO title carries the Near Mint price, so keep it in step.
    maybeRebuildSeo();
    return true;
  }

  function applyCompetitorSuggestedNm(card = state.selected, { force = false } = {}) {
    if (!card?.competitorCompare) return false;
    const suggested = Number(card.competitorCompare.suggestedNm);
    if (!Number.isFinite(suggested) || suggested <= 0) return false;
    const band = card.competitorCompare.rarityBand || '';
    if (!force && band === 'chase' && state.competitorNmApplied) return false;
    if (!force && band === 'chase' && !card.competitorCompare.autoFill) {
      return false;
    }
    card.competitorNm = {
      priceGbp: suggested,
      band,
      action: card.competitorCompare.action || '',
      reason: card.competitorCompare.reason || ''
    };
    const ok = setNearMintPrice(suggested);
    if (ok) state.competitorNmApplied = true;
    return ok;
  }

  function existingShopifyNmPrice() {
    for (const match of state.stockMatches.values()) {
      if (!match?.found) continue;
      const condition = requestedConditionForMatch(match);
      if (normalizeConditionKey(condition) !== 'Near Mint' && !/near\s*mint|\bnm\b/i.test(String(match?.variant?.title || ''))) {
        continue;
      }
      const price = Number(match?.variant?.price);
      if (Number.isFinite(price) && price > 0) return price;
    }
    return null;
  }

  async function maybeOverlayCompetitorPrices(card, { currentNm = null } = {}) {
    updateTotalCardsLink(null);
    if (!card || !shouldFetchCompetitorPrices(card)) {
      if (els.applyCompetitorNm) els.applyCompetitorNm.hidden = true;
      return;
    }
    const number = String(card.cardNumber || '').trim();
    const requestId = ++state.competitorRequest;
    const justTcgNm = justTcgNmPrice(card);
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timer = controller ? setTimeout(() => controller.abort(), 12000) : null;
    try {
      // The card's extras carry the Cardmarket id that makes a Total Cards
      // match exact. Give them a moment, but never hold the prices up for long.
      if (state.extrasPromise) {
        await Promise.race([state.extrasPromise, new Promise(resolve => setTimeout(resolve, 3500))]);
        if (requestId !== state.competitorRequest || state.selected !== card) return;
      }
      const params = new URLSearchParams({
        number,
        game: card.game || '',
        rarity: card.rarity || '',
        record: '1'
      });
      const cardName = C ? C.displayName(catalogueCard(card)) : String(card.englishName || card.name || '').trim();
      const setName = String(state.autofill.plan?.set?.seoName || card.englishSetName || card.setName || '').trim();
      if (cardName) params.set('name', cardName);
      if (setName) params.set('set', setName);
      if (card.setName && card.setName !== setName) params.set('providerSet', card.setName);
      if (state.extras?.cardmarketId) params.set('cardmarketId', state.extras.cardmarketId);
      params.set('label', els.title?.value.trim() || buildTitle());
      // Printing matters as much as the number: a reverse holo and the plain
      // card share 012/084 but not the price. Without this the server cannot
      // tell them apart and will price against whichever it finds first.
      const finish = els.finish?.value || '';
      if (finish) params.set('finish', finish);
      if (justTcgNm != null && Number.isFinite(justTcgNm)) params.set('justTcgNm', String(justTcgNm));
      const shopifyNm = currentNm != null ? currentNm : existingShopifyNmPrice();
      if (shopifyNm != null) params.set('currentNm', String(shopifyNm));
      const data = await api(`api/competitor-prices.php?${params}`, controller ? { signal: controller.signal } : {});
      if (requestId !== state.competitorRequest || state.selected !== card) return;

      card.competitorCompare = data;
      const tc = (data.sources || []).find(source => source.id === 'totalcards' && source.url);
      updateTotalCardsLink(tc || (data.links || []).find(link => link.id === 'totalcards') || null);

      const band = data.rarityBand || 'mid';
      const suggested = data.suggestedNm != null ? Number(data.suggestedNm) : null;
      const canAuto = !!data.autoFill && suggested != null && suggested > 0 && (band === 'volume' || band === 'mid');

      if (canAuto && !state.competitorNmApplied) {
        card.competitorNm = {
          priceGbp: suggested,
          band,
          action: data.action || '',
          reason: data.reason || ''
        };
        setNearMintPrice(suggested);
        state.competitorNmApplied = true;
        const label = band === 'volume' ? 'Volume' : 'Mid';
        showMessage(`Near Mint set to £${suggested.toFixed(2)} (${label} price strategy). LP+ keep JustTCG when available.`, 'success');
      }

      renderMarketSummary(card);
      updateCompetitorApplyButton(card);
    } catch {
      if (els.applyCompetitorNm) els.applyCompetitorNm.hidden = true;
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  function updateCompetitorApplyButton(card = state.selected) {
    if (!els.applyCompetitorNm) return;
    const compare = card?.competitorCompare;
    const suggested = compare?.suggestedNm != null ? Number(compare.suggestedNm) : null;
    if (!compare || suggested == null || !Number.isFinite(suggested) || suggested <= 0) {
      els.applyCompetitorNm.hidden = true;
      return;
    }
    const band = compare.rarityBand || '';
    const action = (compare.existing?.action || compare.action || 'hold').toUpperCase();
    els.applyCompetitorNm.hidden = false;
    els.applyCompetitorNm.textContent = `Apply suggested NM £${suggested.toFixed(2)} (${action}${band ? ` · ${band}` : ''})`;
  }

  async function api(url, options = {}) {
    const { timeoutMs, headers, signal, ...rest } = options;
    const controller = timeoutMs && !signal ? new AbortController() : null;
    const timer = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
    try {
      const response = await fetch(url, {
        credentials: 'same-origin',
        headers: { Accept: 'application/json', ...(headers || {}) },
        ...rest,
        signal: signal || controller?.signal
      });
      let data;
      try { data = await response.json(); } catch { data = { ok: false, error: `Server returned HTTP ${response.status}.` }; }
      if (!response.ok || !data.ok) throw new Error(data.error || `Request failed (${response.status}).`);
      return data;
    } catch (error) {
      if (error?.name === 'AbortError') {
        throw new Error('Request timed out. Refresh and try again.');
      }
      throw error;
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  /** Hard ceiling for JustTCG / catalogue boot checks — pills must leave Connecting. */
  const BOOT_CONNECT_TIMEOUT_MS = 12000;
  /** Shopify meta can be heavier; still keep connection pills bounded. */
  const BOOT_SHOPIFY_TIMEOUT_MS = 15000;
  const BOOT_WATCHDOG_MS = 16000;
  const CONNECTING_BADGE_RE = /connecting to/i;

  function makeOperationId() {
    if (crypto.randomUUID) return crypto.randomUUID();
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const hex = [...bytes].map(value => value.toString(16).padStart(2, '0')).join('');
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  }

  // --- intake tally ------------------------------------------------------
  // Everything below keeps a visible record of what has been booked in today.
  // The success message is shown for 650ms and then prepareNextCard() clears
  // the screen, so before this there was no way to notice a quantity typed as
  // 11 instead of 1, or to get back to a card that had just been submitted.

  function renderIntakeTally() {
    if (!els.intakeTallyText) return;
    const { cards = 0, units = 0 } = state.intake.today || {};
    const cardWord = cards === 1 ? 'card' : 'cards';
    els.intakeTallyText.textContent = units && units !== cards
      ? `Today ${cards} ${cardWord} · ${units} units`
      : `Today ${cards} ${cardWord}`;
    if (els.intakeTally) els.intakeTally.dataset.active = cards > 0 ? 'true' : 'false';
  }

  function renderIntakeRecent() {
    const list = els.intakeRecentList;
    if (!list) return;
    list.replaceChildren();

    const rows = state.intake.recent || [];
    if (!rows.length) {
      const empty = document.createElement('p');
      empty.className = 'intake-recent-empty';
      empty.textContent = 'Nothing booked in yet. Cards appear here as you submit them.';
      list.replaceChildren(empty);
      return;
    }

    for (const row of rows) {
      const li = document.createElement('li');

      const action = document.createElement('span');
      action.className = 'intake-recent-action';
      action.dataset.action = row.action === 'restocked' ? 'restocked' : 'created';
      action.textContent = row.action === 'restocked' ? 'Restock' : 'New';

      const title = document.createElement('span');
      title.className = 'intake-recent-title';
      const label = row.productTitle || row.number || 'Untitled card';
      if (row.adminUrl) {
        const link = document.createElement('a');
        link.href = row.adminUrl;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.textContent = label;
        link.title = label;
        title.append(link);
      } else {
        title.textContent = label;
        title.title = label;
      }

      const units = document.createElement('span');
      units.className = 'intake-recent-units';
      const n = Number(row.units || 0);
      units.textContent = `+${n}`;
      // The time is what makes a mistake locatable against a Shopify record.
      const when = row.at ? new Date(row.at) : null;
      if (when && !Number.isNaN(when.getTime())) {
        units.title = when.toLocaleString();
        units.textContent = `+${n} · ${when.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
      }

      li.append(action, title, units);
      list.append(li);
    }
  }

  async function loadIntakeLog() {
    try {
      const data = await api('api/intake-log.php?limit=12');
      state.intake.today = data.today || { cards: 0, units: 0 };
      state.intake.recent = Array.isArray(data.recent) ? data.recent : [];
    } catch {
      // A tally that cannot load is cosmetic. Never let it interrupt intake.
    }
    renderIntakeTally();
    renderIntakeRecent();
  }

  /**
   * Record the card that was just submitted, without waiting for the server.
   *
   * The screen resets 650ms after a submit, so the entry has to be on screen
   * before then. The server has already written the authoritative line; this
   * is the same fact, shown immediately.
   */
  function noteIntakeLocally(action, product, units) {
    state.intake.recent.unshift({
      at: new Date().toISOString(),
      action,
      productTitle: product?.title || '',
      adminUrl: product?.adminUrl || '',
      units: Number(units) || 0
    });
    state.intake.recent = state.intake.recent.slice(0, 12);
    state.intake.today = {
      ...state.intake.today,
      cards: Number(state.intake.today?.cards || 0) + 1,
      units: Number(state.intake.today?.units || 0) + (Number(units) || 0)
    };
    renderIntakeTally();
    renderIntakeRecent();
  }

  function setIntakeRecentOpen(open) {
    if (!els.intakeRecent || !els.intakeTally) return;
    els.intakeRecent.hidden = !open;
    els.intakeTally.dataset.open = open ? 'true' : 'false';
    els.intakeTallyButton?.setAttribute('aria-expanded', open ? 'true' : 'false');
  }

  function intakeRecentIsOpen() {
    return els.intakeTally?.dataset.open === 'true';
  }

  function showMessage(text, type = '') {
    if (!els.message) return;
    els.message.textContent = text;
    els.message.className = `message${type ? ` ${type}` : ''}`;
    els.message.hidden = !text;
    if (text) els.message.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function showWarnings(warnings) {
    if (!els.warnings) return;
    const list = (warnings || []).filter(Boolean);
    els.warnings.hidden = !list.length;
    els.warnings.textContent = list.join('\n');
  }

  function updateApiUsage(usage) {
    if (!els.apiUsageBadge || !usage || !usage.dailyLimit) {
      if (els.apiUsageBadge) els.apiUsageBadge.hidden = true;
      return;
    }
    const used = Number(usage.dailyUsed) || 0;
    const limit = Number(usage.dailyLimit) || 0;
    const remaining = Number(usage.dailyRemaining ?? Math.max(0, limit - used));
    const ratio = limit > 0 ? Math.min(1, used / limit) : 0;
    const pct = Math.round(ratio * 100);
    const plan = usage.plan || 'JustTCG';
    const planLine = usage.planLimit
      ? `Plan quota ${usage.planUsed || 0}/${usage.planLimit}`
      : 'Plan quota unavailable';
    const updated = usage.updatedAt
      ? `Updated ${new Date(usage.updatedAt * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
      : 'Live from JustTCG';

    els.apiUsageBadge.hidden = false;
    els.apiUsageBadge.classList.toggle('is-warn', ratio >= 0.7 && ratio < 0.9);
    els.apiUsageBadge.classList.toggle('is-critical', ratio >= 0.9);
    els.apiUsageBadge.title = [
      `${plan}`,
      `Daily API ${used}/${limit} used · ${remaining} remaining`,
      planLine,
      usage.rateLimit ? `Rate limit ${usage.rateLimit}/min` : '',
      updated
    ].filter(Boolean).join('\n');
    els.apiUsageBadge.replaceChildren();
    const meter = document.createElement('span');
    meter.className = 'usage-meter';
    meter.setAttribute('aria-hidden', 'true');
    const fill = document.createElement('span');
    fill.style.width = `${pct}%`;
    meter.append(fill);
    const copy = document.createElement('span');
    copy.className = 'usage-copy';
    copy.textContent = `API ${used}/${limit} · ${remaining} left`;
    els.apiUsageBadge.append(meter, copy);
  }

  function setProgress(step) {
    $$('.progress-step').forEach((el, index) => el.classList.toggle('active', index < step));
    $$('.progress-line').forEach((el, index) => el.classList.toggle('active', index < step - 1));
  }

  function gameLabel(game) {
    return gameNames[game] || state.catalogueGames.find(item => item.id === game)?.name || game || 'Trading Card Game';
  }

  function vendorDefault(game) {
    if (vendorDefaults[game]) return vendorDefaults[game];
    if (/one-piece|digimon|gundam|dragon-ball|union-arena/i.test(game)) return 'Bandai';
    if (/pokemon/i.test(game)) return 'Pokémon';
    if (/magic/i.test(game)) return 'Wizards of the Coast';
    if (/lorcana/i.test(game)) return 'Ravensburger Ltd';
    return '';
  }

  function addSelectOption(select, value, label = value, selected = false) {
    if (!value) return null;
    let option = [...select.options].find(item => item.value === value);
    if (!option) {
      option = new Option(label, value, false, selected);
      select.add(option);
    }
    if (selected) option.selected = true;
    return option;
  }

  function replaceStringOptions(select, values, placeholder = '') {
    select.replaceChildren();
    if (placeholder) select.add(new Option(placeholder, ''));
    [...new Set((values || []).filter(Boolean))]
      .sort((a, b) => a.localeCompare(b))
      .forEach(value => select.add(new Option(value, value)));
  }

  function selectedPickerValues(select) {
    return [...select.selectedOptions].map(option => ({
      value: option.value,
      label: option.textContent || option.value
    }));
  }

  function renderPickerChips(name) {
    const picker = pickers[name];
    const select = picker.select();
    const chips = picker.chips();
    chips.replaceChildren();
    selectedPickerValues(select).forEach(item => {
      const chip = document.createElement('span');
      chip.className = 'picker-chip';
      const label = document.createElement('span');
      label.textContent = item.label;
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.setAttribute('aria-label', `Remove ${item.label}`);
      remove.textContent = '×';
      remove.addEventListener('click', () => {
        const option = [...select.options].find(entry => entry.value === item.value);
        if (option) option.selected = false;
        renderPickerChips(name);
        hidePickerSuggestions(name);
      });
      chip.append(label, remove);
      chips.append(chip);
    });
  }

  function hidePickerSuggestions(name) {
    const picker = pickers[name];
    picker.activeIndex = -1;
    picker.suggestions().hidden = true;
    picker.suggestions().replaceChildren();
  }

  function rankPickerMatches(options, query) {
    const needle = normalize(query);
    if (!needle) {
      return options.slice(0, 12).map(option => ({ option, score: 0 }));
    }
    return options
      .map(option => {
        const label = normalize(option.textContent || option.value);
        const value = normalize(option.value);
        let score = 0;
        if (label === needle || value === needle) score = 100;
        else if (label.startsWith(needle) || value.startsWith(needle)) score = 80;
        else if (label.includes(needle) || value.includes(needle)) score = 55;
        else return null;
        return { option, score };
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score || a.option.textContent.localeCompare(b.option.textContent))
      .slice(0, 12);
  }

  function renderPickerSuggestions(name) {
    const picker = pickers[name];
    const select = picker.select();
    const search = picker.search();
    const panel = picker.suggestions();
    const query = search.value.trim();
    const available = [...select.options].filter(option => !option.selected);
    const matches = rankPickerMatches(available, query);
    const exact = available.some(option =>
      normalize(option.textContent) === normalize(query) || normalize(option.value) === normalize(query)
    );
    panel.replaceChildren();

    if (!matches.length && !(picker.allowCreate && query && !exact)) {
      const empty = document.createElement('div');
      empty.className = 'picker-suggestion-empty';
      empty.textContent = query ? picker.emptyLabel : `Start typing to search ${name}`;
      panel.append(empty);
      panel.hidden = false;
      picker.activeIndex = -1;
      return;
    }

    matches.forEach(({ option }, index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'picker-suggestion';
      button.setAttribute('role', 'option');
      button.dataset.index = String(index);
      button.dataset.value = option.value;
      const title = document.createElement('strong');
      title.textContent = option.textContent || option.value;
      button.append(title);
      if (option.value !== option.textContent && name === 'collections') {
        const meta = document.createElement('small');
        meta.textContent = 'Shopify collection';
        button.append(meta);
      }
      button.addEventListener('mousedown', event => event.preventDefault());
      button.addEventListener('click', () => choosePickerValue(name, option.value, option.textContent || option.value));
      panel.append(button);
    });

    if (picker.allowCreate && query && !exact) {
      const create = document.createElement('button');
      create.type = 'button';
      create.className = 'picker-suggestion';
      create.dataset.index = String(matches.length);
      create.dataset.create = '1';
      create.dataset.value = query;
      const title = document.createElement('strong');
      title.textContent = picker.createLabel(query);
      const meta = document.createElement('small');
      meta.textContent = 'Create a new Shopify tag';
      create.append(title, meta);
      create.addEventListener('mousedown', event => event.preventDefault());
      create.addEventListener('click', () => choosePickerValue(name, query, query, true));
      panel.append(create);
    }

    picker.activeIndex = panel.querySelectorAll('.picker-suggestion').length ? 0 : -1;
    updatePickerActiveOption(name);
    panel.hidden = false;
  }

  function updatePickerActiveOption(name) {
    const picker = pickers[name];
    const buttons = $$('.picker-suggestion', picker.suggestions());
    buttons.forEach((button, index) => {
      button.classList.toggle('is-active', index === picker.activeIndex);
      if (index === picker.activeIndex) button.scrollIntoView({ block: 'nearest' });
    });
  }

  function choosePickerValue(name, value, label = value, create = false) {
    const picker = pickers[name];
    const select = picker.select();
    if (create || ![...select.options].some(option => option.value === value)) {
      addSelectOption(select, value, label, true);
    } else {
      const option = [...select.options].find(entry => entry.value === value);
      if (option) option.selected = true;
    }
    picker.search().value = '';
    hidePickerSuggestions(name);
    renderPickerChips(name);
    picker.search().focus();
  }

  function bindPicker(name) {
    const picker = pickers[name];
    const search = picker.search();
    search.addEventListener('focus', () => renderPickerSuggestions(name));
    search.addEventListener('input', () => renderPickerSuggestions(name));
    search.addEventListener('keydown', event => {
      const buttons = $$('.picker-suggestion', picker.suggestions());
      if (event.key === 'ArrowDown' && buttons.length) {
        event.preventDefault();
        picker.activeIndex = Math.min(buttons.length - 1, Math.max(0, picker.activeIndex) + 1);
        updatePickerActiveOption(name);
        return;
      }
      if (event.key === 'ArrowUp' && buttons.length) {
        event.preventDefault();
        picker.activeIndex = Math.max(0, picker.activeIndex - 1);
        updatePickerActiveOption(name);
        return;
      }
      if (event.key === 'Escape') {
        hidePickerSuggestions(name);
        return;
      }
      if (event.key === 'Enter') {
        event.preventDefault();
        const active = buttons[picker.activeIndex];
        if (active) {
          const value = active.dataset.value;
          const create = active.dataset.create === '1';
          choosePickerValue(name, value, create ? value : (active.querySelector('strong')?.textContent || value), create);
          return;
        }
        const query = search.value.trim();
        if (picker.allowCreate && query) choosePickerValue(name, query, query, true);
      }
      if (event.key === 'Backspace' && !search.value) {
        const selected = selectedPickerValues(picker.select());
        const last = selected[selected.length - 1];
        if (!last) return;
        const option = [...picker.select().options].find(entry => entry.value === last.value);
        if (option) option.selected = false;
        renderPickerChips(name);
      }
    });
    search.addEventListener('blur', () => {
      setTimeout(() => hidePickerSuggestions(name), 120);
    });
  }

  function setCatalogueGamesUnavailable(message) {
    if (els.game) {
      els.game.replaceChildren(new Option(message || 'JustTCG unavailable — refresh to retry', ''));
    }
    if (els.providerBadge) els.providerBadge.textContent = 'JustTCG connection error';
  }

  function badgeStillConnecting(el) {
    return !!(el && CONNECTING_BADGE_RE.test(String(el.textContent || '')));
  }

  function forceStuckConnectionsFailed(reason) {
    let changed = false;
    if (badgeStillConnecting(els.providerBadge)) {
      setCatalogueGamesUnavailable('JustTCG timed out — refresh to retry');
      changed = true;
    }
    if (badgeStillConnecting(els.shopBadge)) {
      els.shopBadge.textContent = 'Shopify connection error';
      changed = true;
    }
    if (changed) {
      showMessage(reason || 'Connection checks timed out. Hard-refresh, or unregister the service worker if this keeps happening.', 'error');
    }
  }

  function scheduleBootConnectionWatchdog() {
    setTimeout(() => {
      forceStuckConnectionsFailed(
        'Connection checks timed out. Hard-refresh, or unregister the service worker if this keeps happening.'
      );
    }, BOOT_WATCHDOG_MS);
  }

  async function loadCatalogueMeta() {
    try {
      const data = await api('api/catalogue-meta.php', { timeoutMs: BOOT_CONNECT_TIMEOUT_MS });
      state.catalogueGames = data.games || [];
      if (!state.catalogueGames.length) {
        setCatalogueGamesUnavailable('No JustTCG games returned — refresh to retry');
        showMessage('JustTCG returned an empty games list.', 'error');
        return;
      }
      els.game.replaceChildren();
      state.catalogueGames.forEach(game => {
        gameNames[game.id] = game.name;
        els.game.add(new Option(game.name, game.id));
      });
      const prefs = readPrefs();
      const preferred = state.catalogueGames.find(game => game.id === prefs.game)
        || state.catalogueGames.find(game => game.id === 'pokemon')
        || state.catalogueGames[0];
      if (preferred) els.game.value = preferred.id;
      if (prefs.language === 'en' || prefs.language === 'ja') els.language.value = prefs.language;
      if (els.providerBadge) els.providerBadge.textContent = `JustTCG · ${state.catalogueGames.length} games`;
      updateApiUsage(data.usage);
      try {
        await handleGameChange();
        if (prefs.setQuery) els.setQuery.value = prefs.setQuery;
      } catch (error) {
        showMessage(`JustTCG sets could not load: ${error.message}`, 'warning');
      }
    } catch (error) {
      setCatalogueGamesUnavailable('JustTCG unavailable — refresh to retry');
      showMessage(error.message, 'error');
    }
  }

  async function loadGameSets(game) {
    if (!game) return;
    try {
      let sets = state.setsByGame[game];
      if (!sets) {
        const data = await api(`api/catalogue-meta.php?game=${encodeURIComponent(game)}`, {
          timeoutMs: BOOT_CONNECT_TIMEOUT_MS
        });
        sets = data.sets || [];
        state.setsByGame[game] = sets;
        updateApiUsage(data.usage);
      }
      els.setSuggestions.replaceChildren();
      sets.forEach(set => {
        const option = document.createElement('option');
        option.value = set.name;
        option.label = [set.releaseDate, set.id].filter(Boolean).join(' · ');
        els.setSuggestions.append(option);
      });
    } catch (error) {
      els.setSuggestions.replaceChildren();
      showMessage(`JustTCG sets could not load: ${error.message}`, 'warning');
    }
  }

  function applyShopifyMeta(data, { fromCache = false } = {}) {
    state.shopMeta = data;
    state.shop = data.shop;
    const cacheNote = fromCache || data.cached ? ' · cached' : '';
    if (els.shopBadge) {
      els.shopBadge.textContent = data.shop?.name ? `${data.shop.name} · connected${cacheNote}` : `Shopify connected${cacheNote}`;
    }
    showWarnings(data.warnings);

    // Smart collections fill themselves from the tags/vendor/type set above and
    // reject manual adds, so only manual collections belong in the picker. The
    // smart ones stay in state.shopMeta for the breadcrumb metafield lookup.
    els.collections.replaceChildren();
    (data.collections || [])
      .filter(collection => !collection.smart)
      .forEach(collection => els.collections.add(new Option(collection.title, collection.id)));

    els.location.replaceChildren(new Option('Choose location…', ''));
    (data.locations || []).forEach(location => els.location.add(new Option(location.name, location.id)));
    const prefs = readPrefs();
    if (prefs.locationId && [...els.location.options].some(option => option.value === prefs.locationId)) {
      els.location.value = prefs.locationId;
    } else if ((data.locations || []).length === 1) {
      els.location.value = data.locations[0].id;
    }

    replaceStringOptions(els.vendor, data.vendors || []);
    replaceStringOptions(els.productType, data.productTypes || []);
    replaceStringOptions(els.tags, data.tags || []);
    renderPickerChips('tags');
    renderPickerChips('collections');

    els.publications.replaceChildren();
    (data.publications || []).forEach(publication => {
      const title = publication.catalog?.title || publication.name || 'Unnamed sales channel';
      const option = new Option(title, publication.id, true, true);
      els.publications.add(option);
    });

    els.category.replaceChildren(new Option('No category', ''));
    (data.categories || [])
      .filter(category => !category.isArchived)
      .sort((a, b) => a.fullName.localeCompare(b.fullName))
      .forEach(category => els.category.add(new Option(category.fullName, category.id)));
    const preferredId = data.preferredCategoryId || '';
    if (preferredId && [...els.category.options].some(option => option.value === preferredId)) {
      els.category.value = preferredId;
    } else {
      const gaming = [...els.category.options].find(option =>
        /collectible trading cards.*gaming cards/i.test(option.textContent)
      ) || [...els.category.options].find(option => /gaming cards/i.test(option.textContent));
      if (gaming) els.category.value = gaming.value;
    }

    if (prefs.status === 'ACTIVE' || prefs.status === 'DRAFT') els.status.value = prefs.status;

    populateTaxonomyOptions(data.categoryOptions || {});
    if (state.selected) {
      // Rebuilding the tag/collection option lists above clears the selection,
      // so re-derive it from the card that is actually open.
      applyAutofill(state.selected);
      applyTaxonomyDefaults(state.selected);
      checkExistingStock();
    }
  }

  async function loadShopifyMeta() {
    try {
      try {
        const raw = sessionStorage.getItem(SHOPIFY_META_CACHE_KEY);
        const cached = raw ? JSON.parse(raw) : null;
        if (cached?.payload?.ok && cached.savedAt && Date.now() - cached.savedAt < SHOPIFY_META_CLIENT_TTL_MS) {
          applyShopifyMeta(cached.payload, { fromCache: true });
          return;
        }
      } catch { /* ignore bad client cache */ }

      const data = await api('api/shopify-meta.php', { timeoutMs: BOOT_SHOPIFY_TIMEOUT_MS });
      applyShopifyMeta(data);
      try {
        sessionStorage.setItem(SHOPIFY_META_CACHE_KEY, JSON.stringify({ savedAt: Date.now(), payload: data }));
      } catch { /* ignore quota */ }
    } catch (error) {
      if (els.shopBadge) els.shopBadge.textContent = 'Shopify connection error';
      showMessage(error.message, 'error');
    }
  }

  function extractExactNumber(value) {
    const normalized = value
      .replace(/[／⁄∕]/g, '/')
      .replace(/[－–—−]/g, '-')
      .trim();
    const patterns = [
      /(?:[A-Z]{1,8}\d{0,4}[A-Z]?[- ])?[A-Z]*\d{1,5}[A-Z]?[\/]\d{1,5}/i,
      /\b[A-Z]{1,8}\d{0,4}[A-Z]?[- ][A-Z]*\d{1,5}[A-Z]*\b/i,
      /\b(?:PRB|OP|BT|EX|ST|EB|RB|LM)\d{2}[A-Z]?\d{2,4}\b/i,
      /\b(?:SV|SM|XY|BW)\d{1,2}[A-Z]?\d{2,4}\b/i,
      /\b\d{4,8}\b/
    ];
    for (const pattern of patterns) {
      const match = normalized.match(pattern);
      if (match) return match[0].replace(/\s+/g, '');
    }
    return /^[A-Z]*\d{1,5}[A-Z]*$/i.test(normalized) ? normalized : '';
  }

  function usesSetPrefixedNumbers(game) {
    return /one-piece|digimon|gundam|dragon-ball|union-arena/i.test(String(game || ''));
  }

  function extractBandaiSetCode(value) {
    const text = String(value || '').trim().toUpperCase();
    if (!text) return '';
    if (/^(?:PRB|OP|BT|EX|ST|EB|RB|LM|GD|UA|P)\d{1,3}[A-Z]{0,3}$/.test(text)) return text;
    const embedded = text.match(/\b((?:PRB|OP|BT|EX|ST|EB|RB|LM|GD|UA)\d{1,3}[A-Z]{0,3})\b/);
    return embedded ? embedded[1] : '';
  }

  function padLocalCardNumber(localRaw, width = 3) {
    const raw = String(localRaw || '').trim().toUpperCase();
    const match = raw.match(/^([A-Z]*)(\d+)([A-Z]*)$/);
    if (!match) return raw;
    return match[1] + match[2].padStart(width, '0') + match[3];
  }

  /** Fallback when JustTCG set ids/names omit the printed code (OP16, etc.). */
  function bandaiSetCodeAlias(setQuery) {
    const wanted = normalize(setQuery);
    if (!wanted) return '';
    const aliases = {
      thetimeofbattle: 'OP16',
      thetimeofbattleonepiececardgame: 'OP16',
      thetimeofbattlereleaseeventcards: 'OP16',
      thetimeofbattlereleaseeventcardsonepiececardgame: 'OP16'
    };
    if (aliases[wanted]) return aliases[wanted];
    for (const [needle, code] of Object.entries(aliases)) {
      if (wanted.includes(needle)) return code;
    }
    return '';
  }

  function readLearnedSetCodes() {
    try {
      const raw = localStorage.getItem('cardIntake.setCodes');
      const parsed = raw ? JSON.parse(raw) : {};
      return parsed && typeof parsed === 'object' ? parsed : {};
    } catch {
      return {};
    }
  }

  function rememberSetCode(setQuery, code) {
    const key = normalize(setQuery);
    const setCode = extractBandaiSetCode(code);
    if (!key || !setCode) return;
    state.setCodes = state.setCodes || readLearnedSetCodes();
    if (state.setCodes[key] === setCode) return;
    state.setCodes[key] = setCode;
    try { localStorage.setItem('cardIntake.setCodes', JSON.stringify(state.setCodes)); } catch { /* ignore */ }
  }

  function resolveSetCodeFromCatalogue(game, setQuery) {
    const wanted = normalize(setQuery);
    if (!wanted) return '';
    const direct = extractBandaiSetCode(setQuery);
    if (direct) return direct;
    const alias = bandaiSetCodeAlias(setQuery);
    if (alias) return alias;
    state.setCodes = state.setCodes || readLearnedSetCodes();
    if (state.setCodes[wanted]) return state.setCodes[wanted];
    const sets = state.setsByGame[game] || [];
    const exact = sets.find(set => normalize(set.id) === wanted || normalize(set.name) === wanted);
    const fuzzy = exact || sets.find(set => {
      const name = normalize(set.name);
      const id = normalize(set.id);
      return (name && (name.includes(wanted) || wanted.includes(name)))
        || (id && (id.includes(wanted) || wanted.includes(id)));
    });
    if (!fuzzy) return '';
    return extractBandaiSetCode(fuzzy.id)
      || extractBandaiSetCode(fuzzy.name)
      || bandaiSetCodeAlias(fuzzy.id)
      || bandaiSetCodeAlias(fuzzy.name)
      || state.setCodes[normalize(fuzzy.name)]
      || state.setCodes[normalize(fuzzy.id)]
      || '';
  }

  /** Expand 065 + OP16 / set context → OP16-065 for Bandai-style games. */
  function expandNumberWithSetContext(game, setQuery, number) {
    const trimmed = String(number || '').trim();
    if (!trimmed || !setQuery?.trim() || !usesSetPrefixedNumbers(game)) return trimmed;
    if (/[-\/]/.test(trimmed)) return trimmed;
    if (/^(?:PRB|OP|BT|EX|ST|EB|RB|LM|GD|UA)\d{1,3}[A-Z]{0,3}\d{2,4}$/i.test(trimmed.replace(/\s+/g, ''))) {
      return trimmed.replace(/\s+/g, '');
    }
    const local = trimmed.replace(/\s+/g, '');
    if (!/^[A-Z]*\d{1,6}[A-Z]*$/i.test(local)) return trimmed;
    const setCode = resolveSetCodeFromCatalogue(game, setQuery);
    if (!setCode) return trimmed;
    return `${setCode}-${padLocalCardNumber(local, 3)}`;
  }

  async function searchSealed() {
    const query = els.query.value.trim();
    const set = els.setQuery.value.trim();
    if ((query + set).length < 2) {
      showMessage('Enter a product name or choose a set.', 'error');
      return;
    }
    const submit = els.searchSubmit || $('button[type="submit"]', els.searchForm);
    submit.disabled = true;
    showMessage(`Searching sealed ${gameLabel(els.game.value)} products…`);
    try {
      const params = new URLSearchParams({ game: els.game.value, lang: els.language.value, q: query, set, kind: 'sealed' });
      const data = await api(`api/search.php?${params}`);
      state.results = (data.results || []).map(row => ({ ...row, kind: 'sealed' }));
      state.selected = null;
      updateApiUsage(data.usage);
      renderResults();
      setProgress(2);
      if (!state.results.length) {
        showMessage(set ? `No sealed products were found in ${set}. Try the product name instead.` : 'No sealed products matched. Choose the set to list everything in it.', 'error');
      } else {
        showMessage(`${state.results.length} sealed product${state.results.length === 1 ? '' : 's'} found. Choose the exact product.`);
      }
    } catch (error) {
      state.results = [];
      renderResults();
      showMessage(error.message, 'error');
    } finally {
      submit.disabled = false;
    }
  }

  async function searchCards() {
    if (state.mode === 'sealed') return searchSealed();
    let query = els.query.value.trim();
    const set = els.setQuery.value.trim();
    let number = els.numberQuery.value.trim();

    // Staff can paste the number into the first field. Move an
    // unmistakable identifier into the strict number filter automatically.
    if (!number) {
      const extracted = extractExactNumber(query);
      if (extracted) {
        number = extracted;
        query = query.replace(extracted, '').trim();
        els.query.value = query;
        els.numberQuery.value = number;
      }
    }
    const expanded = expandNumberWithSetContext(els.game.value, set, number);
    if (expanded && expanded !== number) {
      number = expanded;
      els.numberQuery.value = number;
    }
    if ((query + set + number).length < 2) {
      showMessage('Enter a card name, set or printed card number.', 'error');
      return;
    }
    const submit = $('button[type="submit"]', els.searchForm);
    submit.disabled = true;
    const strictNumberSearch = Boolean(number);
    showMessage(strictNumberSearch
      ? `Searching for the exact printed number ${number} in ${gameLabel(els.game.value)} ${languageNames[els.language.value]}…`
      : `Searching ${gameLabel(els.game.value)} ${languageNames[els.language.value]} printings…`);
    try {
      const params = new URLSearchParams({ game: els.game.value, lang: els.language.value, q: query, set, number });
      const data = await api(`api/search.php?${params}`);
      const serverNumber = String(data.search?.strictNumber || '').trim();
      if (serverNumber && serverNumber !== els.numberQuery.value.trim()) {
        number = serverNumber;
        els.numberQuery.value = serverNumber;
      }
      if (set) {
        rememberSetCode(set, serverNumber || number);
        (data.results || []).forEach(card => {
          rememberSetCode(set, card.cardNumber || card.setCode || '');
          if (card.setName) rememberSetCode(card.setName, card.cardNumber || card.setCode || '');
          if (card.setId) rememberSetCode(card.setId, card.cardNumber || card.setCode || '');
        });
      }
      state.results = data.results;
      state.selected = null;
      updateApiUsage(data.usage);
      renderResults();
      setProgress(2);
      if (!data.results.length) {
        const askedJapanese = els.language.value === 'ja' && els.game.value !== 'pokemon-japan';
        showMessage(askedJapanese
          ? `No Japanese printings were found in JustTCG for ${gameLabel(els.game.value)}. JustTCG only has a dedicated Japanese catalogue for Pokémon (Pokemon Japan); English images are no longer shown for Japanese searches.`
          : (strictNumberSearch
            ? `No exact match was found for ${number}. No cards with a different numerator or denominator are being shown.`
            : 'No candidates were found. Search by exact printed number and set code, then add the card name.'), 'error');
      } else {
        showMessage(strictNumberSearch
          ? `${data.results.length} exact-number match${data.results.length === 1 ? '' : 'es'} found for ${number}. Different card totals have been excluded.`
          : `${data.results.length} ranked candidate${data.results.length === 1 ? '' : 's'} found. Confirm the image, set, number and finish.`);
        const top = data.results[0];
        if (data.results.length === 1 && (top?.confidence || 0) >= 70) {
          selectCard(0);
          showMessage(`Auto-selected the only exact match (${top.confidence}%). Check price and quantity, then upload.`, 'success');
        }
      }
    } catch (error) {
      state.results = [];
      renderResults();
      showMessage(error.message, 'error');
    } finally {
      submit.disabled = false;
    }
  }

  function renderResults() {
    els.results.replaceChildren();
    els.resultsPanel.hidden = false;
    els.resultCount.textContent = `${state.results.length} found`;
    if (!state.results.length) {
      const empty = document.createElement('p');
      empty.className = 'result-empty';
      empty.textContent = 'No candidates yet.';
      els.results.append(empty);
      return;
    }
    state.results.forEach((card, index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = `result-card${state.selected?.externalId === card.externalId ? ' selected' : ''}`;
      button.addEventListener('click', () => selectCard(index));
      if (card.imageUrl) {
        const image = document.createElement('img');
        image.className = 'result-image';
        image.src = card.imageUrl;
        image.alt = '';
        image.loading = 'lazy';
        image.dataset.fallbackIndex = '0';
        image.addEventListener('error', () => {
          const fallbacks = card.imageFallbackUrls || [];
          const index = Number(image.dataset.fallbackIndex || 0);
          if (fallbacks[index]) {
            image.dataset.fallbackIndex = String(index + 1);
            image.src = fallbacks[index];
          } else image.replaceWith(noImage());
        });
        button.append(image);
      } else button.append(noImage());

      const copy = document.createElement('span');
      copy.className = 'result-copy';
      const top = document.createElement('span');
      top.className = 'result-topline';
      const confidence = document.createElement('b');
      confidence.className = `confidence ${card.confidence >= 75 ? 'high' : card.confidence >= 50 ? 'medium' : 'low'}`;
      confidence.textContent = `${card.confidence}% match`;
      const provider = document.createElement('i');
      provider.textContent = card.provider || 'Database';
      top.append(confidence, provider);
      const name = document.createElement('strong');
      name.textContent = card.languageCode === 'ja' && card.englishName ? `${card.englishName} · ${card.name}` : (card.name || 'Unnamed card');
      const set = document.createElement('span');
      const resolved = C ? C.resolveSet(card) : null;
      set.textContent = [resolved?.known ? resolved.seoName : (card.englishSetName || card.setName || 'Set not supplied'), card.setCode].filter(Boolean).join(' · ');
      const meta = document.createElement('span');
      const printed = state.mode === 'sealed' ? '' : (C ? C.printedNumber({ ...card, setReleaseDate: resolveSetReleaseDate(card) }, resolved) : card.cardNumber);
      if (printed) {
        const num = document.createElement('b');
        num.className = 'result-number';
        num.textContent = printed;
        meta.append(num, document.createTextNode(' · '));
      }
      meta.append(document.createTextNode([card.rarity, card.marketLowest != null ? `from £${Number(card.marketLowest).toFixed(2)}` : '', ...(card.matchReasons || [])].filter(Boolean).join(' · ')));
      copy.append(top, name, set, meta);
      const arrow = document.createElement('span');
      arrow.className = 'result-arrow';
      arrow.textContent = '→';
      button.append(copy, arrow);
      els.results.append(button);
    });
  }

  function noImage() {
    const placeholder = document.createElement('span');
    placeholder.className = 'result-placeholder';
    placeholder.textContent = 'No image';
    return placeholder;
  }

  function selectCard(index) {
    state.selected = state.results[index];
    state.titleDirty = false;
    state.seoDirty = false;
    state.operationId = '';
    state.stockMode = '';
    state.stockMatches = new Map();
    state.stockCandidates = [];
    state.existingProductId = '';
    state.forceCreateNew = false;
    state.skuSuffix = '';
    state.skuAttempt = 0;
    state.submitting = false;
    state.competitorNmApplied = false;
    state.competitorRequest += 1;
    if (state.selected) {
      delete state.selected.totalCardsNm;
      delete state.selected.competitorNm;
      delete state.selected.competitorCompare;
    }
    hideStockCandidates();
    setExistingEditorMode('listing');
    renderResults();
    const card = state.selected;
    if (state.mode === 'sealed') card.kind = 'sealed';
    state.extras = null;
    state.descriptionDirty = false;
    state.altDirty = false;
    updateTotalCardsLink(null);
    if (els.applyCompetitorNm) els.applyCompetitorNm.hidden = true;
    els.emptyEditor.hidden = true;
    els.productForm.hidden = false;
    els.editorState.textContent = 'Ready to list';
    els.editorState.classList.add('ready');
    const resolved = C ? C.resolveSet({ ...card, setReleaseDate: resolveSetReleaseDate(card) }) : null;
    els.selectedGame.textContent = [gameLabel(card.game), card.language, state.mode === 'sealed' ? 'Sealed product' : ''].filter(Boolean).join(' · ');
    els.selectedName.textContent = C ? C.displayName(card) || card.name : card.name;
    els.selectedMeta.textContent = [resolved?.known ? resolved.seoName : (card.englishSetName || card.setName), state.mode === 'sealed' ? '' : (C ? C.printedNumber({ ...card, setReleaseDate: resolveSetReleaseDate(card) }, resolved) : card.cardNumber), card.rarity].filter(Boolean).join(' · ');
    els.selectedSource.href = card.sourceUrl || '#';
    els.selectedSource.hidden = !card.sourceUrl;

    els.translationPanel.hidden = card.languageCode !== 'ja';
    els.englishName.value = card.englishName || (card.languageCode === 'en' ? card.name : '');
    els.englishSet.value = card.englishSetName || (card.languageCode === 'en' ? card.setName : '');
    state.englishNameAuto = els.englishName.value;

    populateFinish(card);
    applyAutofill(card);
    applyTaxonomyDefaults(card);
    renderVariants(card);
    const priced = applyMarketPrices(card);
    renderMarketSummary(card);
    rebuildTitle();
    rebuildSeo();
    rebuildDescription(true);
    renderFacts();
    setCatalogueImage(card);
    loadExtras(card);
    updateEbayLinks();
    checkExistingStock();
    els.confirmed.checked = false;
    els.createButton.disabled = false;
    if (els.nextCard) els.nextCard.hidden = true;
    updateCreateButton();
    setProgress(3);
    writePrefs({
      game: els.game.value,
      language: els.language.value,
      setQuery: els.setQuery.value.trim(),
      locationId: els.location.value,
      status: els.status.value
    });

    if (card.languageCode === 'ja' && !els.englishName.value) {
      showMessage('Japanese card matched, but an English name was not returned. Enter the English card name before publishing.', 'warning');
    } else if (priced) {
      showMessage(`Market GBP prices filled for ${priced} condition${priced === 1 ? '' : 's'}. Confirm against eBay UK before publishing.`, 'success');
    }
    maybeOverlayCompetitorPrices(card);
    if (window.innerWidth < 981) $('#editor-panel').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  const SHOP_LABELS = { lockett: 'Lockett Labs', totalcards: 'Total Cards', chaoscards: 'Chaos Cards', magicmadhouse: 'Magic Madhouse', justtcg: 'Market (US)' };

  function money(value) {
    const n = Number(value);
    return Number.isFinite(n) ? `£${n.toFixed(2)}` : '';
  }

  function el(tag, attrs, children) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else node.setAttribute(k, v === true ? '' : v);
    }
    for (const child of [].concat(children || [])) {
      if (child == null || child === false) continue;
      node.append(child.nodeType ? child : document.createTextNode(String(child)));
    }
    return node;
  }

  /** A small line of prices over time. Our own line is drawn in ember. */
  function sparkline(points, isUs) {
    const priced = (points || []).filter(p => p && p.p != null);
    if (priced.length < 2) return null;
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('class', 'sparkline');
    svg.setAttribute('viewBox', '0 0 84 24');
    svg.setAttribute('aria-hidden', 'true');
    const values = priced.map(p => Number(p.p));
    const min = Math.min(...values), max = Math.max(...values);
    const span = max - min || 1;
    const d = priced.map((p, i) => `${i ? 'L' : 'M'}${(i / (priced.length - 1) * 82 + 1).toFixed(1)} ${(22 - (Number(p.p) - min) / span * 20).toFixed(1)}`).join(' ');
    const path = document.createElementNS(ns, 'path');
    path.setAttribute('d', d);
    if (isUs) path.setAttribute('class', 'is-us');
    svg.append(path);
    return svg;
  }

  /**
   * The price board: our price, each UK shop's matched listing with its stock
   * and price, the market reference, and how each has moved. A shop whose
   * listing is a different printing or out of stock is shown but never counts.
   */
  function renderMarketSummary(card) {
    const variants = (card.marketVariants || []).filter(variant => variant.price != null).slice(0, 8);
    const compare = card.competitorCompare;
    const hasCompare = !!(compare && Array.isArray(compare.sources));
    els.marketSummary.replaceChildren();
    if (els.compareChecked) els.compareChecked.hidden = true;
    if (!variants.length && !hasCompare) {
      els.marketSummary.hidden = true;
      if (els.applyMarketPrices) els.applyMarketPrices.hidden = true;
      updateCompetitorApplyButton(card);
      return;
    }

    const ours = readNearMintInputPrice();
    if (hasCompare) {
      const action = String(compare.existing?.action || compare.action || 'hold').toLowerCase();
      const position = compare.position || {};
      const suggested = compare.suggestedNm != null ? Number(compare.suggestedNm) : null;
      const lowest = compare.lowestInStock != null ? Number(compare.lowestInStock) : null;
      let headline = 'No UK shop has this printing in stock';
      if (lowest != null && ours != null) {
        const diff = ours - lowest;
        headline = Math.abs(diff) < 0.005 ? `Level with the cheapest UK price, ${money(lowest)}`
          : diff < 0 ? `${money(-diff)} under the cheapest UK price` : `${money(diff)} over the cheapest UK price (${money(lowest)})`;
      } else if (lowest != null) {
        headline = `Cheapest in stock in the UK: ${money(lowest)}`;
      }
      els.marketSummary.append(el('div', { class: 'compare-verdict' }, [
        el('span', { class: 'verdict-badge', 'data-action': action, text: action }),
        el('div', { class: 'verdict-copy' }, [
          el('strong', { text: headline }),
          el('span', { text: [suggested != null ? `Suggested ${money(suggested)} (${compare.rarityBand || 'mid'} band)` : '', compare.existing?.reason || compare.reason || ''].filter(Boolean).join('. ') })
        ])
      ]));

      const history = compare.history?.series || {};
      const change = compare.history?.change || {};
      const table = el('table', { class: 'compare-table' });
      table.append(el('thead', {}, el('tr', {}, [
        el('th', { text: 'Shop' }), el('th', { text: 'Stock' }), el('th', { class: 'num', text: 'Price' }), el('th', { class: 'hide-sm', text: '90 days' })
      ])));
      const body = el('tbody');
      const usRow = el('tr', { class: 'is-us' }, [
        el('td', {}, el('div', { class: 'shop-name' }, [el('strong', { text: 'Lockett Labs' }), el('small', { text: compare.existing?.yourPrice != null ? 'Price in Shopify now' : 'Price on this form' })])),
        el('td', {}, el('span', { class: 'stock-flag in', text: 'Listing' })),
        el('td', { class: 'num price-cell' }, el('strong', { text: ours != null ? money(ours) : 'Not priced' })),
        el('td', { class: 'hide-sm' }, sparkline(history.lockett, true))
      ]);
      body.append(usRow);
      for (const source of compare.sources) {
        if (source.id === 'justtcg') continue;
        const counts = source.matched && source.available === true && source.priceGbp != null;
        const stockText = !source.matched ? 'Not stocked' : source.available === true ? (source.stock != null ? `${source.stock} in stock` : 'In stock') : source.available === false ? 'Out of stock' : 'Unknown';
        const stockClass = !source.matched ? 'none' : source.available === true ? 'in' : 'out';
        const delta = counts && ours != null ? Number(source.priceGbp) - ours : null;
        const nameCell = el('div', { class: 'shop-name' }, [
          el('strong', { text: source.label || SHOP_LABELS[source.id] || source.id }),
          source.title ? el('small', { class: 'shop-match' }, source.url ? el('a', { href: source.url, target: '_blank', rel: 'noopener noreferrer', text: source.title }) : source.title) : null,
          el('small', { text: source.matched ? [source.condition ? `${source.condition}` : '', ...(source.evidence || [])].filter(Boolean).join(' · ') : (source.note || 'No match') })
        ]);
        const priceCell = el('td', { class: 'num price-cell' }, [
          el('strong', { text: source.priceGbp != null && source.matched ? money(source.priceGbp) : '' }),
          delta != null ? el('span', { class: `delta ${delta >= 0 ? 'up' : 'down'}`, text: `${delta >= 0 ? '+' : '−'}${money(Math.abs(delta))} vs us` }) : null,
          change[source.id] != null ? el('span', { class: 'delta', text: `${change[source.id] > 0 ? '+' : ''}${change[source.id]}% in 90 days` }) : null
        ]);
        body.append(el('tr', { class: counts ? '' : 'is-muted' }, [
          el('td', {}, nameCell),
          el('td', {}, el('span', { class: `stock-flag ${stockClass}`, text: stockText })),
          priceCell,
          el('td', { class: 'hide-sm' }, sparkline(history[source.id], false))
        ]));
      }
      const market = compare.sources.find(source => source.id === 'justtcg');
      if (market && market.priceGbp != null) {
        body.append(el('tr', { class: 'is-muted' }, [
          el('td', {}, el('div', { class: 'shop-name' }, [el('strong', { text: 'Market reference' }), el('small', { text: `TCGplayer Near Mint via JustTCG, converted at the ${card.marketRateDate || 'latest'} rate` })])),
          el('td', {}, el('span', { class: 'stock-flag none', text: 'US' })),
          el('td', { class: 'num price-cell' }, el('strong', { text: money(market.priceGbp) })),
          el('td', { class: 'hide-sm' }, sparkline(history.justtcg, false))
        ]));
      }
      table.append(body);
      els.marketSummary.append(table);

      const foot = el('div', { class: 'compare-foot' });
      const links = el('div', { class: 'compare-links' });
      (compare.links || []).forEach(link => links.append(el('a', { href: link.url, target: '_blank', rel: 'noopener noreferrer', text: link.label || link.id })));
      foot.append(links, el('span', { text: 'Only in-stock listings of the same printing count towards the suggestion.' }));
      els.marketSummary.append(foot);
      if (els.compareChecked && compare.checkedAt) {
        els.compareChecked.hidden = false;
        els.compareChecked.textContent = `Checked ${new Date(compare.checkedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
      }
    }

    if (variants.length) {
      const list = el('div', { class: 'market-price-list' });
      variants.forEach(variant => {
        const change = variant.priceChange7d != null ? `, 7 days ${variant.priceChange7d > 0 ? '+' : ''}${Number(variant.priceChange7d).toFixed(1)}%` : '';
        list.append(el('span', { text: `${normalizeConditionKey(variant.condition) || variant.condition || 'Condition'} ${variant.printing || 'Normal'}: ${money(variant.price)}${change}` }));
      });
      els.marketSummary.append(el('p', { class: 'field-help', text: 'Market by condition (lower conditions price from these):' }), list);
    }

    els.marketSummary.hidden = false;
    if (els.applyMarketPrices) els.applyMarketPrices.hidden = !variants.length;
    updateCompetitorApplyButton(card);
  }

  function chooseLiveValue(select, value) {
    if (!value) return;
    addSelectOption(select, value, value);
    select.value = value;
  }

  /**
   * Finish choices in the store's wording. The catalogue's own printings come
   * first (what the card actually exists in), then the rest of the house list.
   */
  function populateFinish(card) {
    if (els.finishField) els.finishField.hidden = state.mode === 'sealed';
    els.finish.replaceChildren();
    if (state.mode === 'sealed') {
      els.finish.add(new Option('Sealed', 'Sealed'));
      els.finish.value = 'Sealed';
      return;
    }
    const fromCatalogue = [...new Set((card.marketVariants || []).map(v => C.finishFromPrinting(v.printing, card.game)))];
    const fromName = C.parseName(card.name || '').finish;
    const house = C.finishChoices(card.game);
    const options = [...new Set([...(fromName ? [fromName] : []), ...fromCatalogue, ...house])];
    const labels = { 'Reverse Holo': 'Reverse holo', Standard: 'Standard (no foil)' };
    options.forEach(value => els.finish.add(new Option(labels[value] || value, value)));
    let chosen = fromName || (fromCatalogue.length === 1 ? fromCatalogue[0] : (fromCatalogue.includes('Standard') ? 'Standard' : fromCatalogue[0])) || 'Standard';
    // Lorcana and Magic sometimes carry "(Foil)" in the catalogue name.
    if (/\(\s*foil\s*\)/i.test(String(card?.name || ''))) chosen = 'Foil';
    els.finish.value = options.includes(chosen) ? chosen : options[0];
  }

  /**
   * JustTCG often embeds the printed number and finish in the card name
   * ("Dusclops - 019/064 (Cosmos Holo)"). Strip those so the house title format
   * can add set / finish / number once: "Name : SET (Finish) - NUMBER".
   */
  function cleanListingCardName(rawName, card = state.selected) {
    let name = String(rawName || '').trim();
    if (!name) return '';

    const number = String(card?.cardNumber || '').trim();
    if (number) {
      const escaped = number.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      name = name.replace(new RegExp(`\\s*[-–—:]\\s*${escaped}\\b`, 'i'), '');
      const compact = number.replace(/^0+/, '').replace(/\/0+/, '/');
      if (compact && compact !== number) {
        const compactEscaped = compact.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        name = name.replace(new RegExp(`\\s*[-–—:]\\s*0*${compactEscaped.replace('/', '/0*')}\\b`, 'i'), '');
      }
    }

    // Trailing finish / treatment in parentheses, including Cosmos Holo variants.
    name = name.replace(/\s*\((?:cosmos\s+)?(?:reverse\s+)?(?:holo(?:foil)?|foil|etched|stamped|promo)\)\s*$/i, '');
    // Generic trailing parenthetical that duplicates the selected finish.
    const finish = String(els.finish?.value || card?.finish || '').trim();
    if (finish && finish !== 'Standard') {
      const finishEscaped = finish.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      name = name.replace(new RegExp(`\\s*\\(${finishEscaped}\\)\\s*$`, 'i'), '');
    }

    return name.replace(/\s+/g, ' ').replace(/\s*[-–—:]\s*$/, '').trim();
  }

  function titleName() {
    const card = state.selected || {};
    const raw = card.languageCode === 'ja'
      ? (els.englishName.value.trim() || card.englishName || card.name)
      : (els.englishName.value.trim() || card.englishName || card.name);
    return cleanListingCardName(raw, Object.keys(card).length ? card : state.selected);
  }

  function titleSet() {
    const card = state.selected || {};
    const fromPlan = state.autofill.plan?.titleSet || state.autofill.plan?.seoSet || '';
    const fromField = els.englishSet.value.trim();
    if (fromField) return fromField;
    if (fromPlan) return fromPlan;
    return card.englishSetName || card.setName || '';
  }

  /**
   * The card as the catalogue engine sees it: staff's English name and set
   * when they have typed one, the provider's own name otherwise (it carries
   * qualifiers such as "(Cosmos Holo)" that the cleaned field drops), and the
   * set's release date and printed size when known.
   */
  function catalogueCard(card = state.selected) {
    if (!card) return null;
    const typedName = els.englishName?.value.trim() || '';
    const typedSet = els.englishSet?.value.trim() || '';
    const nameEdited = typedName && typedName !== state.englishNameAuto;
    return {
      ...card,
      englishName: nameEdited ? typedName : (card.languageCode === 'ja' ? (typedName || card.englishName || '') : card.name),
      englishSetName: typedSet || card.englishSetName || card.setName,
      setReleaseDate: state.autofill.setReleaseDate || resolveSetReleaseDate(card),
      printedTotal: state.extras?.printedTotal || 0,
      releasedAt: state.extras?.releasedAt || ''
    };
  }

  /** The number exactly as printed on the card: 25/111, 025/198, TG16/TG30. */
  function printedNumber(card = state.selected) {
    if (!card || state.mode === 'sealed') return '';
    const cc = catalogueCard(card);
    return C.printedNumber(cc, state.autofill.plan?.set || C.resolveSet(cc));
  }

  function buildTitle() {
    const card = state.selected;
    if (!card) return '';
    const cc = catalogueCard(card);
    const set = state.autofill.plan?.set || C.resolveSet(cc);
    if (state.mode === 'sealed') return C.buildSealedTitle(cc, { set, englishName: cc.englishName });
    return C.buildTitle(cc, { finish: els.finish.value, set, englishName: cc.englishName });
  }

  function rebuildTitle() {
    els.title.value = buildTitle();
    state.titleDirty = false;
    if (els.titleRule && state.selected) {
      const n = printedNumber();
      els.titleRule.textContent = state.mode === 'sealed' ? 'store sealed format' : (n ? `number as printed: ${n}` : 'store format');
    }
    updateEbayLinks();
    updateSerp();
  }

  const SEO_TITLE_MAX = 70;
  const SEO_DESCRIPTION_MAX = 160;

  function finishLabel() {
    const finish = els.finish?.value || '';
    return finish && finish !== 'Standard' && finish !== 'Sealed' ? finish : '';
  }

  /** "Sneasel 25/111 30th Celebration | £9.95 In Stock UK", within 70 characters. */
  function buildSeoTitle(card = state.selected) {
    if (!card) return '';
    const cc = catalogueCard(card);
    return C.seoTitle(cc, { finish: els.finish.value, price: readNearMintInputPrice(), set: state.autofill.plan?.set, sealed: state.mode === 'sealed', englishName: cc.englishName });
  }

  function buildSeoDescription(card = state.selected) {
    if (!card) return '';
    const cc = catalogueCard(card);
    return C.seoDescription(cc, { finish: els.finish.value, set: state.autofill.plan?.set, sealed: state.mode === 'sealed', englishName: cc.englishName });
  }

  function buildImageAlt(card = state.selected) {
    if (!card) return '';
    const cc = catalogueCard(card);
    return C.imageAlt(cc, { finish: els.finish.value, set: state.autofill.plan?.set, sealed: state.mode === 'sealed', scan: state.image?.kind === 'own' || state.image?.kind === 'scan', englishName: cc.englishName });
  }

  function buildImageFilename(card = state.selected, ext = 'jpg') {
    if (!card) return 'card.jpg';
    const cc = catalogueCard(card);
    return C.imageFilename(cc, { finish: els.finish.value, set: state.autofill.plan?.set, sealed: state.mode === 'sealed', ext, englishName: cc.englishName });
  }

  function updateSeoCounts() {
    if (els.seoTitleCount) els.seoTitleCount.textContent = String((els.seoTitle?.value || '').length);
    if (els.seoDescriptionCount) els.seoDescriptionCount.textContent = String((els.seoDescription?.value || '').length);
    updateSerp();
  }

  function rebuildSeo() {
    if (!els.seoTitle || !els.seoDescription) return;
    els.seoTitle.value = buildSeoTitle();
    els.seoDescription.value = buildSeoDescription();
    if (els.imageAlt && !state.altDirty) els.imageAlt.value = buildImageAlt();
    state.seoDirty = false;
    updateSeoCounts();
  }

  function maybeRebuildSeo() {
    if (state.seoDirty) updateSeoCounts();
    else rebuildSeo();
  }

  function maybeRebuildTitle() {
    if (!state.titleDirty) rebuildTitle();
    else updateEbayLinks();
  }

  /** How the listing will read in Google: the SEO title, the product address and the description. */
  function updateSerp() {
    if (!els.serpTitle) return;
    const title = els.seoTitle?.value.trim() || els.title.value.trim();
    const handle = (els.title.value || '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/['’]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    els.serpUrl.textContent = `lockett-labs.com › products › ${handle.slice(0, 48)}${handle.length > 48 ? '…' : ''}`;
    els.serpTitle.textContent = title.length > 62 ? `${title.slice(0, 60).replace(/\s+\S*$/, '')} …` : title;
    els.serpDesc.textContent = els.seoDescription?.value.trim() || '';
    updateStrength();
  }

  /**
   * Listing strength: the things that decide whether a card page earns its
   * place in search and converts once it is found. Each is checked from the
   * listing as it stands, so the score moves as staff fix things.
   */
  function updateStrength() {
    if (!els.strengthList || !state.selected) return;
    const sealed = state.mode === 'sealed';
    const words = (els.descriptionPreview?.textContent || '').trim().split(/\s+/).filter(Boolean).length;
    const seoTitle = els.seoTitle?.value || '';
    const number = printedNumber();
    const kind = state.image?.kind || '';
    const plan = state.autofill.plan || {};
    const links = collectionLinks(plan);
    const checks = [
      { ok: kind === 'own' || kind === 'scan' || (sealed && !!kind), weight: 22, text: kind === 'own' ? 'Photo is your scan of this card' : kind === 'scan' ? 'Photo is a scan of the printed card' : sealed ? 'Product photo chosen' : 'Scan the card: the photo is a digital render' },
      { ok: sealed || !!number, weight: 8, text: number ? `Number as printed (${number})` : 'Printed number missing' },
      { ok: !!plan.set?.known, weight: 12, text: plan.set?.known ? `Filed under ${plan.setTag}${plan.eraTag ? ` and ${plan.eraTag}` : ''}` : 'Set not in the store table: check the tag' },
      { ok: !!state.autofill.primaryCollection, weight: 6, text: state.autofill.primaryCollection ? 'Breadcrumb collection set' : 'No breadcrumb collection found' },
      { ok: words >= 70, weight: 14, text: `Description ${words} words${words >= 70 ? '' : ' (aim for 70 or more)'}` },
      { ok: !!(state.extras?.details && Object.keys(state.extras.details).length) || sealed, weight: 8, text: state.extras?.details && Object.keys(state.extras.details).length ? 'Card facts from the card database' : 'No card database facts yet' },
      { ok: seoTitle.length >= 30 && seoTitle.length <= 70 && /£\d/.test(seoTitle), weight: 10, text: seoTitle.length ? `Search title ${seoTitle.length}/70 with price` : 'Search title missing' },
      { ok: (els.seoDescription?.value.length || 0) >= 90, weight: 6, text: 'Search description' },
      { ok: (els.imageAlt?.value.length || 0) >= 15, weight: 6, text: 'Image alt text describes the card' },
      { ok: !!(links.set || links.era), weight: 4, text: links.set || links.era ? 'Links back to the set' : 'No set collection to link to' },
      { ok: sealed || !!state.extras?.tcgCardId || !/pokemon/i.test(state.selected.game || ''), weight: 4, text: state.extras?.tcgCardId ? `Card panel id ${state.extras.tcgCardId}` : 'Card panel id resolves at upload' }
    ];
    const total = checks.reduce((sum, c) => sum + c.weight, 0);
    const score = Math.round(checks.reduce((sum, c) => sum + (c.ok ? c.weight : 0), 0) / total * 100);
    els.strengthScore.textContent = String(score);
    els.strengthFill.style.width = `${score}%`;
    els.strength.dataset.band = score >= 85 ? 'good' : score >= 60 ? 'fair' : 'weak';
    els.strengthList.replaceChildren(...checks.map(c => {
      const li = document.createElement('li');
      li.dataset.ok = c.ok ? 'true' : 'false';
      li.textContent = c.text;
      return li;
    }));
  }

  // --- card extras, pictures and scans -----------------------------------
  //
  // Database images for modern printings are digital renders: a flat gold
  // border where the real Classic Collection card has glitter foil, no
  // reverse holo pattern at all. So the listing photo is chosen in order of
  // truth: a scan made here of the card in hand, then a database scan of the
  // printed card (TCGdex for older Pokemon sets, Scryfall for Magic), and only
  // then a digital render, which is labelled as one.

  async function loadExtras(card) {
    const request = ++state.extrasRequest;
    const payload = {
      game: card.game, name: card.name, englishName: card.englishName, setName: card.setName,
      englishSetName: card.englishSetName, setId: card.setId, cardNumber: card.cardNumber,
      languageCode: card.languageCode, scryfallId: card.scryfallId, tcgplayerId: card.tcgplayerId,
      externalId: card.externalId, rarity: card.rarity, setTag: state.autofill.plan?.setTag || ''
    };
    state.extrasPromise = api('api/card-extras.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify({ card: payload }),
      timeoutMs: 15000
    }).then(data => {
      if (request !== state.extrasRequest || state.selected !== card) return;
      state.extras = data;
      // Magic's printed set size makes "035/331" possible.
      if (data.printedTotal || data.releasedAt) { maybeRebuildTitle(); maybeRebuildSeo(); }
      renderFacts();
      renderCandidates();
      const scan = (data.images || []).find(image => image.kind === 'scan');
      if (scan && state.image?.kind !== 'own') chooseCatalogueImage(scan);
      rebuildDescription();
      updateStrength();
    }).catch(() => {
      // Extras are a bonus: the card lists without them.
    });
    return state.extrasPromise;
  }

  function renderFacts() {
    if (!els.identityFacts) return;
    const card = state.selected;
    els.identityFacts.replaceChildren();
    if (!card) return;
    const plan = state.autofill.plan || {};
    const d = state.extras?.details || {};
    const facts = [
      ['Printed number', printedNumber()],
      ['Set', plan.set ? `${plan.set.seoName}${plan.set.classic ? ' Classic Collection' : ''}` : ''],
      ['Released', state.autofill.setReleaseDate],
      ['Rarity', d.rarity || (card.rarity && !/^none$/i.test(card.rarity) ? card.rarity : '')],
      ['Illustrator', d.illustrator],
      ['HP / type', [d.hp ? `${d.hp} HP` : '', (d.types || []).join(', ')].filter(Boolean).join(', ')],
      ['Card panel', state.extras?.tcgCardId || '']
    ];
    for (const [k, v] of facts) {
      if (!v) continue;
      const dt = document.createElement('dt');
      dt.textContent = k;
      const dd = document.createElement('dd');
      dd.textContent = v;
      els.identityFacts.append(dt, dd);
    }
  }

  function setImageView(src, kind, label, note) {
    els.selectedImage.onerror = null;
    els.selectedImage.src = src || 'assets/icon.svg';
    els.selectedImage.alt = els.imageAlt?.value || 'Listing picture';
    if (els.imageBadge) {
      els.imageBadge.hidden = !kind;
      els.imageBadge.dataset.kind = kind || '';
      els.imageBadge.textContent = label || '';
    }
    if (els.imageNote) {
      els.imageNote.textContent = note || '';
      els.imageNote.classList.toggle('is-warn', kind === 'digital');
    }
  }

  /** The catalogue's own picture, shown until something better is chosen. */
  function setCatalogueImage(card) {
    const url = card.imageUrl || '';
    const sealed = state.mode === 'sealed';
    state.image = url ? { kind: sealed ? 'product' : 'digital', source: 'url', url } : null;
    if (els.imageQuality) els.imageQuality.replaceChildren();
    setImageView(url, url ? (sealed ? 'scan' : 'digital') : '', sealed ? 'Product photo' : 'Digital render',
      sealed ? 'The catalogue product photo. Photograph the box if it differs.'
        : 'This is a digital render, not the printed card. Scan the card so the photo shows its real finish.');
    els.selectedImage.dataset.fallbackIndex = '0';
    els.selectedImage.onerror = () => {
      const fallbacks = card.imageFallbackUrls || [];
      const index = Number(els.selectedImage.dataset.fallbackIndex || 0);
      if (fallbacks[index]) {
        els.selectedImage.dataset.fallbackIndex = String(index + 1);
        els.selectedImage.src = fallbacks[index];
        if (state.image) state.image.url = fallbacks[index];
      } else { els.selectedImage.onerror = null; els.selectedImage.src = 'assets/icon.svg'; state.image = null; }
    };
    renderCandidates();
    if (!state.altDirty && els.imageAlt) els.imageAlt.value = buildImageAlt();
    updateStrength();
  }

  function chooseCatalogueImage(image) {
    state.image = { kind: image.kind, source: 'url', url: image.url, label: image.label };
    setImageView(image.url, image.kind, image.kind === 'scan' ? 'Database scan' : 'Digital render', image.note || '');
    if (els.imageQuality) els.imageQuality.replaceChildren();
    if (!state.altDirty && els.imageAlt) els.imageAlt.value = buildImageAlt();
    renderCandidates();
    updateStrength();
  }

  /** A scan made in the scan station: shown at once, uploaded in the background. */
  function setOwnImage(result) {
    if (!state.selected) return;
    if (state.image?.kind === 'own' && state.image.objectUrl && state.image.objectUrl !== result.url) {
      // The tray keeps its own object URLs; only revoke ones made for this card.
      if (!result.fromTray) URL.revokeObjectURL(state.image.objectUrl);
    }
    state.image = { kind: 'own', source: 'blob', blob: result.blob, objectUrl: result.url, quality: result.quality, staged: null, upload: null };
    const chips = result.chips || [];
    setImageView(result.url, 'own', 'Your scan', 'This photo goes on the listing, named for the card so search engines can read it.');
    if (els.imageQuality) {
      els.imageQuality.replaceChildren(...chips.map(c => {
        const span = document.createElement('span');
        span.className = `scan-chip scan-chip--${c.tone}`;
        span.textContent = c.text;
        return span;
      }));
    }
    if (!state.altDirty && els.imageAlt) els.imageAlt.value = buildImageAlt();
    renderCandidates();
    updateStrength();
    stageOwnImage();
    showMessage(chips.some(c => c.tone === 'bad') ? 'Scan attached, but check the quality notes under the picture.' : 'Scan attached. It uploads in the background while you price the card.', chips.some(c => c.tone === 'bad') ? 'warning' : 'success');
    setProgress(3);
  }

  /** Stage the scan with Shopify now, so publishing does not wait for it. */
  function stageOwnImage() {
    const image = state.image;
    if (!image || image.kind !== 'own' || !image.blob) return null;
    if (image.upload) return image.upload;
    const ext = image.blob.type === 'image/webp' ? 'webp' : image.blob.type === 'image/png' ? 'png' : 'jpg';
    const form = new FormData();
    form.append('image', image.blob, buildImageFilename(state.selected, ext));
    form.append('filename', buildImageFilename(state.selected, ext));
    image.upload = fetch('api/scan-upload.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'X-CSRF-Token': csrf, Accept: 'application/json' },
      body: form
    }).then(async response => {
      const data = await response.json().catch(() => ({ ok: false, error: `Upload failed (HTTP ${response.status}).` }));
      if (!response.ok || !data.ok) throw new Error(data.error || 'The scan could not be uploaded.');
      if (state.image === image) image.staged = { url: data.resourceUrl, filename: data.filename };
      return data;
    }).catch(error => {
      if (state.image === image) image.upload = null;
      throw error;
    });
    image.upload.catch(() => {});
    return image.upload;
  }

  function renderCandidates() {
    if (!els.imageCandidates) return;
    els.imageCandidates.replaceChildren();
    const card = state.selected;
    if (!card) return;
    const items = [];
    if (state.image?.kind === 'own') items.push({ kind: 'own', url: state.image.objectUrl, label: 'Your scan', own: true });
    for (const image of state.extras?.images || []) items.push({ ...image, label: image.kind === 'scan' ? 'Scan' : 'Render' });
    if (!items.some(item => item.id === 'tcgplayer') && card.imageUrl) items.push({ id: 'catalogue', kind: state.mode === 'sealed' ? 'scan' : 'digital', url: card.imageUrl, label: state.mode === 'sealed' ? 'Photo' : 'Render' });
    if (items.length < 2) return;
    for (const item of items) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'candidate';
      button.dataset.kind = item.kind;
      const active = item.own ? state.image?.kind === 'own' : state.image?.kind !== 'own' && state.image?.url === item.url;
      button.setAttribute('aria-pressed', active ? 'true' : 'false');
      button.title = item.note || item.label;
      const img = document.createElement('img');
      img.src = item.thumb || item.url;
      img.alt = '';
      img.loading = 'lazy';
      img.onerror = () => { img.onerror = null; img.src = item.url; };
      const label = document.createElement('span');
      label.textContent = item.label;
      button.append(img, label);
      button.addEventListener('click', () => {
        if (item.own) return;
        chooseCatalogueImage(item);
      });
      els.imageCandidates.append(button);
    }
  }

  /** Pixels of the catalogue picture, so the scan station can tell which way up a scan is. */
  async function referencePixels() {
    const card = state.selected;
    if (!card || !window.LLScanStation) return null;
    const url = (state.extras?.images || [])[0]?.url || card.imageUrl;
    if (!url) return null;
    if (state.referenceCache.has(url)) return state.referenceCache.get(url);
    const blob = await fetchImageBlob(url);
    const decoded = await window.LLScanStation.decode(blob);
    const pixels = decoded.pixels;
    state.referenceCache.set(url, pixels);
    if (state.referenceCache.size > 6) state.referenceCache.delete(state.referenceCache.keys().next().value);
    return pixels;
  }

  async function fetchImageBlob(url) {
    const response = await fetch('api/image-fetch.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify({ url })
    });
    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.error || `The image could not be fetched (HTTP ${response.status}).`);
    }
    return response.blob();
  }

  function setupScanStation() {
    if (!window.LLScanStation || !els.imagePanel) return;
    try {
      state.station = window.LLScanStation.create({
        worker: 'assets/ll-scan-worker.js?v=6.0.0',
        onResult: result => setOwnImage(result),
        getReference: referencePixels,
        fetchUrl: fetchImageBlob,
        notify: (text, type) => showMessage(text, type)
      });
    } catch (error) {
      console.warn('Scan station unavailable', error);
      return;
    }
    const ready = () => !!state.selected;
    state.station.attachDropTarget(els.imagePanel, ready);
    state.station.attachPaste(ready);
    state.station.onTray(renderTray);
    els.scanCamera?.addEventListener('click', () => state.station.openCamera());
    els.scanFile?.addEventListener('change', () => {
      if (els.scanFile.files?.length) state.station.handleFiles(els.scanFile.files, 'file');
      els.scanFile.value = '';
    });
    els.scanUrlToggle?.addEventListener('click', () => {
      const open = els.scanUrlForm.hidden;
      els.scanUrlForm.hidden = !open;
      els.scanUrlToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      if (open) els.scanUrl.focus();
    });
    const importUrl = () => {
      const url = els.scanUrl.value.trim();
      if (!/^https:\/\//i.test(url)) { showMessage('Paste an https address of an image.', 'warning'); return; }
      state.station.importUrl(url);
    };
    els.scanUrlGo?.addEventListener('click', importUrl);
    els.scanUrl?.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); importUrl(); } });
    els.trayClear?.addEventListener('click', () => state.station.clearTray());
  }

  function renderTray(items) {
    if (!els.trayPanel) return;
    const waiting = items.filter(item => !item.used).length;
    els.trayPanel.hidden = !items.length;
    els.trayList.replaceChildren();
    items.forEach((item, index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = `tray-item${item.used ? ' is-used' : ''}`;
      button.disabled = item.used;
      const img = document.createElement('img');
      img.src = item.url;
      img.alt = `Tray scan ${index + 1}`;
      const label = document.createElement('span');
      label.textContent = item.used ? 'Used' : `Scan ${index + 1}`;
      button.append(img, label);
      button.addEventListener('click', () => {
        if (!state.selected) { showMessage('Find the card first, then tap its scan.', 'warning'); return; }
        const taken = state.station.takeFromTray(index);
        if (taken) setOwnImage({ ...taken, fromTray: true });
      });
      els.trayList.append(button);
    });
    if (waiting && state.selected && state.image?.kind !== 'own' && els.imageNote) {
      els.imageNote.textContent = `${waiting} scan${waiting === 1 ? '' : 's'} waiting in the tray. Tap the one that matches this card.`;
    }
  }

  // --- singles or sealed ---------------------------------------------------

  function setMode(mode, { silent = false } = {}) {
    const next = mode === 'sealed' ? 'sealed' : 'single';
    const changed = next !== state.mode;
    state.mode = next;
    document.body.classList.toggle('mode-sealed', next === 'sealed');
    els.modeSingle?.setAttribute('aria-checked', next === 'single' ? 'true' : 'false');
    els.modeSealed?.setAttribute('aria-checked', next === 'sealed' ? 'true' : 'false');
    if (els.searchKicker) els.searchKicker.textContent = next === 'sealed' ? 'Find the product' : 'Find the card';
    if (els.searchQueryLabel) els.searchQueryLabel.textContent = next === 'sealed' ? 'Product name' : 'Card name';
    if (els.query) els.query.placeholder = next === 'sealed' ? 'e.g. Elite Trainer Box, Booster Bundle' : els.query.dataset.cardPlaceholder || els.query.placeholder;
    if (els.confirmText) els.confirmText.textContent = next === 'sealed'
      ? 'I checked the product, set and language, and it is factory sealed.'
      : 'I checked the card, set, number, language and finish.';
    if (els.searchGuidance) els.searchGuidance.textContent = next === 'sealed'
      ? 'Choose the set to see every sealed product in it, or search by name.'
      : els.searchGuidance.dataset.cardText || els.searchGuidance.textContent;
    writePrefs({ mode: next });
    if (changed && !silent) prepareNextCard(false);
  }

  function updateEbayLinks() {
    const query = els.title.value.trim() || buildTitle();
    const encoded = encodeURIComponent(query);
    els.ebayLive.href = `https://www.ebay.co.uk/sch/i.html?_nkw=${encoded}&LH_PrefLoc=1`;
    els.ebaySold.href = `https://www.ebay.co.uk/sch/i.html?_nkw=${encoded}&LH_PrefLoc=1&LH_Sold=1&LH_Complete=1`;
  }

  function setStockStatus(mode, title, detail) {
    if (!els.stockCheck) return;
    els.stockCheck.hidden = false;
    els.stockCheck.className = `stock-check ${mode}`;
    if (els.stockTitle) els.stockTitle.textContent = title;
    if (els.stockDetail) els.stockDetail.textContent = detail;
  }

  function hideStockCandidates() {
    state.stockCandidates = [];
    els.stockCandidate.replaceChildren();
    els.stockCandidateActions.hidden = true;
    els.stockCandidateSelector.hidden = true;
    els.confirmStockCandidate.disabled = true;
    els.stockCandidateLink.hidden = true;
    els.stockCandidateLink.removeAttribute('href');
    els.rejectStockCandidates.hidden = false;
    els.shopifyPreview.hidden = true;
    els.shopifyPreviewVariants.replaceChildren();
    els.shopifyPreviewStoreLink.hidden = true;
    els.shopifyPreviewStoreLink.removeAttribute('href');
  }

  function setExistingEditorMode(mode) {
    const deciding = mode === 'decision' || mode === 'restock';
    els.productForm.classList.toggle('existing-decision', deciding);
    els.productForm.classList.toggle('restock-mode', mode === 'restock');
    els.confirmed.required = mode !== 'restock';
    if (mode === 'restock') els.confirmed.checked = true;
    else els.confirmed.checked = false;
    if (!state.selected) return;
    els.editorState.textContent = mode === 'restock' ? 'Restock existing' : (mode === 'decision' ? 'Confirm Shopify match' : 'Ready to list');
  }

  function requestedConditionForMatch(match) {
    const wantedSku = String(match?.sku || '').toUpperCase();
    const row = $$('.variant-row', els.variants).find(item => $('.variant-sku', item).value.trim().toUpperCase() === wantedSku);
    return row?.dataset.condition || match?.variant?.title || 'Condition';
  }

  function renderShopifyProductPreview(candidate) {
    if (!candidate?.product) {
      els.shopifyPreview.hidden = true;
      return;
    }
    const product = candidate.product;
    const image = product.image?.url || 'assets/icon.svg';
    els.shopifyPreviewImage.src = image;
    els.shopifyPreviewImage.alt = product.image?.altText || `${product.title || 'Existing Shopify product'} image`;
    els.shopifyPreviewImage.onerror = () => { els.shopifyPreviewImage.onerror = null; els.shopifyPreviewImage.src = 'assets/icon.svg'; };
    els.shopifyPreviewTitle.textContent = product.title || 'Untitled Shopify product';
    const matches = candidate.matches || [];
    const existing = matches.reduce((total, match) => total + (Number(match.existingQuantity) || 0), 0);
    const evidence = (candidate.reasons || []).join(' · ');
    const locationName = els.location.selectedOptions[0]?.textContent || 'selected location';
    els.shopifyPreviewMeta.textContent = [product.status, `${existing} in stock at ${locationName}`, evidence].filter(Boolean).join(' · ');
    els.shopifyPreviewVariants.replaceChildren();
    matches.filter(match => match.found).forEach(match => {
      const item = document.createElement('span');
      item.textContent = `${requestedConditionForMatch(match)} · ${Number(match.existingQuantity) || 0} in stock`;
      els.shopifyPreviewVariants.append(item);
    });
    if (!els.shopifyPreviewVariants.childElementCount) {
      const item = document.createElement('span');
      item.textContent = 'No unique condition variant matched';
      els.shopifyPreviewVariants.append(item);
    }
    els.shopifyPreviewStoreLink.hidden = !product.onlineStoreUrl;
    if (product.onlineStoreUrl) els.shopifyPreviewStoreLink.href = product.onlineStoreUrl;
    else els.shopifyPreviewStoreLink.removeAttribute('href');
    els.shopifyPreview.hidden = false;
  }

  function updateStockCandidateSelection() {
    const candidate = state.stockCandidates.find(item => item.product?.id === els.stockCandidate.value);
    els.confirmStockCandidate.disabled = !candidate?.usable;
    els.stockCandidateLink.hidden = !candidate?.product?.adminUrl;
    if (candidate?.product?.adminUrl) els.stockCandidateLink.href = candidate.product.adminUrl;
    else els.stockCandidateLink.removeAttribute('href');
    els.rejectStockCandidates.hidden = candidate?.canReject === false;
    renderShopifyProductPreview(candidate);
  }

  function renderStockCandidates(candidates) {
    state.stockCandidates = Array.isArray(candidates) ? candidates : [];
    els.stockCandidate.replaceChildren();
    state.stockCandidates.forEach(candidate => {
      const product = candidate.product || {};
      const reasons = (candidate.reasons || []).join(', ') || 'similar title';
      const existing = (candidate.matches || []).reduce((total, match) => total + (Number(match.existingQuantity) || 0), 0);
      const strength = candidate.score ? `${candidate.score} match score` : 'Exact Shopify match';
      const option = new Option(`${strength} · ${product.title || 'Untitled product'} · ${existing} in stock · ${reasons}`, product.id || '');
      option.disabled = !candidate.usable || !product.id;
      els.stockCandidate.add(option);
    });
    const firstUsable = state.stockCandidates.find(candidate => candidate.usable && candidate.product?.id);
    const firstVisible = firstUsable || state.stockCandidates[0];
    if (firstVisible?.product?.id) els.stockCandidate.value = firstVisible.product.id;
    els.stockCandidateSelector.hidden = state.stockCandidates.length < 2;
    updateStockCandidateSelection();
    els.stockCandidateActions.hidden = !state.stockCandidates.length;
  }

  function fillRestockPricesFromShopify() {
    $$('.variant-row', els.variants).forEach(row => {
      const sku = $('.variant-sku', row)?.value.trim().toUpperCase() || '';
      const match = state.stockMatches.get(sku);
      const priceInput = $('.variant-price', row);
      if (!priceInput || !match?.found) return;
      const existing = Number(match.variant?.price);
      if (Number.isFinite(existing) && existing >= 0) {
        priceInput.value = existing.toFixed(2);
      }
      const enabled = !!$('.variant-checkbox', row)?.checked;
      priceInput.disabled = !enabled;
    });
    // Restock pulls the live Shopify price, which the SEO title quotes.
    maybeRebuildSeo();
  }

  function activateConfirmedCandidate(candidate) {
    state.existingProductId = candidate.product.id;
    state.forceCreateNew = false;
    state.stockMode = 'existing';
    state.stockMatches = new Map((candidate.matches || []).map(match => [String(match.sku || '').toUpperCase(), match]));
    state.operationId = '';
    els.stockCandidateActions.hidden = true;
    setExistingEditorMode('restock');
    setStockStatus('existing', 'Existing Shopify product confirmed', 'Add quantity for the conditions you hold. You can also change the Shopify price for each enabled condition before submitting.');
    fillRestockPricesFromShopify();
    renderVariantStock();
    updateCreateButton();
  }

  function confirmExistingCandidate() {
    const candidate = state.stockCandidates.find(item => item.product?.id === els.stockCandidate.value);
    if (!candidate?.usable) {
      showMessage('That product does not have a unique matching condition variant. Choose another result or create a new listing.', 'error');
      return;
    }
    activateConfirmedCandidate(candidate);
  }

  function rejectStockCandidates() {
    // A rejected product that was found by SKU already owns this card's SKU.
    // The server will never create a second product with it (every later check
    // would be ambiguous), so the new listing has to get a SKU of its own.
    const skuOwner = state.stockCandidates.find(candidate => candidate.skuMatch);
    state.existingProductId = '';
    state.forceCreateNew = true;
    // Cancel any in-flight stock check that started before the rejection, or it
    // will finish later and overwrite forceCreateNew / re-show candidates.
    state.stockRequest += 1;
    state.stockMode = 'new';
    state.stockMatches = new Map();
    state.stockCandidates = [];
    state.operationId = '';
    hideStockCandidates();
    setExistingEditorMode('listing');
    setStockStatus('new', 'Creating a separate Shopify listing', 'You confirmed that none of the possible existing products is this card. Exact SKU safeguards will still run on submit.');
    if (skuOwner && state.selected) {
      const takenSkus = (skuOwner.matches || []).map(match => match.sku).filter(Boolean);
      state.skuAttempt += 1;
      state.skuSuffix = skuDisambiguator(state.selected, state.skuAttempt);
      refreshVariantSkus();
      showMessage(`${takenSkus.join(', ') || 'This SKU'} already belongs to “${skuOwner.product?.title || 'another Shopify product'}”, so this listing will use SKU suffix -${state.skuSuffix}. Shopify is being checked again for the new SKU.`, 'warning');
      checkExistingStock();
      return;
    }
    renderVariantStock();
    updateCreateButton();
  }

  /**
   * Short, repeatable tag that separates a card from the product that already
   * holds its base SKU. Language comes first because the base SKU does not
   * carry it; a hash of the card's identity covers everything else.
   */
  function skuDisambiguator(card, attempt) {
    const language = String(card?.languageCode || '').toLowerCase();
    if (attempt === 1 && language && language !== 'en') return skuSlug(language, 3);
    const seed = [card?.externalId, card?.name, card?.setName, card?.cardNumber, language, attempt].join('|');
    let hash = 2166136261;
    for (const char of seed) hash = Math.imul(hash ^ char.codePointAt(0), 16777619) >>> 0;
    return 'X' + hash.toString(36).toUpperCase().padStart(4, '0').slice(-4);
  }

  function refreshVariantSkus() {
    if (!state.selected) return;
    $$('.variant-row', els.variants).forEach(row => {
      const input = $('.variant-sku', row);
      if (input) input.value = makeSku(state.selected, row.dataset.condition);
    });
    state.operationId = '';
  }

  /**
   * Once staff dismiss a possible match — or edit listing identity after seeing
   * one — do not keep re-surfacing candidates until the next card is selected.
   */
  function dismissPendingStockSuggestion() {
    if (state.stockMode === 'candidate' && !state.existingProductId) {
      state.forceCreateNew = true;
      state.stockRequest += 1;
      state.stockMode = 'new';
      state.stockCandidates = [];
      hideStockCandidates();
      setExistingEditorMode('listing');
      setStockStatus('new', 'Creating a separate Shopify listing', 'Possible matches dismissed for this card after you edited the listing. Exact SKU safeguards still run on submit.');
      updateCreateButton();
    }
  }

  function stockIdentity() {
    const card = state.selected || {};
    return {
      externalId: card.externalId || '',
      title: els.title.value.trim() || buildTitle(),
      name: card.name || '',
      englishName: els.englishName.value.trim() || card.englishName || '',
      setName: card.setName || '',
      // The store's own set name ("Pitch Black", not "ME05: Pitch Black"), so
      // existing titles and metafields written in house style still match.
      englishSetName: els.englishSet.value.trim() && els.englishSet.value.trim() !== card.setName
        ? els.englishSet.value.trim()
        : (state.autofill.plan?.set?.seoName || card.englishSetName || ''),
      cardNumber: card.cardNumber || '',
      finish: els.finish.value || '',
      game: card.game || '',
      gameName: gameLabel(card.game)
    };
  }

  function enabledStockVariants() {
    return $$('.variant-row', els.variants)
      .filter(row => $('.variant-checkbox', row).checked)
      .map(row => ({ condition: row.dataset.condition, sku: $('.variant-sku', row).value.trim() }))
      .filter(variant => variant.condition && variant.sku);
  }

  function renderVariantStock() {
    $$('.variant-row', els.variants).forEach(row => {
      const sku = $('.variant-sku', row)?.value.trim().toUpperCase() || '';
      const match = state.stockMatches.get(sku);
      const stock = $('.variant-stock', row);
      const enabled = !!$('.variant-checkbox', row)?.checked;
      if (!stock) return;
      row.classList.remove('has-stock', 'stock-conflict');
      if (!enabled) {
        stock.textContent = 'Enable this condition to check its Shopify stock';
        return;
      }
      if (!match) {
        stock.textContent = state.stockMode === 'candidate'
          ? 'Confirm whether a possible existing product is this card'
          : (state.stockMode ? 'No existing Shopify stock' : 'Stock not checked yet');
        return;
      }
      if (match.ambiguous) {
        row.classList.add('stock-conflict');
        stock.textContent = 'Duplicate SKU in Shopify';
        return;
      }
      if (match.found) {
        row.classList.add('has-stock');
        const add = enabled ? Math.max(0, Number($('.variant-quantity', row)?.value) || 0) : 0;
        const existing = Number(match.existingQuantity) || 0;
        stock.textContent = enabled
          ? `${existing} in stock · add ${add} → ${existing + add}`
          : `${existing} in stock at this location`;
      } else {
        stock.textContent = 'No matching Shopify SKU';
      }
    });
  }

  async function checkExistingStock() {
    if (!state.selected) return;
    const requestId = ++state.stockRequest;
    const confirmedProductId = state.existingProductId;
    const retainConfirmation = state.stockMode === 'existing' && !!confirmedProductId;
    // Keep a staff rejection across title/merch edits until the next card.
    const forceCreateNew = !!state.forceCreateNew && !retainConfirmation;
    if (!els.location.value) {
      state.stockMatches = new Map();
      state.stockMode = '';
      state.existingProductId = '';
      hideStockCandidates();
      setExistingEditorMode('listing');
      setStockStatus('waiting', 'Choose an inventory location', 'Stock is checked against the selected Shopify location.');
      renderVariantStock();
      updateCreateButton();
      return;
    }

    const variants = enabledStockVariants();
    if (!variants.length) {
      if (retainConfirmation) setExistingEditorMode('restock');
      else setExistingEditorMode('listing');
      setStockStatus('waiting', 'Enable a condition', 'Choose at least one physical condition before checking Shopify stock.');
      renderVariantStock();
      updateCreateButton();
      return;
    }
    state.stockMatches = new Map();
    state.stockMode = '';
    state.existingProductId = '';
    state.forceCreateNew = forceCreateNew;
    hideStockCandidates();
    setExistingEditorMode(retainConfirmation ? 'decision' : 'listing');
    setStockStatus('loading', 'Checking Shopify stock…', 'Checking exact SKUs, then card title, set name, printed number and condition variants.');
    try {
      const data = await api('api/check-stock.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
        body: JSON.stringify({
          locationId: els.location.value,
          identity: stockIdentity(),
          variants,
          forceCreateNew,
          preferredProductId: retainConfirmation ? confirmedProductId : ''
        })
      });
      if (requestId !== state.stockRequest) return;
      // Re-read after await: staff may have rejected while this request was in flight.
      const effectiveForceNew = forceCreateNew || !!state.forceCreateNew;
      state.forceCreateNew = effectiveForceNew;
      state.stockMode = data.mode;
      state.stockMatches = new Map((data.matches || []).map(match => [String(match.sku || '').toUpperCase(), match]));
      const product = data.products?.[0];
      if (data.mode === 'existing') {
        const candidate = {
          product,
          matches: data.matches || [],
          usable: true,
          score: data.score || 0,
          reasons: [data.matchMethod, ...(data.reasons || [])].filter(Boolean),
          canReject: true
        };
        const exactSku = data.matchMethod === 'Exact SKU' || data.matchMethod === 'SKU and condition';
        candidate.skuMatch = exactSku;
        if (retainConfirmation && confirmedProductId === product?.id) {
          activateConfirmedCandidate(candidate);
        } else if (effectiveForceNew && !exactSku) {
          state.stockMode = 'new';
          setExistingEditorMode('listing');
          setStockStatus('new', 'Creating a separate Shopify listing', 'Possible existing matches stay dismissed for this card. Exact SKU safeguards still run on submit.');
        } else {
          state.stockMode = 'candidate';
          setExistingEditorMode('decision');
          renderStockCandidates([candidate]);
          setStockStatus('existing', 'Confirm the existing Shopify product', 'Compare the Shopify preview below with the selected card. Stock cannot be changed until you confirm the match.');
        }
      } else if (data.mode === 'mixed') {
        setExistingEditorMode('listing');
        setStockStatus('conflict', 'Existing and new condition SKUs are mixed', 'Enable only existing conditions or add the missing condition variant in Shopify first.');
      } else if (data.mode === 'ambiguous') {
        setExistingEditorMode('listing');
        setStockStatus('conflict', 'Duplicate Shopify SKU found', 'Resolve the duplicate SKU in Shopify before adding stock.');
      } else if (data.mode === 'candidate') {
        if (effectiveForceNew) {
          state.stockMode = 'new';
          setExistingEditorMode('listing');
          setStockStatus('new', 'Creating a separate Shopify listing', 'Possible existing matches stay dismissed for this card. Exact SKU safeguards still run on submit.');
        } else {
          const candidates = (data.candidates || []).map(candidate => ({ ...candidate, canReject: true }));
          state.stockMode = 'candidate';
          setExistingEditorMode('decision');
          renderStockCandidates(candidates);
          const retained = retainConfirmation ? candidates.find(candidate => candidate.usable && candidate.product?.id === confirmedProductId) : null;
          const best = candidates[0];
          const summary = best
            ? `Best result: ${best.product?.title || 'Untitled product'} (${best.score || 0} match score). Review the possible products before any inventory update.`
            : 'A similar title was found, but its condition variants could not be matched safely. Confirm that it is separate before creating a new listing.';
          if (retained) {
            els.stockCandidate.value = retained.product.id;
            updateStockCandidateSelection();
            activateConfirmedCandidate(retained);
          } else {
            setStockStatus('warning', 'Possible existing listing needs confirmation', summary);
          }
        }
      } else {
        setExistingEditorMode('listing');
        setStockStatus(
          'new',
          effectiveForceNew ? 'Creating a separate Shopify listing' : 'No existing listing found',
          effectiveForceNew
            ? 'Possible existing matches stay dismissed for this card. Exact SKU safeguards still run on submit.'
            : 'Submitting will create a new Shopify product with the quantities below.'
        );
      }
      renderVariantStock();
      updateCreateButton();
      const shopifyNm = existingShopifyNmPrice();
      if (state.selected && shouldFetchCompetitorPrices(state.selected) && (data.mode === 'existing' || data.mode === 'candidate' || shopifyNm != null)) {
        maybeOverlayCompetitorPrices(state.selected, { currentNm: shopifyNm });
      }
    } catch (error) {
      if (requestId !== state.stockRequest) return;
      state.stockMode = '';
      hideStockCandidates();
      setExistingEditorMode('listing');
      setStockStatus('warning', 'Shopify stock check unavailable', `${error.message} The server will check again before any inventory change.`);
      renderVariantStock();
      updateCreateButton();
    }
  }

  let stockCheckTimer;
  function scheduleStockCheck() {
    clearTimeout(stockCheckTimer);
    stockCheckTimer = setTimeout(checkExistingStock, 320);
  }

  function isOnePiece(game) {
    return /one-piece/i.test(String(game || ''));
  }

  function isPokemon(game) {
    return /pokemon/i.test(String(game || ''));
  }

  function isDisneyLorcana(game) {
    return /disney|lorcana/i.test(String(game || ''));
  }

  function isMagic(game) {
    return /magic|mtg/i.test(String(game || ''));
  }

  function usesFoilNotHolo(game) {
    return isDisneyLorcana(game) || isMagic(game);
  }

  function onePieceSetCode(card) {
    const direct = String(card.setCode || '').trim();
    if (direct) return direct.toUpperCase();
    const number = String(card.cardNumber || card.number || '');
    const match = number.match(/\b([A-Z]{1,8}\d{1,4}[A-Z]?)\b/i);
    return match ? match[1].toUpperCase() : '';
  }

  /**
   * Everything the editor auto-fills is derived from this one card only, so a
   * previous card's set, era or language can never leak into the next listing.
   * The set table, tag spellings and era names live in assets/ll-catalogue.js,
   * built from the tags the store already uses.
   */
  function buildAutofillPlan(card) {
    const game = card?.game || '';
    const sealed = state.mode === 'sealed';
    const releaseDate = resolveSetReleaseDate(card);
    const cc = { ...catalogueCard(card), setReleaseDate: releaseDate };
    const set = C.resolveSet(cc);
    const preOrder = sealed && /^\d{4}-\d{2}-\d{2}$/.test(releaseDate) && releaseDate > new Date().toISOString().slice(0, 10);
    const tags = C.buildTags(cc, { set, sealed, finish: els.finish?.value || '', preOrder });
    const plan = {
      game,
      set,
      productType: productTypeDefaults[game] || (isPokemon(game) ? 'Pokemon' : gameLabel(game)),
      vendor: vendorDefault(game),
      setTag: set.tag,
      eraTag: set.era,
      titleSet: set.segment,
      seoSet: set.seoName,
      setCode: isOnePiece(game) ? onePieceSetCode(card) : '',
      preOrder,
      tags
    };
    // Collections are matched on the card's own tags, exact title only.
    plan.collections = plan.tags.filter(tag => tag !== SINGLES_TAG && tag !== 'Foil' && tag !== 'Sealed Product');
    return plan;
  }

  function listingHasFoil(card) {
    const finish = String(els.finish?.value || card?.finish || '').trim();
    if (/foil/i.test(finish)) return true;
    const name = String(card?.englishName || card?.name || els.englishName?.value || '');
    return /\(\s*foil\s*\)/i.test(name);
  }

  /** Keep the Foil tag in sync with finish without wiping other manual tag edits. */
  function syncFoilTag(card) {
    if (!els.tags || isPokemon(card?.game)) return;
    const want = listingHasFoil(card);
    const existing = [...els.tags.options].find(option => normalize(option.value || option.textContent) === 'foil');
    if (want) {
      addSelectOption(els.tags, 'Foil', 'Foil', true);
    } else if (existing) {
      existing.selected = false;
    }
    renderPickerChips('tags');
    if (state.autofill?.plan) {
      const tags = new Set(state.autofill.plan.tags || []);
      if (want) tags.add('Foil');
      else tags.delete('Foil');
      state.autofill.plan.tags = [...tags];
    }
  }

  /** Storefront breadcrumbs read custom.primary_collection: prefer the set, then the era. */
  function resolvePrimaryCollection(plan) {
    const collections = state.shopMeta?.collections || [];
    for (const title of [plan.setTag, plan.eraTag]) {
      const needle = normalize(title);
      if (!needle) continue;
      const match = collections.find(collection => normalize(collection.title) === needle);
      if (match) return match;
    }
    return null;
  }

  /** JustTCG ships a release date per set; custom.release_date is otherwise blank. */
  function resolveSetReleaseDate(card) {
    const sets = state.setsByGame[card?.game] || [];
    const wanted = [card?.setId, card?.englishSetName, card?.setName]
      .map(value => normalize(value))
      .filter(Boolean);
    if (!wanted.length) return '';
    const match = sets.find(set => wanted.includes(normalize(set.id)) || wanted.includes(normalize(set.name)));
    const date = String(match?.releaseDate || '').trim().slice(0, 10);
    return /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : '';
  }

  function renderAutofillSummary() {
    if (!els.autofillSummary) return;
    const { plan, primaryCollection, setReleaseDate } = state.autofill;
    if (!plan) {
      els.autofillSummary.hidden = true;
      return;
    }
    const parts = [
      `Filed as ${plan.productType}`,
      plan.setTag ? `set tag ${plan.setTag}` : '',
      plan.eraTag ? `era ${plan.eraTag}` : (isPokemon(plan.game) && !plan.set?.promoTag ? 'no era: this set is not in the store table yet' : ''),
      primaryCollection ? `breadcrumb ${primaryCollection.title}` : 'no breadcrumb collection matched',
      setReleaseDate ? `released ${setReleaseDate}` : '',
      plan.preOrder ? 'tagged Pre-Order until release' : ''
    ].filter(Boolean);
    els.autofillSummary.textContent = parts.join(' · ');
    els.autofillSummary.hidden = false;
  }

  function applyAutofill(card) {
    if (!card) return;
    state.autofill.setReleaseDate = resolveSetReleaseDate(card);
    const plan = buildAutofillPlan(card);
    state.autofill = {
      plan,
      primaryCollection: resolvePrimaryCollection(plan),
      setReleaseDate: resolveSetReleaseDate(card)
    };
    chooseLiveValue(els.vendor, plan.vendor);
    chooseLiveValue(els.productType, plan.productType);

    [...els.tags.options].forEach(option => { option.selected = false; });
    plan.tags.forEach(tag => addSelectOption(els.tags, tag, tag, true));
    renderPickerChips('tags');

    const wanted = new Set(plan.collections.map(value => normalize(value)));
    [...els.collections.options].forEach(option => {
      option.selected = wanted.has(normalize(option.textContent));
    });
    renderPickerChips('collections');
    renderAutofillSummary();
  }

  function normalize(value) {
    return String(value || '').toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '');
  }

  function cardRarityValue(card) {
    if (!card || typeof card !== 'object') return '';
    const raw = firstNonEmpty([
      card.rarity,
      card.rarityName,
      card.rarity_name,
      card.details?.rarity,
      card.details?.rarityName
    ]);
    return String(raw || '').trim();
  }

  function firstNonEmpty(values) {
    for (const value of values) {
      if (value == null) continue;
      if (typeof value === 'string' && !value.trim()) continue;
      if (typeof value === 'object') continue;
      return value;
    }
    return '';
  }

  // Exact match first; fuzzy only when lengths are close (avoids Rare→Super Rare).
  function bestTaxonomyOptionMatch(select, rawWanted) {
    const wanted = normalize(rawWanted);
    if (!wanted || !select) return null;
    const options = [...select.options].filter(option => option && (option.value || option.textContent));
    let best = null;
    let bestScore = 0;

    options.forEach(option => {
      const label = normalize(option.textContent);
      const value = normalize(option.value);
      [label, value].forEach(candidate => {
        if (!candidate) return;
        const score = taxonomyMatchScore(wanted, candidate);
        if (score > bestScore) {
          bestScore = score;
          best = option;
        }
      });
    });

    return bestScore > 0 ? best : null;
  }

  function taxonomyMatchScore(wanted, candidate) {
    if (!wanted || !candidate) return 0;
    if (wanted === candidate) return 10000 + candidate.length;

    const shorter = wanted.length <= candidate.length ? wanted : candidate;
    const longer = wanted.length <= candidate.length ? candidate : wanted;
    const ratio = shorter.length / longer.length;

    if (candidate.startsWith(wanted) || wanted.startsWith(candidate)) {
      // Allow light prefix/suffix wording diffs, but reject distant substrings.
      if (ratio < 0.45) return 0;
      return 5000 + Math.round(ratio * 100) + shorter.length;
    }

    if (candidate.includes(wanted) || wanted.includes(candidate)) {
      // Strict includes: blocks Rare↔Super Rare and Common↔Uncommon false friends.
      if (ratio < 0.85) return 0;
      return 1000 + Math.round(ratio * 100) + shorter.length;
    }

    return 0;
  }

  function renderVariants(card) {
    els.variants.replaceChildren();
    const sealed = state.mode === 'sealed';
    if (els.variantsTitle) els.variantsTitle.textContent = sealed ? 'Price and quantity' : 'Conditions held';
    if (els.variantsHelp) els.variantsHelp.textContent = sealed
      ? 'Sealed product is one variant. Quantity is added to Shopify stock, never used as a replacement total.'
      : 'Tick each condition you hold. Quantity is added to Shopify stock, never used as a replacement total.';
    // Sealed product is a single variant under Shopify's own placeholder option.
    (sealed ? ['Default Title'] : conditions).forEach((condition, index) => {
      const fragment = $('#variant-template')?.content.cloneNode(true);
      const row = fragment && $('.variant-row', fragment);
      if (!row) return;
      const checkbox = $('.variant-checkbox', row);
      const conditionLabel = $('.condition-name', row);
      if (conditionLabel) conditionLabel.textContent = sealed ? 'Sealed product' : condition;
      checkbox.checked = index === 0;
      if (sealed) checkbox.disabled = true;
      row.dataset.condition = condition;
      const inputs = $$('.variant-price, .variant-quantity, .variant-sku', row);
      inputs.forEach(input => { input.disabled = !checkbox.checked; });
      const suggested = marketPriceForCondition(card, condition);
      $('.variant-price', row).value = suggested != null && suggested > 0 ? suggested.toFixed(2) : '0.00';
      $('.variant-sku', row).value = makeSku(card, condition);
      checkbox.addEventListener('change', () => {
        inputs.forEach(input => { input.disabled = !checkbox.checked; });
        state.operationId = '';
        scheduleStockCheck();
        // The description lists the conditions held.
        rebuildDescription();
      });
      inputs.forEach(input => input.addEventListener('input', () => {
        state.operationId = '';
        if (input.classList.contains('variant-sku')) scheduleStockCheck();
        else {
          renderVariantStock();
          if (input.classList.contains('variant-price') && (condition === 'Near Mint' || condition === 'Default Title')) {
            maybeRebuildSeo();
            if (state.selected?.competitorCompare) renderMarketSummary(state.selected);
          }
        }
      }));
      els.variants.append(row);
    });
  }

  /**
   * SKU is the join key Shopify restocks match on, so it has to be stable:
   * the same physical card must produce the same SKU every time, whoever
   * types it in and whatever the provider returns.
   *
   * The previous scheme was not. It read the set from titleSet(), which falls
   * back to an editable field, so "SCARLET & VIOLET BASE" and "Scarlet &
   * Violet Base Set" produced two SKUs for one card. It also passed the
   * collector number through raw, so "080/196" and "80/196" diverged. And it
   * pasted full names together then truncated at 100 characters, which a long
   * Magic set name already exceeds ("Dungeons & Dragons: Adventures in the
   * Forgotten Realms" reaches 102).
   *
   * This builds from stable identifiers only, in a fixed short form:
   *
   *   LL-PKM-SVB-080-RH-NM
   *
   * Nothing here comes from a field staff can edit.
   */
  const SKU_GAME_CODES = {
    pokemon: 'PKM',
    'magic-the-gathering': 'MTG',
    magic: 'MTG',
    mtg: 'MTG',
    'disney-lorcana': 'LOR',
    lorcana: 'LOR',
    'one-piece-card-game': 'OPC',
    'one-piece': 'OPC',
    digimon: 'DGM',
    'digimon-card-game': 'DGM',
    'yu-gi-oh': 'YGO',
    yugioh: 'YGO',
    'star-wars-unlimited': 'SWU',
  };

  // Must stay identical to SKU_FINISH_CODES in lib/sku.php. If the two drift,
  // the intake tool and the backfill mint different SKUs for the same card.
  const SKU_FINISH_CODES = {
    '': 'STD',
    standard: 'STD',
    normal: 'STD',
    holo: 'HOLO',
    holofoil: 'HOLO',
    'reverse holo': 'RH',
    'reverse foil': 'RH',
    foil: 'FOIL',
    'cold foil': 'FOIL',
    sealed: 'SLD',
    'non-holo': 'NH',
    'pokeball reverse holo': 'PBRH',
    'masterball reverse holo': 'MBRH',
    'ball reverse holo': 'BRH',
    'energy reverse holo': 'ERH',
    'rocket reverse holo': 'RRH',
  };

  const SKU_CONDITION_CODES = {
    'near mint': 'NM',
    'lightly played': 'LP',
    'moderately played': 'MP',
    'heavily played': 'HP',
    damaged: 'DMG',
  };

  const skuSlug = (value, max) => String(value || '')
    .normalize('NFKD')
    .replace(/[^a-z0-9]+/gi, '')
    .toUpperCase()
    .slice(0, max);

  function skuGameCode(game) {
    const key = String(game || '').toLowerCase().trim();
    return SKU_GAME_CODES[key] || skuSlug(key, 4) || 'TCG';
  }

  /**
   * The set component comes from the English set name, not the provider's set
   * code.
   *
   * This matters for the backfill. The products already in the store have no
   * provider set code, only a set name in their title and metafields. If this
   * tool keyed on the code and the backfill keyed on the name, the two would
   * mint different SKUs for the same card and the join would never close. The
   * name is on both paths, and slugging makes "LOST ORIGIN" and "Lost Origin"
   * agree.
   */
  function skuSetCode(card) {
    const name = String(card.englishSetName || card.setName || '').trim();
    // 16, not 12. At 12 "MCDONALDS 2022", "MCDONALDS 2023" and "MCDONALDS
    // 2024" all collapse to MCDONALDS202 and collide.
    return skuSlug(name, 16) || 'SET';
  }

  /**
   * Local number, zero-padded, plus the set total when the card has one. The
   * total keeps two sets apart if their names slug to the same twelve
   * characters.
   */
  function skuNumber(card) {
    const raw = String(card.cardNumber || card.externalId || '').trim();
    if (!raw) return 'NA';
    const slash = raw.match(/^0*(\d+)([a-z]?)\s*\/\s*0*(\d+)([a-z]?)$/i);
    if (slash) {
      const local = slash[1].padStart(3, '0') + (slash[2] || '').toUpperCase();
      return local + '-' + slash[3] + (slash[4] || '').toUpperCase();
    }
    return skuSlug(raw, 14) || 'NA';
  }

  /**
   * Sealed product: LL-PKM-SLD-PITCHBLACK-ELITETRAINERBOX. Twin of
   * sku_build_sealed() in lib/sku.php.
   */
  function makeSealedSku(card) {
    const setName = String(state.autofill.plan?.set?.seoName || card.englishSetName || card.setName || '').trim();
    const product = C ? C.sealedProduct(catalogueCard(card), { set: state.autofill.plan?.set }) : String(card.name || '');
    return ['LL', skuGameCode(card.game), 'SLD', skuSlug(setName, 16) || 'SET', skuSlug(product, 24) || 'ITEM', state.skuSuffix]
      .filter(Boolean).join('-').slice(0, 100);
  }

  function makeSku(card, condition) {
    if (condition === 'Default Title' || state.mode === 'sealed') return makeSealedSku(card);
    const finishKey = String(els.finish.value || '').toLowerCase().trim();
    const conditionKey = String(condition || '').toLowerCase().trim();
    const parts = [
      'LL',
      skuGameCode(card.game),
      skuSetCode(card),
      skuNumber(card),
      SKU_FINISH_CODES[finishKey === 'standard' ? '' : finishKey] || skuSlug(finishKey, 5) || 'STD',
      state.skuSuffix,
      SKU_CONDITION_CODES[conditionKey] || skuSlug(conditionKey, 4) || 'NM',
    ];
    return parts.filter(Boolean).join('-').slice(0, 100);
  }

  function populateTaxonomyOptions(optionsByAlias) {
    const fields = $$('.taxonomy-field');
    if (!fields.length) return;
    let liveCount = 0;
    fields.forEach(field => {
      const alias = field.dataset?.alias || categoryKeyAliases[field.dataset?.key] || '';
      const select = $('select', field);
      if (!select) return;
      const values = Array.isArray(optionsByAlias?.[alias]) ? optionsByAlias[alias] : [];
      select.replaceChildren();
      values
        .slice()
        .sort((a, b) => String(a?.displayName || '').localeCompare(String(b?.displayName || '')))
        .forEach(item => {
          if (item?.id && item?.displayName) select.add(new Option(item.displayName, item.id));
        });
      if (values.length) liveCount += 1;
      select.hidden = values.length === 0;
    });
    if (els.taxonomyState) {
      els.taxonomyState.textContent = liveCount ? `${liveCount}/10 live` : 'Manual fallback';
      els.taxonomyState.classList.toggle('warning', liveCount < 10);
    }
  }

  function applyTaxonomyDefaults(card) {
    const fields = $$('.taxonomy-field');
    if (!fields.length || !card) return;
    const defaults = {
      'toy-game-material': 'Cardboard',
      'card-attributes': els.finish?.value === 'Standard' ? '' : (els.finish?.value || ''),
      condition: 'Near Mint',
      grading: 'Ungraded',
      rarity: cardRarityValue(card),
      theme: gameLabel(card.game),
      // Already desired for all TCG single-card intake.
      'trading-card-packaging': 'Single card'
    };
    // One Piece–specific category metafield defaults.
    if (isOnePiece(card.game)) {
      defaults['age-group'] = 'All ages';
      defaults['product-use'] = 'Collectible/numismatic';
      defaults.theme = 'Anime';
    }
    fields.forEach(field => {
      const key = field.dataset.key;
      const select = $('select', field);
      const input = $('input', field);
      if (select) [...select.options].forEach(option => { option.selected = false; });
      const wantedRaw = defaults[key];
      if (input && wantedRaw !== undefined) input.value = wantedRaw || '';
      if (!wantedRaw || !select) return;
      const match = bestTaxonomyOptionMatch(select, wantedRaw);
      if (match) match.selected = true;
    });
  }

  function categoryDefinition(key) {
    return (state.shopMeta?.categoryMetafieldDefinitions || []).find(
      definition => definition?.namespace === 'shopify' && definition?.key === key
    ) || null;
  }

  function collectCategoryMetafields() {
    // Constrained shopify.* attrs require a matching product category.
    const categoryId = els.category?.value || '';
    if (!categoryId) return [];

    const definitionKeys = new Set(
      (state.shopMeta?.categoryMetafieldDefinitions || [])
        .filter(definition => definition?.namespace === 'shopify' && definition?.key)
        .map(definition => definition.key)
    );
    const seen = new Set();

    return $$('.taxonomy-field').map(field => {
      const key = field?.dataset?.key;
      if (!key || seen.has(key)) return null;
      seen.add(key);
      const select = $('select', field);
      const input = $('input', field);
      const selectedOptions = select ? [...select.selectedOptions].filter(option => option?.value) : [];
      const definition = categoryDefinition(key);
      const manual = input?.value?.trim() || '';
      const displayParts = [
        ...selectedOptions.map(option => (option.textContent || '').trim()),
        manual
      ].filter(Boolean);
      const displayValue = [...new Set(displayParts)].join(', ');
      if (!displayValue && !selectedOptions.length) return null;

      let value = '';
      let type = definition?.type?.name || '';
      // Only write shopify standard values for defs that apply to this category.
      const canUseStandard = !definitionKeys.size || definitionKeys.has(key);
      if (canUseStandard && selectedOptions.length && type === 'list.metaobject_reference') {
        value = JSON.stringify(selectedOptions.map(option => option.value));
      } else if (canUseStandard && selectedOptions.length && type === 'metaobject_reference') {
        value = selectedOptions[0].value;
      } else if (canUseStandard && manual && type === 'single_line_text_field') {
        value = manual;
      } else if (canUseStandard && manual && type === 'list.single_line_text_field') {
        value = JSON.stringify([manual]);
      } else {
        // Keep displayValue for tcg_category fallback; clear typed standard value.
        type = '';
        value = '';
      }

      if (!value && !displayValue) return null;
      return { key, type, value, displayValue };
    }).filter(Boolean);
  }

  function collectPayload() {
    const card = state.selected;
    const plan = state.autofill.plan || {};
    const image = state.image || null;
    let imagePayload = null;
    if (image?.kind === 'own' && image.staged?.url) {
      imagePayload = { source: 'staged', url: image.staged.url, alt: els.imageAlt?.value.trim() || '', kind: 'own', filename: image.staged.filename };
    } else if (image?.url && image.source === 'url') {
      imagePayload = { source: 'url', url: image.url, alt: els.imageAlt?.value.trim() || '', kind: image.kind };
    }
    return {
      ...card,
      kind: state.mode === 'sealed' ? 'sealed' : 'single',
      englishName: els.englishName.value.trim(),
      englishSetName: els.englishSet.value.trim(),
      printedNumber: printedNumber(),
      title: els.title.value.trim(),
      finish: state.mode === 'sealed' ? '' : els.finish.value,
      vendor: els.vendor.value,
      productType: els.productType.value,
      categoryId: els.category.value,
      descriptionHtml: els.description.value.trim(),
      tags: [...els.tags.selectedOptions].map(option => option.value),
      collectionIds: [...els.collections.selectedOptions].map(option => option.value),
      seoTitle: els.seoTitle?.value.trim() || '',
      seoDescription: els.seoDescription?.value.trim() || '',
      setTag: plan.setTag || '',
      eraTag: plan.eraTag || '',
      setCode: plan.setCode || '',
      primaryCollectionId: state.autofill.primaryCollection?.id || '',
      setReleaseDate: state.autofill.setReleaseDate || '',
      tcgCardId: state.extras?.tcgCardId || '',
      tcgSetId: state.extras?.tcgSetId || '',
      image: imagePayload,
      imageUrl: '',
      attachScanToExisting: !!(els.attachScanExisting?.checked && image?.kind === 'own' && image.staged?.url),
      locationId: els.location.value,
      status: els.status.value,
      publicationIds: [...els.publications.selectedOptions].map(option => option.value),
      operationId: state.operationId,
      existingProductId: state.existingProductId,
      forceCreateNew: state.forceCreateNew,
      categoryMetafields: collectCategoryMetafields(),
      variants: $$('.variant-row', els.variants).map(row => ({
        enabled: $('.variant-checkbox', row).checked,
        condition: row.dataset.condition,
        price: $('.variant-price', row).value,
        quantity: $('.variant-quantity', row).value,
        sku: $('.variant-sku', row).value.trim()
      }))
    };
  }

  async function createProduct(event) {
    event.preventDefault();
    if (!state.selected || !els.productForm.reportValidity()) return;
    if (state.stockMode === 'candidate') {
      showMessage('Confirm the matching Shopify product or choose “None match” before uploading.', 'error');
      return;
    }
    if (state.selected.languageCode === 'ja' && !els.englishName.value.trim()) {
      showMessage('Enter the English card name for this Japanese product.', 'error');
      els.englishName.focus();
      return;
    }
    const enabled = $$('.variant-checkbox:checked', els.variants);
    if (!enabled.length) {
      showMessage('Enable at least one physical condition variant.', 'error');
      return;
    }
    state.operationId ||= makeOperationId();
    state.submitting = true;
    updateCreateButton();
    // A scan made here is uploaded in the background when it is attached; if
    // that has not finished, finish it now. A listing never goes up with a
    // half-uploaded picture.
    if (state.image?.kind === 'own' && !state.image.staged) {
      els.createButton.textContent = 'Uploading the scan…';
      showMessage('Finishing the scan upload…');
      try {
        await stageOwnImage();
      } catch (error) {
        showMessage(`The scan did not upload: ${error.message} Try again, or choose another picture.`, 'error');
        state.submitting = false;
        updateCreateButton();
        return;
      }
    }
    els.createButton.textContent = state.stockMode === 'existing' ? 'Adding stock in Shopify…' : 'Creating in Shopify…';
    showMessage('Re-checking Shopify and applying the safe inventory action…');
    try {
      const data = await api('api/create-product.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
        body: JSON.stringify(collectPayload())
      });
      const variantCount = data.product.variants?.nodes?.length || enabled.length;
      if (data.action === 'restocked') {
        const inventory = data.inventory || {};
        const units = Number(inventory.added || 0);
        const priceNote = Number(inventory.pricesUpdated || 0) > 0
          ? ` Updated ${Number(inventory.pricesUpdated)} price${Number(inventory.pricesUpdated) === 1 ? '' : 's'} in Shopify.`
          : '';
        const seoNote = data.seoRefreshed ? ' The SEO title now quotes the new price.' : '';
        const scanNote = data.scanAttached?.mediaId ? ' Your scan is now the first picture.' : (data.scanAttached?.error ? ` The scan could not be added: ${data.scanAttached.error}` : '');
        showMessage(`Added ${units} ${state.mode === 'sealed' ? 'unit' : 'card'}${units === 1 ? '' : 's'} to “${data.product.title}”. Stock at this location is now ${Number(inventory.current || 0)}; the previous ${Number(inventory.previous || 0)} was preserved.${priceNote}${seoNote}${scanNote}`, data.scanAttached?.error ? 'warning' : 'success');
        noteIntakeLocally('restocked', data.product, units);
        els.createButton.textContent = 'Shopify stock updated ✓';
        els.confirmed.checked = false;
        queueNextCard();
        return;
      }
      const publication = data.publication || {};
      const publicationText = els.status.value === 'ACTIVE'
        ? ` Published to ${publication.published || 0} channel${publication.published === 1 ? '' : 's'}.`
        : ' It remains unpublished while in Draft status.';
      const categoryMeta = data.categoryMetafields || {};
      const categoryText = categoryMeta.requested
        ? ` Category metafields set: ${categoryMeta.set || 0}/${categoryMeta.requested}.`
        : '';
      const cardIdText = data.tcgCardId
        ? ` Card panel id ${data.tcgCardId} stored.`
        : (isPokemon(state.selected?.game) && state.mode !== 'sealed' ? ' The card panel id could not be resolved, so the product page falls back to the image file name.' : '');
      const linked = Object.keys(data.catalogueLinks || {});
      const linkText = linked.length ? ` Filters linked: ${linked.map(k => k.replace('_name', '').replace('_', ' ')).join(', ')}.` : '';
      const imageText = data.imageKind === 'own' ? ' Your scan is the product photo.' : (data.imageKind === 'digital' ? ' The photo is a digital render; replace it with a scan when you can.' : '');
      const errors = [
        ...(publication.errors?.length ? [`Channel warning: ${publication.errors.join(' ')}`] : []),
        ...(categoryMeta.errors?.length ? [`Category metafield warning: ${categoryMeta.errors.join(' ')}`] : [])
      ].join(' ');
      const variantText = state.mode === 'sealed' ? '' : ` with ${variantCount} condition variant${variantCount === 1 ? '' : 's'}`;
      showMessage(`Created “${data.product.title}”${variantText}.${publicationText}${imageText}${linkText}${categoryText}${cardIdText}${errors ? ` ${errors}` : ''}`, errors ? 'warning' : 'success');
      // enabled holds checkbox elements, so the quantities come off their rows.
      noteIntakeLocally('created', data.product, enabled.reduce((sum, box) => {
        const qty = Number($('.variant-quantity', box.closest('.variant-row'))?.value);
        return sum + (Number.isFinite(qty) ? qty : 0);
      }, 0));
      els.createButton.textContent = 'Created in Shopify ✓';
      els.confirmed.checked = false;
      queueNextCard();
    } catch (error) {
      showMessage(error.message, 'error');
      state.submitting = false;
      updateCreateButton();
    }
  }

  function queueNextCard() {
    if (els.nextCard) els.nextCard.hidden = false;
    // Keep staff in a fast loop: preserve game/set/location and jump back to identify.
    setTimeout(() => prepareNextCard(false), 650);
  }

  function prepareNextCard(announce = true) {
    const keptSet = els.setQuery.value;
    const keptGame = els.game.value;
    const keptLanguage = els.language.value;
    const keptLocation = els.location.value;
    const keptStatus = els.status.value;

    state.results = [];
    state.selected = null;
    state.titleDirty = false;
    state.stockMode = '';
    state.stockMatches = new Map();
    state.stockCandidates = [];
    state.existingProductId = '';
    state.forceCreateNew = false;
    state.skuSuffix = '';
    state.skuAttempt = 0;
    state.stockRequest += 1;
    state.totalCardsRequest += 1;
    state.operationId = '';
    state.submitting = false;
    state.autofill = { plan: null, primaryCollection: null, setReleaseDate: '' };
    state.seoDirty = false;
    renderAutofillSummary();
    if (els.seoTitle) els.seoTitle.value = '';
    if (els.seoDescription) els.seoDescription.value = '';
    updateSeoCounts();

    els.query.value = '';
    els.numberQuery.value = '';
    els.setQuery.value = keptSet;
    els.resultsPanel.hidden = true;
    els.results.replaceChildren();
    els.emptyEditor.hidden = false;
    els.productForm.hidden = true;
    els.editorState.textContent = 'Waiting for match';
    els.editorState.classList.remove('ready');
    els.stockCheck.hidden = true;
    updateTotalCardsLink(null);
    hideStockCandidates();
    setExistingEditorMode('listing');
    if (els.nextCard) els.nextCard.hidden = true;
    if (els.applyMarketPrices) els.applyMarketPrices.hidden = true;
    updateCreateButton();
    writePrefs({
      game: keptGame,
      language: keptLanguage,
      setQuery: keptSet,
      locationId: keptLocation,
      status: keptStatus
    });
    setProgress(1);
    if (announce) showMessage(keptSet ? `Ready for the next card in “${keptSet}”. Enter the printed number.` : 'Ready for the next card. Enter the printed number.');
    const focusTarget = els.numberQuery;
    focusTarget.focus();
    focusTarget.select?.();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function selectAllPublications() {
    [...els.publications.options].forEach(option => { option.selected = true; });
  }

  function updateCreateButton() {
    const needsConfirmation = state.stockMode === 'candidate';
    const conflict = state.stockMode === 'mixed' || state.stockMode === 'ambiguous';
    els.createButton.disabled = state.submitting || conflict || needsConfirmation;
    if (state.submitting) return;
    if (needsConfirmation) {
      els.createButton.textContent = 'Confirm possible existing product';
    } else if (conflict) {
      els.createButton.textContent = 'Resolve Shopify SKU conflict';
    } else if (state.stockMode === 'existing') {
      els.createButton.textContent = 'Add stock / update prices';
    } else {
      els.createButton.textContent = els.status.value === 'ACTIVE' ? 'Create and publish product' : 'Create Shopify draft';
    }
  }

  function resetApp() {
    prepareNextCard(true);
    els.setQuery.value = '';
    writePrefs({ setQuery: '' });
    showMessage('Ready for the next card.');
  }

  async function handleGameChange() {
    state.results = [];
    state.selected = null;
    state.stockMode = '';
    state.stockMatches = new Map();
    state.stockCandidates = [];
    state.existingProductId = '';
    state.forceCreateNew = false;
    state.skuSuffix = '';
    state.skuAttempt = 0;
    state.stockRequest += 1;
    state.operationId = '';
    state.submitting = false;
    els.resultsPanel.hidden = true;
    els.emptyEditor.hidden = false;
    els.productForm.hidden = true;
    hideStockCandidates();
    setExistingEditorMode('listing');

    if (els.game.value === 'pokemon-japan') {
      els.language.value = 'ja';
      els.language.disabled = true;
    } else if (els.game.value === 'pokemon') {
      els.language.value = 'en';
      els.language.disabled = true;
    } else {
      els.language.disabled = false;
    }

    const examples = {
      pokemon: ['Charizard', 'Base Set', '4/102'],
      'pokemon-japan': ['', 'Terastal Festival ex', '090/187'],
      'one-piece-card-game': ['Sakazuki', 'The Time of Battle', '065 or OP16-065'],
      'digimon-card-game': ['Agumon', 'BT14', '001 or BT14-001'],
      'magic-the-gathering': ['Black Lotus', 'Limited Edition Alpha', '232'],
      'disney-lorcana': ['Elsa', 'The First Chapter', '207/204']
    };
    const example = examples[els.game.value] || ['Card name', 'Choose a JustTCG set', 'Printed number'];
    els.query.placeholder = example[0] ? `e.g. ${example[0]}` : 'Optional — number-only search supported';
    els.setQuery.placeholder = `e.g. ${example[1]}`;
    els.numberQuery.placeholder = `e.g. ${example[2]}`;
    if (els.searchGuidance) {
      if (els.game.value === 'pokemon-japan') {
        els.searchGuidance.textContent = 'Japanese Pokémon: the card name and set are optional. Enter the complete printed number, such as 026/086. JustTCG Pokemon Japan is searched and wrong totals are rejected.';
      } else if (usesSetPrefixedNumbers(els.game.value)) {
        els.searchGuidance.textContent = 'Printed-number searches are strict. With a set selected you can enter just 065 — it expands to OP16-065 (or BT14-001, etc.). Full ids like OP16-065 still work.';
      } else {
        els.searchGuidance.textContent = 'Printed-number searches are strict. Wrong card numbers are removed before results are displayed.';
      }
    }
    await loadGameSets(els.game.value);
    const prefs = readPrefs();
    if (prefs.game === els.game.value && prefs.setQuery) els.setQuery.value = prefs.setQuery;
    writePrefs({ game: els.game.value, language: els.language.value });
    setProgress(1);
  }

  function requireEl(el, label) {
    if (!el) throw new Error(`Missing UI element #${label}. Hard-refresh or clear the site service worker cache.`);
    return el;
  }

  try {
    // Kick connection status before UI wiring so pills never wait on listeners.
    scheduleBootConnectionWatchdog();
    const bootConnections = Promise.all([
      loadShopifyMeta().catch(error => {
        if (badgeStillConnecting(els.shopBadge)) {
          els.shopBadge.textContent = 'Shopify connection error';
        }
        console.warn('Shopify boot failed', error);
      }),
      loadCatalogueMeta().catch(error => {
        if (badgeStillConnecting(els.providerBadge)) {
          setCatalogueGamesUnavailable('JustTCG unavailable — refresh to retry');
        }
        console.warn('JustTCG boot failed', error);
      })
    ]);

    requireEl(els.searchForm, 'search-form').addEventListener('submit', event => { event.preventDefault(); searchCards(); });
    requireEl(els.productForm, 'product-form').addEventListener('submit', createProduct);
    requireEl(els.reset, 'reset-button').addEventListener('click', resetApp);
    els.nextCard?.addEventListener('click', () => prepareNextCard(true));
    els.applyMarketPrices?.addEventListener('click', () => {
      const filled = applyMarketPrices();
      maybeRebuildSeo();
      if (state.selected && shouldFetchCompetitorPrices(state.selected) && !state.selected.competitorCompare) {
        maybeOverlayCompetitorPrices(state.selected);
      }
      showMessage(filled
        ? `Applied market GBP prices to ${filled} condition${filled === 1 ? '' : 's'}.`
        : 'No matching market prices were available for the selected finish.', filled ? 'success' : 'warning');
    });
    els.applyCompetitorNm?.addEventListener('click', () => {
      if (!state.selected?.competitorCompare) {
        showMessage('No competitor suggestion is available yet.', 'warning');
        return;
      }
      const suggested = Number(state.selected.competitorCompare.suggestedNm);
      if (!Number.isFinite(suggested) || suggested <= 0) {
        showMessage('No suggested Near Mint price to apply.', 'warning');
        return;
      }
      state.selected.competitorNm = {
        priceGbp: suggested,
        band: state.selected.competitorCompare.rarityBand || '',
        action: state.selected.competitorCompare.action || '',
        reason: state.selected.competitorCompare.reason || ''
      };
      setNearMintPrice(suggested);
      state.competitorNmApplied = true;
      renderMarketSummary(state.selected);
      showMessage(`Near Mint set to £${suggested.toFixed(2)} from price strategy.`, 'success');
    });
    requireEl(els.game, 'game').addEventListener('change', handleGameChange);
    requireEl(els.language, 'card-language').addEventListener('change', () => {
      state.results = [];
      state.selected = null;
      writePrefs({ language: els.language.value });
      setProgress(1);
    });
    requireEl(els.setQuery, 'search-set').addEventListener('change', () => writePrefs({ setQuery: els.setQuery.value.trim() }));
    els.setQuery.addEventListener('blur', () => writePrefs({ setQuery: els.setQuery.value.trim() }));
    requireEl(els.status, 'product-status').addEventListener('change', () => {
      writePrefs({ status: els.status.value });
      updateCreateButton();
    });
    requireEl(els.location, 'location').addEventListener('change', () => {
      writePrefs({ locationId: els.location.value });
      state.operationId = '';
      checkExistingStock();
    });
    requireEl(els.rebuildTitle, 'rebuild-title').addEventListener('click', () => {
      dismissPendingStockSuggestion();
      rebuildTitle();
      state.operationId = '';
      scheduleStockCheck();
    });
    requireEl(els.title, 'product-title').addEventListener('input', () => {
      dismissPendingStockSuggestion();
      state.titleDirty = true;
      state.operationId = '';
      updateEbayLinks();
      scheduleStockCheck();
    });
    requireEl(els.englishName, 'english-card-name').addEventListener('input', () => {
      dismissPendingStockSuggestion();
      maybeRebuildTitle();
      maybeRebuildSeo();
      state.operationId = '';
      scheduleStockCheck();
    });
    requireEl(els.englishSet, 'english-set-name').addEventListener('input', () => {
      dismissPendingStockSuggestion();
      maybeRebuildTitle();
      maybeRebuildSeo();
      state.operationId = '';
      scheduleStockCheck();
    });
    els.rebuildSeo?.addEventListener('click', () => {
      rebuildSeo();
      showMessage('SEO title and description rebuilt from the card details and Near Mint price.', 'success');
    });
    els.seoTitle?.addEventListener('input', () => { state.seoDirty = true; updateSeoCounts(); });
    els.seoDescription?.addEventListener('input', () => { state.seoDirty = true; updateSeoCounts(); });
    requireEl(els.finish, 'finish').addEventListener('change', () => {
      dismissPendingStockSuggestion();
      // A new finish mints a different base SKU, so the old collision is moot.
      state.skuSuffix = '';
      state.skuAttempt = 0;
      maybeRebuildTitle();
      maybeRebuildSeo();
      if (state.selected) {
        els.description.value = buildListingDescription(state.selected);
        applyTaxonomyDefaults(state.selected);
        renderVariants(state.selected);
        applyMarketPrices(state.selected);
        syncFoilTag(state.selected);
        state.operationId = '';
        checkExistingStock();
      }
    });
    bindPicker('tags');
    bindPicker('collections');
    requireEl(els.selectAllPublications, 'select-all-publications').addEventListener('click', selectAllPublications);
    requireEl(els.stockCandidate, 'stock-candidate').addEventListener('change', updateStockCandidateSelection);
    requireEl(els.confirmStockCandidate, 'confirm-stock-candidate').addEventListener('click', confirmExistingCandidate);
    requireEl(els.rejectStockCandidates, 'reject-stock-candidates').addEventListener('click', rejectStockCandidates);

    if (els.intakeTallyButton) {
      els.intakeTallyButton.addEventListener('click', () => {
        const opening = !intakeRecentIsOpen();
        setIntakeRecentOpen(opening);
        if (opening) loadIntakeLog();
      });
      // Clicking anywhere else closes it, the way a menu should behave.
      document.addEventListener('click', event => {
        if (!intakeRecentIsOpen()) return;
        if (els.intakeTally?.contains(event.target)) return;
        setIntakeRecentOpen(false);
      });
    }
    els.intakeRecentRefresh?.addEventListener('click', loadIntakeLog);

    document.addEventListener('keydown', event => {
      if (event.defaultPrevented || event.metaKey || event.ctrlKey || event.altKey) return;

      // Escape is handled even while typing, because that is when it is
      // wanted: closing whatever is open, then backing out of the card.
      if (event.key === 'Escape') {
        if (intakeRecentIsOpen()) {
          event.preventDefault();
          setIntakeRecentOpen(false);
          return;
        }
        // A picker suggestion list is open. Escape closes that, not the form.
        // Wiping a part-finished card because someone was mid tag search would
        // be worse than the missing shortcut this replaced.
        const openPicker = Object.keys(pickers).find(name => !pickers[name].suggestions()?.hidden);
        if (openPicker) {
          event.preventDefault();
          hidePickerSuggestions(openPicker);
          return;
        }
        const tag = event.target?.tagName;
        if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
        event.preventDefault();
        resetApp();
        return;
      }

      const tag = event.target?.tagName;
      const typing = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || event.target?.isContentEditable;
      if (typing) return;

      // These used to do the same thing. The toolbar advertises three keys and
      // two of them were wrong: / and N both advanced to the next card, and
      // Escape was not bound at all.
      if (event.key === '/') {
        event.preventDefault();
        els.numberQuery?.focus();
        els.numberQuery?.select?.();
        return;
      }
      if (event.key.toLowerCase() === 'n') {
        event.preventDefault();
        prepareNextCard(true);
      }
    });

    loadIntakeLog();

    bootConnections.catch(() => {});
    if ('serviceWorker' in navigator && location.protocol === 'https:') {
      navigator.serviceWorker.register('sw.js').catch(() => {});
    }
  } catch (error) {
    const message = error?.message || 'Unknown boot error';
    if (els.providerBadge) els.providerBadge.textContent = 'App boot error';
    if (els.shopBadge) els.shopBadge.textContent = 'App boot error';
    setCatalogueGamesUnavailable('App failed to start — hard refresh');
    showMessage(`Card Intake failed to start: ${message}`, 'error');
    console.error(error);
  }
})();
