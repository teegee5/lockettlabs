/*
 * Lockett Labs scan engine.
 *
 * Turns a phone photo or a flatbed scan of a real card into a straight,
 * evenly lit, correctly shaped product image. No DOM, no network, no
 * dependencies: it works on plain { width, height, data } pixel buffers, so it
 * runs in the scan worker in the browser and in Node for tests.
 *
 *   detectCards(image)      every card-shaped object, best first
 *   warpCard(image, corners) the card flattened to 63 x 88 proportions
 *   finishCard(image)        rounded corners, optional colour, quality score
 *   squareCanvas(image)      the store's final 1:1 frame (card fills 94%)
 *
 * Why this exists: database images for modern printings are digital renders.
 * A render shows a flat gold border where the real Classic Collection card
 * has glitter foil, and no reverse holo pattern at all. Only a scan of the
 * card in hand shows the printing a customer is buying.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LLScan = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /** A trading card is 63 x 88 mm. */
  const CARD_RATIO = 63 / 88;
  /** Output resolution: 20 pixels per millimetre. */
  const OUT_W = 1260;
  const OUT_H = 1760;
  /** Corner radius of a standard card, 1/8 inch, at 20 px/mm. */
  const CORNER_RADIUS = 63;
  /** The store's image automation: the card fills 94% of a square, 1000px minimum. */
  const SQUARE_FILL = 0.94;
  const SQUARE_MIN = 1000;

  function makeImage(width, height, fill) {
    const data = new Uint8ClampedArray(width * height * 4);
    if (fill) {
      for (let i = 0; i < data.length; i += 4) {
        data[i] = fill[0]; data[i + 1] = fill[1]; data[i + 2] = fill[2]; data[i + 3] = 255;
      }
    }
    return { width, height, data };
  }

  // ------------------------------------------------------------------ pixels

  /** Area-average downscale so the longest side is at most maxSide. */
  function downscale(img, maxSide) {
    const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
    if (scale >= 1) return { image: img, scale: 1 };
    const w = Math.max(1, Math.round(img.width * scale));
    const h = Math.max(1, Math.round(img.height * scale));
    const out = makeImage(w, h);
    const sx = img.width / w;
    const sy = img.height / h;
    const src = img.data;
    const dst = out.data;
    for (let y = 0; y < h; y++) {
      const y0 = Math.floor(y * sy);
      const y1 = Math.min(img.height, Math.max(y0 + 1, Math.floor((y + 1) * sy)));
      for (let x = 0; x < w; x++) {
        const x0 = Math.floor(x * sx);
        const x1 = Math.min(img.width, Math.max(x0 + 1, Math.floor((x + 1) * sx)));
        let r = 0, g = 0, b = 0, n = 0;
        // Sparse sampling inside big blocks keeps a 12 MP photo fast.
        const stepY = Math.max(1, Math.floor((y1 - y0) / 4));
        const stepX = Math.max(1, Math.floor((x1 - x0) / 4));
        for (let yy = y0; yy < y1; yy += stepY) {
          let i = (yy * img.width + x0) * 4;
          for (let xx = x0; xx < x1; xx += stepX, i += stepX * 4) {
            r += src[i]; g += src[i + 1]; b += src[i + 2]; n++;
          }
        }
        const o = (y * w + x) * 4;
        dst[o] = r / n; dst[o + 1] = g / n; dst[o + 2] = b / n; dst[o + 3] = 255;
      }
    }
    return { image: out, scale: w / img.width };
  }

  function luminance(img) {
    const n = img.width * img.height;
    const out = new Float32Array(n);
    const d = img.data;
    for (let i = 0, p = 0; p < n; i += 4, p++) out[p] = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
    return out;
  }

  /** Median colour of the outer frame: what the card is lying on. */
  function backgroundColour(img) {
    const { width: w, height: h, data: d } = img;
    const band = Math.max(2, Math.round(Math.min(w, h) * 0.02));
    const rs = [], gs = [], bs = [];
    const take = (x, y) => { const i = (y * w + x) * 4; rs.push(d[i]); gs.push(d[i + 1]); bs.push(d[i + 2]); };
    for (let y = 0; y < h; y += 2) {
      for (let x = 0; x < band; x += 1) { take(x, y); take(w - 1 - x, y); }
    }
    for (let x = 0; x < w; x += 2) {
      for (let y = 0; y < band; y += 1) { take(x, y); take(x, h - 1 - y); }
    }
    const med = a => { a.sort((p, q) => p - q); return a[a.length >> 1]; };
    return [med(rs), med(gs), med(bs)];
  }

  function otsu(values, max) {
    const bins = 256;
    const hist = new Float64Array(bins);
    const k = (bins - 1) / (max || 1);
    for (let i = 0; i < values.length; i++) hist[Math.min(bins - 1, Math.round(values[i] * k))]++;
    let sum = 0;
    for (let i = 0; i < bins; i++) sum += i * hist[i];
    let sumB = 0, wB = 0, best = 0, threshold = 0;
    const total = values.length;
    for (let i = 0; i < bins; i++) {
      wB += hist[i];
      if (!wB) continue;
      const wF = total - wB;
      if (!wF) break;
      sumB += i * hist[i];
      const mB = sumB / wB;
      const mF = (sum - sumB) / wF;
      const between = wB * wF * (mB - mF) * (mB - mF);
      if (between > best) { best = between; threshold = i; }
    }
    return threshold / k;
  }

  function dilate(mask, w, h, r) {
    const tmp = new Uint8Array(w * h);
    const out = new Uint8Array(w * h);
    for (let y = 0; y < h; y++) {
      let count = 0;
      const row = y * w;
      for (let x = -r; x < w + r; x++) {
        const add = x + r, sub = x - r - 1;
        if (add >= 0 && add < w) count += mask[row + add];
        if (sub >= 0 && sub < w) count -= mask[row + sub];
        if (x >= 0 && x < w) tmp[row + x] = count > 0 ? 1 : 0;
      }
    }
    for (let x = 0; x < w; x++) {
      let count = 0;
      for (let y = -r; y < h + r; y++) {
        const add = y + r, sub = y - r - 1;
        if (add >= 0 && add < h) count += tmp[add * w + x];
        if (sub >= 0 && sub < h) count -= tmp[sub * w + x];
        if (y >= 0 && y < h) out[y * w + x] = count > 0 ? 1 : 0;
      }
    }
    return out;
  }

  function erode(mask, w, h, r) {
    // Erosion is dilation of the complement, with the frame counted as
    // foreground so a card touching the edge survives.
    const inv = new Uint8Array(w * h);
    for (let i = 0; i < inv.length; i++) inv[i] = mask[i] ? 0 : 1;
    const grown = dilate(inv, w, h, r);
    const out = new Uint8Array(w * h);
    for (let i = 0; i < out.length; i++) out[i] = grown[i] ? 0 : 1;
    return out;
  }

  function close(mask, w, h, r) { return erode(dilate(mask, w, h, r), w, h, r); }
  function open(mask, w, h, r) { return dilate(erode(mask, w, h, r), w, h, r); }

  /** Connected components (4-neighbour), largest first. */
  function components(mask, w, h, minArea) {
    const labels = new Int32Array(w * h);
    const stack = new Int32Array(w * h);
    const out = [];
    let next = 1;
    for (let start = 0; start < mask.length; start++) {
      if (!mask[start] || labels[start]) continue;
      let sp = 0, area = 0;
      let minX = w, minY = h, maxX = 0, maxY = 0;
      stack[sp++] = start;
      labels[start] = next;
      while (sp) {
        const p = stack[--sp];
        area++;
        const x = p % w, y = (p - x) / w;
        if (x < minX) minX = x; if (x > maxX) maxX = x;
        if (y < minY) minY = y; if (y > maxY) maxY = y;
        if (x > 0 && mask[p - 1] && !labels[p - 1]) { labels[p - 1] = next; stack[sp++] = p - 1; }
        if (x < w - 1 && mask[p + 1] && !labels[p + 1]) { labels[p + 1] = next; stack[sp++] = p + 1; }
        if (y > 0 && mask[p - w] && !labels[p - w]) { labels[p - w] = next; stack[sp++] = p - w; }
        if (y < h - 1 && mask[p + w] && !labels[p + w]) { labels[p + w] = next; stack[sp++] = p + w; }
      }
      if (area >= minArea) out.push({ label: next, area, minX, minY, maxX, maxY });
      next++;
    }
    out.sort((a, b) => b.area - a.area);
    return { labels, list: out };
  }

  /** Mask of one component with its holes filled (holo art and text are interior). */
  function solidComponent(labels, w, h, comp) {
    const { label, minX, minY, maxX, maxY } = comp;
    const bw = maxX - minX + 3, bh = maxY - minY + 3;
    const box = new Uint8Array(bw * bh);
    for (let y = minY; y <= maxY; y++) {
      for (let x = minX; x <= maxX; x++) if (labels[y * w + x] === label) box[(y - minY + 1) * bw + (x - minX + 1)] = 1;
    }
    // Flood the outside from the padded border; whatever it cannot reach is inside.
    const outside = new Uint8Array(bw * bh);
    const stack = new Int32Array(bw * bh);
    let sp = 0;
    stack[sp++] = 0; outside[0] = 1;
    while (sp) {
      const p = stack[--sp];
      const x = p % bw, y = (p - x) / bw;
      const n = [x > 0 ? p - 1 : -1, x < bw - 1 ? p + 1 : -1, y > 0 ? p - bw : -1, y < bh - 1 ? p + bw : -1];
      for (const q of n) if (q >= 0 && !outside[q] && !box[q]) { outside[q] = 1; stack[sp++] = q; }
    }
    const solid = new Uint8Array(bw * bh);
    let area = 0;
    for (let i = 0; i < solid.length; i++) if (!outside[i]) { solid[i] = 1; area++; }
    return { solid, bw, bh, ox: minX - 1, oy: minY - 1, area };
  }

  function boundaryPoints(c) {
    const { solid, bw, bh, ox, oy } = c;
    const pts = [];
    for (let y = 1; y < bh - 1; y++) {
      for (let x = 1; x < bw - 1; x++) {
        const p = y * bw + x;
        if (!solid[p]) continue;
        if (!solid[p - 1] || !solid[p + 1] || !solid[p - bw] || !solid[p + bw]) pts.push([x + ox, y + oy]);
      }
    }
    return pts;
  }

  // ---------------------------------------------------------------- geometry

  function convexHull(points) {
    if (points.length < 3) return points.slice();
    const pts = points.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]);
    const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
    const lower = [];
    for (const p of pts) {
      while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0) lower.pop();
      lower.push(p);
    }
    const upper = [];
    for (let i = pts.length - 1; i >= 0; i--) {
      const p = pts[i];
      while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0) upper.pop();
      upper.push(p);
    }
    upper.pop(); lower.pop();
    return lower.concat(upper);
  }

  function polygonArea(poly) {
    let a = 0;
    for (let i = 0; i < poly.length; i++) {
      const p = poly[i], q = poly[(i + 1) % poly.length];
      a += p[0] * q[1] - q[0] * p[1];
    }
    return Math.abs(a) / 2;
  }

  /**
   * The four hull vertices enclosing the largest area. Greedy simplification
   * alone can cut a whole corner off a rounded rectangle; an exhaustive search
   * over a lightly simplified hull lands on the tip of each corner arc.
   */
  function quadFromHull(hull) {
    const poly = simplifyHull(hull, 28);
    const n = poly.length;
    if (n < 4) return null;
    if (n === 4) return poly;
    let best = null, bestArea = -1;
    for (let a = 0; a < n - 3; a++) {
      for (let b = a + 1; b < n - 2; b++) {
        for (let c = b + 1; c < n - 1; c++) {
          for (let d = c + 1; d < n; d++) {
            const q = [poly[a], poly[b], poly[c], poly[d]];
            const area = polygonArea(q);
            if (area > bestArea) { bestArea = area; best = q; }
          }
        }
      }
    }
    return best;
  }

  /** Visvalingam: drop the vertex whose triangle is smallest until `keep` remain. */
  function simplifyHull(hull, keep) {
    let poly = hull.slice();
    while (poly.length > keep) {
      let worst = 0, worstArea = Infinity;
      for (let i = 0; i < poly.length; i++) {
        const a = poly[(i - 1 + poly.length) % poly.length], b = poly[i], c = poly[(i + 1) % poly.length];
        const area = Math.abs((b[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (b[1] - a[1])) / 2;
        if (area < worstArea) { worstArea = area; worst = i; }
      }
      poly.splice(worst, 1);
    }
    return poly;
  }

  /** Order four points top-left, top-right, bottom-right, bottom-left. */
  function orderCorners(points) {
    const cx = points.reduce((s, p) => s + p[0], 0) / points.length;
    const cy = points.reduce((s, p) => s + p[1], 0) / points.length;
    const sorted = points.slice().sort((a, b) => Math.atan2(a[1] - cy, a[0] - cx) - Math.atan2(b[1] - cy, b[0] - cx));
    // Clockwise in image space starting at the angle closest to top-left.
    let start = 0, best = Infinity;
    for (let i = 0; i < 4; i++) {
      const s = sorted[i][0] + sorted[i][1];
      if (s < best) { best = s; start = i; }
    }
    return [0, 1, 2, 3].map(k => sorted[(start + k) % 4]);
  }

  function dist(a, b) { return Math.hypot(a[0] - b[0], a[1] - b[1]); }

  function quadSides(q) {
    const top = dist(q[0], q[1]), right = dist(q[1], q[2]), bottom = dist(q[2], q[3]), left = dist(q[3], q[0]);
    return { top, right, bottom, left, w: (top + bottom) / 2, h: (left + right) / 2 };
  }

  /** Total least squares line through points: returns [nx, ny, c] with nx*x + ny*y = c. */
  function fitLine(points) {
    let mx = 0, my = 0;
    for (const p of points) { mx += p[0]; my += p[1]; }
    mx /= points.length; my /= points.length;
    let sxx = 0, syy = 0, sxy = 0;
    for (const p of points) {
      const dx = p[0] - mx, dy = p[1] - my;
      sxx += dx * dx; syy += dy * dy; sxy += dx * dy;
    }
    const theta = 0.5 * Math.atan2(2 * sxy, sxx - syy); // direction of the line
    const nx = -Math.sin(theta), ny = Math.cos(theta);
    return [nx, ny, nx * mx + ny * my];
  }

  function intersect(l1, l2) {
    const det = l1[0] * l2[1] - l2[0] * l1[1];
    if (Math.abs(det) < 1e-9) return null;
    return [(l1[2] * l2[1] - l2[2] * l1[1]) / det, (l1[0] * l2[2] - l2[0] * l1[2]) / det];
  }

  /**
   * Straight edges, true corners. A card has rounded corners, so the hull's
   * corner points sit inside the real corner. Fit a line to each side's
   * middle stretch and intersect neighbours instead.
   */
  function refineQuad(quad, boundary) {
    // The simplified hull keeps the points where each rounded corner meets a
    // straight edge, so its "corners" sit a corner radius inside the real
    // ones. Assign every outline point to its nearest side, fit each side as
    // a line away from the corners, intersect, and repeat with the better
    // corners. Three rounds settle it.
    let corners = quad;
    for (let round = 0; round < 3; round++) {
      const sides = [];
      for (let i = 0; i < 4; i++) {
        const a = corners[i], b = corners[(i + 1) % 4];
        const len = dist(a, b);
        if (len < 8) return corners;
        sides.push({ a, ux: (b[0] - a[0]) / len, uy: (b[1] - a[1]) / len, len, pts: [] });
      }
      for (const p of boundary) {
        let best = -1, bestD = Infinity;
        for (let i = 0; i < 4; i++) {
          const s = sides[i];
          const d = Math.abs((p[0] - s.a[0]) * s.uy - (p[1] - s.a[1]) * s.ux);
          if (d < bestD) { bestD = d; best = i; }
        }
        const s = sides[best];
        const t = ((p[0] - s.a[0]) * s.ux + (p[1] - s.a[1]) * s.uy) / s.len;
        if (t < 0.15 || t > 0.85) continue;
        if (bestD > Math.max(3, s.len * 0.06)) continue;
        s.pts.push(p);
      }
      const lines = [];
      for (const s of sides) {
        if (s.pts.length < 8) return corners;
        let line = fitLine(s.pts);
        // One pass of outlier rejection: a shadow or a scuffed edge.
        const res = s.pts.map(p => Math.abs(line[0] * p[0] + line[1] * p[1] - line[2]));
        const sorted = res.slice().sort((x, y) => x - y);
        const cut = Math.max(1.2, sorted[Math.floor(sorted.length * 0.8)] * 1.6);
        const keep = s.pts.filter((_, k) => res[k] <= cut);
        if (keep.length >= 8) line = fitLine(keep);
        lines.push(line);
      }
      const next = [];
      for (let i = 0; i < 4; i++) {
        const p = intersect(lines[(i + 3) % 4], lines[i]);
        if (!p) return corners;
        const side = Math.min(dist(quad[i], quad[(i + 1) % 4]), dist(quad[i], quad[(i + 3) % 4]));
        if (dist(p, quad[i]) > side * 0.15) return corners;
        next.push(p);
      }
      corners = next;
    }
    return corners;
  }

  function isConvex(q) {
    let sign = 0;
    for (let i = 0; i < 4; i++) {
      const a = q[i], b = q[(i + 1) % 4], c = q[(i + 2) % 4];
      const z = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
      if (Math.abs(z) < 1e-6) return false;
      const s = Math.sign(z);
      if (sign && s !== sign) return false;
      sign = s;
    }
    return true;
  }

  function aspectScore(q) {
    const s = quadSides(q);
    const r = Math.min(s.w, s.h) / Math.max(s.w, s.h);
    return Math.exp(-Math.pow((r - CARD_RATIO) / 0.11, 2));
  }

  // ------------------------------------------------------------- detection

  function candidateMasks(small) {
    const { width: w, height: h } = small;
    const n = w * h;
    const bg = backgroundColour(small);
    const d = small.data;
    // Opponent colour space: lightness, red-green, yellow-blue. A yellow
    // card border on grey paper has almost the same lightness as the paper,
    // so a brightness-weighted distance cannot see the edge; yellow-blue can.
    const L = new Float32Array(n), A = new Float32Array(n), B = new Float32Array(n);
    for (let i = 0, p = 0; p < n; i += 4, p++) {
      L[p] = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
      A[p] = d[i] - d[i + 1];
      B[p] = (d[i] + d[i + 1]) / 2 - d[i + 2];
    }
    const bL = 0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2], bA = bg[0] - bg[1], bB = (bg[0] + bg[1]) / 2 - bg[2];
    const distMap = new Float32Array(n);
    let maxD = 1;
    for (let p = 0; p < n; p++) {
      const dl = L[p] - bL, da = (A[p] - bA) * 0.75, db = (B[p] - bB) * 0.75;
      const v = Math.sqrt(dl * dl + da * da + db * db);
      distMap[p] = v;
      if (v > maxD) maxD = v;
    }
    const t = Math.max(16, otsu(distMap, maxD));
    const colourMask = new Uint8Array(n);
    const lowMask = new Uint8Array(n);
    const tLow = Math.max(12, t * 0.5);
    for (let p = 0; p < n; p++) {
      colourMask[p] = distMap[p] > t ? 1 : 0;
      lowMask[p] = distMap[p] > tLow ? 1 : 0;
    }

    // Edges close a card's outline even when its border matches the backing
    // (a white-bordered card on a white scanner lid shows only a shadow line).
    const sobel = (ch, p) => {
      const gx = ch[p - w + 1] + 2 * ch[p + 1] + ch[p + w + 1] - ch[p - w - 1] - 2 * ch[p - 1] - ch[p + w - 1];
      const gy = ch[p + w - 1] + 2 * ch[p + w] + ch[p + w + 1] - ch[p - w - 1] - 2 * ch[p - w] - ch[p - w + 1];
      return Math.abs(gx) + Math.abs(gy);
    };
    const grad = new Float32Array(n);
    let maxG = 1;
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const p = y * w + x;
        const g = Math.max(sobel(L, p), 0.6 * sobel(A, p), 0.6 * sobel(B, p));
        grad[p] = g;
        if (g > maxG) maxG = g;
      }
    }
    const gt = Math.max(24, otsu(grad, maxG) * 0.8);
    const edgeMask = new Uint8Array(n);
    for (let p = 0; p < n; p++) edgeMask[p] = grad[p] > gt ? 1 : 0;

    const r = Math.max(1, Math.round(Math.min(w, h) / 160));
    return [
      { name: 'colour', mask: open(close(colourMask, w, h, r * 2), w, h, r), raw: colourMask, threshold: t },
      { name: 'colour-low', mask: open(close(lowMask, w, h, r * 2), w, h, r * 2), raw: lowMask, threshold: tLow },
      { name: 'edges', mask: close(edgeMask, w, h, r * 2), raw: edgeMask, threshold: gt }
    ];
  }

  function scoreQuad(quad, area, imageArea) {
    const qa = polygonArea(quad);
    if (!qa) return 0;
    const rect = Math.min(1, area / qa);
    const coverage = qa / imageArea;
    if (coverage < 0.03 || coverage > 0.985) return 0;
    const sizeScore = Math.min(1, coverage / 0.12);
    return rect * rect * aspectScore(quad) * (0.6 + 0.4 * sizeScore);
  }

  /**
   * Every card in the picture, best first. Corners are in source pixels,
   * ordered top-left, top-right, bottom-right, bottom-left.
   *
   * @param {{width:number,height:number,data:Uint8ClampedArray}} img
   * @param {{max?:number, work?:number, refine?:boolean}} options
   */
  function detectCards(img, options) {
    const opts = options || {};
    const { image: small, scale } = downscale(img, opts.work || 720);
    const { width: w, height: h } = small;
    const imageArea = w * h;
    const found = [];
    for (const candidate of candidateMasks(small)) {
      const { labels, list } = components(candidate.mask, w, h, imageArea * 0.02);
      for (const comp of list.slice(0, 12)) {
        // A component touching all four sides is the background, not a card.
        if (comp.minX <= 0 && comp.minY <= 0 && comp.maxX >= w - 1 && comp.maxY >= h - 1) continue;
        const solid = solidComponent(labels, w, h, comp);
        const boundary = boundaryPoints(solid);
        if (boundary.length < 20) continue;
        const hull = convexHull(boundary);
        let quad = quadFromHull(hull);
        if (!quad) continue;
        quad = orderCorners(quad);
        if (!isConvex(quad)) continue;
        const refined = orderCorners(refineQuad(quad, boundary));
        const score = scoreQuad(refined, solid.area, imageArea);
        if (score < 0.35) continue;
        found.push({ corners: refined, score, method: candidate.name, area: solid.area });
      }
    }
    // A card's art window is itself roughly card-shaped. Anything lying wholly
    // inside another plausible card is part of that card, never a card itself.
    for (const inner of found) {
      inner.nested = found.some(outer => outer !== inner && outer.score >= 0.5
        && polygonArea(outer.corners) > polygonArea(inner.corners) * 1.15
        && inner.corners.every(p => pointInQuad(p, outer.corners)));
    }
    for (let i = found.length - 1; i >= 0; i--) if (found[i].nested) found.splice(i, 1);
    // Merge duplicates found by both masks: keep the better of overlapping quads.
    found.sort((a, b) => b.score - a.score);
    const kept = [];
    for (const f of found) {
      const c = centroid(f.corners);
      if (kept.some(k => pointInQuad(c, k.corners))) continue;
      kept.push(f);
    }
    const max = opts.max || 12;
    const results = kept.slice(0, max).map(f => ({
      corners: f.corners.map(p => [p[0] / scale, p[1] / scale]),
      score: Math.round(f.score * 100) / 100,
      method: f.method
    }));
    if (opts.refine !== false) {
      for (const r of results) r.corners = snapEdges(img, r.corners, 1 / scale);
    }
    return results;
  }

  function centroid(q) {
    return [q.reduce((s, p) => s + p[0], 0) / q.length, q.reduce((s, p) => s + p[1], 0) / q.length];
  }

  function pointInQuad(p, q) {
    let inside = false;
    for (let i = 0, j = q.length - 1; i < q.length; j = i++) {
      const xi = q[i][0], yi = q[i][1], xj = q[j][0], yj = q[j][1];
      if ((yi > p[1]) !== (yj > p[1]) && p[0] < ((xj - xi) * (p[1] - yi)) / (yj - yi) + xi) inside = !inside;
    }
    return inside;
  }

  /** The best single card, or a full-frame fallback for an already cropped scan. */
  function detectCard(img, options) {
    const found = detectCards(img, { ...(options || {}), max: 1 });
    const ratio = Math.min(img.width, img.height) / Math.max(img.width, img.height);
    const cardShaped = Math.abs(ratio - CARD_RATIO) < 0.03;
    const fullFrame = {
      corners: [[0, 0], [img.width - 1, 0], [img.width - 1, img.height - 1], [0, img.height - 1]],
      score: 0.5,
      method: 'full-frame'
    };
    if (found.length) {
      // An image already cropped to the card (a flatbed scan, a saved file)
      // has no desk around it, so the best "card" found is the inner panel,
      // inset evenly on every side. Use the whole frame instead.
      if (cardShaped) {
        const xs = found[0].corners.map(p => p[0]), ys = found[0].corners.map(p => p[1]);
        const margins = [Math.min(...xs) / img.width, 1 - Math.max(...xs) / img.width, Math.min(...ys) / img.height, 1 - Math.max(...ys) / img.height];
        if (margins.every(m => m < 0.08)) return fullFrame;
      }
      return found[0];
    }
    return Math.abs(ratio - CARD_RATIO) < 0.06 ? fullFrame : null;
  }

  function sampleLum(img, x, y) {
    const { width: w, height: h, data: d } = img;
    if (x < 0 || y < 0 || x > w - 1 || y > h - 1) return -1;
    const x0 = Math.floor(x), y0 = Math.floor(y);
    const x1 = Math.min(w - 1, x0 + 1), y1 = Math.min(h - 1, y0 + 1);
    const fx = x - x0, fy = y - y0;
    const l = (xx, yy) => { const i = (yy * w + xx) * 4; return 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]; };
    return (l(x0, y0) * (1 - fx) + l(x1, y0) * fx) * (1 - fy) + (l(x0, y1) * (1 - fx) + l(x1, y1) * fx) * fy;
  }

  /** Bilinear sample in the opponent space used for detection: [L, R-G, Y-B]. */
  function sampleOpp(img, x, y) {
    const { width: w, height: h, data: d } = img;
    if (x < 0 || y < 0 || x > w - 1 || y > h - 1) return null;
    const x0 = Math.floor(x), y0 = Math.floor(y);
    const x1 = Math.min(w - 1, x0 + 1), y1 = Math.min(h - 1, y0 + 1);
    const fx = x - x0, fy = y - y0;
    const w00 = (1 - fx) * (1 - fy), w10 = fx * (1 - fy), w01 = (1 - fx) * fy, w11 = fx * fy;
    const i00 = (y0 * w + x0) * 4, i10 = (y0 * w + x1) * 4, i01 = (y1 * w + x0) * 4, i11 = (y1 * w + x1) * 4;
    const r = d[i00] * w00 + d[i10] * w10 + d[i01] * w01 + d[i11] * w11;
    const g = d[i00 + 1] * w00 + d[i10 + 1] * w10 + d[i01 + 1] * w01 + d[i11 + 1] * w11;
    const b = d[i00 + 2] * w00 + d[i10 + 2] * w10 + d[i01 + 2] * w01 + d[i11 + 2] * w11;
    return [0.299 * r + 0.587 * g + 0.114 * b, (r - g) * 0.75, ((r + g) / 2 - b) * 0.75];
  }

  /**
   * Snap each side onto the strongest edge in the full-resolution image.
   * Detection runs on a 720px copy; at 4000px a one-pixel miss there is a
   * five-pixel sliver of desk here.
   */
  function snapEdges(img, corners, factor) {
    const reach = Math.max(4, Math.ceil(factor * 2.5));
    const lines = [];
    for (let i = 0; i < 4; i++) {
      const a = corners[i], b = corners[(i + 1) % 4];
      const len = dist(a, b);
      const ux = (b[0] - a[0]) / len, uy = (b[1] - a[1]) / len;
      // Outward normal for a clockwise quad in image coordinates.
      const nx = uy, ny = -ux;
      const pts = [];
      const samples = 48;
      for (let s = 0; s < samples; s++) {
        const t = 0.1 + 0.8 * (s / (samples - 1));
        const px = a[0] + (b[0] - a[0]) * t, py = a[1] + (b[1] - a[1]) * t;
        // Colour-aware gradient along the normal: a yellow border on a white
        // lid barely changes brightness but changes yellow-blue a lot, and a
        // drop shadow changes brightness but hardly any colour.
        let best = -1, bestOff = 0;
        const profile = [];
        for (let o = -reach - 1; o <= reach + 1; o++) profile.push(sampleOpp(img, px + nx * o, py + ny * o));
        for (let k = 1; k < profile.length - 1; k++) {
          const p0 = profile[k - 1], p1 = profile[k + 1];
          if (!p0 || !p1) continue;
          const g = Math.max(Math.abs(p1[0] - p0[0]), 0.9 * Math.abs(p1[1] - p0[1]), 0.9 * Math.abs(p1[2] - p0[2]));
          // A slight pull towards the predicted line breaks ties with art
          // lines just inside the border.
          const o = k - reach - 1;
          const score = g * (1 - 0.15 * Math.abs(o) / reach);
          if (score > best) { best = score; bestOff = o; }
        }
        if (best > 12) pts.push([px + nx * bestOff, py + ny * bestOff]);
      }
      if (pts.length < 12) return corners;
      // Discard outliers (art lines inside the border) before the final fit.
      let line = fitLine(pts);
      const residuals = pts.map(p => Math.abs(line[0] * p[0] + line[1] * p[1] - line[2]));
      const sorted = residuals.slice().sort((x, y) => x - y);
      const cut = Math.max(1, sorted[Math.floor(sorted.length * 0.7)] * 1.5);
      const inliers = pts.filter((_, k) => residuals[k] <= cut);
      if (inliers.length >= 10) line = fitLine(inliers);
      lines.push(line);
    }
    const out = [];
    for (let i = 0; i < 4; i++) {
      const p = intersect(lines[(i + 3) % 4], lines[i]);
      if (!p || dist(p, corners[i]) > reach * 3) return corners;
      out.push(p);
    }
    return out;
  }

  // --------------------------------------------------------------- warping

  /** Homography mapping each src point onto its dst point (4 pairs). */
  function homography(src, dst) {
    const A = [];
    const b = [];
    for (let i = 0; i < 4; i++) {
      const [x, y] = src[i];
      const [u, v] = dst[i];
      A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u);
      A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v);
    }
    const h = solve(A, b);
    return h ? [h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[7], 1] : null;
  }

  function solve(A, b) {
    const n = b.length;
    const M = A.map((row, i) => row.concat([b[i]]));
    for (let c = 0; c < n; c++) {
      let piv = c;
      for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[piv][c])) piv = r;
      if (Math.abs(M[piv][c]) < 1e-12) return null;
      [M[c], M[piv]] = [M[piv], M[c]];
      for (let r = 0; r < n; r++) {
        if (r === c) continue;
        const f = M[r][c] / M[c][c];
        if (!f) continue;
        for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
      }
    }
    return M.map((row, i) => row[n] / row[i]);
  }

  /**
   * Flatten the card to 63 x 88. Maps every output pixel back into the source
   * and samples it bilinearly; when the card is much larger in the source than
   * the output, four samples per pixel stop the print rosette aliasing.
   *
   * @param corners four source points TL, TR, BR, BL
   * @param options { width, height, inset } inset trims a hair of the edge (fraction)
   */
  function warpCard(img, corners, options) {
    const opts = options || {};
    const W = opts.width || OUT_W;
    const H = opts.height || OUT_H;
    const inset = opts.inset == null ? 0.004 : opts.inset;
    const dx = W * inset, dy = H * inset;
    // Output rect expanded by the inset maps onto the card's own corners, so
    // the visible output sits a hair inside the edge and never shows desk.
    const dst = [[-dx, -dy], [W + dx, -dy], [W + dx, H + dy], [-dx, H + dy]];
    const Hm = homography(dst, corners);
    if (!Hm) throw new Error('These corners do not make a card shape.');
    const out = makeImage(W, H);
    const src = img.data, sw = img.width, sh = img.height;
    const o = out.data;
    const s = quadSides(corners);
    const ss = Math.max(s.w / W, s.h / H) > 1.6 ? 2 : 1;
    const step = 1 / ss;
    const [a, b, c, d, e, f, g, h] = Hm;
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        let r = 0, gg = 0, bb = 0;
        for (let sy = 0; sy < ss; sy++) {
          const yy = y + (sy + 0.5) * step;
          for (let sx = 0; sx < ss; sx++) {
            const xx = x + (sx + 0.5) * step;
            const den = g * xx + h * yy + 1;
            let u = (a * xx + b * yy + c) / den - 0.5;
            let v = (d * xx + e * yy + f) / den - 0.5;
            if (u < 0) u = 0; else if (u > sw - 1) u = sw - 1;
            if (v < 0) v = 0; else if (v > sh - 1) v = sh - 1;
            const x0 = u | 0, y0 = v | 0;
            const x1 = x0 + 1 < sw ? x0 + 1 : x0, y1 = y0 + 1 < sh ? y0 + 1 : y0;
            const fx = u - x0, fy = v - y0;
            const i00 = (y0 * sw + x0) * 4, i10 = (y0 * sw + x1) * 4, i01 = (y1 * sw + x0) * 4, i11 = (y1 * sw + x1) * 4;
            const w00 = (1 - fx) * (1 - fy), w10 = fx * (1 - fy), w01 = (1 - fx) * fy, w11 = fx * fy;
            r += src[i00] * w00 + src[i10] * w10 + src[i01] * w01 + src[i11] * w11;
            gg += src[i00 + 1] * w00 + src[i10 + 1] * w10 + src[i01 + 1] * w01 + src[i11 + 1] * w11;
            bb += src[i00 + 2] * w00 + src[i10 + 2] * w10 + src[i01 + 2] * w01 + src[i11 + 2] * w11;
          }
        }
        const k = ss * ss;
        const i = (y * W + x) * 4;
        o[i] = r / k; o[i + 1] = gg / k; o[i + 2] = bb / k; o[i + 3] = 255;
      }
    }
    return out;
  }

  /** Quarter turns clockwise, for a card photographed sideways or upside down. */
  function rotate(img, quarterTurns) {
    const q = ((quarterTurns % 4) + 4) % 4;
    if (!q) return img;
    const { width: w, height: h, data: d } = img;
    const out = makeImage(q % 2 ? h : w, q % 2 ? w : h);
    const o = out.data;
    const ow = out.width;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        let nx, ny;
        if (q === 1) { nx = h - 1 - y; ny = x; }
        else if (q === 2) { nx = w - 1 - x; ny = h - 1 - y; }
        else { nx = y; ny = w - 1 - x; }
        const i = (y * w + x) * 4, j = (ny * ow + nx) * 4;
        o[j] = d[i]; o[j + 1] = d[i + 1]; o[j + 2] = d[i + 2]; o[j + 3] = d[i + 3];
      }
    }
    return out;
  }

  /** Turn corners so the result is portrait: a card is always taller than wide. */
  function portraitCorners(corners, quarterTurns) {
    let c = corners.slice();
    const s = quadSides(c);
    if (s.w > s.h) c = [c[3], c[0], c[1], c[2]];
    const q = ((quarterTurns || 0) % 4 + 4) % 4;
    for (let i = 0; i < q; i++) c = [c[3], c[0], c[1], c[2]];
    return c;
  }

  // -------------------------------------------------------------- finishing

  /**
   * Even out a phone photo: per-channel levels from the card's own darkest
   * and brightest areas, blended and capped so a yellow border stays yellow
   * and holo foil is not blown out.
   */
  function autoLevels(img, strength) {
    const k = strength == null ? 0.6 : strength;
    const { width: w, height: h, data: d } = img;
    const hist = [new Uint32Array(256), new Uint32Array(256), new Uint32Array(256)];
    const mx = Math.round(w * 0.06), my = Math.round(h * 0.06);
    let n = 0;
    for (let y = my; y < h - my; y += 2) {
      for (let x = mx; x < w - mx; x += 2) {
        const i = (y * w + x) * 4;
        hist[0][d[i]]++; hist[1][d[i + 1]]++; hist[2][d[i + 2]]++; n++;
      }
    }
    const pct = (hh, p) => { let acc = 0; const target = n * p; for (let v = 0; v < 256; v++) { acc += hh[v]; if (acc >= target) return v; } return 255; };
    const maps = hist.map(hh => {
      const lo = Math.min(40, pct(hh, 0.004));
      const hi = Math.max(200, pct(hh, 0.996));
      const gain = Math.min(1.35, 255 / Math.max(1, hi - lo));
      const lut = new Uint8ClampedArray(256);
      for (let v = 0; v < 256; v++) {
        const stretched = (v - lo) * gain;
        lut[v] = v + (stretched - v) * k;
      }
      return lut;
    });
    const out = makeImage(w, h);
    const o = out.data;
    for (let i = 0; i < d.length; i += 4) {
      o[i] = maps[0][d[i]]; o[i + 1] = maps[1][d[i + 1]]; o[i + 2] = maps[2][d[i + 2]]; o[i + 3] = 255;
    }
    return out;
  }

  /** Light unsharp mask: restores the edge lost to bilinear resampling. */
  function sharpen(img, amount) {
    const a = amount == null ? 0.35 : amount;
    const { width: w, height: h, data: d } = img;
    const out = makeImage(w, h);
    const o = out.data;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        if (x === 0 || y === 0 || x === w - 1 || y === h - 1) {
          o[i] = d[i]; o[i + 1] = d[i + 1]; o[i + 2] = d[i + 2]; o[i + 3] = 255; continue;
        }
        for (let c = 0; c < 3; c++) {
          const blur = (d[i - 4 + c] + d[i + 4 + c] + d[i - w * 4 + c] + d[i + w * 4 + c] + 4 * d[i + c]) / 8;
          o[i + c] = d[i + c] + (d[i + c] - blur) * a * 2;
        }
        o[i + 3] = 255;
      }
    }
    return out;
  }

  /** Anti-aliased rounded corners onto a solid backing (white by default). */
  function roundCorners(img, radius, backing) {
    const r = radius == null ? Math.round(CORNER_RADIUS * img.width / OUT_W) : radius;
    const bg = backing || [255, 255, 255];
    const { width: w, height: h, data: d } = img;
    const centres = [[r, r], [w - r, r], [w - r, h - r], [r, h - r]];
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        let cx = -1, cy = -1;
        if (x < r && y < r) [cx, cy] = centres[0];
        else if (x >= w - r && y < r) [cx, cy] = centres[1];
        else if (x >= w - r && y >= h - r) [cx, cy] = centres[2];
        else if (x < r && y >= h - r) [cx, cy] = centres[3];
        else continue;
        const dd = Math.hypot(x + 0.5 - cx, y + 0.5 - cy);
        const alpha = Math.max(0, Math.min(1, r - dd + 0.5));
        if (alpha >= 1) continue;
        const i = (y * w + x) * 4;
        d[i] = d[i] * alpha + bg[0] * (1 - alpha);
        d[i + 1] = d[i + 1] * alpha + bg[1] * (1 - alpha);
        d[i + 2] = d[i + 2] * alpha + bg[2] * (1 - alpha);
      }
    }
    return img;
  }

  /**
   * How good is this scan? Sharpness is the variance of the Laplacian on a
   * fixed-size copy, so the number means the same at any resolution. Glare is
   * the share of clipped, colourless pixels. Both are judged inside the card.
   */
  function quality(img) {
    const { image: small } = downscale(img, 640);
    const { width: w, height: h } = small;
    const lum = luminance(small);
    const mx = Math.round(w * 0.05), my = Math.round(h * 0.05);
    let sum = 0, sumSq = 0, n = 0, clipped = 0, dark = 0, lumSum = 0;
    const d = small.data;
    for (let y = my; y < h - my; y++) {
      for (let x = mx; x < w - mx; x++) {
        const p = y * w + x;
        const lap = lum[p - 1] + lum[p + 1] + lum[p - w] + lum[p + w] - 4 * lum[p];
        sum += lap; sumSq += lap * lap; n++;
        const i = p * 4;
        const max = Math.max(d[i], d[i + 1], d[i + 2]), min = Math.min(d[i], d[i + 1], d[i + 2]);
        if (max >= 250 && max - min < 14) clipped++;
        if (max < 22) dark++;
        lumSum += lum[p];
      }
    }
    const mean = sum / n;
    const sharpness = Math.round(sumSq / n - mean * mean);
    const glare = clipped / n;
    const exposure = lumSum / n;
    return {
      sharpness,
      sharp: sharpness >= 160 ? 'sharp' : sharpness >= 70 ? 'soft' : 'blurry',
      glare: Math.round(glare * 1000) / 10,
      glareLevel: glare < 0.006 ? 'none' : glare < 0.03 ? 'some' : 'heavy',
      exposure: Math.round(exposure),
      exposureLevel: exposure < 60 ? 'dark' : exposure > 215 ? 'bright' : 'good',
      crushed: Math.round((dark / n) * 1000) / 10,
      width: img.width,
      height: img.height
    };
  }

  /** Flattened card to finished card: optional levels, sharpen, rounded corners. */
  function finishCard(img, options) {
    const opts = options || {};
    let out = img;
    if (opts.autoColour) out = autoLevels(out, opts.strength);
    if (opts.sharpen !== false) out = sharpen(out, opts.sharpenAmount);
    if (opts.round !== false) roundCorners(out, opts.radius, opts.backing);
    return { image: out, quality: quality(out) };
  }

  /**
   * The store's frame: a white square the card fills 94% of, at least 1000px.
   * The image automation squares anything that is not square; delivering it
   * square means the listing looks right the moment it is created.
   */
  function squareCanvas(img, options) {
    const opts = options || {};
    const fill = opts.fill || SQUARE_FILL;
    const min = opts.min || SQUARE_MIN;
    const bg = opts.backing || [255, 255, 255];
    let side = Math.ceil(Math.max(img.width, img.height) / fill);
    let card = img;
    if (side < min) {
      const scale = min / side;
      card = resize(img, Math.round(img.width * scale), Math.round(img.height * scale));
      side = min;
    }
    const out = makeImage(side, side, bg);
    const ox = Math.floor((side - card.width) / 2), oy = Math.floor((side - card.height) / 2);
    const s = card.data, o = out.data;
    for (let y = 0; y < card.height; y++) {
      const si = y * card.width * 4;
      const oi = ((y + oy) * side + ox) * 4;
      o.set(s.subarray(si, si + card.width * 4), oi);
    }
    return out;
  }

  /** Bilinear resize, for the rare upscale and for previews. */
  function resize(img, W, H) {
    const out = makeImage(W, H);
    const sx = img.width / W, sy = img.height / H;
    const s = img.data, o = out.data, sw = img.width, sh = img.height;
    for (let y = 0; y < H; y++) {
      const v = Math.min(sh - 1, Math.max(0, (y + 0.5) * sy - 0.5));
      const y0 = v | 0, y1 = Math.min(sh - 1, y0 + 1), fy = v - y0;
      for (let x = 0; x < W; x++) {
        const u = Math.min(sw - 1, Math.max(0, (x + 0.5) * sx - 0.5));
        const x0 = u | 0, x1 = Math.min(sw - 1, x0 + 1), fx = u - x0;
        const i = (y * W + x) * 4;
        for (let c = 0; c < 3; c++) {
          const a = s[(y0 * sw + x0) * 4 + c] * (1 - fx) + s[(y0 * sw + x1) * 4 + c] * fx;
          const b = s[(y1 * sw + x0) * 4 + c] * (1 - fx) + s[(y1 * sw + x1) * 4 + c] * fx;
          o[i + c] = a * (1 - fy) + b * fy;
        }
        o[i + 3] = 255;
      }
    }
    return out;
  }

  /** Small, zero-mean, unit-variance grey thumbnail for comparing two images. */
  function signature(img, w, h) {
    const small = resize(downscale(img, Math.max(w, h) * 4).image, w, h);
    const out = new Float32Array(w * h);
    let mean = 0;
    for (let p = 0, i = 0; p < out.length; p++, i += 4) {
      out[p] = 0.299 * small.data[i] + 0.587 * small.data[i + 1] + 0.114 * small.data[i + 2];
      mean += out[p];
    }
    mean /= out.length;
    let v = 0;
    for (let p = 0; p < out.length; p++) { out[p] -= mean; v += out[p] * out[p]; }
    const sd = Math.sqrt(v / out.length) || 1;
    for (let p = 0; p < out.length; p++) out[p] /= sd;
    return out;
  }

  /**
   * Which way up is the scan? Geometry cannot tell a card from the same card
   * upside down, but the app always knows which card it is listing, so the
   * catalogue picture settles it: correlate the scan both ways round against
   * the reference and keep the better match. Digital renders and scans agree
   * on layout even where their colours differ.
   *
   * @returns {{turns:0|2, confidence:number, upright:number, flipped:number}}
   */
  function matchOrientation(card, reference) {
    const w = 18, h = 25;
    const a = signature(card, w, h);
    const b = signature(reference, w, h);
    let upright = 0, flipped = 0;
    const n = a.length;
    for (let p = 0; p < n; p++) {
      upright += a[p] * b[p];
      flipped += a[n - 1 - p] * b[p];
    }
    upright /= n; flipped /= n;
    return {
      turns: flipped > upright ? 2 : 0,
      confidence: Math.round(Math.abs(upright - flipped) * 100) / 100,
      upright: Math.round(upright * 100) / 100,
      flipped: Math.round(flipped * 100) / 100
    };
  }

  /**
   * One call from source photo to finished square. Used by the worker.
   *
   * @param img source pixels
   * @param options { corners?, quarterTurns?, autoColour?, square? }
   */
  function process(img, options) {
    const opts = options || {};
    let corners = opts.corners;
    let detection = null;
    if (!corners) {
      detection = detectCard(img);
      if (!detection) return { ok: false, reason: 'No card edge found. Lay the card on a plain, contrasting surface, or drag the corners by hand.' };
      corners = detection.corners;
    }
    let turns = opts.quarterTurns || 0;
    let orientation = null;
    let oriented = portraitCorners(corners, turns);
    let flat = warpCard(img, oriented, { inset: opts.inset });
    if (opts.reference && opts.quarterTurns == null) {
      orientation = matchOrientation(flat, opts.reference);
      if (orientation.turns === 2 && orientation.confidence >= 0.08) {
        turns = 2;
        oriented = portraitCorners(corners, turns);
        flat = rotate(flat, 2);
      }
    }
    const finished = finishCard(flat, { autoColour: !!opts.autoColour });
    const output = opts.square === false ? finished.image : squareCanvas(finished.image);
    return { ok: true, corners, detection, turns, orientation, card: finished.image, image: output, quality: finished.quality };
  }

  return {
    CARD_RATIO, OUT_W, OUT_H, CORNER_RADIUS, SQUARE_FILL, SQUARE_MIN,
    makeImage, downscale, backgroundColour, otsu, dilate, erode, close, open, components,
    convexHull, quadFromHull, orderCorners, refineQuad, isConvex, aspectScore, quadSides,
    detectCards, detectCard, snapEdges, homography, warpCard, rotate, portraitCorners,
    autoLevels, sharpen, roundCorners, quality, finishCard, squareCanvas, resize, process, matchOrientation,
    pointInQuad,
    _candidateMasks: candidateMasks
  };
});
