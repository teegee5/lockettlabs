/*
 * Scan worker. Keeps the heavy pixel work off the page so the camera view and
 * the corner handles stay smooth while a 12 megapixel photo is flattened.
 *
 * Messages in:
 *   { id, type: 'load',    key, image }                 keep a source image
 *   { id, type: 'detect',  key | image, options }       find cards
 *   { id, type: 'process', key, options }               flatten, finish, square
 *   { id, type: 'preview', key, options }               small flattened preview
 *   { id, type: 'forget',  key }
 * Every reply is { id, ok, ... } or { id, ok: false, error }.
 */
/* global importScripts, LLScan */
'use strict';
importScripts('ll-scan.js?v=6.0.0');

const store = new Map();
let reference = null;

function asImage(msg) {
  if (msg.key && store.has(msg.key)) return store.get(msg.key);
  if (msg.image) return { width: msg.image.width, height: msg.image.height, data: new Uint8ClampedArray(msg.image.buffer) };
  throw new Error('That photo is no longer loaded. Open it again.');
}

function pack(img) {
  return { width: img.width, height: img.height, buffer: img.data.buffer };
}

self.onmessage = event => {
  const msg = event.data || {};
  const reply = (data, transfer) => self.postMessage({ id: msg.id, ok: true, ...data }, transfer || []);
  try {
    if (msg.type === 'load') {
      store.set(msg.key, asImage(msg));
      // Only the newest few photos are kept; each is up to 64 MB of pixels.
      while (store.size > 3) store.delete(store.keys().next().value);
      reply({});
      return;
    }
    if (msg.type === 'reference') {
      reference = msg.image ? { width: msg.image.width, height: msg.image.height, data: new Uint8ClampedArray(msg.image.buffer) } : null;
      reply({});
      return;
    }
    if (msg.type === 'forget') {
      store.delete(msg.key);
      reply({});
      return;
    }
    if (msg.type === 'detect') {
      const img = asImage(msg);
      const opts = msg.options || {};
      const cards = LLScan.detectCards(img, { max: opts.max || 12, work: opts.work || 720, refine: opts.refine !== false });
      let best = cards[0] || null;
      if (!opts.multi) {
        const single = LLScan.detectCard(img, { work: opts.work || 720, refine: opts.refine !== false });
        best = single;
      }
      reply({ cards, best });
      return;
    }
    if (msg.type === 'preview') {
      const img = asImage(msg);
      const o = msg.options || {};
      const corners = LLScan.portraitCorners(o.corners, o.quarterTurns || 0);
      let flat = LLScan.warpCard(img, corners, { width: o.width || 378, height: o.height || 528 });
      if (o.autoColour) flat = LLScan.autoLevels(flat);
      LLScan.roundCorners(flat);
      reply({ image: pack(flat) }, [flat.data.buffer]);
      return;
    }
    if (msg.type === 'process') {
      const img = asImage(msg);
      const o = msg.options || {};
      const result = LLScan.process(img, {
        corners: o.corners,
        quarterTurns: o.quarterTurns,
        autoColour: !!o.autoColour,
        reference: o.useReference && reference ? reference : null
      });
      if (!result.ok) { self.postMessage({ id: msg.id, ok: false, error: result.reason }); return; }
      reply({
        image: pack(result.image),
        corners: result.corners,
        turns: result.turns,
        orientation: result.orientation,
        quality: result.quality
      }, [result.image.data.buffer]);
      return;
    }
    throw new Error('Unknown scan request.');
  } catch (error) {
    self.postMessage({ id: msg.id, ok: false, error: error && error.message ? error.message : String(error) });
  }
};
