<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/retailers/chaos.php';

$assertions = [];

$assertions[] = retailer_chaos_search_url('OP16-040') === 'https://www.chaoscards.co.uk/search/op16-040';
$assertions[] = retailer_chaos_search_url('OP16-045') === 'https://www.chaoscards.co.uk/search/op16-045';
$assertions[] = retailer_chaos_search_url('026/086') === 'https://www.chaoscards.co.uk/search/026-086';
// Name + number slug (Tyranitar-style), not bare 135-193.
$assertions[] = retailer_chaos_search_url('135/193', 'Tyranitar') === 'https://www.chaoscards.co.uk/search/tyranitar-135-193';
$assertions[] = retailer_chaos_search_url('135/193', 'Tatsugiri') === 'https://www.chaoscards.co.uk/search/tatsugiri-135-193';

$fixture = [
    'Results' => [
        [
            'Document' => [
                'title' => ['One Piece OP16-045 Crocodile Uncommon'],
                'price' => ['0.25'],
                'code' => ['OPSC-OP16-045'],
                'in_stock' => ['true'],
                'url' => ['/one-piece-op16-045-crocodile'],
            ],
        ],
        [
            'Document' => [
                'title' => ['One Piece OP16-045a Alt Art'],
                'price' => ['12.00'],
                'code' => ['OPSC-OP16-045A'],
                'in_stock' => ['true'],
                'url' => ['/one-piece-op16-045a'],
            ],
        ],
        [
            'Document' => [
                'title' => ['One Piece OP16-040 Some Card'],
                'price' => ['0.40'],
                'code' => ['OPSC-OP16-040'],
                'in_stock' => ['false'],
                'url' => ['/one-piece-op16-040'],
            ],
        ],
    ],
];

$rows = retailer_chaos_extract_rows($fixture);
$assertions[] = count($rows) === 3;
$assertions[] = ($rows[0]['priceGbp'] ?? null) === 0.25;
$assertions[] = ($rows[0]['inStock'] ?? null) === true;
$assertions[] = ($rows[2]['inStock'] ?? null) === false;

$assertions[] = retailer_chaos_row_matches_number($rows[0], 'OP16-045') === true;
$assertions[] = retailer_chaos_row_matches_number($rows[1], 'OP16-045') === false; // alt art suffix
$assertions[] = retailer_chaos_row_matches_number($rows[2], 'OP16-040') === true;

// Wugtrio Chaos title: unpadded mid-title number vs padded scan input.
$wugtrioRow = [
    'title' => 'Wugtrio : SCARLET AND VIOLET - PARADOX RIFT 53/182 - Pokemon Single Card',
    'code' => '',
    'url' => '/wugtrio-scarlet-violet-paradox-rift-53-182',
    'priceGbp' => 0.15,
    'inStock' => true,
];
$assertions[] = retailer_chaos_row_matches_number($wugtrioRow, '053/182') === true;
$assertions[] = retailer_chaos_row_matches_number($wugtrioRow, '53/182') === true;
$assertions[] = retailer_chaos_row_matches_number($wugtrioRow, '53-182') === true;
$assertions[] = retailer_name_score($wugtrioRow['title'], 'Wugtrio') === 100;
$assertions[] = retailer_name_score($wugtrioRow['title'], 'Tyranitar') === 0;

$oosOnly = [
    'Results' => [[
        'Document' => [
            'title' => ['Card OP16-040'],
            'price' => ['0.40'],
            'code' => ['X-OP16-040'],
            'in_stock' => ['0'],
            'url' => ['/search/op16-040'],
        ],
    ]],
];
$oosRows = retailer_chaos_extract_rows($oosOnly);
$assertions[] = ($oosRows[0]['inStock'] ?? null) === false;

// Number-only collision: Tyranitar vs Tatsugiri both 135/193 — name filter required.
$pokeFixture = [
    'Results' => [
        [
            'Document' => [
                'title' => ['Pokemon Japanese Tatsugiri 135/193 MEGA Dream ex'],
                'price' => ['2.50'],
                'code' => ['PKM-135-193-TAT'],
                'in_stock' => ['true'],
                'url' => ['/pokemon-tatsugiri-135-193'],
            ],
        ],
        [
            'Document' => [
                'title' => ['Pokemon Tyranitar 135/193 Paldea Evolved'],
                'price' => ['0.80'],
                'code' => ['PKM-135-193-TYR'],
                'in_stock' => ['true'],
                'url' => ['/pokemon-tyranitar-135-193'],
            ],
        ],
    ],
];
$pokeRows = retailer_chaos_extract_rows($pokeFixture);
$assertions[] = count($pokeRows) === 2;
$tyMatches = [];
$wrongMatches = [];
foreach ($pokeRows as $row) {
    if (!retailer_chaos_row_matches_number($row, '135/193')) continue;
    $hay = trim(($row['title'] ?? '') . ' ' . ($row['code'] ?? '') . ' ' . ($row['url'] ?? ''));
    if (retailer_name_score($hay, 'Tyranitar') >= 60) {
        $tyMatches[] = $row;
    }
    if (retailer_name_score($hay, 'Tyranitar') < 60) {
        $wrongMatches[] = $row;
    }
}
$assertions[] = count($tyMatches) === 1;
$assertions[] = str_contains((string) ($tyMatches[0]['title'] ?? ''), 'Tyranitar');
$assertions[] = count($wrongMatches) === 1;
$assertions[] = str_contains((string) ($wrongMatches[0]['title'] ?? ''), 'Tatsugiri');

foreach ($assertions as $index => $ok) {
    if (!$ok) {
        fwrite(STDERR, "Chaos HawkSearch assertion failed at index {$index}\n");
        exit(1);
    }
}

echo "Chaos HawkSearch tests passed.\n";
