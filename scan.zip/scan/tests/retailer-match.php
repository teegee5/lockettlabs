<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/retailers/match.php';

$assertions = [];

// Search keyword prefers name + number (Tyranitar-style), not bare number.
$assertions[] = retailer_search_keyword('135/193', 'Tyranitar', 'Paldea Evolved') === 'Tyranitar 135/193';
$assertions[] = retailer_search_keyword('OP16-045', 'Crocodile') === 'Crocodile OP16-045';
$assertions[] = retailer_search_keyword('135/193') === '135/193';

// Padding: prefer unpadded slash form for HawkSearch-style keywords.
$assertions[] = retailer_search_keyword('053/182', 'Wugtrio') === 'Wugtrio 53/182';
$assertions[] = retailer_search_keyword('53/182', 'Wugtrio') === 'Wugtrio 53/182';
$wugKeywords = retailer_search_keywords('053/182', 'Wugtrio', 'Paradox Rift');
$assertions[] = in_array('Wugtrio 53/182', $wugKeywords, true);
$assertions[] = in_array('Wugtrio 053/182', $wugKeywords, true);
$assertions[] = in_array('Wugtrio Paradox Rift 53/182', $wugKeywords, true);

// Number forms / regex: 053/182 ≡ 53/182 ≡ 53-182
$assertions[] = retailer_number_forms('053/182') === ['53/182', '053/182'];
$assertions[] = retailer_slash_number_parts('53-182') === ['53', '182'];

// Chaos mid-title (number not trailing) + padding mismatch.
$chaosTitle = 'Wugtrio : SCARLET AND VIOLET - PARADOX RIFT 53/182 - Pokemon Single Card';
$assertions[] = retailer_text_contains_exact_number($chaosTitle, '053/182') === true;
$assertions[] = retailer_text_contains_exact_number($chaosTitle, '53/182') === true;
$assertions[] = retailer_text_contains_exact_number($chaosTitle, '53-182') === true;

// Total Cards trailing padded title when scanning unpadded / padded.
$tcTitle = 'Pokemon - Scarlet & Violet - Paradox Rift - Wugtrio - 053/182';
$assertions[] = retailer_title_matches_number($tcTitle, '53/182') === true;
$assertions[] = retailer_title_matches_number($tcTitle, '053/182') === true;
$assertions[] = retailer_handle_matches_number(
    'pokemon-scarlet-violet-paradox-rift-wugtrio-053-182',
    '53/182'
) === true;

// Name score: same number, different Pokémon must not collide.
$tyranitarTitle = 'Pokemon Tyranitar 135/193 Paldea Evolved';
$tatsugiriTitle = 'Pokemon Japanese Tatsugiri 135/193 MEGA Dream ex';
$assertions[] = retailer_name_score($tyranitarTitle, 'Tyranitar') === 100;
$assertions[] = retailer_name_score($tatsugiriTitle, 'Tyranitar') === 0;
$assertions[] = retailer_name_score($tatsugiriTitle, 'Tatsugiri') === 100;
$assertions[] = retailer_identity_matches($tyranitarTitle, 'Tyranitar', 'Paldea Evolved') === true;
$assertions[] = retailer_identity_matches($tatsugiriTitle, 'Tyranitar', 'Paldea Evolved') === false;
$assertions[] = retailer_identity_matches($tatsugiriTitle, '') === false; // no name → cannot safely match

// Set bonus helps when both titles contain the name somehow.
$assertions[] = retailer_set_score($tyranitarTitle, 'Paldea Evolved') >= 10;
$assertions[] = retailer_set_score($tatsugiriTitle, 'Paldea Evolved') === 0;

// OP suffix rejection still holds after padding-aware matchers.
$assertions[] = retailer_title_matches_number('Card (Uncommon) - OP16-045', 'OP16-045') === true;
$assertions[] = retailer_title_matches_number('Card (SR) - OP16-032a', 'OP16-032') === false;

foreach ($assertions as $index => $ok) {
    if (!$ok) {
        fwrite(STDERR, "Retailer match assertion failed at index {$index}\n");
        exit(1);
    }
}

echo "Retailer match identity tests passed.\n";
