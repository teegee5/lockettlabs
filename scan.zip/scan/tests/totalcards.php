<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/totalcards.php';

$assertions = [
    totalcards_normalize_number(' op16-045 ') === 'OP16-045',
    totalcards_title_matches_number('One Piece - The Time of Battle - Crocodile (Uncommon) - OP16-045', 'OP16-045'),
    !totalcards_title_matches_number('One Piece - Boa Hancock (Super Rare) - OP16-032a', 'OP16-032'),
    totalcards_title_matches_number('One Piece - Boa Hancock (Super Rare) - OP16-032', 'OP16-032'),
    totalcards_handle_matches_number('one-piece-the-time-of-battle-crocodile-op16-045', 'OP16-045'),
    !totalcards_handle_matches_number('one-piece-the-time-of-battle-boa-hancock-op16-032a', 'OP16-032'),
    totalcards_sku_matches('OPSC-OP16-045', 'OP16-045'),
    !totalcards_sku_matches('OPSC-OP16-032A', 'OP16-032'),
    totalcards_rarity_from_title('One Piece - The Time of Battle - Crocodile (Uncommon) - OP16-045') === 'Uncommon',
    totalcards_is_common_or_uncommon('Uncommon'),
    totalcards_is_common_or_uncommon('Common'),
    !totalcards_is_common_or_uncommon('Super Rare'),
    totalcards_parse_price('0.28') === 0.28,
    totalcards_parse_price(0) === null,
    // NM fill: always next odd pence strictly above Total Cards retail.
    totalcards_adjust_nm_price(0.23) === 0.25,
    totalcards_adjust_nm_price(0.28) === 0.29,
    totalcards_adjust_nm_price(0.18) === 0.19,
    totalcards_adjust_nm_price(0.24) === 0.25,
    totalcards_adjust_nm_price(0.25) === 0.27,
    totalcards_adjust_nm_price(0.20) === 0.21,
    totalcards_adjust_nm_price(1.00) === 1.01,
    // Pokémon padding: Total Cards 053/182 ↔ scan 53/182.
    totalcards_title_matches_number(
        'Pokemon - Scarlet & Violet - Paradox Rift - Wugtrio - 053/182',
        '53/182'
    ),
    totalcards_title_matches_number(
        'Pokemon - Scarlet & Violet - Paradox Rift - Wugtrio - 053/182',
        '053/182'
    ),
    totalcards_handle_matches_number(
        'pokemon-scarlet-violet-paradox-rift-wugtrio-053-182',
        '53/182'
    ),
];

foreach ($assertions as $index => $ok) {
    if (!$ok) {
        fwrite(STDERR, 'Total Cards assertion failed at index ' . $index . PHP_EOL);
        exit(1);
    }
}

echo "Total Cards helper tests passed.\n";
