/**
 * Regression: bare local numbers expand with set context (mirrors PHP helpers).
 * Run: node tests/expand-set-number.js
 */
function normalize(value) {
  return String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
}
function extractBandaiSetCode(value) {
  const text = String(value || '').trim().toUpperCase();
  if (!text) return '';
  if (/^(?:PRB|OP|BT|EX|ST|EB|RB|LM|GD|UA|P)\d{1,3}[A-Z]{0,3}$/.test(text)) return text;
  const embedded = text.match(/\b((?:PRB|OP|BT|EX|ST|EB|RB|LM|GD|UA)\d{1,3}[A-Z]{0,3})\b/);
  return embedded ? embedded[1] : '';
}
function bandaiSetCodeAlias(setQuery) {
  const wanted = normalize(setQuery);
  if (!wanted) return '';
  const aliases = {
    thetimeofbattle: 'OP16',
    thetimeofbattleonepiececardgame: 'OP16',
    thetimeofbattlereleaseeventcards: 'OP16',
    thetimeofbattlereleaseeventcardsonepiececardgame: 'OP16',
  };
  if (aliases[wanted]) return aliases[wanted];
  for (const [needle, code] of Object.entries(aliases)) {
    if (wanted.includes(needle)) return code;
  }
  return '';
}
function padLocalCardNumber(localRaw, width = 3) {
  const match = String(localRaw || '').trim().toUpperCase().match(/^([A-Z]*)(\d+)([A-Z]*)$/);
  if (!match) return String(localRaw || '').toUpperCase();
  return match[1] + match[2].padStart(width, '0') + match[3];
}
function expandNumberWithSetContext(game, setQuery, number) {
  const trimmed = String(number || '').trim();
  if (!trimmed || !setQuery?.trim() || !/one-piece|digimon|gundam|dragon-ball|union-arena/i.test(game)) return trimmed;
  if (/[-\/]/.test(trimmed)) return trimmed;
  if (/^(?:PRB|OP|BT|EX|ST|EB|RB|LM|GD|UA)\d{1,3}[A-Z]{0,3}\d{2,4}$/i.test(trimmed.replace(/\s+/g, ''))) {
    return trimmed.replace(/\s+/g, '');
  }
  const local = trimmed.replace(/\s+/g, '');
  if (!/^[A-Z]*\d{1,6}[A-Z]*$/i.test(local)) return trimmed;
  const setCode = extractBandaiSetCode(setQuery) || bandaiSetCodeAlias(setQuery);
  if (!setCode) return trimmed;
  return `${setCode}-${padLocalCardNumber(local, 3)}`;
}

const cases = [
  ['002', 'OP16', 'one-piece-card-game', 'OP16-002'],
  ['002', 'The Time of Battle', 'one-piece-card-game', 'OP16-002'],
  ['065', 'OP16', 'one-piece-card-game', 'OP16-065'],
  ['65', 'OP16', 'one-piece-card-game', 'OP16-065'],
  ['65', 'The Time of Battle', 'one-piece-card-game', 'OP16-065'],
  ['026/086', 'OP16', 'one-piece-card-game', '026/086'],
];

let failed = 0;
for (const [number, set, game, expected] of cases) {
  const actual = expandNumberWithSetContext(game, set, number);
  const ok = actual === expected;
  if (!ok) failed += 1;
  console.log(`${ok ? 'OK' : 'FAIL'} ${number} + ${set} => ${actual} (want ${expected})`);
}
process.exit(failed ? 1 : 0);
