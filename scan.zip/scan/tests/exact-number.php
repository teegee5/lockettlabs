<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/providers.php';

$cases = [
    ['026/086', ['cardNumber' => '026/086', 'setCode' => ''], true],
    ['026/086', ['cardNumber' => '26/86', 'setCode' => ''], true],
    ['026/086', ['cardNumber' => '026/084', 'setCode' => ''], false],
    ['026/086', ['cardNumber' => '126/086', 'setCode' => ''], false],
    ['OP01-026', ['cardNumber' => 'OP01-026', 'setCode' => 'OP01'], true],
    ['OP01-026', ['cardNumber' => 'OP02-026', 'setCode' => 'OP02'], false],
    ['OP16-065', ['cardNumber' => 'OP16-065', 'setCode' => 'OP16'], true],
    ['OP16-065', ['cardNumber' => 'OP16-165', 'setCode' => 'OP16'], false],
    ['OP16-065', ['cardNumber' => 'OP16-065a', 'setCode' => 'OP16'], false],
    ['SV8A-090', ['cardNumber' => '090/187', 'setCode' => 'sv8a'], true],
    ['SV8A-090', ['cardNumber' => '090/187', 'setCode' => 'sv7a'], false],
];

$expansion = [
    ['065', 'OP16', 'one-piece-card-game', 'OP16-065'],
    ['65', 'OP16', 'one-piece-card-game', 'OP16-065'],
    ['002', 'OP16', 'one-piece-card-game', 'OP16-002'],
    ['002', 'The Time of Battle', 'one-piece-card-game', 'OP16-002'],
    ['65', 'The Time of Battle', 'one-piece-card-game', 'OP16-065'],
    ['OP16-065', 'The Time of Battle', 'one-piece-card-game', 'OP16-065'],
    ['001', 'BT14', 'digimon-card-game', 'BT14-001'],
    ['026', 'Base Set', 'pokemon', '026'],
    ['026/086', 'OP16', 'one-piece-card-game', '026/086'],
];
foreach ($expansion as [$number, $set, $game, $expected]) {
    $actual = expand_number_with_set_context($number, $set, $game);
    if ($actual !== $expected) {
        fwrite(STDERR, "Expansion failed: {$number} + {$set} => {$actual}, expected {$expected}\n");
        exit(1);
    }
}

$matchCases = [
    ['OP16-002', ['cardNumber' => 'OP16-002', 'setCode' => 'OP16'], true],
    ['OP16-002', ['cardNumber' => 'OP16-002a', 'setCode' => 'OP16'], false],
    ['002', ['cardNumber' => 'OP16-002', 'setCode' => 'OP16'], true],
];
foreach ($matchCases as [$needle, $card, $expected]) {
    $actual = exact_card_number_match($card, $needle);
    if ($actual !== $expected) {
        fwrite(STDERR, "Match failed: {$needle} against {$card['cardNumber']}\n");
        exit(1);
    }
}

foreach ($cases as [$needle, $card, $expected]) {
    $actual = exact_card_number_match($card, $needle);
    if ($actual !== $expected) {
        fwrite(STDERR, "Failed: {$needle} against {$card['cardNumber']}\n");
        exit(1);
    }
}

echo "Exact card-number tests passed.\n";
