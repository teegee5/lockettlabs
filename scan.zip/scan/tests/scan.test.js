// node tests/scan.test.js
//
// The scan engine against procedurally drawn cards with known corners. The
// full photographic benchmark (30 real cards on wood, paper, mat, black and
// flatbed, plus a four-card sheet) lives with the overhaul notes because its
// fixtures are 650 MB; this file keeps the guarantees runnable anywhere.
'use strict';

const assert = require('assert');
const S = require('../assets/ll-scan.js');

let passed = 0;
const failures = [];
function test(name, fn) {
  try { fn(); passed += 1; } catch (error) { failures.push(`${name}\n    ${error.stack.split('\n').slice(0, 3).join('\n    ')}`); }
}

/** A card-like picture: yellow border, dark body, a bright art box near the top, text bars. */
function drawCard(w, h) {
  const img = S.makeImage(w, h, [236, 200, 52]);
  const d = img.data;
  const set = (x, y, c) => { const i = (y * w + x) * 4; d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2]; };
  const bx = Math.round(w * 0.055), by = Math.round(h * 0.04);
  for (let y = by; y < h - by; y++) for (let x = bx; x < w - bx; x++) set(x, y, [46, 44, 52]);
  for (let y = Math.round(h * 0.12); y < Math.round(h * 0.5); y++) {
    for (let x = Math.round(w * 0.12); x < Math.round(w * 0.88); x++) {
      set(x, y, [150 + ((x * 7) % 60), 90 + ((y * 5) % 80), 200 - ((x + y) % 70)]);
    }
  }
  for (let line = 0; line < 6; line++) {
    const y0 = Math.round(h * (0.58 + line * 0.06));
    for (let y = y0; y < y0 + Math.round(h * 0.015); y++) for (let x = Math.round(w * 0.15); x < Math.round(w * (0.6 + (line % 3) * 0.1)); x++) set(x, y, [230, 230, 228]);
  }
  return img;
}

/** Composite a card into a photo with a perspective homography, rounded corners and noise. */
function photograph(card, W, H, corners, background) {
  const out = S.makeImage(W, H, background || [120, 82, 52]);
  const o = out.data;
  // Map photo pixels back into the card.
  const Hm = S.homography(corners, [[0, 0], [card.width, 0], [card.width, card.height], [0, card.height]]);
  const r = card.width * 0.05;
  let seed = 7;
  const rand = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const den = Hm[6] * x + Hm[7] * y + 1;
      const u = (Hm[0] * x + Hm[1] * y + Hm[2]) / den;
      const v = (Hm[3] * x + Hm[4] * y + Hm[5]) / den;
      const i = (y * W + x) * 4;
      let inside = u >= 0 && v >= 0 && u < card.width && v < card.height;
      if (inside) {
        const cx = Math.min(Math.max(u, r), card.width - r), cy = Math.min(Math.max(v, r), card.height - r);
        if (Math.hypot(u - cx, v - cy) > r) inside = false;
      }
      if (inside) {
        const j = ((v | 0) * card.width + (u | 0)) * 4;
        o[i] = card.data[j]; o[i + 1] = card.data[j + 1]; o[i + 2] = card.data[j + 2];
      }
      const n = (rand() - 0.5) * 8;
      o[i] = Math.max(0, Math.min(255, o[i] + n)); o[i + 1] = Math.max(0, Math.min(255, o[i + 1] + n)); o[i + 2] = Math.max(0, Math.min(255, o[i + 2] + n));
    }
  }
  return out;
}

function cornerError(found, truth) {
  let worst = 0;
  for (const c of found) worst = Math.max(worst, Math.min(...truth.map(t => Math.hypot(t[0] - c[0], t[1] - c[1]))));
  return worst;
}

const card = drawCard(630, 880);
const truth = [[212, 160], [742, 214], [700, 948], [168, 905]];
const photo = photograph(card, 960, 1120, truth);

test('finds a skewed card on wood to within a pixel or two', () => {
  const det = S.detectCard(photo);
  assert.ok(det, 'no card found');
  const err = cornerError(det.corners, truth);
  assert.ok(err < 2.5, `corner error ${err.toFixed(2)}px`);
});

test('finds a light-bordered card on white paper', () => {
  const pale = drawCard(630, 880);
  const p = photograph(pale, 960, 1120, truth, [232, 230, 226]);
  const det = S.detectCard(p);
  assert.ok(det, 'no card found');
  assert.ok(cornerError(det.corners, truth) < 3, 'corner error too large');
});

test('produces the store frame: square, card fills 94%, at least 1000px', () => {
  const res = S.process(photo, {});
  assert.ok(res.ok, res.reason);
  assert.strictEqual(res.image.width, res.image.height);
  assert.strictEqual(res.image.width, Math.ceil(S.OUT_H / S.SQUARE_FILL));
  assert.ok(res.image.width >= S.SQUARE_MIN);
  assert.strictEqual(res.card.width, S.OUT_W);
  assert.strictEqual(res.card.height, S.OUT_H);
  // The frame is white and the card corners are rounded onto white.
  const d = res.image.data;
  assert.deepStrictEqual([d[0], d[1], d[2]], [255, 255, 255]);
  const c = res.card.data;
  assert.ok(c[0] > 240 && c[1] > 240 && c[2] > 240, 'corner pixel should be rounded away to white');
});

test('a sideways photo comes out portrait', () => {
  const sideways = photograph(card, 1200, 900, [[180, 760], [170, 170], [990, 160], [1000, 750]]);
  const res = S.process(sideways, {});
  assert.ok(res.ok, res.reason);
  assert.ok(res.card.height > res.card.width);
});

test('the catalogue picture decides which way up', () => {
  const upsideDown = photograph(card, 960, 1120, [truth[2], truth[3], truth[0], truth[1]]);
  const res = S.process(upsideDown, { reference: card });
  assert.ok(res.ok);
  assert.strictEqual(res.turns, 2, 'should have turned the scan the right way up');
  const check = S.matchOrientation(res.card, card);
  assert.strictEqual(check.turns, 0);
});

test('quality: a sharp scan scores sharp, a blurred one does not', () => {
  const sharp = S.quality(S.warpCard(photo, S.detectCard(photo).corners));
  const blurred = S.makeImage(card.width, card.height);
  const d = card.data, b = blurred.data, w = card.width, h = card.height;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      for (let k = 0; k < 3; k++) {
        let s = 0, n = 0;
        for (let dy = -6; dy <= 6; dy += 2) for (let dx = -6; dx <= 6; dx += 2) {
          const xx = Math.min(w - 1, Math.max(0, x + dx)), yy = Math.min(h - 1, Math.max(0, y + dy));
          s += d[(yy * w + xx) * 4 + k]; n++;
        }
        b[(y * w + x) * 4 + k] = s / n;
      }
      b[(y * w + x) * 4 + 3] = 255;
    }
  }
  const soft = S.quality(blurred);
  assert.ok(sharp.sharpness > soft.sharpness * 2, `sharp ${sharp.sharpness} vs blurred ${soft.sharpness}`);
  assert.notStrictEqual(soft.sharp, 'sharp');
});

test('glare is measured inside the card', () => {
  const glary = S.makeImage(630, 880, [60, 60, 70]);
  for (let y = 300; y < 500; y++) for (let x = 200; x < 450; x++) {
    const i = (y * 630 + x) * 4; glary.data[i] = 255; glary.data[i + 1] = 255; glary.data[i + 2] = 255;
  }
  const q = S.quality(glary);
  assert.strictEqual(q.glareLevel, 'heavy');
  assert.strictEqual(S.quality(card).glareLevel, 'none');
});

test('a flatbed sheet with two cards yields two crops', () => {
  const sheet = S.makeImage(1400, 1100, [246, 246, 244]);
  const placeCard = (ox, oy) => {
    const p = photograph(card, 1400, 1100, [[ox, oy], [ox + 504, oy], [ox + 504, oy + 704], [ox, oy + 704]], [246, 246, 244]);
    for (let i = 0; i < p.data.length; i += 4) {
      if (Math.abs(p.data[i] - 246) + Math.abs(p.data[i + 1] - 246) + Math.abs(p.data[i + 2] - 244) > 24) {
        sheet.data[i] = p.data[i]; sheet.data[i + 1] = p.data[i + 1]; sheet.data[i + 2] = p.data[i + 2];
      }
    }
  };
  placeCard(120, 180);
  placeCard(780, 220);
  const found = S.detectCards(sheet, { max: 6 });
  assert.strictEqual(found.length, 2, `found ${found.length}`);
});

test('a tight crop with no background is used whole', () => {
  const det = S.detectCard(card);
  assert.ok(det);
  assert.ok(det.method === 'full-frame' || cornerError(det.corners, [[0, 0], [629, 0], [629, 879], [0, 879]]) < 4);
});

test('homography maps the four corners exactly', () => {
  const src = [[10, 20], [300, 15], [320, 400], [5, 380]];
  const dst = [[0, 0], [100, 0], [100, 140], [0, 140]];
  const H = S.homography(src, dst);
  for (let i = 0; i < 4; i++) {
    const [x, y] = src[i];
    const den = H[6] * x + H[7] * y + 1;
    assert.ok(Math.abs((H[0] * x + H[1] * y + H[2]) / den - dst[i][0]) < 1e-6);
    assert.ok(Math.abs((H[3] * x + H[4] * y + H[5]) / den - dst[i][1]) < 1e-6);
  }
});

console.log(`${passed} passed, ${failures.length} failed`);
if (failures.length) {
  for (const f of failures) console.log(' - ' + f);
  process.exit(1);
}
