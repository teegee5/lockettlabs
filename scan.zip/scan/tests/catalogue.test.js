// node tests/catalogue.test.js
//
// The store's title grammar, checked against real listings. Each expected
// title below is either copied from the live catalogue or is the corrected
// form the owner asked for (printed numbers, no forced zero).
'use strict';

const assert = require('assert');
const C = require('../assets/ll-catalogue.js');

let passed = 0;
const failures = [];
function test(name, fn) {
  try { fn(); passed += 1; } catch (error) { failures.push(`${name}\n    ${error.message}`); }
}
const eq = (actual, expected, label) => assert.strictEqual(actual, expected, `${label || ''} expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
const pk = (setName, name, cardNumber, extra) => ({ game: 'pokemon', languageCode: 'en', setName, name, cardNumber, ...(extra || {}) });

// --------------------------------------------------------------- numbers

test('Classic Collection reprint keeps its original unpadded number (the reported Sneasel)', () => {
  const card = pk('ME: 30th Celebration Classic Collection', 'Sneasel', '025/111', { rarity: 'Classic Collection' });
  eq(C.printedNumber(card), '25/111');
  eq(C.buildTitle(card, { finish: 'Holo' }), 'Sneasel : 30TH CELEBRATION - 25/111');
});

test('a 30th Celebration card whose total is not /128 is treated as Classic Collection', () => {
  eq(C.printedNumber(pk('ME: 30th Celebration', 'Dark Tyranitar', '019/109')), '19/109');
  eq(C.printedNumber(pk('ME: 30th Celebration', 'Pikachu', '25/128')), '025/128');
});

test('vintage and pre-SWSH sets print without the zero', () => {
  eq(C.printedNumber(pk('Neo Genesis', 'Sneasel', '025/111')), '25/111');
  eq(C.printedNumber(pk('SM - Cosmic Eclipse', 'Sunflora', '008/236')), '8/236');
  eq(C.printedNumber(pk('XY - BREAKthrough', 'Braixen', '026/162')), '26/162');
  eq(C.printedNumber(pk('Legendary Treasures', 'Zekrom', '51/113')), '51/113');
  eq(C.printedNumber(pk('Jungle', 'Kangaskhan (21)', '21/64')), '21/64');
});

test('Sword & Shield onward pads both sides to three digits', () => {
  eq(C.printedNumber(pk('ME05: Pitch Black', 'Armarouge', '12/84')), '012/084');
  eq(C.printedNumber(pk('Celebrations', "Professor's Research", '023/025')), '023/025');
  eq(C.printedNumber(pk('Pokemon GO', 'Bibarel', '60/78')), '060/078');
  eq(C.printedNumber(pk('SV: Paldean Fates', 'Capsakid', '106/91')), '106/091');
});

test('lettered sub-sets are written as printed', () => {
  eq(C.printedNumber(pk('SWSH09: Brilliant Stars Trainer Gallery', 'Mimikyu V', 'TG16/TG30')), 'TG16/TG30');
  eq(C.printedNumber(pk('Hidden Fates: Shiny Vault', 'Eevee', 'SV41/SV94')), 'SV41/SV94');
  eq(C.printedNumber(pk('Generations: Radiant Collection', 'Charizard', 'RC5/RC32')), 'RC5/RC32');
});

test('promo codes follow the store: SWSH070, SVP093, MEP011, SM32', () => {
  eq(C.printedNumber(pk('SWSH: Sword & Shield Promo Cards', 'Eevee V', 'SWSH065')), 'SWSH065');
  eq(C.printedNumber(pk('ME: Mega Evolution Promo', 'Oshawott - 051', '051')), 'MEP051');
  eq(C.printedNumber(pk('ME: Mega Evolution Promo', 'Mega Latias ex', '11')), 'MEP011');
  eq(C.printedNumber(pk('SV: Scarlet & Violet Promo Cards', 'Smoliv', '23')), 'SVP023');
  eq(C.printedNumber(pk('SM Promos', 'Tapu Bulu GX', 'SM32')), 'SM32');
  eq(C.printedNumber(pk('SM Promos', 'Tapu Koko', 'SM05')), 'SM05');
  eq(C.printedNumber(pk('MEE: Mega Evolution Energies', 'Basic Fire Energy - 002', '2')), 'MEE002');
});

test('mixed promo families trust the number in the provider name', () => {
  eq(C.printedNumber(pk('League & Championship Cards', 'Malamar - 51/131 (League Challenge) [1st Place]', '051/131')), '51/131');
  eq(C.printedNumber(pk('Alternate Art Promos', 'Reset Stamp - 206a/236', '206a/236')), '206a/236');
  eq(C.printedNumber(pk('League & Championship Cards', 'Charcade - 026/182', '026/182')), '026/182');
});

test('McDonald\'s years print the way each year was printed', () => {
  eq(C.printedNumber(pk("McDonald's 25th Anniversary Promos", 'Pikachu', '025/025')), '25/25');
  eq(C.printedNumber(pk("McDonald's Promos 2022", 'Sprigatito', '01/15')), '1/15');
  eq(C.printedNumber(pk("McDonald's Promos 2023", 'Fuecoco', '2/15')), '002/015');
});

test('an unknown set falls back to its release date', () => {
  eq(C.printedNumber(pk('ME07: Future Set', 'Testmon', '5/100', { setReleaseDate: '2027-01-15' })), '005/100');
  eq(C.printedNumber(pk('Some Old Set', 'Testmon', '005/100', { setReleaseDate: '2012-05-01' })), '5/100');
  eq(C.printedNumber(pk('Some Undated Set', 'Testmon', '005/100')), '005/100');
});

test('Japanese cards keep three-digit printing', () => {
  eq(C.printedNumber({ game: 'pokemon-japan', languageCode: 'ja', setName: 'SV2D: Clay Burst', name: 'Flamigo', cardNumber: '82/71' }), '082/071');
});

test('Lorcana prints without the zero', () => {
  eq(C.printedNumber({ game: 'disney-lorcana', setName: 'Fabled', name: 'x', cardNumber: '043/204' }), '43/204');
  eq(C.printedNumber({ game: 'disney-lorcana', setName: 'Fabled', name: 'x', cardNumber: '1/204' }), '1/204');
});

test('Magic gets 035/331 only when the printed total is known and the era printed it', () => {
  eq(C.printedNumber({ game: 'magic-the-gathering', setName: 'Double Masters 2022', cardNumber: '35', printedTotal: 331, releasedAt: '2022-07-08' }), '035/331');
  eq(C.printedNumber({ game: 'magic-the-gathering', setName: 'Marvel Super Heroes', cardNumber: '189', printedTotal: 280, releasedAt: '2026-06-26' }), '189');
  eq(C.printedNumber({ game: 'magic-the-gathering', setName: 'Double Masters 2022', cardNumber: '35' }), '35');
});

test('Bandai codes pass through', () => {
  eq(C.printedNumber({ game: 'one-piece-card-game', setName: "The World's Strongest Warriors", cardNumber: 'op17-049' }), 'OP17-049');
  eq(C.printedNumber({ game: 'digimon-card-game', setName: 'Great Legend', cardNumber: 'BT4-057' }), 'BT4-057');
});

test('sealed rows have no number', () => {
  eq(C.printedNumber(pk('ME: 30th Celebration', '30th Celebration Elite Trainer Box', 'N/A')), '');
});

// --------------------------------------------------------------- titles

test('Pokemon single, store format with lower-case "Reverse holo"', () => {
  eq(C.buildTitle(pk('ME05: Pitch Black', 'Armarouge', '12/84'), { finish: 'Reverse Holo' }), 'Armarouge : PITCH BLACK (Reverse holo) - 012/084');
  eq(C.buildTitle(pk('SV01: Scarlet & Violet Base Set', 'Grimer', '126/198'), { finish: 'Reverse Holo' }), 'Grimer : SCARLET & VIOLET BASE (Reverse holo) - 126/198');
  eq(C.buildTitle(pk('SV: Scarlet & Violet 151', 'Charmander', '4/165'), { finish: 'Standard' }), 'Charmander : 151 - 004/165');
  eq(C.buildTitle(pk('Pokemon GO', 'Bibarel', '60/78'), { finish: 'Reverse Holo' }), 'Bibarel : POKEMON GO! (Reverse holo) - 060/078');
  eq(C.buildTitle(pk('SM - Burning Shadows', 'Ribombee', '096/147'), { finish: 'Reverse Holo' }), 'Ribombee : BURNING SHADOWS (Reverse holo) - 96/147');
});

test('ball patterns keep the store spelling', () => {
  eq(C.buildTitle(pk('SV: Prismatic Evolutions', 'Litleo', '9/131'), { finish: 'Masterball Reverse holo' }), 'Litleo : PRISMATIC EVOLUTIONS (Masterball Reverse holo) - 009/131');
  eq(C.buildTitle(pk('SV: Prismatic Evolutions', 'Litleo', '9/131'), { finish: 'Pokeball Reverse holo' }), 'Litleo : PRISMATIC EVOLUTIONS (Pokeball Reverse holo) - 009/131');
});

test('Classic Collection drops "(Holo)" like every Celebrations reprint in the store', () => {
  eq(C.buildTitle(pk('Celebrations: Classic Collection', 'Charizard', '4/102', { rarity: 'Classic Collection' }), { finish: 'Holo' }), 'Charizard : CELEBRATIONS - 4/102');
  eq(C.buildTitle(pk('Celebrations', "Professor's Research", '023/025'), { finish: 'Holo' }), "Professor's Research : CELEBRATIONS (Holo) - 023/025");
});

test('Trainer Gallery and Shiny Vault file under their parent set', () => {
  eq(C.buildTitle(pk('SWSH09: Brilliant Stars Trainer Gallery', 'Mimikyu V', 'TG16/TG30'), { finish: 'Holo' }), 'Mimikyu V : BRILLIANT STARS (Holo) - TG16/TG30');
  eq(C.buildTitle(pk('Hidden Fates: Shiny Vault', 'Eevee', 'SV41/SV94'), { finish: 'Standard' }), 'Eevee : HIDDEN FATES - SV41/SV94');
});

test('provider name noise is removed and real qualifiers kept', () => {
  eq(C.buildTitle(pk('SV: Shrouded Fable', 'Dusclops - 019/064 (Cosmos Holo)', '019/064'), {}), 'Dusclops : SHROUDED FABLE (Cosmos Holo) - 019/064');
  eq(C.buildTitle(pk('Jungle', 'Kangaskhan (21)', '21/64'), { finish: 'Holo' }), 'Kangaskhan : JUNGLE (Holo) - 21/64');
  eq(C.buildTitle(pk('SWSH: Sword & Shield Promo Cards', 'Eevee V - SWSH065 (Eevee Stamped)', 'SWSH065'), {}), 'Eevee V : PROMO (Stamped) - SWSH065');
  eq(C.buildTitle(pk('League & Championship Cards', 'Malamar - 51/131 (League Challenge) [1st Place]', '051/131'), {}), 'Malamar : LEAGUE PROMO (1st Place) - 51/131');
  eq(C.buildTitle(pk('SV: Scarlet & Violet Promo Cards', 'Thundurus (Pokemon Center Stamped)', '209'), {}), 'Thundurus : PROMO (Pokemon Center Stamped) - SVP209');
});

test('promos go under PROMO with the code', () => {
  eq(C.buildTitle(pk('ME: Mega Evolution Promo', 'Charcadet', '22'), {}), 'Charcadet : PROMO - MEP022');
  eq(C.buildTitle(pk('SV: Scarlet & Violet Promo Cards', 'Eevee', '43'), { finish: 'Holo' }), 'Eevee : PROMO (Holo) - SVP043');
  eq(C.buildTitle(pk('Prize Pack Series Cards', 'Iono', '185/193'), {}), 'Iono : PLAY! PRIZE PACK LEAGUE PROMO - 185/193');
});

test('Japanese Pokemon uses the store\'s English set tag', () => {
  const card = { game: 'pokemon-japan', languageCode: 'ja', setName: 'SV6: Transformation Mask', name: 'Ogerpon', englishName: 'Ogerpon', cardNumber: '012/101' };
  eq(C.buildTitle(card, { finish: 'Standard' }), 'Ogerpon : MASK OF CHANGE - 012/101');
  eq(C.buildTags(card).join('|'), 'Single Cards|Mask Of Change|Japanese Scarlet & Violet|Japanese');
  eq(C.buildTitle({ game: 'pokemon-japan', languageCode: 'ja', setName: 'SV2D: Clay Burst', name: 'Flamigo', cardNumber: '082/071' }), 'Flamigo : CLAY BURST - 082/071');
});

test('Lorcana: (Foil) and rarity after the character, version after the colon, no set', () => {
  const lor = (name, number, rarity, setName) => ({ game: 'disney-lorcana', setName: setName || 'Fabled', name, cardNumber: number, rarity });
  eq(C.buildTitle(lor('Elsa - Spirit of Winter', '043/204', 'Super Rare'), { finish: 'Standard' }), 'Elsa : Spirit of Winter - 43/204');
  eq(C.buildTitle(lor('Maleficent - Formidable Queen', '35/204', 'Rare', 'Shimmering Skies'), { finish: 'Foil' }), 'Maleficent (Foil) : Formidable Queen - 35/204');
  eq(C.buildTitle(lor('Elsa - Snow Queen', '210/204', 'Epic'), { finish: 'Foil' }), 'Elsa (Epic Rare) : Snow Queen - 210/204');
  eq(C.buildTitle(lor('Kanine Krunchies', '43/204', 'Common'), {}), 'Kanine Krunchies - 43/204');
  eq(C.buildTags(lor('Kuzco - Wanted Llama', '45/204', 'Common', 'Rise of the Floodborn'), { finish: 'Standard' }).join('|'), 'Single Cards|Rise Of The Floodborn|Disney Lorcana');
  eq(C.buildTags(lor('Elsa - Snow Queen', '210/204', 'Epic'), { finish: 'Foil' }).join('|'), 'Single Cards|Fabled|Disney Lorcana|Foil');
});

test('Magic: (FOIL) on the name, product line spelled out', () => {
  const mtg = { game: 'magic-the-gathering', setName: 'Double Masters 2022', name: 'Wingsteed Rider', cardNumber: '35', printedTotal: 331, releasedAt: '2022-07-08' };
  eq(C.buildTitle(mtg, { finish: 'Foil' }), 'Wingsteed Rider (FOIL) : DOUBLE MASTERS 2022 - 035/331');
  eq(C.buildTitle({ ...mtg, setName: 'Innistrad: Crimson Vow', name: "Hero's Downfall", cardNumber: '120', printedTotal: 277, releasedAt: '2021-11-19' }, {}), "Hero's Downfall : INNISTRAD CRIMSON VOW - 120/277");
  eq(C.buildTitle({ game: 'magic-the-gathering', setName: 'Teenage Mutant Ninja Turtles', name: 'Mutagen Man, Living Ooze (Extended Art)', cardNumber: '273' }, {}), 'Mutagen Man, Living Ooze (Extended Art) : TEENAGE MUTANT NINJA TURTLES - 273');
  eq(C.buildTags({ ...mtg, setName: 'Innistrad: Crimson Vow' }, { finish: 'Standard' }).join('|'), 'Single Cards|Crimson Vow|Magic the Gathering');
});

test('One Piece and Digimon', () => {
  const op = { game: 'one-piece-card-game', setName: "The World's Strongest Warriors", name: 'Charlotte Linlin', cardNumber: 'OP17-049' };
  eq(C.buildTitle(op, { finish: 'Foil' }), "Charlotte Linlin : THE WORLD'S STRONGEST WARRIORS (Foil) - OP17-049");
  eq(C.buildTitle({ ...op, name: 'Monkey.D.Luffy (030)', cardNumber: 'OP17-030' }, {}), "Monkey.D.Luffy : THE WORLD'S STRONGEST WARRIORS - OP17-030");
  eq(C.buildTitle({ ...op, name: 'Monkey.D.Luffy (ST31-004) (SP)', cardNumber: 'ST31-004' }, {}), "Monkey.D.Luffy : THE WORLD'S STRONGEST WARRIORS (SP) - ST31-004");
  eq(C.buildTags(op, { finish: 'Foil' }).join('|'), "Single Cards|The World's Strongest Warriors|One Piece Card Game|OP17|English|Foil");
  eq(C.buildTitle({ game: 'digimon-card-game', setName: 'Double Diamond', name: 'Mamemon', cardNumber: 'BT6-064', rarity: 'Super Rare' }, {}), 'Mamemon : DOUBLE DIAMOND (SR) - BT6-064');
  eq(C.buildTitle({ game: 'digimon-card-game', setName: 'Great Legend', name: 'GrapLeomon', cardNumber: 'BT4-057', rarity: 'Common' }, {}), 'GrapLeomon : GREAT LEGEND - BT4-057');
});

// --------------------------------------------------------------- tags

test('Pokemon tags are the store\'s set and era tags, nothing invented', () => {
  eq(C.buildTags(pk('ME05: Pitch Black', 'Armarouge', '12/84')).join('|'), 'Single Cards|Pitch Black|Mega Evolution');
  eq(C.buildTags(pk('ME: 30th Celebration Classic Collection', 'Sneasel', '025/111', { rarity: 'Classic Collection' })).join('|'), 'Single Cards|30th ANNIVERSARY COLLECTION|Mega Evolution');
  eq(C.buildTags(pk('SV01: Scarlet & Violet Base Set', 'Grimer', '126/198')).join('|'), 'Single Cards|Scarlet & Violet (Base)|Scarlet & Violet');
  eq(C.buildTags(pk('ME01: Mega Evolution', 'Meganium', '10/132')).join('|'), 'Single Cards|Mega Evolution (Base)|Mega Evolution');
  eq(C.buildTags(pk('XY - BREAKthrough', 'Braixen', '26/162')).join('|'), 'Single Cards|BREAKthrough|XY');
  eq(C.buildTags(pk('SWSH: Sword & Shield Promo Cards', 'Espeon V', 'SWSH201')).join('|'), 'Single Cards|Promos|Sword & Shield');
  eq(C.buildTags(pk('Prize Pack Series Cards', 'Iono', '185/193')).join('|'), 'Single Cards|Promos|Pokemon Play!');
});

test('an unknown set keeps its cleaned name and gets no guessed era', () => {
  const set = C.resolveSet(pk('ME07: Brand New Set', 'x', '1/100'));
  eq(set.tag, 'Brand New Set');
  eq(set.era, '');
  eq(set.known, false);
});

// --------------------------------------------------------------- sealed

test('sealed titles match the store', () => {
  const sealed = (setName, name, game) => ({ game: game || 'pokemon', setName, name, cardNumber: 'N/A' });
  eq(C.isSealed(sealed('ME: 30th Celebration', '30th Celebration Elite Trainer Box')), true);
  eq(C.isSealed(pk('ME05: Pitch Black', 'Armarouge', '12/84')), false);
  eq(C.buildSealedTitle(sealed('ME: 30th Celebration', '30th Celebration Figure Collection [Mewtwo]')), 'Pokemon : 30th Celebration - Figure Collection - Mewtwo');
  eq(C.buildSealedTitle(sealed('ME: 30th Celebration', '30th Celebration Elite Trainer Box')), 'Pokemon : 30th Celebration - Elite Trainer Box');
  eq(C.buildSealedTitle(sealed('ME05: Pitch Black', 'Pitch Black Booster Pack')), 'Pokemon : Pitch Black - Booster Pack (x1)');
  eq(C.buildSealedTitle(sealed('ME06: Delta Reign', 'Delta Reign Booster Box')), 'Pokemon : Delta Reign - Booster Box');
  eq(C.buildSealedTitle(sealed('Azurite Sea', 'Azurite Sea Booster Box', 'disney-lorcana')), 'Disney Lorcana : Azurite Sea - Booster Box (24 Packs)');
  eq(C.buildTags(sealed('ME: 30th Celebration', '30th Celebration Elite Trainer Box'), { sealed: true, preOrder: true }).join('|'), 'Sealed Product|30th ANNIVERSARY COLLECTION|Mega Evolution|Pre-Order');
});

// --------------------------------------------------------------- SEO

test('SEO title quotes printed number, store set name and price, within 70', () => {
  const sneasel = pk('ME: 30th Celebration Classic Collection', 'Sneasel', '025/111', { rarity: 'Classic Collection' });
  eq(C.seoTitle(sneasel, { finish: 'Holo', price: 9.95 }), 'Sneasel 25/111 30th Celebration | £9.95 In Stock UK');
  const lampent = pk('ME05: Pitch Black', 'Lampent', '37/84');
  eq(C.seoTitle(lampent, { finish: 'Reverse Holo', price: 0.65 }), 'Lampent 037/084 Pitch Black Reverse Holo | £0.65 In Stock UK');
  const long = pk('SV: Prismatic Evolutions', 'Team Rocket\'s Mewtwo ex Special Illustration', '231/131');
  const t = C.seoTitle(long, { finish: 'Holo', price: 129.99 });
  assert.ok(t.length <= 70, `too long: ${t.length} ${t}`);
});

test('SEO description never names the provider code and stays within 160', () => {
  const sneasel = pk('ME: 30th Celebration Classic Collection', 'Sneasel', '025/111', { rarity: 'Classic Collection' });
  const d = C.seoDescription(sneasel, { finish: 'Holo' });
  assert.ok(d.length <= 160, `too long ${d.length}`);
  assert.ok(!/ME:/.test(d), d);
  assert.ok(/25\/111/.test(d) && /30th Celebration Classic Collection/.test(d), d);
});

test('no copy uses a dash as punctuation', () => {
  const card = pk('ME05: Pitch Black', 'Armarouge', '12/84');
  const html = C.descriptionHtml(card, { finish: 'Reverse Holo', details: { illustrator: 'Kouki Saitou', hp: 120, types: ['Fire'] } });
  for (const text of [C.seoDescription(card, { finish: 'Reverse Holo' }), html]) {
    assert.ok(!/[–—]/.test(text), 'en or em dash in ' + text);
    assert.ok(!/\s-\s/.test(text.replace(/<[^>]+>/g, '')), 'spaced hyphen in ' + text);
  }
});

test('image alt and file name carry the card identity', () => {
  const sneasel = pk('ME: 30th Celebration Classic Collection', 'Sneasel', '025/111', { rarity: 'Classic Collection' });
  eq(C.imageFilename(sneasel, { finish: 'Holo' }), 'sneasel-25-111-30th-celebration-classic-collection-lockett-labs.jpg');
  eq(C.imageAlt(sneasel, { finish: 'Holo', scan: true }), 'Sneasel 25/111 30th Celebration Classic Collection Pokémon card, scanned front');
});

test('description lists only known facts and links back into the set', () => {
  const card = pk('ME05: Pitch Black', 'Armarouge', '12/84', { rarity: 'Rare' });
  const html = C.descriptionHtml(card, {
    finish: 'Reverse Holo',
    set: C.resolveSet({ ...card, setReleaseDate: '2026-07-17' }),
    details: { illustrator: 'Kouki Saitou', hp: 120, types: ['Fire'], attacks: [{ name: 'Flame Cannon', cost: ['Fire', 'Colorless'], damage: 90 }] },
    links: { set: { url: '/collections/pitch-black', title: 'Shop Pitch Black singles' } }
  });
  assert.ok(html.includes('<strong>Illustrator:</strong> Kouki Saitou'));
  assert.ok(html.includes('17 July 2026'));
  assert.ok(html.includes('href="/collections/pitch-black"'));
  assert.ok(!html.includes('Regulation mark'), 'unknown field must be left out');
});

test('plan() bundles everything from one card', () => {
  const p = C.plan(pk('ME: 30th Celebration Classic Collection', 'Sneasel', '025/111', { rarity: 'Classic Collection' }), { finish: 'Holo', price: 9.95 });
  eq(p.title, 'Sneasel : 30TH CELEBRATION - 25/111');
  eq(p.number, '25/111');
  eq(p.sealed, false);
  eq(p.seoTitle, 'Sneasel 25/111 30th Celebration | £9.95 In Stock UK');
});


test('sealed SEO, alt and description copy never use a spaced hyphen', () => {
  const card = { game: 'pokemon', setName: 'ME: 30th Celebration', name: '30th Celebration Figure Collection [Mewtwo]', cardNumber: 'N/A' };
  const p = C.plan(card, { price: 24.99 });
  eq(p.seoTitle, '30th Celebration Figure Collection Mewtwo | £24.99 In Stock UK');
  for (const text of [p.seoDescription, p.imageAlt, C.descriptionHtml(card, { sealed: true }).replace(/<[^>]+>/g, '')]) {
    assert.ok(!/\s-\s|[–—]/.test(text), 'dash in ' + text);
  }
  eq(p.imageFilename, '30th-celebration-figure-collection-mewtwo-lockett-labs.jpg');
});

test('articles read naturally', () => {
  const html = C.descriptionHtml({ game: 'pokemon', setName: 'SV: Prismatic Evolutions', name: 'Eevee', cardNumber: '74/131' }, { finish: 'Energy Reverse holo' });
  assert.ok(html.includes('is an energy reverse holo Pokémon card'), html);
  const op = C.descriptionHtml({ game: 'one-piece-card-game', setName: 'Romance Dawn', name: 'Nami', cardNumber: 'OP01-016' }, {});
  assert.ok(op.includes('is a One Piece card'), op);
});

console.log(`${passed} passed, ${failures.length} failed`);
if (failures.length) {
  for (const f of failures) console.log(' - ' + f);
  process.exit(1);
}
