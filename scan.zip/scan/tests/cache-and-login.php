<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';

/**
 * Cache pruning and login hardening.
 *
 * The cache folder had never had anything deleted from it: 1,771 entries when
 * it was first measured, on shared hosting. It also holds things
 * that are not cache at all, and losing those would be serious. The variant
 * backups in particular are the only defence against the productSet incident
 * the README describes, where a single bad write collapsed every multi-variant
 * product in the catalogue and inventory quantities were unrecoverable.
 *
 * So the first group of assertions is really one question: can the sweep ever
 * delete something it must not?
 */

$assertions = [];
$labels = [];

$check = static function (string $label, bool $ok) use (&$assertions, &$labels): void {
    $assertions[] = $ok;
    $labels[] = $label;
};

// --- what counts as disposable --------------------------------------------
// Cache entries are named for the sha256 of their key and nothing else in the
// folder is, which is why the rule is a pattern rather than a list of names to
// spare. A list would have to be updated every time something durable was
// added, and forgetting once would delete it.
$check('a cache entry is disposable',
    cache_is_disposable(hash('sha256', 'any key') . '.json'));
$check('a 64 hex name is disposable',
    cache_is_disposable(str_repeat('a', 64) . '.json'));

foreach ([
    'chaos-snapshot.json',
    'chaos-snapshot.log',
    'justtcg-usage.json',
    'bandai-set-codes.json',
    'sku-backfill-plan.csv',
    'sku-backfill-collisions.csv',
    '.htaccess',
    '.gitkeep',
    'index.json',
    'pokemon.json',
    'variant-backup-2026-09-12.json',
] as $name) {
    $check("'{$name}' is never deleted", cache_is_disposable($name) === false);
}

// Near misses, because the pattern is the entire safety guarantee.
foreach ([
    str_repeat('a', 63) . '.json',          // too short
    str_repeat('a', 65) . '.json',          // too long
    str_repeat('A', 64) . '.json',          // upper case is not what hash() emits
    str_repeat('g', 64) . '.json',          // not hex
    str_repeat('a', 64) . '.txt',           // wrong extension
    str_repeat('a', 64),                    // no extension
    'prefix-' . str_repeat('a', 64) . '.json',
] as $name) {
    $check("near miss '" . substr($name, 0, 12) . "...' is not disposable", cache_is_disposable($name) === false);
}

// --- the sweep keeps fresh files ------------------------------------------
// A dry run reports without deleting, which is what tools/prune-cache.php
// leans on, and a sweep must never remove something inside its own TTL.
$fresh = cache_file_path('sweep-test-' . bin2hex(random_bytes(4)));
file_put_contents($fresh, '{"probe":true}');
$dry = cache_sweep(86400, false);
$check('a dry run deletes nothing', is_file($fresh));
$check('a dry run still reports counts', isset($dry['scanned'], $dry['removed']));

$applied = cache_sweep(86400, true);
$check('a fresh file survives a real sweep', is_file($fresh));
$check('the sweep skips what it must keep', $applied['skipped'] >= 1);
@unlink($fresh);

// An old file does go.
$old = cache_file_path('sweep-old-' . bin2hex(random_bytes(4)));
file_put_contents($old, '{"probe":true}');
touch($old, time() - (120 * 86400));
cache_sweep(45 * 86400, true);
$check('a file past the cutoff is removed', !is_file($old));
@unlink($old);

// --- login ----------------------------------------------------------------
// A bcrypt hash must be recognised as one, and anything else must not be, or
// the fallback comparison would run against a hash and never match.
$check('a bcrypt hash is recognised',
    password_get_info(password_hash('a-long-enough-password', PASSWORD_DEFAULT))['algo'] !== null);
$check('plain text is not a hash',
    (password_get_info('replace-with-a-long-unique-password')['algo'] ?? 0) === 0
    || password_get_info('replace-with-a-long-unique-password')['algo'] === null);

$hash = password_hash('the-actual-staff-password', PASSWORD_DEFAULT);
$check('the right password verifies', password_verify('the-actual-staff-password', $hash));
$check('a wrong password does not', password_verify('nearly-the-right-one', $hash) === false);
$check('an empty password does not', password_verify('', $hash) === false);

// Lockout bookkeeping. These write to the cache folder under the current
// client address, which on the command line is the literal 'cli'.
app_login_clear_failures();
$check('a cleared counter is not locked out', app_login_lockout_remaining() === 0);
$check('a cleared counter reads zero', app_login_attempts()['count'] === 0);

for ($i = 0; $i < LOGIN_MAX_ATTEMPTS; $i++) {
    app_login_record_failure();
}
$check('repeated failures lock out', app_login_lockout_remaining() > 0);
$check('the lockout is about the configured length',
    app_login_lockout_remaining() <= LOGIN_LOCKOUT_SECONDS && app_login_lockout_remaining() > LOGIN_LOCKOUT_SECONDS - 60);
$check('a locked out attempt is refused outright', app_attempt_login('anything') === false);

app_login_clear_failures();
$check('clearing lifts the lockout', app_login_lockout_remaining() === 0);

foreach ($assertions as $index => $ok) {
    if (!$ok) {
        fwrite(STDERR, 'Cache/login assertion failed: ' . ($labels[$index] ?? ('index ' . $index)) . PHP_EOL);
        exit(1);
    }
}

echo 'Cache and login tests passed (' . count($assertions) . " assertions).\n";
