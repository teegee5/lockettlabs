<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/shopify-inventory.php';

$sku = 'POKEMON-SV8A-090-HOLO-NEAR-MINT';
$response = [
    'sku0' => [
        'nodes' => [[
            'id' => 'gid://shopify/ProductVariant/101',
            'title' => 'Near Mint',
            'sku' => $sku,
            'price' => '5.00',
            'inventoryQuantity' => 3,
            'product' => [
                'id' => 'gid://shopify/Product/201',
                'title' => 'Okidogi ex : TERASTAL FESTIVAL EX (Holo) - 090/187',
                'handle' => 'okidogi-ex',
                'status' => 'ACTIVE',
                'onlineStoreUrl' => 'https://example.myshopify.com/products/okidogi-ex',
                'featuredMedia' => ['preview' => ['image' => [
                    'url' => 'https://cdn.shopify.com/s/files/okidogi.png',
                    'altText' => 'Okidogi ex card',
                    'width' => 480,
                    'height' => 672,
                ]]],
            ],
            'inventoryItem' => [
                'id' => 'gid://shopify/InventoryItem/301',
                'tracked' => true,
                'inventoryLevel' => [
                    'isActive' => true,
                    'quantities' => [['name' => 'available', 'quantity' => 3]],
                ],
            ],
        ]],
    ],
];

$matches = normalize_shopify_stock_matches($response, [$sku]);
$preview = shopify_inventory_preview($matches, [['sku' => $sku, 'quantity' => 1]]);
$legacyProduct = [
    'id' => 'gid://shopify/Product/202',
    'title' => 'Okidogi ex : TERASTAL FESTIVAL EX (Holo) - 090/187',
    'handle' => 'okidogi-ex-legacy',
    'status' => 'ACTIVE',
    'metadata' => [
        'databaseId' => '',
        'cardNumber' => '',
        'setName' => '',
        'englishSetName' => '',
        'originalName' => '',
        'englishName' => '',
        'finish' => '',
        'gameId' => '',
    ],
    'variants' => [[
        'id' => 'gid://shopify/ProductVariant/102',
        'title' => 'Near Mint',
        'sku' => '',
        'price' => '5.00',
        'inventoryQuantity' => 3,
        'inventoryItemId' => 'gid://shopify/InventoryItem/302',
        'existingQuantity' => 3,
        'inventoryActive' => true,
        'selectedOptions' => ['Near Mint'],
    ]],
];
$legacyIdentity = shopify_card_identity([
    'externalId' => 'justtcg-okidogi-090',
    'title' => 'Okidogi ex : TERASTAL FESTIVAL EX (Holo) - 090/187',
    'name' => 'Okidogi ex',
    'englishName' => 'Okidogi ex',
    'setName' => 'TERASTAL FESTIVAL EX',
    'englishSetName' => 'TERASTAL FESTIVAL EX',
    'cardNumber' => '090/187',
    'finish' => 'Holo',
    'game' => 'pokemon-japan',
]);
$legacyRequests = [['condition' => 'Near Mint', 'sku' => $sku, 'quantity' => 1]];
$legacyMatch = shopify_match_product_variants($legacyProduct, $legacyRequests);
$legacyScore = score_shopify_card_product($legacyIdentity, $legacyProduct, $legacyRequests);
$legacyPreview = shopify_inventory_preview($legacyMatch, $legacyRequests);
$wrongNumberProduct = $legacyProduct;
$wrongNumberProduct['title'] = 'Okidogi ex : TERASTAL FESTIVAL EX (Holo) - 091/187';
$wrongNumberScore = score_shopify_card_product($legacyIdentity, $wrongNumberProduct, $legacyRequests);
$kuzanQueries = shopify_card_search_queries(shopify_card_identity([
    'name' => 'Kuzan',
    'setName' => 'The Time of Battle',
    'cardNumber' => 'OP16-063',
]));
$kuzanProduct = $legacyProduct;
$kuzanProduct['id'] = 'gid://shopify/Product/203';
$kuzanProduct['title'] = 'Kuzan (Rare) - THE TIME OF BATTLE - OP16-063';
$kuzanProduct['variants'][0]['id'] = 'gid://shopify/ProductVariant/103';
$kuzanProduct['variants'][0]['title'] = 'Default Title';
$kuzanProduct['variants'][0]['inventoryItemId'] = 'gid://shopify/InventoryItem/303';
$kuzanProduct['variants'][0]['existingQuantity'] = 5;
$kuzanProduct['variants'][0]['inventoryQuantity'] = 5;
$kuzanProduct['variants'][0]['selectedOptions'] = ['Default Title'];
$kuzanIdentity = shopify_card_identity([
    'name' => 'Kuzan',
    'englishName' => 'Kuzan',
    'setName' => 'The Time of Battle',
    'englishSetName' => 'The Time of Battle',
    'cardNumber' => 'OP16-063',
    'game' => 'one-piece-card-game',
]);
$kuzanRequests = [['condition' => 'Near Mint', 'sku' => 'ONE-PIECE-OP16-063-NEAR-MINT', 'quantity' => 1]];
$kuzanScore = score_shopify_card_product($kuzanIdentity, $kuzanProduct, $kuzanRequests);
$inventoryChange = shopify_inventory_change(
    'gid://shopify/InventoryItem/303',
    'gid://shopify/Location/404',
    1,
    5
);
$assertions = [
    $matches[0]['found'] === true,
    $matches[0]['existingQuantity'] === 3,
    $matches[0]['inventoryActive'] === true,
    $matches[0]['product']['onlineStoreUrl'] === 'https://example.myshopify.com/products/okidogi-ex',
    $matches[0]['product']['image']['url'] === 'https://cdn.shopify.com/s/files/okidogi.png',
    shopify_stock_mode($matches) === 'existing',
    $preview === ['previous' => 3, 'added' => 1, 'current' => 4],
    preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-5[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/', inventory_operation_uuid('repeatable-operation')) === 1,
    inventory_operation_uuid('repeatable-operation') === inventory_operation_uuid('repeatable-operation'),
    $legacyMatch[0]['found'] === true,
    $legacyMatch[0]['matchType'] === 'condition',
    $legacyMatch[0]['variant']['sku'] === '',
    $legacyScore['numberExact'] === true,
    $legacyScore['eligible'] === true,
    $legacyScore['usable'] === true,
    $legacyScore['score'] >= 75,
    $legacyPreview === ['previous' => 3, 'added' => 1, 'current' => 4],
    $wrongNumberScore['numberExact'] === false,
    $wrongNumberScore['numberConflict'] === true,
    $wrongNumberScore['eligible'] === false,
    shopify_card_numbers_equal('090/187', 'Okidogi ex - 090／187') === true,
    shopify_card_numbers_equal('OP16-065', 'Sakazuki OP16-065') === true,
    shopify_card_numbers_equal('090/187', 'Okidogi ex - 091/187') === false,
    $kuzanQueries[0] === 'Kuzan OP16-063',
    in_array('OP16-063', $kuzanQueries, true),
    count(array_filter($kuzanQueries, static fn(string $query): bool => str_starts_with($query, 'title:'))) === 0,
    $kuzanScore['numberExact'] === true,
    $kuzanScore['eligible'] === true,
    $kuzanScore['usable'] === true,
    $kuzanScore['score'] >= 75,
    $kuzanScore['matches'][0]['matchType'] === 'single variant',
    $kuzanScore['matches'][0]['existingQuantity'] === 5,
    $inventoryChange === [
        'delta' => 1,
        'inventoryItemId' => 'gid://shopify/InventoryItem/303',
        'locationId' => 'gid://shopify/Location/404',
        'changeFromQuantity' => 5,
    ],
];

foreach ($assertions as $index => $passed) {
    if (!$passed) {
        fwrite(STDERR, 'Shopify inventory assertion failed at index ' . $index . PHP_EOL);
        exit(1);
    }
}

echo "Shopify additive inventory and legacy-title matching tests passed.\n";
