<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/intake-log.php';

/**
 * The intake log.
 *
 * Before this existed there was no record of anything staff did. The success
 * message was the only evidence a card had been booked in, and the screen
 * clears itself 650ms later, so a quantity typed as 11 instead of 1 could not
 * be noticed afterwards.
 *
 * These run against a temporary directory, never the real logs/.
 */

$assertions = [];
$labels = [];

$check = static function (string $label, bool $ok) use (&$assertions, &$labels): void {
    $assertions[] = $ok;
    $labels[] = $label;
};

// --- entry shape -----------------------------------------------------------
// The client posts the JustTCG card object spread into the payload, so the
// printed number arrives as cardNumber, not number, and reading the wrong key
// would log every card without its identity.
$entry = intake_log_entry(
    'created',
    ['id' => 'gid://shopify/Product/1', 'title' => 'Armarouge : PITCH BLACK (Reverse holo) - 012/084', 'adminUrl' => 'https://admin.example/1'],
    ['game' => 'pokemon', 'setName' => 'Pitch Black', 'englishSetName' => 'Pitch Black', 'cardNumber' => '012/084', 'finish' => 'Reverse holo'],
    [['condition' => 'Near Mint', 'price' => '0.65', 'quantity' => 3, 'sku' => 'LL-PKM-PITCHBLACK-012-084-RH-NM']],
    3,
    'gid://shopify/Location/9',
    'New listing'
);

$check('action recorded', $entry['action'] === 'created');
$check('product id recorded', $entry['productId'] === 'gid://shopify/Product/1');
$check('admin url recorded', $entry['adminUrl'] === 'https://admin.example/1');
$check('printed number read from cardNumber', $entry['number'] === '012/084');
$check('set read from the English field', $entry['setName'] === 'Pitch Black');
$check('finish recorded', $entry['finish'] === 'Reverse holo');
$check('units recorded', $entry['units'] === 3);
$check('condition captured', $entry['conditions'][0]['condition'] === 'Near Mint');
$check('condition quantity captured', $entry['conditions'][0]['qty'] === 3);
$check('condition price is numeric', $entry['conditions'][0]['price'] === 0.65);

// setName alone is used when there is no English field, which is how Japanese
// cards arrive.
$japanese = intake_log_entry('created', [], ['setName' => 'ポケモン'], [], 1, '');
$check('falls back to setName', $japanese['setName'] === 'ポケモン');

// A number posted as `number` rather than `cardNumber` still lands.
$alt = intake_log_entry('created', [], ['number' => 'OP16-065'], [], 1, '');
$check('number field also accepted', $alt['number'] === 'OP16-065');

// --- negative quantities cannot be logged ----------------------------------
$negative = intake_log_entry('restocked', [], [], [], -5, '');
$check('units never negative', $negative['units'] === 0);

// --- round trip through a real file ----------------------------------------
// intake_log_* write to logs/ relative to the library, so the round trip is
// exercised against the tail reader directly rather than by moving the app's
// own log out of the way.
$dir = sys_get_temp_dir() . '/scan-intake-log-test-' . bin2hex(random_bytes(4));
mkdir($dir, 0750, true);
$path = $dir . '/intake.jsonl';

$today = gmdate('Y-m-d');
$written = [];
for ($i = 1; $i <= 40; $i++) {
    $row = [
        'action' => $i % 3 === 0 ? 'restocked' : 'created',
        'productTitle' => 'Card number ' . $i,
        'units' => $i,
        'at' => $today . sprintf('T%02d:00:00+00:00', $i % 24),
    ];
    $written[] = $row;
    file_put_contents($path, json_encode($row, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND);
}

$tail = intake_log_tail_lines($path, 5);
$check('tail returns the number asked for', count($tail) === 5);
$check('tail returns the LAST lines', json_decode($tail[4], true)['productTitle'] === 'Card number 40');
$check('tail lines are whole and decodable', json_decode($tail[0], true) !== null);

$check('tail of a missing file is empty', intake_log_tail_lines($dir . '/nope.jsonl', 5) === []);
$check('tail with a zero limit is empty', intake_log_tail_lines($path, 0) === []);
$check('tail larger than the file returns everything', count(intake_log_tail_lines($path, 500)) === 40);

// A partial line at the front of the read window must not become a row. Write
// a file far larger than the read window and confirm every line still decodes.
$big = $dir . '/big.jsonl';
for ($i = 0; $i < 400; $i++) {
    file_put_contents($big, json_encode([
        'action' => 'created',
        'productTitle' => str_repeat('x', 400) . $i,
        'units' => 1,
        'at' => gmdate('c'),
    ], JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND);
}
$bigTail = intake_log_tail_lines($big, 10);
$everyLineDecodes = true;
foreach ($bigTail as $line) {
    if (!is_array(json_decode($line, true))) $everyLineDecodes = false;
}
$check('no partial line survives a mid-file read', $everyLineDecodes);
$check('big tail still returns the limit', count($bigTail) === 10);

// --- the summary's date prefix ---------------------------------------------
// intake_log_today_summary() rejects lines with a cheap string match before
// paying for a decode, so the stamp gmdate('c') writes has to be findable that
// way. If this breaks, the tally silently reads zero all day.
$line = json_encode(['action' => 'created', 'at' => gmdate('c')], JSON_UNESCAPED_SLASHES);
$check('stamp is findable by date prefix', str_contains($line, '"at":"' . gmdate('Y-m-d')));

array_map('unlink', glob($dir . '/*') ?: []);
@rmdir($dir);

foreach ($assertions as $index => $ok) {
    if (!$ok) {
        fwrite(STDERR, 'Intake log assertion failed: ' . ($labels[$index] ?? ('index ' . $index)) . PHP_EOL);
        exit(1);
    }
}

echo 'Intake log tests passed (' . count($assertions) . " assertions).\n";
