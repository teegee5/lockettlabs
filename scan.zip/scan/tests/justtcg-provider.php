<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/providers.php';

$sample = [
    'uuid' => '11111111-1111-5111-8111-111111111111',
    'id' => 'pokemon-japan-terastal-festival-ex-okidogi-ex-double-rare',
    'name' => 'Okidogi ex',
    'game' => 'Pokemon Japan',
    'set' => 'terastal-festival-ex-pokemon-japan',
    'set_name' => 'Terastal Festival ex',
    'number' => '090/187',
    'rarity' => 'Double Rare',
    'tcgplayerId' => '123456',
    'details' => 'Basic Pokémon ex',
    'variants' => [
        ['uuid' => 'v1', 'condition' => 'Near Mint', 'printing' => 'Holofoil', 'language' => 'Japanese', 'price' => 4.25, 'lastUpdated' => 1780000000],
        ['uuid' => 'v2', 'condition' => 'Lightly Played', 'printing' => 'Holofoil', 'language' => 'Japanese', 'price' => 3.10, 'lastUpdated' => 1780000000],
    ],
];

$card = normalize_justtcg_card($sample, 'pokemon-japan', 'ja');
$converted = convert_justtcg_market_prices_to_gbp([$card], [
    'date' => '2026-07-15',
    'base' => 'USD',
    'quote' => 'GBP',
    'rate' => 0.75,
])[0];
$hidden = convert_justtcg_market_prices_to_gbp([$card], [
    'date' => '2026-07-15',
    'base' => 'USD',
    'quote' => 'GBP',
    'rate' => 0,
])[0];

// English OP row must NOT become Japanese just because the UI requested ja.
$englishOp = normalize_justtcg_card([
    'uuid' => '22222222-2222-5222-8222-222222222222',
    'id' => 'one-piece-card-game-izo-op16-002',
    'name' => 'Izo',
    'game' => 'One Piece Card Game',
    'set' => 'the-time-of-battle-one-piece-card-game',
    'set_name' => 'The Time of Battle',
    'number' => 'OP16-002',
    'rarity' => 'Uncommon',
    'tcgplayerId' => '695987',
    'details' => '',
    'variants' => [
        ['uuid' => 'v-en', 'condition' => 'Near Mint', 'printing' => 'Normal', 'language' => 'English', 'price' => 0.45, 'lastUpdated' => 1780000000],
    ],
], 'one-piece-card-game', 'ja');

$assertions = [
    $card['provider'] === 'JustTCG',
    $card['languageCode'] === 'ja',
    $card['englishName'] === 'Okidogi ex',
    $card['cardNumber'] === '090/187',
    $card['description'] === 'Basic Pokémon ex',
    $card['apiDescription'] === 'Basic Pokémon ex',
    in_array('Holo', $card['finishOptions'], true),
    // Disney / Magic Holofoil is Foil — never Holo.
    in_array('Foil', normalize_justtcg_card([
        'uuid' => '33333333-3333-5333-8333-333333333333',
        'id' => 'disney-lorcana-promo-if-i-didnt-have-you',
        'name' => "If I Didn't Have You",
        'game' => 'Disney Lorcana',
        'set' => 'disney-lorcana-promo-cards-disney-lorcana',
        'set_name' => 'Disney Lorcana Promo Cards',
        'number' => '14',
        'rarity' => 'Promo',
        'tcgplayerId' => '705081',
        'details' => '',
        'variants' => [
            ['uuid' => 'v-foil', 'condition' => 'Near Mint', 'printing' => 'Holofoil', 'language' => 'English', 'price' => 8.31, 'lastUpdated' => 1780000000],
        ],
    ], 'disney-lorcana', 'en')['finishOptions'], true),
    !in_array('Holo', normalize_justtcg_card([
        'uuid' => '33333333-3333-5333-8333-333333333333',
        'id' => 'disney-lorcana-promo-if-i-didnt-have-you',
        'name' => "If I Didn't Have You",
        'game' => 'Disney Lorcana',
        'set' => 'disney-lorcana-promo-cards-disney-lorcana',
        'set_name' => 'Disney Lorcana Promo Cards',
        'number' => '14',
        'rarity' => 'Promo',
        'tcgplayerId' => '705081',
        'details' => '',
        'variants' => [
            ['uuid' => 'v-foil', 'condition' => 'Near Mint', 'printing' => 'Holofoil', 'language' => 'English', 'price' => 8.31, 'lastUpdated' => 1780000000],
        ],
    ], 'disney-lorcana', 'en')['finishOptions'], true),
    in_array('Foil', normalize_justtcg_card([
        'uuid' => '44444444-4444-5444-8444-444444444444',
        'id' => 'mtg-sample-foil',
        'name' => 'Abrade',
        'game' => 'Magic: The Gathering',
        'set' => 'innistrad-crimson-vow-magic-the-gathering',
        'set_name' => 'Innistrad: Crimson Vow',
        'number' => '139/277',
        'rarity' => 'Common',
        'tcgplayerId' => '1',
        'details' => '',
        'variants' => [
            ['uuid' => 'v-mtg', 'condition' => 'Near Mint', 'printing' => 'Foil', 'language' => 'English', 'price' => 0.2, 'lastUpdated' => 1780000000],
        ],
    ], 'magic-the-gathering', 'en')['finishOptions'], true),
    (parsed_card_number('14/P4')['localRaw'] ?? '') === '14',
    (parsed_card_number('14/P4')['denominatorRaw'] ?? '') === 'P4',
    exact_card_number_match(['cardNumber' => '14'], '14/P4'),
    justtcg_number_query(parsed_card_number('14/P4')) === '14',
    $card['marketLowest'] === 3.10,
    $converted['marketCurrency'] === 'GBP',
    $converted['marketLowest'] === 2.33,
    $converted['marketVariants'][0]['price'] === 3.19,
    $hidden['marketLowest'] === null && $hidden['marketVariants'] === [],
    str_contains($card['imageUrl'], '123456'),
    $englishOp['languageCode'] === 'en',
    $englishOp['language'] !== 'Japanese',
    exact_card_number_match($card, '90/187'),
    !exact_card_number_match($card, '090/186'),
    exact_card_number_match($card, '090187'),
    exact_card_number_match($card, '054245') === false,
    exact_card_number_match(['cardNumber' => 'OP16-043', 'setCode' => 'OP16'], 'op16043'),
    exact_card_number_match(['cardNumber' => 'OP16-043', 'setCode' => 'OP16'], 'OP16-043'),
    exact_card_number_match(['cardNumber' => '054/245'], '054245'),
    justtcg_number_query(expand_compact_card_number('op16043', 'one-piece-card-game')) === 'OP16-043',
    justtcg_number_query(expand_compact_card_number('054245', 'pokemon')) === '054/245',
    pad_local_card_number('65', 3) === '065',
    pad_local_card_number('065', 3) === '065',
    pad_local_card_number('65A', 3) === '065A',
    extract_bandai_set_code('OP16') === 'OP16',
    extract_bandai_set_code('The Time of Battle') === '',
    expand_number_with_set_context('065', 'OP16', 'one-piece-card-game') === 'OP16-065',
    expand_number_with_set_context('65', 'OP16', 'one-piece-card-game') === 'OP16-065',
    expand_number_with_set_context('002', 'OP16', 'one-piece-card-game') === 'OP16-002',
    expand_number_with_set_context('002', 'The Time of Battle', 'one-piece-card-game') === 'OP16-002',
    expand_number_with_set_context('65', 'The Time of Battle', 'one-piece-card-game') === 'OP16-065',
    expand_number_with_set_context('OP16-065', 'OP16', 'one-piece-card-game') === 'OP16-065',
    expand_number_with_set_context('OP16065', 'The Time of Battle', 'one-piece-card-game') === 'OP16065',
    expand_number_with_set_context('001', 'BT14', 'digimon-card-game') === 'BT14-001',
    expand_number_with_set_context('026', 'Terastal Festival ex', 'pokemon-japan') === '026',
    expand_number_with_set_context('026/086', 'OP16', 'one-piece-card-game') === '026/086',
    exact_card_number_match(['cardNumber' => 'OP16-065', 'setCode' => 'OP16'], 'OP16-065'),
    exact_card_number_match(['cardNumber' => 'OP16-002', 'setCode' => 'OP16'], 'OP16-002'),
    exact_card_number_match(['cardNumber' => 'OP16-002', 'setCode' => 'OP16'], '002'),
    !exact_card_number_match(['cardNumber' => 'OP16-165', 'setCode' => 'OP16'], 'OP16-065'),
    !exact_card_number_match(['cardNumber' => 'OP16-065a', 'setCode' => 'OP16'], 'OP16-065'),
    justtcg_resolve_set_id('one-piece-card-game', 'OP16') === '',
    bandai_set_code_alias('The Time of Battle') === 'OP16',
    bandai_set_code_alias('the-time-of-battle-one-piece-card-game') === 'OP16',
    justtcg_legacy_game_id('mtg', 'en') === 'magic-the-gathering',
    justtcg_legacy_game_id('pokemon', 'ja') === 'pokemon-japan',
];

$enriched = enrich_card_api_descriptions([
    [
        'description' => '',
        'apiDescription' => '',
        'cardType' => '',
        'scryfallId' => '',
    ],
    [
        'description' => 'Printed type line',
        'apiDescription' => '',
        'cardType' => '',
        'scryfallId' => '',
    ],
]);
$assertions[] = ($enriched[1]['apiDescription'] ?? '') === 'Printed type line';
$assertions[] = ($enriched[0]['description'] ?? '') === '';

foreach ($assertions as $index => $passed) {
    if (!$passed) {
        fwrite(STDERR, 'JustTCG provider assertion failed at index ' . $index . PHP_EOL);
        exit(1);
    }
}

echo "JustTCG provider tests passed.\n";
