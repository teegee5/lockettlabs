<?php
declare(strict_types=1);

// Offline checks for how the backfill reads a product. No network is used here;
// these cover the parsing that decides which set and card a product refers to.
require_once __DIR__ . '/../lib/backfill.php';

$assertions = [];

$product = [
    'id' => 'gid://shopify/Product/1',
    'title' => 'Abomasnow : CHILLING REIGN (Reverse holo) - 010/198',
    'tags' => ['Chilling Reign', 'Single Cards', 'Sword & Shield'],
    'metafields' => ['nodes' => []],
];

// The set comes from the product's own title, never from its era tag.
$assertions[] = backfill_set_names($product) === ['CHILLING REIGN'];
$assertions[] = backfill_card_name($product) === 'Abomasnow';
$assertions[] = backfill_card_number($product) === '010/198';
// "Sword & Shield" is a real TCGdex set (swsh1). It must never be offered.
$assertions[] = !in_array('Sword & Shield', backfill_set_names($product), true);

// No finish suffix to strip.
$plain = ['title' => 'Antique Armor Fossil : PITCH BLACK - 072/084', 'metafields' => ['nodes' => []]];
$assertions[] = backfill_set_names($plain) === ['PITCH BLACK'];
$assertions[] = backfill_card_name($plain) === 'Antique Armor Fossil';
$assertions[] = backfill_card_number($plain) === '072/084';

// A colon inside the card name must not be mistaken for the separator.
$colon = ['title' => 'Type: Null : PITCH BLACK (Reverse holo) - 069/084', 'metafields' => ['nodes' => []]];
$assertions[] = backfill_card_name($colon) === 'Type: Null';
$assertions[] = backfill_set_names($colon) === ['PITCH BLACK'];

// An apostrophe in the card name is left alone.
$apostrophe = ['title' => "Gladion's Final Battle : PITCH BLACK - 108/084", 'metafields' => ['nodes' => []]];
$assertions[] = backfill_card_name($apostrophe) === "Gladion's Final Battle";
$assertions[] = backfill_card_number($apostrophe) === '108/084';

// tcg metafields written by the intake app are preferred over title parsing.
$withMeta = [
    'title' => 'Whatever The Title Says : NONSENSE - 999/999',
    'metafields' => ['nodes' => [
        ['key' => 'english_set_name', 'value' => 'Pitch Black'],
        ['key' => 'set_name', 'value' => 'Pitch Black JP'],
        ['key' => 'english_name', 'value' => 'Lampent'],
        ['key' => 'card_number', 'value' => '037/084'],
    ]],
];
$assertions[] = backfill_set_names($withMeta) === ['Pitch Black', 'Pitch Black JP', 'NONSENSE'];
$assertions[] = backfill_card_name($withMeta) === 'Lampent';
$assertions[] = backfill_card_number($withMeta) === '037/084';

// A title that does not follow the house format yields nothing rather than junk.
$odd = ['title' => 'Some Sealed Product Box', 'metafields' => ['nodes' => []]];
$assertions[] = backfill_set_names($odd) === [];
$assertions[] = backfill_card_name($odd) === '';

// The tag used to select products is quoted safely for the Shopify query.
$assertions[] = backfill_product_query('Pitch Black') === "tag:'Pitch Black' AND tag:'Single Cards'";

foreach ($assertions as $index => $passed) {
    if ($passed !== true) {
        fwrite(STDERR, 'Backfill assertion failed at index ' . $index . PHP_EOL);
        exit(1);
    }
}

echo "Backfill tests passed.\n";
