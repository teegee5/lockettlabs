<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/retailers/rapidapi_tcg.php';
require_once __DIR__ . '/../lib/retailers/compare.php';

$assertions = [];

$assertions[] = retailer_rapidapi_tcg_game_slug('one-piece-card-game') === 'one-piece';
$assertions[] = retailer_rapidapi_tcg_game_slug('pokemon') === 'pokemon';
$assertions[] = retailer_rapidapi_tcg_host() === 'tcgplayer-price-data.p.rapidapi.com'
    || retailer_rapidapi_tcg_host() !== '';

// Missing key → soft fail with config hint (no network).
$noKey = retailer_rapidapi_tcg_from_response('OP16-002', [
    'ok' => true,
    'status' => 200,
    'body' => '{}',
    'error' => '',
]);
// Empty JSON → no match (key not involved in from_response).
$assertions[] = $noKey['matched'] === false;
$assertions[] = ($noKey['note'] ?? '') === 'No match';

$blockedAuth = retailer_rapidapi_tcg_from_response('OP16-002', [
    'ok' => true,
    'status' => 403,
    'body' => '{"message":"Forbidden"}',
    'error' => '',
]);
$assertions[] = $blockedAuth['matched'] === false;
$assertions[] = str_contains((string) ($blockedAuth['note'] ?? ''), 'RAPIDAPI_KEY')
    || str_contains((string) ($blockedAuth['note'] ?? ''), 'Blocked');

$sampleBody = json_encode([
    'results' => [
        [
            'name' => 'Monkey D. Luffy - OP16-002',
            'number' => 'OP16-002',
            'setName' => 'Heroines Edition',
            'lowPrice' => 1.25,
            'marketPrice' => 1.50,
            'productId' => '123456',
        ],
        [
            'name' => 'Other Card - OP16-099',
            'number' => 'OP16-099',
            'lowPrice' => 9.99,
        ],
    ],
], JSON_UNESCAPED_SLASHES);

$matched = retailer_rapidapi_tcg_from_response('OP16-002', [
    'ok' => true,
    'status' => 200,
    'body' => $sampleBody,
    'error' => '',
]);

// FX may succeed or fail offline; either matched with GBP or blocked on FX.
$assertions[] = !empty($matched['matched']) || str_contains((string) ($matched['note'] ?? ''), 'USD→GBP');
if (!empty($matched['matched']) && ($matched['available'] ?? null) === true) {
    $assertions[] = ($matched['market'] ?? false) === true;
    $assertions[] = isset($matched['priceGbp']) && (float) $matched['priceGbp'] > 0;
    $assertions[] = str_contains((string) ($matched['url'] ?? ''), 'tcgplayer.com');
    $assertions[] = str_contains((string) ($matched['note'] ?? ''), 'Market');
} else {
    $assertions[] = true;
    $assertions[] = true;
    $assertions[] = true;
    $assertions[] = true;
}

// Prefer lowPrice over marketPrice when extracting USD.
$usd = retailer_rapidapi_tcg_extract_usd([
    'lowPrice' => 1.25,
    'marketPrice' => 1.50,
]);
$assertions[] = $usd === 1.25;

// Compare board labels no longer include Chaos / Hills.
$labels = competitor_source_labels();
$assertions[] = !isset($labels['chaos']);
$assertions[] = !isset($labels['hills']);
$assertions[] = isset($labels['rapidapi_tcg']);
$assertions[] = isset($labels['totalcards']);
$assertions[] = isset($labels['magicmadhouse']);
$assertions[] = isset($labels['unicorn']);

$empty = competitor_prices_empty('OP16-002', 'volume', 'test');
$ids = array_column($empty['sources'], 'id');
$assertions[] = !in_array('chaos', $ids, true);
$assertions[] = !in_array('hills', $ids, true);
$assertions[] = in_array('rapidapi_tcg', $ids, true);

// Missing API key lookup fails soft without throwing.
$lookup = retailer_rapidapi_tcg_lookup('OP16-002', 'one-piece-card-game');
$assertions[] = ($lookup['id'] ?? '') === 'rapidapi_tcg';
$assertions[] = empty($lookup['matched']);
$assertions[] = str_contains((string) ($lookup['note'] ?? ''), 'RAPIDAPI_KEY')
    || str_contains((string) ($lookup['note'] ?? ''), 'rapidapi_key')
    || ($lookup['note'] ?? '') === 'Blocked';

foreach ($assertions as $index => $ok) {
    if (!$ok) {
        fwrite(STDERR, 'RapidAPI TCG assertion failed at index ' . $index . PHP_EOL);
        exit(1);
    }
}

echo "RapidAPI TCG tests passed.\n";
