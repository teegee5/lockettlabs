<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/retailers/match.php';
require_once __DIR__ . '/../lib/retailers/finish.php';
require_once __DIR__ . '/../lib/retailers/chaos-snapshot.php';

/**
 * The Chaos Cards snapshot, split per game.
 *
 * It used to be one file: 13 MB and 41,841 cards, decoded in full on every
 * card lookup to retrieve a single key. Now each game has its own file and the
 * game decides which one is opened, so a Pokemon lookup reads 0.7 MB.
 *
 * Two things have to hold for that to be safe. The game the intake form sends
 * must reach the right shard, and a card whose game is unknown must still be
 * findable rather than silently missing.
 */

$assertions = [];
$labels = [];

$check = static function (string $label, bool $ok) use (&$assertions, &$labels): void {
    $assertions[] = $ok;
    $labels[] = $label;
};

// --- game to shard ---------------------------------------------------------
// Every one of these is a real value the form or JustTCG produces.
$cases = [
    'pokemon' => 'pokemon',
    'pokemon-japan' => 'pokemon',     // Chaos index English printings
    'Pokémon' => 'pokemon',
    'magic-the-gathering' => 'mtg',
    'mtg' => 'mtg',
    'MTG' => 'mtg',
    'disney-lorcana' => 'lorcana',
    'disney' => 'lorcana',            // the store's own product-type word
    'Disney Lorcana' => 'lorcana',
    'one-piece-card-game' => 'one-piece',
    'one piece' => 'one-piece',
    'digimon-card-game' => 'digimon',
    'yugioh' => 'yu-gi-oh',
    'yu-gi-oh!' => 'yu-gi-oh',
];
foreach ($cases as $game => $expected) {
    $check("game '{$game}' routes to {$expected}", retailer_chaos_shard_for_game($game) === $expected);
}

// Unknown games must return null, which makes the lookup try every shard
// rather than guessing a wrong one.
foreach (['', '   ', 'union-arena', 'gundam-card-game', 'dragon-ball-super'] as $game) {
    $check("game '{$game}' has no shard", retailer_chaos_shard_for_game($game) === null);
}

// Lorcana is tested before Disney, because the store sends the game as
// "disney" on its own and a Disney-first rule would send it nowhere.
$check('lorcana wins over the disney substring',
    retailer_chaos_shard_for_game('disney lorcana') === 'lorcana');

// --- search order ----------------------------------------------------------
$order = retailer_chaos_snapshot_search_order('pokemon');
$check('a known game opens exactly one shard', count($order) === 1);

$all = retailer_chaos_snapshot_search_order('');
$check('an unknown game searches more than one place', count($all) >= 1);
if (retailer_chaos_snapshot_is_sharded()) {
    $check('an unknown game searches every shard', count($all) === count(CHAOS_SNAPSHOT_SHARDS));
    $check('every shard name is known', array_diff($all, CHAOS_SNAPSHOT_SHARDS) === []);
} else {
    // No shards written yet: the reader must fall back to the combined file
    // rather than reporting no snapshot at all.
    $check('falls back to the combined file', $all === [null]);
}

// --- keys are unchanged by sharding ---------------------------------------
// The key format is what ties the PHP side to tools/chaos-snapshot.mjs. If it
// drifts, every lookup silently returns "not in the snapshot".
$check('pokemon style key',
    retailer_chaos_snapshot_key('Armarouge', '012/084', 'Reverse holo') === 'armarouge|12/84|reverse');
$check('leading zeros are not identity',
    retailer_chaos_snapshot_key('Armarouge', '12/84', 'Reverse holo')
    === retailer_chaos_snapshot_key('Armarouge', '012/084', 'Reverse holo'));
$check('set code key survives',
    retailer_chaos_snapshot_key('Sengoku', 'OP16-060', '') === 'sengoku|OP16-060|normal');
$check('empty finish means normal',
    str_ends_with((string) retailer_chaos_snapshot_key('Blitzle', '50/198', ''), '|normal'));
$check('ball reverses keep their own token',
    str_ends_with((string) retailer_chaos_snapshot_key('Salandit', '34/217', 'Ball Reverse holo'), '|ball-reverse'));
$check('poke ball reverse is not plain reverse',
    str_ends_with((string) retailer_chaos_snapshot_key('Exeggcute', '1/131', 'Pokeball Reverse holo'), '|pokeball-reverse'));
$check('apostrophes are kept',
    retailer_chaos_snapshot_key("Misty's Lapras", '194/182', '') === "misty's lapras|194/182|normal");
$check('a nameless card has no key',
    retailer_chaos_snapshot_key('', '012/084', '') === null);

// --- a miss is a miss ------------------------------------------------------
// Quoting the wrong card is the failure this whole path exists to avoid, so a
// card that is not there must come back unmatched, never with a price.
$missing = retailer_chaos_from_snapshot('999/999', 'Not A Real Card Name At All', '', 'pokemon');
$check('a card that is not stocked returns no match', $missing['matched'] === false);
$check('a card that is not stocked returns no price', ($missing['priceGbp'] ?? null) === null);

$unkeyable = retailer_chaos_from_snapshot('012/084', '', '', 'pokemon');
$check('a card with no name returns no match', $unkeyable['matched'] === false);

foreach ($assertions as $index => $ok) {
    if (!$ok) {
        fwrite(STDERR, 'Chaos shard assertion failed: ' . ($labels[$index] ?? ('index ' . $index)) . PHP_EOL);
        exit(1);
    }
}

echo 'Chaos snapshot shard tests passed (' . count($assertions) . " assertions).\n";
