<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/retailers/strategy.php';
require_once __DIR__ . '/../lib/retailers/match.php';
require_once __DIR__ . '/../lib/retailers/compare.php';
require_once __DIR__ . '/../lib/totalcards.php';

$assertions = [];

// Rarity bands — One Piece
$assertions[] = competitor_rarity_band('Common') === 'volume';
$assertions[] = competitor_rarity_band('Uncommon') === 'volume';
$assertions[] = competitor_rarity_band('UC') === 'volume';
$assertions[] = competitor_rarity_band('Rare') === 'mid';
$assertions[] = competitor_rarity_band('Super Rare') === 'mid';
$assertions[] = competitor_rarity_band('SR') === 'mid';
$assertions[] = competitor_rarity_band('Secret Rare') === 'chase';
$assertions[] = competitor_rarity_band('SEC') === 'chase';
$assertions[] = competitor_rarity_band('SP') === 'chase';
$assertions[] = competitor_rarity_band('Manga Rare') === 'chase';
$assertions[] = competitor_rarity_band('Alternate Art') === 'chase';
$assertions[] = competitor_rarity_band('Leader') === 'chase';

// Rarity bands — Pokémon
$assertions[] = competitor_rarity_band('Illustration Rare') === 'chase';
$assertions[] = competitor_rarity_band('Special Illustration Rare') === 'chase';
$assertions[] = competitor_rarity_band('Ultra Rare') === 'mid';
$assertions[] = competitor_rarity_band('Hyper Rare') === 'chase';

// All games can compare — structure uses JustTCG + Total Cards + UK links (no game gate).
$emptyDigimon = competitor_prices_empty('BT14-001', 'volume', 1.50, price_compare_uk_links('BT14-001', 'Agumon', 'BT14'), 'No match');
$assertions[] = $emptyDigimon['ok'] === true;
$assertions[] = $emptyDigimon['justTcgNm'] === 1.50;
$assertions[] = in_array('justtcg', array_column($emptyDigimon['sources'], 'id'), true);
$assertions[] = in_array('totalcards', array_column($emptyDigimon['sources'], 'id'), true);
$assertions[] = in_array('chaoscards', array_column($emptyDigimon['sources'], 'id'), true);
$assertions[] = count($emptyDigimon['links'] ?? []) >= 5;

// Empty number path
$empty = competitor_prices_empty('', 'volume', 0.55, price_compare_uk_links(''), 'Enter a printed card number.');
$assertions[] = $empty['justTcgNm'] === 0.55;
$assertions[] = $empty['suggestedNm'] === null;

// JustTCG-only scarcity raise (no UK in-stock)
$scarce = competitor_suggest_nm('volume', 1.25, []);
$assertions[] = $scarce['action'] === 'raise';
$assertions[] = $scarce['suggestedNm'] === 1.25;
$assertions[] = $scarce['autoFill'] === true;

// Volume undercut + odd pence (with £0.15 floor)
$assertions[] = competitor_undercut_odd_pence(0.28) === 0.27;
$assertions[] = competitor_undercut_odd_pence(0.29) === 0.27;
$assertions[] = competitor_undercut_odd_pence(1.00) === 0.99;
$assertions[] = competitor_undercut_odd_pence(0.15) === 0.15; // match floor
$assertions[] = competitor_undercut_odd_pence(0.16) === 0.15; // undercut to floor
$assertions[] = competitor_apply_rarity_price_floor(0.15, 'volume') === 0.15;
$assertions[] = competitor_apply_rarity_price_floor(0.15, 'mid') === 0.19; // Rare bump
$assertions[] = competitor_apply_rarity_price_floor(0.15, 'chase') === 0.19;

$vol = competitor_suggest_nm('volume', 0.50, [0.28, 0.35]);
$assertions[] = $vol['suggestedNm'] === 0.27;
$assertions[] = $vol['autoFill'] === true;
$assertions[] = $vol['action'] === 'undercut';

$volFloor = competitor_suggest_nm('volume', 0.50, [0.15]);
$assertions[] = $volFloor['suggestedNm'] === 0.15;

$mid = competitor_suggest_nm('mid', 0.20, [0.28]);
$assertions[] = $mid['suggestedNm'] === 0.20;
$mid2 = competitor_suggest_nm('mid', 0.40, [0.28]);
$assertions[] = $mid2['suggestedNm'] === 0.27;

$midRareFloor = competitor_suggest_nm('mid', 0.50, [0.15]);
$assertions[] = $midRareFloor['suggestedNm'] === 0.19;
$assertions[] = $midRareFloor['action'] === 'raise';

$chase = competitor_suggest_nm('chase', 5.00, [3.00, 4.00, 8.00]);
$assertions[] = $chase['suggestedNm'] === 5.00;
$assertions[] = $chase['autoFill'] === false;
$chase2 = competitor_suggest_nm('chase', 2.00, [3.00, 4.00, 8.00]);
$assertions[] = $chase2['suggestedNm'] === 4.00;

// Exact number match helpers
$assertions[] = retailer_title_matches_number('Card (Uncommon) - OP16-045', 'OP16-045');
$assertions[] = !retailer_title_matches_number('Card (SR) - OP16-032a', 'OP16-032');
$assertions[] = retailer_text_contains_exact_number('Pikachu 026/086 Scarlet', '026/086');

// UK links
$links = price_compare_uk_links('OP16-045');
$labels = array_column($links, 'id');
$assertions[] = in_array('totalcards', $labels, true);
$assertions[] = in_array('chaoscards', $labels, true);
$assertions[] = in_array('magicmadhouse', $labels, true);
$assertions[] = in_array('hillscards', $labels, true);
$assertions[] = in_array('unicorn', $labels, true);
$chaos = null;
foreach ($links as $link) {
    if (($link['id'] ?? '') === 'chaoscards') $chaos = $link['url'] ?? '';
}
$assertions[] = $chaos === 'https://www.chaoscards.co.uk/search/op16-045';
$assertions[] = price_compare_chaos_search_url('OP16-040') === 'https://www.chaoscards.co.uk/search/op16-040';
$assertions[] = price_compare_chaos_search_url('026/086') === 'https://www.chaoscards.co.uk/search/026-086';

// Name + number deep links (reject bare number for Pokémon-style collisions).
$tyLinks = price_compare_uk_links('135/193', 'Tyranitar', 'Paldea Evolved');
$tyChaos = null;
$tyTc = null;
foreach ($tyLinks as $link) {
    if (($link['id'] ?? '') === 'chaoscards') $tyChaos = $link['url'] ?? '';
    if (($link['id'] ?? '') === 'totalcards') $tyTc = $link['url'] ?? '';
}
$assertions[] = $tyChaos === 'https://www.chaoscards.co.uk/search/tyranitar-135-193';
$assertions[] = is_string($tyTc) && str_contains($tyTc, rawurlencode('Tyranitar 135/193'));
$assertions[] = price_compare_chaos_search_url('135/193', 'Tyranitar') === 'https://www.chaoscards.co.uk/search/tyranitar-135-193';

// Prefer product URL over search when source matched.
$prefer = price_compare_prefer_product_urls(
    [['id' => 'chaoscards', 'label' => 'Chaos Cards', 'url' => 'https://www.chaoscards.co.uk/search/tyranitar-135-193']],
    [['id' => 'chaoscards', 'matched' => true, 'url' => 'https://www.chaoscards.co.uk/pokemon-tyranitar-135-193']]
);
$assertions[] = ($prefer[0]['url'] ?? '') === 'https://www.chaoscards.co.uk/pokemon-tyranitar-135-193';

// TC in-stock gate
$oosSource = ['matched' => true, 'available' => false, 'priceGbp' => 0.99];
$inStockGate = !empty($oosSource['matched'])
    && ($oosSource['available'] ?? null) === true
    && isset($oosSource['priceGbp']);
$assertions[] = $inStockGate === false;

$inSource = ['matched' => true, 'available' => true, 'priceGbp' => 0.28];
$inStockGate2 = !empty($inSource['matched'])
    && ($inSource['available'] ?? null) === true
    && isset($inSource['priceGbp'])
    && (float) $inSource['priceGbp'] > 0;
$assertions[] = $inStockGate2 === true;

$assertions[] = totalcards_adjust_nm_price(0.28) === 0.29;

// Existing Shopify guidance
$existing = competitor_compare_existing(1.50, 0.28, 0.27, 'volume');
$assertions[] = $existing['action'] === 'lower';

foreach ($assertions as $index => $ok) {
    if (!$ok) {
        fwrite(STDERR, 'Competitor strategy assertion failed at index ' . $index . PHP_EOL);
        exit(1);
    }
}

echo "Competitor strategy tests passed.\n";
