/**
 * Live probe: bare 002 vs expanded OP16-002 against JustTCG.
 * Reads key from config.php; never prints it.
 * Usage: node tests/live-op16-002.js
 */
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const cfg = fs.readFileSync(path.join(root, 'config.php'), 'utf8');
const key = (cfg.match(/justtcg_api_key'\s*=>\s*'([^']+)'/) || [])[1];
if (!key) {
  console.error('No justtcg_api_key in config.php');
  process.exit(1);
}

const base = 'https://api.justtcg.com/v1';
async function get(pathname, params) {
  const url = base + pathname + '?' + new URLSearchParams(params);
  const res = await fetch(url, { headers: { 'x-api-key': key } });
  const body = await res.json();
  return { status: res.status, data: body.data || [], meta: body.meta };
}

function parseNumber(value) {
  value = String(value).trim().toUpperCase().replace(/\s+/g, '');
  let m = value.match(/^([A-Z]{1,12}\d{0,6}[A-Z]?)-([A-Z]*\d{1,6}[A-Z]*)$/);
  if (m) return { setCode: m[1], localRaw: m[2] };
  m = value.match(/^((?:PRB|OP|BT|EX|ST|EB|RB|LM)\d{2}[A-Z]?)(\d{2,4})$/i);
  if (m) return { setCode: m[1].toUpperCase(), localRaw: m[2] };
  return { setCode: '', localRaw: value };
}

async function discoverSetCode(game, setId) {
  const { data } = await get('/cards', {
    game,
    set: setId,
    limit: '24',
    include_null_prices: 'true',
    include_price_history: 'false',
  });
  const counts = {};
  for (const card of data) {
    const parsed = parseNumber(card.number || '');
    if (!parsed.setCode) continue;
    counts[parsed.setCode] = (counts[parsed.setCode] || 0) + 1;
  }
  const ranked = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  return { code: ranked[0]?.[0] || '', counts, sample: data.map((c) => c.number).slice(0, 12) };
}

(async () => {
  const game = 'one-piece-card-game';
  const sets = await get('/sets', { game, q: 'The Time of Battle' });
  const set = (sets.data || []).find((s) => /time of battle/i.test(s.name) && !/release/i.test(s.name));
  console.log('set', set && { id: set.id, name: set.name });
  const setId = set.id;

  const discovered = await discoverSetCode(game, setId);
  console.log('discover', discovered);

  const expanded = discovered.code ? `${discovered.code}-002` : '002';
  console.log('expanded 002 =>', expanded);

  for (const [label, params] of [
    ['bare 002 + set', { game, set: setId, number: '002', limit: '5', include_null_prices: 'true' }],
    ['expanded + set', { game, set: setId, number: expanded, limit: '5', include_null_prices: 'true' }],
    ['OP16-002 no set', { game, number: 'OP16-002', limit: '5', include_null_prices: 'true' }],
    ['bare 065 + set', { game, set: setId, number: '065', limit: '5', include_null_prices: 'true' }],
    ['OP16-065 + set', { game, set: setId, number: 'OP16-065', limit: '5', include_null_prices: 'true' }],
    ['sets q=OP16', null],
  ]) {
    if (label === 'sets q=OP16') {
      const r = await get('/sets', { game, q: 'OP16' });
      console.log(label, (r.data || []).slice(0, 5).map((s) => s.name));
      continue;
    }
    const r = await get('/cards', params);
    console.log(label, 'count=' + r.data.length, r.data.map((c) => `${c.name} [${c.number}]`).join('; '));
  }
})().catch((err) => {
  console.error(err.message || err);
  process.exit(1);
});
