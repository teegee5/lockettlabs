<?php
declare(strict_types=1);

// Offline checks for the TCGdex id helpers. Network lookups are not exercised
// here; these cover the parsing that decides whether a card id is trusted.
require_once __DIR__ . '/../lib/tcgdex.php';

$assertions = [];

$assertions[] = tcgdex_supports_game('pokemon') === true;
$assertions[] = tcgdex_supports_game('pokemon-japan') === true;
$assertions[] = tcgdex_supports_game('magic-the-gathering') === false;

$assertions[] = tcgdex_language('pokemon') === 'en';
$assertions[] = tcgdex_language('pokemon-japan') === 'ja';
$assertions[] = tcgdex_language('pokemon', 'ja') === 'ja';

// Printed numbers reduce to the local part TCGdex indexes on.
$assertions[] = tcgdex_local_number('037/084') === '037';
$assertions[] = tcgdex_local_number('097/084') === '097';
$assertions[] = tcgdex_local_number('SV107') === 'SV107';
$assertions[] = tcgdex_local_number('OP16-026') === '026';
$assertions[] = tcgdex_local_number('  4 / 102 ') === '4';
$assertions[] = tcgdex_local_number('') === '';

// TCGdex pads inconsistently between sets, so both forms must match.
$assertions[] = tcgdex_local_matches('016', '016') === true;
$assertions[] = tcgdex_local_matches('16', '016') === true;
$assertions[] = tcgdex_local_matches('037', '37') === true;
$assertions[] = tcgdex_local_matches('37', '38') === false;
$assertions[] = tcgdex_local_matches('', '016') === false;
$assertions[] = tcgdex_local_matches('SV107', 'SV107') === true;
$assertions[] = tcgdex_local_matches('SV107', 'SV108') === false;

$assertions[] = tcgdex_normalize('Scarlet & Violet—151') === 'scarletviolet151';
$assertions[] = tcgdex_normalize('  Pitch Black ') === 'pitchblack';

// Set selection follows candidate order, not the order sets come back from the
// API. Regression: every Pitch Black single also carries the era tag "Mega
// Evolution", which is a real set (me01) listed before Pitch Black (me05). When
// the era name was allowed to win, all 106 cards resolved to me01 and the
// storefront showed a different card entirely.
$sets = [
    ['id' => 'me01', 'name' => 'Mega Evolution'],
    ['id' => 'me03', 'name' => 'Phantasmal Flames'],
    ['id' => 'me05', 'name' => 'Pitch Black'],
];
$assertions[] = (tcgdex_pick_set($sets, ['Pitch Black', 'Mega Evolution'])['id'] ?? '') === 'me05';
$assertions[] = (tcgdex_pick_set($sets, ['Mega Evolution', 'Pitch Black'])['id'] ?? '') === 'me01';
$assertions[] = (tcgdex_pick_set($sets, ['Pitch Black'])['id'] ?? '') === 'me05';
// An unknown first candidate falls through to the next one, it does not block.
$assertions[] = (tcgdex_pick_set($sets, ['SV: Not A Set', 'Pitch Black'])['id'] ?? '') === 'me05';
// Set ids are accepted as well as names.
$assertions[] = (tcgdex_pick_set($sets, ['me05'])['id'] ?? '') === 'me05';
$assertions[] = tcgdex_pick_set($sets, ['Totally Made Up Set']) === null;
$assertions[] = tcgdex_pick_set($sets, []) === null;
$assertions[] = tcgdex_pick_set([], ['Pitch Black']) === null;

// Guard 2: the printed denominator must match the set's card count. Regression:
// "Abomasnow : CHILLING REIGN - 010/198" resolved to swsh1-10 (Grookey) because
// the era tag "Sword & Shield" was trusted as the set. Chilling Reign prints
// /198 and is swsh6; the Sword & Shield base set holds 202 official cards.
$assertions[] = tcgdex_printed_denominator('010/198') === '198';
$assertions[] = tcgdex_printed_denominator('097/084') === '084';
$assertions[] = tcgdex_printed_denominator('SWSH070') === '';
$assertions[] = tcgdex_printed_denominator('') === '';

$swordShieldBase = ['id' => 'swsh1', 'name' => 'Sword & Shield', 'cardCount' => ['official' => 202, 'total' => 216]];
$chillingReign = ['id' => 'swsh6', 'name' => 'Chilling Reign', 'cardCount' => ['official' => 198, 'total' => 233]];
$assertions[] = tcgdex_set_count_matches($swordShieldBase, '198') === false;
$assertions[] = tcgdex_set_count_matches($chillingReign, '198') === true;
$assertions[] = tcgdex_set_count_matches($chillingReign, '233') === true;
// No denominator printed, or no count known: the check cannot judge, so it passes.
$assertions[] = tcgdex_set_count_matches($swordShieldBase, '') === true;
$assertions[] = tcgdex_set_count_matches(['id' => 'x', 'name' => 'x'], '198') === true;

// Guard 3: the card found must be the card asked for.
$assertions[] = tcgdex_names_match('Abomasnow', 'Grookey') === false;
$assertions[] = tcgdex_names_match('Abomasnow', 'Abomasnow') === true;
$assertions[] = tcgdex_names_match('Type: Null', 'Type Null') === true;
$assertions[] = tcgdex_names_match("Gladion's Final Battle", 'Gladions Final Battle') === true;
// Suffix wording differences are tolerated; a unique localId means there is no
// sibling card in the same set to confuse it with.
$assertions[] = tcgdex_names_match('Abomasnow', 'Abomasnow V') === true;
// An unknown name cannot judge, so it passes rather than blocking everything.
$assertions[] = tcgdex_names_match('', 'Grookey') === true;

// Unsupported game or missing number must never produce an id.
$assertions[] = tcgdex_resolve_card_id('magic-the-gathering', ['Lorwyn Eclipsed'], '80') === '';
$assertions[] = tcgdex_resolve_card_id('pokemon', ['Pitch Black'], '') === '';

foreach ($assertions as $index => $passed) {
    if ($passed !== true) {
        fwrite(STDERR, 'TCGdex assertion failed at index ' . $index . PHP_EOL);
        exit(1);
    }
}

echo "TCGdex tests passed.\n";
