<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/retailers/match.php';
require_once __DIR__ . '/../lib/retailers/finish.php';
require_once __DIR__ . '/../lib/retailers/compare.php';

/**
 * Printing discrimination.
 *
 * Every case below is a real mis-match found while sweeping the whole
 * catalogue against UK retailers. Each one produced a confident, wrong price.
 */

$assertions = [];
$labels = [];

$check = static function (string $label, bool $ok) use (&$assertions, &$labels): void {
    $assertions[] = $ok;
    $labels[] = $label;
};

// --- finish tokens ---------------------------------------------------------
$check('plain title is plain',
    retailer_title_finish_token('Armarouge : PITCH BLACK - 012/084') === 'normal');
$check('bracketed reverse is reverse',
    retailer_title_finish_token('Armarouge : PITCH BLACK (Reverse holo) - 012/084') === 'reverse');
$check('madhouse wording',
    retailer_title_finish_token('ME Pitch Black 020/084 Primarina (Reverse Holo)') === 'reverse');
$check('madhouse half art',
    retailer_title_finish_token('ME Pitch Black 065/084 Mega Excadrill ex (Half Art)') === 'halfart');
$check('chaos inline reverse',
    retailer_title_finish_token('Shadowy Energy (REVERSE HOLO) : MEGA EVOLUTION - PITCH BLACK 83/84') === 'reverse');

// Defect 1: the generic reverse rule used to swallow ball-pattern reverses,
// matching a GBP 5.95 card against a GBP 0.19 one.
$check('master ball reverse keeps its own token',
    retailer_title_finish_token('Litleo : PRISMATIC EVOLUTIONS (Masterball Reverse holo) - 009/131') === 'masterball-reverse');
$check('poke ball reverse keeps its own token',
    retailer_title_finish_token('Applin - 009/131 - (Reverse Holo Poke Ball)') === 'pokeball-reverse');
$check('master ball never matches poke ball',
    retailer_finish_compatible('masterball-reverse', 'pokeball-reverse') === false);
$check('master ball never matches plain reverse',
    retailer_finish_compatible('masterball-reverse', 'reverse') === false);

// Defect 2: "non-holo" contains "holo".
$check('non-holo is not holo',
    retailer_title_finish_token('Pokemon GO 027/078 Pikachu (Non-Holo)') === 'nonholo');
$check('holo intake rejects a non-holo listing',
    retailer_finish_compatible('holo', 'nonholo') === false);

// Defect 3: reprint subsets reuse the original collector number.
$check('celebrations is its own variant',
    retailer_variant_token('Venusaur : CELEBRATIONS - 15/102') === 'celebrations');
$check('base set stays base',
    retailer_variant_token('Pokemon - Base Set - Venusaur - 15/102') === 'base');
$check('celebrations never matches base',
    retailer_variant_compatible('celebrations', 'base') === false);

// --- intake vocabulary -----------------------------------------------------
$check('Standard maps to plain',
    retailer_intake_finish_token('Standard') === 'normal');
$check('Reverse Holo maps to reverse',
    retailer_intake_finish_token('Reverse Holo') === 'reverse');
$check('Foil maps to foil',
    retailer_intake_finish_token('Foil') === 'foil');
$check('foil and holo interchange for foil-only games',
    retailer_finish_compatible('foil', 'holo') === true);
$check('reverse intake rejects a plain listing',
    retailer_finish_compatible('reverse', 'normal') === false);
$check('empty finish applies no constraint',
    retailer_intake_finish_token('') === ''
    && retailer_finish_compatible('', 'masterball-reverse') === true);

// --- the gate as compare.php applies it ------------------------------------
$matchedReverse = retailer_source_result(
    'totalcards', 'Total Cards', true, true, 0.19,
    'https://totalcards.net/products/x', 'In stock'
);
$matchedReverse['title'] = 'Pokemon - Prismatic Evolutions - Litleo - 009/131 - (Reverse Holo)';

// Taking in a Master Ball reverse must not price against a plain reverse.
$gated = competitor_apply_finish_gate($matchedReverse, 'masterball-reverse');
$check('gate drops a plain reverse when taking in a master ball',
    $gated['matched'] === false && $gated['priceGbp'] === null);
$check('gate explains itself',
    str_contains((string) $gated['note'], 'Master Ball'));

// The same listing is fine when that is what we are taking in.
$kept = competitor_apply_finish_gate($matchedReverse, 'reverse');
$check('gate keeps the right printing',
    $kept['matched'] === true && (float) $kept['priceGbp'] === 0.19);

// No finish supplied: unchanged behaviour.
$ungated = competitor_apply_finish_gate($matchedReverse, '');
$check('gate is inert without a finish',
    $ungated['matched'] === true);

// A source that never matched is left alone.
$noMatch = retailer_source_no_match('chaoscards', 'Chaos Cards');
$check('gate leaves a no-match alone',
    competitor_apply_finish_gate($noMatch, 'reverse')['matched'] === false);

foreach ($assertions as $index => $ok) {
    if (!$ok) {
        fwrite(STDERR, 'Finish assertion failed: ' . ($labels[$index] ?? ('index ' . $index)) . PHP_EOL);
        exit(1);
    }
}

echo 'Retailer finish tests passed (' . count($assertions) . " assertions).\n";
