'use strict';

// Exercises the intake editor's autofill rules straight out of assets/app.js so
// the tag/collection/product-type contract cannot drift from the shipped file.
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'assets', 'app.js'), 'utf8');

function slice(startMarker, endMarker) {
  const start = source.indexOf(startMarker);
  const end = source.indexOf(endMarker, start);
  if (start < 0 || end < 0) throw new Error(`Could not locate ${startMarker} in app.js`);
  return source.slice(start, end);
}

const block = [
  slice('  const productTypeDefaults = {', '  const state = {'),
  slice('  const POKEMON_ERAS_EN = {', '  function applyAutofill(card)'),
  slice('  function normalize(value) {', '  function cardRarityValue(card)'),
  slice('  function cleanListingCardName(rawName, card = state.selected) {', '  function rebuildTitle() {'),
  slice('  const SEO_TITLE_MAX =', '  function updateSeoCounts()'),
  'module.exports = { buildAutofillPlan, pokemonSetTaxonomy, buildSeoTitle, buildSeoDescription, cleanListingCardName, buildTitle };'
].join('\n');

// Stand-ins for the few app-level helpers the autofill rules reach for.
const seoStub = { finish: 'Standard', nearMint: null, name: '', set: '' };
const sandbox = {
  els: {
    finish: { get value() { return seoStub.finish; } },
    englishName: { get value() { return seoStub.name; }, set value(v) { seoStub.name = v; } },
    englishSet: { get value() { return seoStub.set; }, set value(v) { seoStub.set = v; } }
  },
  state: { autofill: { plan: null }, selected: null },
  titleName: () => seoStub.name,
  readNearMintInputPrice: () => seoStub.nearMint,
  gameLabel: game => ({
    pokemon: 'Pokémon',
    'pokemon-japan': 'Pokémon Japan',
    'magic-the-gathering': 'Magic: The Gathering',
    'disney-lorcana': 'Disney Lorcana',
    'one-piece-card-game': 'One Piece Card Game'
  })[game] || game,
  vendorDefault: game => (/pokemon/i.test(game) ? 'Pokémon' : (/magic/i.test(game) ? 'Wizards of the Coast' : '')),
  isPokemon: game => /pokemon/i.test(String(game || '')),
  isOnePiece: game => /one-piece/i.test(String(game || '')),
  isDisneyLorcana: game => /disney|lorcana/i.test(String(game || '')),
  isMagic: game => /magic|mtg/i.test(String(game || '')),
  usesFoilNotHolo: game => /disney|lorcana|magic|mtg/i.test(String(game || '')),
  onePieceSetCode: card => String(card.setCode || '').toUpperCase(),
  module: { exports: {} }
};
vm.createContext(sandbox);
vm.runInContext(block, sandbox);
const { buildAutofillPlan } = sandbox.module.exports;

const failures = [];
function check(label, actual, expected) {
  const a = JSON.stringify(actual);
  const b = JSON.stringify(expected);
  if (a !== b) failures.push(`${label}\n  expected ${b}\n  actual   ${a}`);
}

// English Pokémon: Single Cards + set + era, nothing else.
const pitchBlack = buildAutofillPlan({
  game: 'pokemon', languageCode: 'en', setName: 'Pitch Black', rarity: 'Ultra Rare'
});
check('Pitch Black tags', pitchBlack.tags.sort(), ['Mega Evolution', 'Pitch Black', 'Single Cards']);
check('Pitch Black product type', pitchBlack.productType, 'Pokemon');
check('Pitch Black collections', pitchBlack.collections.sort(), ['Mega Evolution', 'Pitch Black']);

check(
  'Base Set 2 tags',
  buildAutofillPlan({ game: 'pokemon', languageCode: 'en', setName: 'Base Set 2' }).tags.sort(),
  ['Base Set', 'Base Set 2', 'Single Cards']
);

// JustTCG prefixes sets; the store's own tag name must still win.
check(
  'SV 151 tags',
  buildAutofillPlan({ game: 'pokemon', languageCode: 'en', setName: 'SV: Scarlet & Violet 151' }).tags.sort(),
  ['151', 'Scarlet & Violet', 'Single Cards']
);

// The base set of an era carries the "(Base)" set tag.
check(
  'Scarlet & Violet base tags',
  buildAutofillPlan({ game: 'pokemon', languageCode: 'en', setName: 'Scarlet & Violet' }).tags.sort(),
  ['Scarlet & Violet', 'Scarlet & Violet (Base)', 'Single Cards']
);

// Unknown set: keep its own name, never guess an era.
check(
  'unknown set tags',
  buildAutofillPlan({ game: 'pokemon', languageCode: 'en', setName: 'Totally Made Up Set' }).tags.sort(),
  ['Single Cards', 'Totally Made Up Set']
);

// Play! Prize Pack League promos: store title/SEO set + Pokemon Play! / Promos tags.
const prizePack = buildAutofillPlan({
  game: 'pokemon', languageCode: 'en', setName: 'Prize Pack Series Cards', rarity: 'Promo'
});
check(
  'Prize Pack tags',
  prizePack.tags.sort(),
  ['Pokemon Play!', 'Promos', 'Single Cards']
);
check('Prize Pack title set', prizePack.titleSet, 'PLAY! Prize Pack League Promo');
check('Prize Pack SEO set', prizePack.seoSet, 'PLAY! Prize Pack League Promo');
check('Prize Pack set tag', prizePack.setTag, 'Pokemon Play!');
check(
  'Prize Pack collections',
  prizePack.collections.sort(),
  ['Pokemon Play!', 'Promos']
);

sandbox.state.autofill.plan = {
  setTag: 'Pokemon Play!',
  titleSet: 'PLAY! Prize Pack League Promo',
  seoSet: 'PLAY! Prize Pack League Promo'
};
seoStub.name = 'Pikachu';
seoStub.set = 'PLAY! Prize Pack League Promo';
seoStub.nearMint = 4.5;
seoStub.finish = 'Standard';
sandbox.state.selected = {
  game: 'pokemon',
  name: 'Pikachu',
  cardNumber: '025/159',
  setName: 'Prize Pack Series Cards'
};
const prizePackSeoLive = {
  title: sandbox.module.exports.buildSeoTitle(sandbox.state.selected),
  description: sandbox.module.exports.buildSeoDescription(sandbox.state.selected)
};
check(
  'Prize Pack SEO title',
  prizePackSeoLive.title,
  'Pikachu 025/159 PLAY! Prize Pack League Promo | £4.50 In Stock UK'
);
check(
  'Prize Pack SEO description',
  prizePackSeoLive.description,
  'Buy Pikachu (025/159) from PLAY! Prize Pack League Promo, a single Pokémon card in mint or near-mint condition. Securely packed, fast UK delivery.'
);

const { cleanListingCardName, buildTitle } = sandbox.module.exports;
check(
  'strips JustTCG number and cosmos finish from name',
  cleanListingCardName('Dusclops - 019/064 (Cosmos Holo)', { cardNumber: '019/064' }),
  'Dusclops'
);

seoStub.finish = 'Holo';
seoStub.name = 'Dusclops - 019/064 (Cosmos Holo)';
seoStub.set = 'PLAY! Prize Pack League Promo';
sandbox.state.selected = {
  game: 'pokemon',
  name: 'Dusclops - 019/064 (Cosmos Holo)',
  cardNumber: '019/064',
  setName: 'Prize Pack Series Cards'
};
sandbox.state.autofill.plan = {
  titleSet: 'PLAY! Prize Pack League Promo',
  seoSet: 'PLAY! Prize Pack League Promo',
  setTag: 'Pokemon Play!'
};
check(
  'Prize Pack product title',
  buildTitle(),
  'Dusclops : PLAY! PRIZE PACK LEAGUE PROMO (Holo) - 019/064'
);

// Disney Lorcana: no set in the title; Foil after the card name; version uses ":".
seoStub.finish = 'Foil';
seoStub.name = "If I Didn't Have You";
seoStub.set = 'Disney Lorcana Promo Cards';
sandbox.state.selected = {
  game: 'disney-lorcana',
  name: "If I Didn't Have You",
  cardNumber: '14/P4',
  setName: 'Disney Lorcana Promo Cards'
};
sandbox.state.autofill.plan = { setTag: 'Disney Lorcana Promo Cards' };
check(
  'Lorcana promo product title',
  buildTitle(),
  "If I Didn't Have You (Foil) - 14/P4"
);

seoStub.name = 'Abu - Bold Henchman';
sandbox.state.selected = {
  game: 'disney-lorcana',
  name: 'Abu - Bold Henchman',
  cardNumber: '114/204',
  setName: 'Azurite Sea'
};
check(
  'Lorcana character foil title',
  buildTitle(),
  'Abu (Foil) : Bold Henchman - 114/204'
);
seoStub.finish = 'Standard';
seoStub.name = 'Abu - Bold Henchman';
check(
  'Lorcana character non-foil title',
  buildTitle(),
  'Abu : Bold Henchman - 114/204'
);

// Japanese Pokémon uses the store's Japanese era tags.
check(
  'Japanese Pokémon tags',
  buildAutofillPlan({ game: 'pokemon-japan', languageCode: 'ja', setName: 'Terastal Festival ex' }).tags.sort(),
  ['Japanese', 'Japanese Scarlet & Violet', 'Single Cards', 'Terastal Festival']
);

// Magic: MTG product type, no era, no rarity, no Japanese tag on an English card.
const mtg = buildAutofillPlan({
  game: 'magic-the-gathering', languageCode: 'en', setName: 'Adventures in the Forgotten Realms', rarity: 'Rare'
});
check('MTG tags', mtg.tags.sort(), ['Adventures in the Forgotten Realms', 'Magic the Gathering', 'Single Cards']);
check('MTG product type', mtg.productType, 'MTG');

check(
  'Lorcana tags',
  buildAutofillPlan({ game: 'disney-lorcana', languageCode: 'en', setName: 'The First Chapter' }).tags.sort(),
  ['Disney Lorcana', 'Single Cards', 'The First Chapter']
);

seoStub.finish = 'Foil';
check(
  'Lorcana Foil tag',
  buildAutofillPlan({
    game: 'disney-lorcana',
    languageCode: 'en',
    setName: 'Disney Lorcana Promo Cards',
    name: "If I Didn't Have You"
  }).tags.sort(),
  ['Disney Lorcana', 'Disney Lorcana Promo Cards', 'Foil', 'Single Cards']
);
seoStub.finish = 'Standard';
check(
  'Lorcana Foil from catalogue name',
  buildAutofillPlan({
    game: 'disney-lorcana',
    languageCode: 'en',
    setName: 'The First Chapter',
    name: 'Elsa - Ice Maker (Foil)'
  }).tags.sort(),
  ['Disney Lorcana', 'Foil', 'Single Cards', 'The First Chapter']
);
seoStub.finish = 'Standard';

check(
  'Lorcana Foil collections exclude Foil tag',
  buildAutofillPlan({
    game: 'disney-lorcana',
    languageCode: 'en',
    setName: 'The First Chapter',
    name: 'Elsa - Ice Maker (Foil)'
  }).collections.sort(),
  ['Disney Lorcana', 'The First Chapter']
);

const onePiece = buildAutofillPlan({
  game: 'one-piece-card-game', languageCode: 'en', setName: 'The Time of Battle', setCode: 'OP16'
});
check(
  'One Piece tags',
  onePiece.tags.sort(),
  ['English', 'OP16', 'One Piece Card Game', 'Single Cards', 'The Time of Battle']
);
check('One Piece product type', onePiece.productType, 'One Piece');

// --- SEO ---------------------------------------------------------------
const { buildSeoTitle, buildSeoDescription } = sandbox.module.exports;

function seoFor(card, { finish = 'Standard', nearMint = null, setTag = '' } = {}) {
  seoStub.finish = finish;
  seoStub.nearMint = nearMint;
  seoStub.name = card.name;
  sandbox.state.autofill.plan = setTag ? { setTag } : null;
  return { title: buildSeoTitle(card), description: buildSeoDescription(card) };
}

// The house format, reproduced from a live product on the store.
const lampent = seoFor(
  { game: 'pokemon', name: 'Lampent', setName: 'Pitch Black', cardNumber: '037/084' },
  { finish: 'Reverse Holo', nearMint: 0.65, setTag: 'Pitch Black' }
);
check('SEO title', lampent.title, 'Lampent 037/084 Pitch Black Reverse Holo | £0.65 In Stock UK');
check(
  'SEO description',
  lampent.description,
  'Buy Lampent Reverse Holo (037/084) from Pitch Black, a single Pokémon card in mint or near-mint condition. Securely packed, fast UK delivery.'
);

// Over-long names drop trailing detail rather than being cut mid-word.
const longCard = seoFor(
  {
    game: 'magic-the-gathering',
    name: 'Faerie // Goblin Double-Sided Token',
    setName: 'Lorwyn Eclipsed',
    cardNumber: '5 // 6'
  },
  { nearMint: 1.69, setTag: 'Lorwyn Eclipsed' }
);
check('long SEO title fits', longCard.title.length <= 70, true);
check('long SEO title', longCard.title, 'Faerie // Goblin Double-Sided Token 5 // 6 | £1.69 In Stock UK');
check('long SEO description fits', longCard.description.length <= 160, true);

// No price yet: the suffix still reads correctly.
const unpriced = seoFor(
  { game: 'pokemon', name: 'Magikarp', setName: 'Base Set 2', cardNumber: '35/130' },
  { setTag: 'Base Set 2' }
);
check('unpriced SEO title', unpriced.title, 'Magikarp 35/130 Base Set 2 | In Stock UK');

if (failures.length) {
  failures.forEach(failure => process.stderr.write(`Autofill assertion failed: ${failure}\n`));
  process.exit(1);
}
process.stdout.write('Autofill tag tests passed.\n');
