<?php
declare(strict_types=1);

require_once __DIR__ . '/lib/bootstrap.php';

$loginError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string) ($_POST['action'] ?? '');
    $token = (string) ($_POST['csrf'] ?? '');
    if (!hash_equals(app_csrf_token(), $token)) {
        $loginError = 'This form expired. Refresh and try again.';
    } elseif ($action === 'logout') {
        app_logout();
        header('Location: ./');
        exit;
    } elseif ($action === 'login') {
        $lockedFor = app_login_lockout_remaining();
        if ($lockedFor > 0) {
            $loginError = sprintf(
                'Too many failed attempts. Try again in %d minute%s.',
                (int) ceil($lockedFor / 60),
                $lockedFor > 60 ? 's' : ''
            );
        } elseif (app_attempt_login((string) ($_POST['password'] ?? ''))) {
            header('Location: ./');
            exit;
        } else {
            $loginError = app_login_lockout_remaining() > 0
                ? 'Too many failed attempts. This address is locked out for 15 minutes.'
                : 'That staff password is not correct.';
        }
    }
}

$configured = app_is_configured();
$authenticated = app_is_authenticated();
$csrf = app_csrf_token();
$v = '6.0.0';
require __DIR__ . '/lib/ui.php';
?>
<!doctype html>
<html lang="en-GB">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="theme-color" content="#16121c">
  <meta name="csrf-token" content="<?= htmlspecialchars($csrf, ENT_QUOTES) ?>">
  <meta name="robots" content="noindex,nofollow">
  <title>Intake · Lockett Labs</title>
  <link rel="manifest" href="manifest.webmanifest">
  <link rel="icon" href="assets/icon.svg" type="image/svg+xml">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Anton&family=Inter:wght@400;500;600;700;800&display=swap">
  <link rel="stylesheet" href="assets/app.css?v=<?= $v ?>">
</head>
<body class="ll">
<?php if (!$configured): ?>
  <main class="auth-shell">
    <section class="auth-card">
      <?= ui_brand_mark('auth-mark') ?>
      <p class="kicker">Secure setup</p>
      <h1 class="display">Connect the Lab</h1>
      <p class="lede">Copy <code>config.example.php</code> to <code>config.php</code>, then add the permanent Shopify domain, a Shopify Admin API token, your JustTCG API key and a staff password hash.</p>
      <p class="alert warning">Never upload a configuration file containing a token that has already been shared elsewhere. Rotate exposed credentials first.</p>
    </section>
  </main>
<?php elseif (!$authenticated): ?>
  <main class="auth-shell">
    <section class="auth-card">
      <?= ui_brand_mark('auth-mark') ?>
      <p class="kicker">Staff access</p>
      <h1 class="display">Card intake</h1>
      <p class="lede">Find the card, scan it, price it against the UK, and list it the way the store lists everything else.</p>
      <?php if ($loginError !== ''): ?><p class="alert error" role="alert"><?= htmlspecialchars($loginError) ?></p><?php endif; ?>
      <form method="post" class="auth-form">
        <input type="hidden" name="action" value="login">
        <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES) ?>">
        <label for="password">Staff password</label>
        <input id="password" name="password" type="password" autocomplete="current-password" required autofocus>
        <button class="button primary full" type="submit">Sign in</button>
      </form>
      <?php if (!app_password_is_hashed()): ?>
        <p class="alert warning">This password is stored in <code>config.php</code> as plain text, so anyone who can read that file has it. Sign in, open <strong>Tools</strong> and use <strong>Staff password hash</strong> to generate a replacement. Signing in does not change.</p>
      <?php endif; ?>
      <p class="security-note">Shopify and catalogue credentials stay on the server.</p>
    </section>
  </main>
<?php else: ?>
  <?= ui_topbar('intake', $csrf) ?>

  <main class="app-shell">
    <section class="workbar" aria-label="Workflow">
      <div class="mode-switch" role="radiogroup" aria-label="What are you listing?">
        <button id="mode-single" class="mode-option" type="button" role="radio" aria-checked="true" data-mode="single">Singles</button>
        <button id="mode-sealed" class="mode-option" type="button" role="radio" aria-checked="false" data-mode="sealed">Sealed</button>
      </div>
      <ol class="progress" aria-label="Progress">
        <li class="progress-step active" data-progress="1"><?= ui_nut() ?><b>Find</b></li>
        <li class="progress-step" data-progress="2"><?= ui_nut() ?><b>Choose</b></li>
        <li class="progress-step" data-progress="3"><?= ui_nut() ?><b>Scan &amp; price</b></li>
        <li class="progress-step" data-progress="4"><?= ui_nut() ?><b>Publish</b></li>
      </ol>
      <div class="workbar-right">
        <div class="workbar-keys" aria-label="Keyboard shortcuts">
          <span><kbd>/</kbd> search</span>
          <span><kbd>S</kbd> scan</span>
          <span><kbd>N</kbd> next</span>
          <span><kbd>Esc</kbd> start over</span>
        </div>
        <div class="intake-tally" data-open="false">
          <button id="intake-tally-button" class="intake-tally-button" type="button" aria-expanded="false" aria-controls="intake-recent">
            <?= ui_nut('intake-tally-nut') ?>
            <span id="intake-tally-text">Today 0 cards</span>
            <svg class="intake-tally-caret" viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>
          </button>
          <div id="intake-recent" class="intake-recent" role="region" aria-label="Recent intake" hidden>
            <div class="intake-recent-head">
              <strong>Booked in today</strong>
              <button id="intake-recent-refresh" class="text-button" type="button">Refresh</button>
            </div>
            <ul id="intake-recent-list" class="intake-recent-list"></ul>
            <p class="intake-recent-note">Written as each listing is submitted, so it survives the screen resetting for the next one.</p>
          </div>
        </div>
      </div>
    </section>

    <div id="app-message" class="message" role="status" hidden></div>
    <div id="setup-warnings" class="message warning" hidden></div>

    <section class="workspace">
      <div class="column intake-column">
        <article class="panel scan-panel">
          <header class="panel-head">
            <div>
              <p class="kicker" id="search-kicker">Find the card</p>
              <h2 class="panel-title" id="search-title">Search the catalogue</h2>
            </div>
            <div class="heading-actions">
              <button id="next-card-button" class="button secondary small" type="button" hidden>Next card</button>
              <button id="reset-button" class="text-button" type="button">Start over</button>
            </div>
          </header>

          <div class="game-controls">
            <div class="field">
              <label for="game">Game</label>
              <select id="game" required>
                <option value="">Loading games…</option>
              </select>
            </div>
            <div class="field">
              <label for="card-language">Printed language</label>
              <select id="card-language">
                <option value="en">English</option>
                <option value="ja">Japanese · 日本語</option>
              </select>
            </div>
          </div>

          <form id="search-form" class="smart-search" autocomplete="off">
            <div class="field span-two">
              <label for="search-query" id="search-query-label">Card name</label>
              <input id="search-query" type="search" placeholder="e.g. Okidogi ex" autocomplete="off" enterkeyhint="search">
            </div>
            <div class="field">
              <label for="search-set">Set</label>
              <input id="search-set" type="search" list="set-suggestions" placeholder="Choose or type a set" autocomplete="off">
              <datalist id="set-suggestions"></datalist>
            </div>
            <div class="field" id="search-number-field">
              <label for="search-number">Printed number</label>
              <input id="search-number" type="search" placeholder="e.g. 25/111 or OP16-065" autocomplete="off" inputmode="text" enterkeyhint="search">
            </div>
            <button class="button primary span-two" type="submit" id="search-submit">
              <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>
              <span>Search</span>
            </button>
            <p id="number-search-guidance" class="strict-search-note span-two">Number searches are strict: a search for 26/86 never shows 26/84 or 126/86.</p>
          </form>
        </article>

        <article class="panel results-panel" id="results-panel" hidden>
          <header class="panel-head">
            <div><p class="kicker">Choose the printing</p><h2 class="panel-title">Results</h2></div>
            <span id="result-count" class="count-badge"></span>
          </header>
          <div id="results" class="results-list"></div>
        </article>

        <article class="panel tray-panel" id="tray-panel" hidden>
          <header class="panel-head">
            <div><p class="kicker">Scan tray</p><h2 class="panel-title">Scanned, waiting for a card</h2></div>
            <button id="tray-clear" class="text-button" type="button">Clear</button>
          </header>
          <p class="section-note">Cards from a flatbed sheet wait here. Find the next card, then tap its scan to attach it.</p>
          <div id="tray-list" class="tray-list"></div>
        </article>
      </div>

      <div class="column editor-column">
        <article class="panel editor-panel" id="editor-panel">
          <header class="panel-head">
            <div><p class="kicker">Shopify listing</p><h2 class="panel-title">Listing</h2></div>
            <span id="editor-state" class="state-badge">Waiting for a card</span>
          </header>

          <div id="empty-editor" class="empty-state">
            <?= ui_brand_mark('empty-mark') ?>
            <h3>Find a card to start</h3>
            <p>Search by printed number with the set filled in, or by name. The listing builds itself in the store's format: title, tags, set links, description and search listing.</p>
            <ol class="empty-steps">
              <li><b>Find</b> the exact printing.</li>
              <li><b>Scan</b> the card in hand, so the photo shows the real finish.</li>
              <li><b>Price</b> against Total Cards, Chaos Cards and Magic Madhouse.</li>
              <li><b>Publish</b>, then the next card is ready.</li>
            </ol>
          </div>

          <form id="product-form" hidden>
            <section class="card-hero">
              <figure class="image-panel" id="image-panel">
                <div class="image-stage" id="image-stage">
                  <img id="selected-image" alt="Selected card" decoding="async">
                  <span id="image-badge" class="image-badge" hidden></span>
                  <div class="image-drop" aria-hidden="true"><span>Drop the scan here</span></div>
                </div>
                <figcaption class="image-caption">
                  <div id="image-quality" class="scan-chips" aria-live="polite"></div>
                  <p id="image-note" class="image-note"></p>
                </figcaption>
                <div class="image-actions">
                  <button id="scan-camera" class="button primary small" type="button">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg>
                    <span>Scan card</span>
                  </button>
                  <label class="button secondary small file-button" for="scan-file">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 16V4m0 0-4 4m4-4 4 4M4 20h16"/></svg>
                    <span>Upload scan</span>
                  </label>
                  <input id="scan-file" type="file" accept="image/*" capture="environment" hidden>
                  <button id="scan-url-toggle" class="text-button" type="button" aria-expanded="false" aria-controls="scan-url-form">From a web address</button>
                </div>
                <div id="scan-url-form" class="scan-url" hidden>
                  <label for="scan-url">Image address</label>
                  <div class="inline-field">
                    <input id="scan-url" type="url" inputmode="url" placeholder="https://… right-click the image, copy image address">
                    <button id="scan-url-go" class="button secondary small" type="button">Fetch</button>
                  </div>
                </div>
                <div id="image-candidates" class="image-candidates" aria-label="Other pictures of this card"></div>
              </figure>

              <div class="identity">
                <p id="selected-game" class="kicker"></p>
                <strong id="selected-name" class="identity-name"></strong>
                <span id="selected-meta" class="identity-meta"></span>
                <dl id="identity-facts" class="identity-facts"></dl>
                <div class="external-links">
                  <a id="selected-source" target="_blank" rel="noopener noreferrer">Catalogue record</a>
                  <a id="ebay-live" target="_blank" rel="noopener noreferrer">eBay UK live</a>
                  <a id="ebay-sold" target="_blank" rel="noopener noreferrer">eBay UK sold</a>
                  <a id="totalcards-link" target="_blank" rel="noopener noreferrer" hidden>Total Cards</a>
                </div>
                <p id="autofill-summary" class="autofill-summary" hidden></p>
              </div>
            </section>

            <div id="stock-check" class="stock-check" hidden>
              <span class="stock-check-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 7h16v13H4zM8 7V4h8v3M8 12h8"/></svg></span>
              <div>
                <div class="stock-copy" role="status" aria-live="polite"><strong id="stock-title"></strong><span id="stock-detail"></span></div>
                <article id="shopify-product-preview" class="shopify-product-preview" hidden>
                  <div class="shopify-preview-media"><img id="shopify-preview-image" alt=""></div>
                  <div class="shopify-preview-copy">
                    <span class="shopify-preview-label">Already in Shopify</span>
                    <strong id="shopify-preview-title"></strong>
                    <span id="shopify-preview-meta"></span>
                    <div id="shopify-preview-variants" class="shopify-preview-variants"></div>
                    <a id="shopify-preview-store-link" class="text-button" target="_blank" rel="noopener noreferrer" hidden>View on the store</a>
                  </div>
                </article>
                <div id="stock-candidate-actions" class="stock-candidate-actions" hidden>
                  <div id="stock-candidate-selector">
                    <label for="stock-candidate">Possible existing products</label>
                    <select id="stock-candidate"></select>
                  </div>
                  <div class="stock-candidate-buttons">
                    <button id="confirm-stock-candidate" class="button secondary small" type="button">Confirm and restock this product</button>
                    <a id="stock-candidate-link" class="text-button" target="_blank" rel="noopener noreferrer" hidden>Open in Shopify</a>
                    <button id="reject-stock-candidates" class="text-button" type="button">This is not the same product</button>
                  </div>
                </div>
                <label id="attach-scan-row" class="toggle-row" hidden>
                  <input id="attach-scan-existing" type="checkbox" checked>
                  <span>Add this scan to the listing as its first picture</span>
                </label>
              </div>
            </div>

            <section class="form-section price-section">
              <div class="subheading"><div><span class="kicker">Price</span><h3>UK market</h3></div><span id="compare-checked" class="pill" hidden></span></div>
              <div id="market-summary" class="market-summary" hidden></div>
              <div class="market-actions">
                <button id="apply-competitor-nm" class="button secondary small" type="button" hidden>Apply suggested price</button>
                <button id="apply-market-prices" class="button secondary small" type="button" hidden>Re-apply market prices</button>
              </div>
            </section>

            <fieldset class="variants-fieldset">
              <legend><span class="kicker" id="variants-kicker">Stock</span><span class="legend-title" id="variants-title">Conditions held</span></legend>
              <p id="variants-help">Tick each condition you hold. Quantity is added to Shopify stock, never used as a replacement total.</p>
              <div id="variants" class="variant-list"></div>
            </fieldset>

            <section id="translation-panel" class="form-section translation-section" data-listing-options hidden>
              <div class="subheading"><div><span class="kicker">Translation</span><h3>English storefront naming</h3></div></div>
              <div class="field-grid">
                <div class="field"><label for="english-card-name">English card name</label><input id="english-card-name" maxlength="220"></div>
                <div class="field"><label for="english-set-name">English set name</label><input id="english-set-name" maxlength="220"></div>
              </div>
              <p class="field-help">Japanese source text stays in the metafields; these English values build the title customers see.</p>
            </section>

            <section class="form-section" data-listing-options>
              <div class="subheading"><div><span class="kicker">Storefront</span><h3>Title and finish</h3></div><button id="rebuild-title" class="text-button" type="button">Rebuild title</button></div>
              <div class="field-grid">
                <div class="field span-two"><label for="product-title">Product title <small id="title-rule"></small></label><input id="product-title" maxlength="255" required spellcheck="false"></div>
                <div class="field" id="finish-field"><label for="finish">Finish</label><select id="finish"></select></div>
                <div class="field"><label for="product-status">Shopify status</label><select id="product-status"><option value="DRAFT">Draft, review first</option><option value="ACTIVE">Active, publish now</option></select></div>
              </div>
              <div class="serp" aria-label="How the listing reads in Google">
                <p class="serp-label">In Google</p>
                <p id="serp-url" class="serp-url">lockett-labs.com › products</p>
                <p id="serp-title" class="serp-title"></p>
                <p id="serp-desc" class="serp-desc"></p>
              </div>
              <div id="listing-strength" class="strength" aria-live="polite">
                <div class="strength-head"><strong>Listing strength</strong><span id="strength-score" class="strength-score">0</span></div>
                <div class="strength-bar" aria-hidden="true"><span id="strength-fill"></span></div>
                <ul id="strength-list" class="strength-list"></ul>
              </div>
            </section>

            <section class="form-section intake-inventory" data-listing-options>
              <div class="subheading"><div><span class="kicker">Fast path</span><h3>Location</h3></div></div>
              <div class="field-grid">
                <div class="field"><label for="location">Inventory location</label><select id="location" required></select></div>
                <div class="field"><label for="vendor">Vendor</label><select id="vendor" required></select></div>
                <div class="field"><label for="product-type">Product type</label><select id="product-type" required></select></div>
                <div class="field"><label for="product-category">Shopify category</label><select id="product-category"></select></div>
              </div>
            </section>

            <details id="advanced-listing-details" class="advanced-listing" data-listing-options>
              <summary>
                <?= ui_nut('summary-nut') ?>
                <div><span class="kicker">Built for you, open to edit</span><h3>Description, search listing, tags and channels</h3></div>
              </summary>

              <section class="form-section">
                <div class="subheading"><div><span class="kicker">Product page</span><h3>Description</h3></div><button id="rebuild-description" class="text-button" type="button">Rebuild description</button></div>
                <div id="description-preview" class="description-preview" aria-label="Description as customers see it"></div>
                <details class="html-edit">
                  <summary>Edit the HTML</summary>
                  <textarea id="description" rows="10" spellcheck="false"></textarea>
                </details>
                <p class="field-help">Facts come from the card database (illustrator, HP, attacks, release date) and nothing is guessed. Links point back to the set and era, which gives every card page a route into the catalogue.</p>
              </section>

              <section class="form-section">
                <div class="subheading"><div><span class="kicker">Search engine listing</span><h3>SEO title and description</h3></div><button id="rebuild-seo" class="text-button" type="button">Rebuild SEO</button></div>
                <div class="field-grid">
                  <div class="field span-two">
                    <label for="seo-title">SEO title <small><span id="seo-title-count">0</span>/70</small></label>
                    <input id="seo-title" maxlength="70" autocomplete="off">
                  </div>
                  <div class="field span-two">
                    <label for="seo-description">SEO description <small><span id="seo-description-count">0</span>/160</small></label>
                    <textarea id="seo-description" rows="3" maxlength="160"></textarea>
                  </div>
                  <div class="field span-two">
                    <label for="image-alt">Image alt text</label>
                    <input id="image-alt" maxlength="500" autocomplete="off">
                  </div>
                </div>
              </section>

              <section class="form-section">
                <div class="subheading"><div><span class="kicker">Organisation</span><h3>Tags and collections</h3></div></div>
                <div class="field-grid">
                  <div class="field span-two">
                    <label for="tag-search">Tags <small>search the store's tags, or add one</small></label>
                    <div class="picker" data-picker="tags">
                      <div id="tag-chips" class="picker-chips" aria-live="polite"></div>
                      <div class="picker-search-wrap">
                        <input id="tag-search" type="search" placeholder="Type to find a tag…" autocomplete="off" spellcheck="false">
                        <div id="tag-suggestions" class="picker-suggestions" role="listbox" hidden></div>
                      </div>
                    </div>
                    <select id="tags" multiple hidden tabindex="-1" aria-hidden="true"></select>
                  </div>
                  <div class="field span-two">
                    <label for="collection-search">Collections <small>manual collections only; set, era and game collections fill from tags</small></label>
                    <div class="picker" data-picker="collections">
                      <div id="collection-chips" class="picker-chips" aria-live="polite"></div>
                      <div class="picker-search-wrap">
                        <input id="collection-search" type="search" placeholder="Type to find a collection…" autocomplete="off" spellcheck="false">
                        <div id="collection-suggestions" class="picker-suggestions" role="listbox" hidden></div>
                      </div>
                    </div>
                    <select id="collections" multiple hidden tabindex="-1" aria-hidden="true"></select>
                  </div>
                </div>
              </section>

              <section class="form-section taxonomy-section">
                <div class="subheading"><div><span class="kicker">Shopify taxonomy</span><h3>Category attributes</h3></div><span id="taxonomy-state" class="pill">Loading…</span></div>
                <div id="taxonomy-fields" class="taxonomy-grid">
                  <div class="taxonomy-field" data-key="color-pattern" data-alias="colorPattern"><label>Colour</label><select multiple size="3"></select><input placeholder="Manual value"></div>
                  <div class="taxonomy-field" data-key="toy-game-material" data-alias="toyGameMaterial"><label>Toy/Game material</label><select multiple size="3"></select><input value="Cardboard" placeholder="Cardboard"></div>
                  <div class="taxonomy-field" data-key="card-attributes" data-alias="cardAttributes"><label>Card attributes</label><select multiple size="3"></select><input placeholder="e.g. Holo"></div>
                  <div class="taxonomy-field" data-key="condition" data-alias="condition"><label>Condition</label><select multiple size="3"></select><input value="Near Mint" placeholder="Near Mint"></div>
                  <div class="taxonomy-field" data-key="grading" data-alias="grading"><label>Grading</label><select multiple size="3"></select><input value="Ungraded" placeholder="Ungraded"></div>
                  <div class="taxonomy-field" data-key="product-use" data-alias="productUse"><label>Product use</label><select multiple size="3"></select><input placeholder="e.g. Collecting"></div>
                  <div class="taxonomy-field" data-key="rarity" data-alias="rarity"><label>Rarity</label><select multiple size="3"></select><input placeholder="Rarity from database"></div>
                  <div class="taxonomy-field" data-key="age-group" data-alias="ageGroup"><label>Recommended age group</label><select multiple size="3"></select><input placeholder="e.g. All ages"></div>
                  <div class="taxonomy-field" data-key="theme" data-alias="theme"><label>Theme</label><select multiple size="3"></select><input placeholder="e.g. Anime"></div>
                  <div class="taxonomy-field" data-key="trading-card-packaging" data-alias="tradingCardPackaging"><label>Trading card packaging</label><select multiple size="3"></select><input value="Single card" placeholder="Single card"></div>
                </div>
              </section>

              <section class="form-section">
                <div class="subheading"><div><span class="kicker">Publishing</span><h3>Sales channels</h3></div><button id="select-all-publications" class="text-button" type="button">Select all</button></div>
                <select id="publications" multiple size="8" aria-label="Sales channels"></select>
                <p class="field-help">Active products publish to every selected channel. Drafts stay unpublished until activated.</p>
              </section>
            </details>

            <div class="submit-row">
              <label class="confirm-row"><input id="confirmed-match" type="checkbox" required><span id="confirm-text">I checked the card, set, number, language and finish.</span></label>
              <button id="create-button" class="button primary full" type="submit">Create Shopify draft</button>
              <p class="submit-note">The set, game and location stay ready for the next card.</p>
            </div>
          </form>
        </article>
      </div>
    </section>
  </main>

  <template id="variant-template">
    <div class="variant-row">
      <label class="variant-enable"><input class="variant-checkbox" type="checkbox"><span class="condition-name"></span></label>
      <label class="price-field"><span>Price £</span><input class="variant-price" type="number" min="0" step="0.01" inputmode="decimal" value="0.00" disabled></label>
      <label class="quantity-field"><span>Qty</span><input class="variant-quantity" type="number" min="0" step="1" inputmode="numeric" value="1" disabled></label>
      <label class="sku-field"><span>SKU</span><input class="variant-sku" maxlength="100" disabled spellcheck="false"></label>
      <span class="variant-stock">Stock not checked yet</span>
    </div>
  </template>

  <script src="assets/ll-catalogue.js?v=<?= $v ?>" defer></script>
  <script src="assets/ll-scan-station.js?v=<?= $v ?>" defer></script>
  <script src="assets/app.js?v=<?= $v ?>" defer></script>
<?php endif; ?>
</body>
</html>
