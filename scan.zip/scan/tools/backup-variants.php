<?php
declare(strict_types=1);

/**
 * Nightly variant snapshot, and a health check for collapsed products.
 *
 * On 28 July 2026 a productSet call collapsed every multi-variant product in
 * the catalogue to a single variant. Shopify has no variant undo, so recovering
 * 60 products took a day of archaeology across the Wayback Machine, order
 * history and published set line-ups — and inventory quantities were gone for
 * good, because nothing anywhere had recorded them.
 *
 * This exists so that never happens twice. It writes a full snapshot of every
 * product's variants, prices, SKUs and quantities, so the next bad write is a
 * restore from file rather than guesswork.
 *
 * The same job is available in the browser at backfill.php; both share
 * lib/variant-backup.php so they cannot drift.
 *
 *   php tools/backup-variants.php              snapshot to cache/variant-backups
 *   php tools/backup-variants.php --check      report collapsed products, no write
 *   php tools/backup-variants.php --keep=30    prune snapshots older than N days
 *
 * Cron (nightly, IONOS):
 *   0 3 * * * /usr/bin/php /path/to/tools/backup-variants.php --keep=30
 *
 * Exit codes: 0 clean, 2 collapsed products found, 1 the run itself failed.
 */

require_once __DIR__ . '/../lib/variant-backup.php';

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Command line only. Use backfill.php in the browser instead.\n");
    exit(1);
}

const BACKUP_POLL_SECONDS = 5;
const BACKUP_MAX_WAIT_SECONDS = 900;

$options = getopt('', ['check', 'keep:']);
$checkOnly = array_key_exists('check', $options);
$keepDays = isset($options['keep']) ? max(1, (int) $options['keep']) : 0;

/** Start the catalogue export and block until Shopify finishes it. */
function backup_wait_for_export(): string
{
    variant_backup_start();
    $waited = 0;
    while ($waited < BACKUP_MAX_WAIT_SECONDS) {
        sleep(BACKUP_POLL_SECONDS);
        $waited += BACKUP_POLL_SECONDS;
        $state = variant_backup_poll();
        if ($state['status'] === 'COMPLETED') {
            if ($state['url'] === '') {
                throw new RuntimeException('Export completed but returned no file.');
            }
            return $state['url'];
        }
    }
    throw new RuntimeException('Export did not finish within ' . BACKUP_MAX_WAIT_SECONDS . ' seconds.');
}

try {
    fwrite(STDERR, "Exporting catalogue…\n");
    $result = variant_backup_collect(backup_wait_for_export());
} catch (Throwable $error) {
    fwrite(STDERR, 'Failed: ' . $error->getMessage() . PHP_EOL);
    exit(1);
}

$collapsed = $result['collapsed'];
printf("Products %d, variants %d, collapsed %d\n", $result['products'], $result['variants'], count($collapsed));

if ($collapsed !== []) {
    echo "\nCOLLAPSED — a named option but only one variant left:\n";
    foreach ($collapsed as $row) {
        printf(
            "  %-46s option \"%s\" = %s\n",
            substr($row['title'], 0, 46),
            $row['option'] === '' ? '?' : $row['option'],
            $row['survivor'] === '' ? '?' : $row['survivor']
        );
    }
    echo "\nCheck these against the most recent snapshot before doing anything else.\n";
}

$oversell = $result['oversellable'];
if ($oversell !== []) {
    printf("\nADDABLE AT ZERO — %d variant%s can be added to cart while out of stock:\n", count($oversell), count($oversell) === 1 ? '' : 's');
    foreach (array_slice($oversell, 0, 60) as $row) {
        printf(
            "  %-44s %-22s %s%s  qty %d\n",
            substr($row['title'], 0, 44),
            substr($row['variant'], 0, 22),
            $row['policy'],
            $row['tracked'] ? '' : ' UNTRACKED',
            $row['quantity']
        );
    }
    if (count($oversell) > 60) printf("  ...and %d more\n", count($oversell) - 60);
    echo "\nHiding the Add to basket button does not stop these: the storefront cart\n";
    echo "endpoint is public. Set inventory to Tracked and the policy to DENY.\n";
}

if ($checkOnly) {
    exit(($collapsed === [] && $oversell === []) ? 0 : 2);
}

try {
    $path = variant_backup_write($result['payload'], $keepDays);
} catch (Throwable $error) {
    fwrite(STDERR, 'Failed: ' . $error->getMessage() . PHP_EOL);
    exit(1);
}
printf("Snapshot written: %s (%.1f MB)\n", $path, (int) @filesize($path) / 1048576);

exit(($collapsed === [] && $oversell === []) ? 0 : 2);
