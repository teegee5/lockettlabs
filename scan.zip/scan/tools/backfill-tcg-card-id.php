<?php
declare(strict_types=1);

/**
 * Command line card-id backfill. The browser runner at backfill.php does the
 * same job with the same lib/backfill.php logic; this exists for bulk runs
 * over SSH where a long-lived shell is easier than a browser tab.
 *
 * Dry run (prints what it would write, changes nothing):
 *   php tools/backfill-tcg-card-id.php --tag="Pitch Black"
 *
 * Write:
 *   php tools/backfill-tcg-card-id.php --tag="Pitch Black" --apply
 *
 * Options:
 *   --tag=NAME     Set tag to process. Required.
 *   --apply        Actually write. Without it nothing is sent to Shopify.
 *   --force        Overwrite products that already have an id.
 *   --limit=N      Stop after N products.
 *   --language=ja  Use the Japanese TCGdex catalogue.
 */

require_once __DIR__ . '/../lib/backfill.php';

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "This script is command line only. Use backfill.php in the browser instead.\n");
    exit(1);
}

$options = getopt('', ['tag:', 'apply', 'force', 'limit:', 'language:']);
$setTag = trim((string) ($options['tag'] ?? ''));
$apply = array_key_exists('apply', $options);
$force = array_key_exists('force', $options);
$limit = isset($options['limit']) ? max(1, (int) $options['limit']) : 0;
$language = ($options['language'] ?? '') === 'ja' ? 'ja' : 'en';

if ($setTag === '') {
    fwrite(STDERR, "Usage: php tools/backfill-tcg-card-id.php --tag=\"Pitch Black\" [--apply] [--force] [--limit=N] [--language=ja]\n");
    exit(1);
}

$resolved = [];
$skipped = [];
$unresolved = [];
$cursor = null;
$seen = 0;

do {
    $page = backfill_fetch_page($setTag, $cursor);
    $nodes = $page['nodes'];
    if ($limit > 0 && $seen + count($nodes) > $limit) {
        $nodes = array_slice($nodes, 0, $limit - $seen);
    }
    $seen += count($nodes);

    $outcome = backfill_resolve_page($nodes, $setTag, $language, $force);
    $resolved = array_merge($resolved, $outcome['resolved']);
    $skipped = array_merge($skipped, $outcome['skipped']);
    $unresolved = array_merge($unresolved, $outcome['unresolved']);

    $cursor = $page['hasNextPage'] ? $page['cursor'] : null;
} while ($cursor !== null && ($limit === 0 || $seen < $limit));

printf("Set tag        %s\n", $setTag);
printf("Language       %s\n", $language);
printf("Products seen  %d\n", $seen);
printf("Resolved       %d\n", count($resolved));
printf("Already set    %d\n", count($skipped));
printf("Unresolved     %d\n\n", count($unresolved));

foreach ($resolved as $row) {
    printf("  %-58s -> %s%s\n", $row['title'], $row['cardId'], $row['replaces'] !== '' ? ' (was ' . $row['replaces'] . ')' : '');
}
if ($unresolved !== []) {
    echo "\nUnresolved (left unchanged):\n";
    foreach ($unresolved as $row) {
        printf(
            "  %-58s    set %s, number %s\n",
            $row['title'],
            $row['set'] === '' ? '(none found)' : $row['set'],
            $row['number'] === '' ? '(none found)' : $row['number']
        );
    }
}

if (!$apply) {
    echo "\nDry run. Re-run with --apply to write these metafields.\n";
    exit(0);
}
if ($resolved === []) {
    echo "\nNothing to write.\n";
    exit(0);
}

$result = backfill_write($resolved);
printf("\nWrote %d metafield%s.\n", $result['written'], $result['written'] === 1 ? '' : 's');
$errors = $result['errors'];

if ($force) {
    // A forced re-run that cannot re-derive an id means the stored value is
    // untrustworthy. Empty beats wrong: the storefront falls back cleanly.
    $clear = backfill_clear($unresolved);
    if ($clear['cleared'] > 0) {
        printf("Cleared %d stale id%s that no longer resolve.\n", $clear['cleared'], $clear['cleared'] === 1 ? '' : 's');
    }
    $errors = array_merge($errors, $clear['errors']);
}

foreach ($errors as $error) {
    fwrite(STDERR, 'Error: ' . $error . PHP_EOL);
}
exit($errors === [] ? 0 : 1);
