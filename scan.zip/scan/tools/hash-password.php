<?php
declare(strict_types=1);

/**
 * Turn a staff password into a hash to paste into config.php.
 *
 * The password used to be stored in config.php as itself and compared
 * directly, which means anything that can read that file has the password:
 * a backup, an FTP client, a misconfigured directory listing, anyone who has
 * ever been sent a copy of the config. A hash cannot be read back.
 *
 *   php tools/hash-password.php
 *   php tools/hash-password.php "the password"
 *
 * Then replace the value in config.php:
 *
 *   'admin_password' => '$2y$12$...',
 *
 * Staff keep signing in with the same password they use now. Nothing about
 * the login screen changes. The plaintext form still works until you make this
 * change, so there is no window where anyone is locked out.
 */

require_once __DIR__ . '/../lib/bootstrap.php';

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("Command line only.\n");
}

$password = $argv[1] ?? null;

if ($password === null) {
    // Read without echoing where the terminal allows it, so the password does
    // not end up in shell history or on screen.
    echo 'Staff password: ';
    if (stripos(PHP_OS_FAMILY, 'Windows') === false && @shell_exec('command -v stty') !== null) {
        @shell_exec('stty -echo');
        $password = trim((string) fgets(STDIN));
        @shell_exec('stty echo');
        echo "\n";
    } else {
        $password = trim((string) fgets(STDIN));
    }
}

$password = (string) $password;

if (strlen($password) < 12) {
    // This guards one tool used by a whole shop, reachable from the open
    // internet, and there is no second factor behind it.
    fwrite(STDERR, "Refusing: use at least 12 characters.\n");
    exit(1);
}

$hash = password_hash($password, PASSWORD_DEFAULT);
if (!is_string($hash) || $hash === '') {
    fwrite(STDERR, "Could not hash the password on this PHP build.\n");
    exit(1);
}

if (!password_verify($password, $hash)) {
    fwrite(STDERR, "The hash did not verify against the password. Nothing written.\n");
    exit(1);
}

echo "\nPaste this into config.php, replacing the existing admin_password line:\n\n";
echo "    'admin_password' => '" . $hash . "',\n\n";
echo "Then sign in with the same password as before to confirm it works.\n";
