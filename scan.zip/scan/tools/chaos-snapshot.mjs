// Chaos Cards price snapshot.
//
// Why this exists
// ---------------
// Chaos Cards has no route a PHP request can take.
//
//   - the HawkSearch endpoint the app used returns 403 on every header
//     combination; it is gone
//   - the site now proxies search through /acts, which their robots.txt
//     disallows, so that is off limits by their own stated policy
//   - their /prod/ and /shop/ pages ARE permitted by robots.txt, but sit
//     behind a check that fingerprints the TLS handshake, so curl cannot
//     reach them however the headers are set
//   - their CDN serves one static sitemap over plain HTTP, and it carries
//     URLs and images but no prices
//
// What is left is a real browser. This runs one, on a machine someone is
// logged into, and writes a snapshot the PHP side reads. Prices for the whole
// in-stock singles catalogue in one pass, rather than a request per card.
//
// Their robots.txt asks for a 3 second crawl delay. That is honoured.
//
//   node tools/chaos-snapshot.mjs                  # writes cache/chaos/<game>.json
//   node tools/chaos-snapshot.mjs --resume         # keep what is on disk, refresh over it
//   node tools/chaos-snapshot.mjs --sections=mtg   # one game only
//   node tools/chaos-snapshot.mjs --limit=5        # a few pages, to try it out
//
// Run it daily. The PHP side treats anything older than SNAPSHOT_MAX_AGE_HOURS
// as expired and falls back to the deep link rather than quoting a stale price.

import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync, existsSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
// One file per game. The PHP side opens exactly one of these to answer a
// lookup; the single combined file it replaced was 13 MB and 41,841 cards, all
// of it decoded to retrieve one key. Pokemon alone is about 0.7 MB.
const SHARD_DIR = join(HERE, '..', 'cache', 'chaos');
const INDEX_FILE = join(SHARD_DIR, 'index.json');
const shardPath = name => join(SHARD_DIR, name + '.json');
const CRAWL_DELAY_MS = 3000;
const PER_PAGE = 64;

// Ordered by what the section is worth to us, not alphabetically, because a
// run can be cut short and the last section listed is the one that gets lost.
//
// The two numbers that matter are how many singles we hold in each game and
// what that stock is worth, against how many pages Chaos Cards makes us read:
//
//   game        our singles   stock value   their pages
//   pokemon           8,565       £36,156            42
//   lorcana           1,545        £5,507            22
//   mtg                 851        £1,074           456
//   digimon             217          £182            49
//   one-piece            32          £112            26
//   yu-gi-oh              8            £3           175
//
// Magic and Yu-Gi-Oh together are 631 of the 770 pages and cover £1,077 of
// stock. Pokemon is 42 pages and covers £36,156. So Pokemon runs first and
// Yu-Gi-Oh runs last, and the long tails carry their own page budget so one
// of them cannot eat an entire run.
const SECTIONS = [
  { name: 'pokemon', path: '/shop/card-games/pokemon/singles-pokemon' },
  { name: 'lorcana', path: '/shop/card-games/lorcana/disney-lorcana-single-cards' },
  { name: 'digimon', path: '/shop/card-games/digimon/single-cards-digimon' },
  { name: 'one-piece', path: '/shop/card-games/one-piece-card-game/one-piece-card-game-single-cards' },
  { name: 'mtg', path: '/shop/card-games/magic-the-gathering/singles-magic' },
  { name: 'yu-gi-oh', path: '/shop/card-games/yu-gi-oh/singles-yu-gi-oh' },
];

const args = Object.fromEntries(
  process.argv.slice(2).map(a => {
    const [k, v] = a.replace(/^--/, '').split('=');
    return [k, v ?? true];
  })
);
// 456 is Magic's real page count. A cap below that silently truncates the
// section instead of failing, which is how a run can look clean and still be
// missing a third of the catalogue.
const PAGE_CAP = args.limit ? Math.max(1, parseInt(args.limit, 10)) : 500;

// --sections=digimon,one-piece runs part of the catalogue. Useful when a run
// was cut short and only the tail needs picking up.
const ONLY = typeof args.sections === 'string'
  ? new Set(args.sections.split(',').map(x => x.trim()).filter(Boolean))
  : null;
const PLAN = ONLY ? SECTIONS.filter(s => ONLY.has(s.name)) : SECTIONS;
if (ONLY) {
  const unknown = [...ONLY].filter(n => !SECTIONS.some(s => s.name === n));
  if (unknown.length) {
    console.error('Unknown section(s): ' + unknown.join(', '));
    console.error('Known: ' + SECTIONS.map(s => s.name).join(', '));
    process.exit(1);
  }
}

// --resume keeps what is already on disk and writes over the top of it. Every
// entry carries its own seenAt, so a card refreshed today and a card left from
// yesterday are not pretended to be the same age.
const RESUME = args.resume === true || args.resume === 'true';

const runStartedAt = new Date().toISOString();

const sleep = ms => new Promise(r => setTimeout(r, ms));

// ---------------------------------------------------------------- browser ---
const BROWSERS = [
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  '/usr/bin/google-chrome',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
];

class Browser {
  constructor(port = 9335) { this.port = port; this.next = 1; this.pending = new Map(); }

  async launch() {
    const bin = BROWSERS.find(p => existsSync(p));
    if (!bin) throw new Error('No Chrome or Edge found. Install one, or edit BROWSERS.');
    this.profile = mkdtempSync(join(tmpdir(), 'chaos-snap-'));
    // Headless is detected and refused; this needs a real window, which means
    // it has to run on a desktop session rather than a server cron.
    this.proc = spawn(bin, [
      `--remote-debugging-port=${this.port}`,
      `--user-data-dir=${this.profile}`,
      '--no-first-run', '--no-default-browser-check',
      '--disable-background-networking', '--disable-sync', '--disable-extensions',
      '--window-size=1280,900', 'about:blank',
    ], { stdio: 'ignore' });

    let ws = null;
    for (let i = 0; i < 60 && !ws; i++) {
      try {
        const r = await fetch(`http://127.0.0.1:${this.port}/json/version`);
        if (r.ok) ws = (await r.json()).webSocketDebuggerUrl;
      } catch { /* not up yet */ }
      if (!ws) await sleep(250);
    }
    if (!ws) throw new Error('Chrome did not expose a debugging port.');

    this.ws = new WebSocket(ws);
    this.ws.addEventListener('message', ev => {
      const m = JSON.parse(ev.data);
      const p = m.id && this.pending.get(m.id);
      if (!p) return;
      this.pending.delete(m.id);
      m.error ? p.reject(new Error(m.error.message)) : p.resolve(m.result);
    });
    await new Promise((res, rej) => {
      this.ws.addEventListener('open', res, { once: true });
      this.ws.addEventListener('error', () => rej(new Error('CDP socket failed')), { once: true });
    });

    const { targetId } = await this.send('Target.createTarget', { url: 'about:blank' });
    const { sessionId } = await this.send('Target.attachToTarget', { targetId, flatten: true });
    this.session = sessionId;
    await this.send('Page.enable', {}, sessionId);
    await this.send('Runtime.enable', {}, sessionId);
  }

  send(method, params = {}, sessionId) {
    const id = this.next++;
    const msg = { id, method, params };
    if (sessionId) msg.sessionId = sessionId;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify(msg));
      setTimeout(() => {
        if (this.pending.delete(id)) reject(new Error(`timeout: ${method}`));
      }, 45000);
    });
  }

  async evaluate(expression) {
    const r = await this.send('Runtime.evaluate',
      { expression, returnByValue: true, awaitPromise: true }, this.session);
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.text || 'evaluate threw');
    return r.result.value;
  }

  async goto(url, readyExpr, timeoutMs = 40000) {
    await this.send('Page.navigate', { url }, this.session);
    const until = Date.now() + timeoutMs;
    while (Date.now() < until) {
      await sleep(400);
      try { if (await this.evaluate(readyExpr)) return true; } catch { /* mid-nav */ }
    }
    return false;
  }

  async close() {
    try { this.ws?.close(); } catch {}
    try { this.proc?.kill(); } catch {}
    await sleep(300);
    try { rmSync(this.profile, { recursive: true, force: true }); } catch {}
  }
}

// ------------------------------------------------------------------- keys ---
// These must mirror lib/retailers/finish.php and lib/retailers/match.php, so a
// snapshot entry can be found by the same key the PHP side computes.

const normName = s => String(s || '')
  .replace(/&#0?39;/g, "'").replace(/&amp;/g, '&')
  .toLowerCase().replace(/[''`]/g, "'")
  .replace(/\band\b/g, '&')
  .replace(/[^a-z0-9&' ]+/g, ' ').replace(/\s+/g, ' ').trim();

function finishToken(text) {
  let t = String(text || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  if (!t) return 'normal';
  const rev = t.includes('reverse');
  if (/\bsealed\b/.test(t)) return 'sealed';
  if (/\bnon ?holo\b/.test(t)) return 'nonholo';
  if (/\bart card\b/.test(t)) return 'artcard';
  if (/\bsnowflake\b/.test(t)) return 'snowflake';
  if (/\bmaster ?ball\b/.test(t)) return rev ? 'masterball-reverse' : 'masterball';
  if (/\bpoke ?ball\b/.test(t)) return rev ? 'pokeball-reverse' : 'pokeball';
  if (/\benergy\b/.test(t) && rev) return 'energy-reverse';
  if (/\brocket\b/.test(t) && rev) return 'rocket-reverse';
  if (/\bball\b/.test(t) && rev) return 'ball-reverse';
  if (/\bcosmos\b/.test(t)) return rev ? 'cosmos-reverse' : 'cosmos';
  if (/\bstamped\b/.test(t)) return 'stamped';
  if (/\b(full art|alt(ernate|ernative)? art|special art)\b/.test(t)) return 'fullart';
  if (/\bhalf art\b/.test(t)) return 'halfart';
  if (rev) return 'reverse';
  if (/\bfoil\b/.test(t)) return 'foil';
  if (/\bholo\b/.test(t)) return 'holo';
  return 'normal';
}

/**
 * Chaos Cards uses two layouts, and three of the six games identify cards with
 * a code rather than a number over a set size. All of these are real:
 *
 *   Pokemon   Armarouge (REVERSE HOLO) : MEGA EVOLUTION - PITCH BLACK 12/84 - Pokemon Single Card
 *   Lorcana   Ellie Fredricksen - Loving Wife : 075/207 ATTACK OF THE VINE - Disney Lorcana Single Card
 *   One Piece Sengoku : OP16-060 THE TIME OF BATTLE - One Piece Single Card
 *   Digimon   Susanoomon (Alternative Art) : EX12-076 DIGITAL WORLD SHAMBALA - Digimon Card Game Single Card
 *   Yu-Gi-Oh  Speedroid Taketomborg (Common) : LAVD-ENS05 - Yu-Gi-Oh! Single Card
 *   Magic     Academy Manufactor : 7094 SECRET LAIR DROP SERIES - Magic the Gathering Single Card
 *
 * Pokemon puts the identifier last; everything else puts it first. Yu-Gi-Oh
 * carries no set words at all. So rather than one rigid shape, this splits on
 * the first colon and hunts for an identifier anywhere on the right.
 */
function parseChaosTitle(title) {
  const t = String(title || '')
    .replace(/&#0?39;/g, "'").replace(/&amp;/g, '&')
    .replace(/\s*-\s*[A-Za-z !?.'-]*Single Card\s*$/i, '')
    .trim();

  const split = t.indexOf(' : ');
  if (split < 0) return null;
  const left = t.slice(0, split);
  const right = t.slice(split + 3);

  const num = extractNumber(right);
  if (!num) return null;

  // Treatments are bracketed on either side of the colon.
  const parens = [...t.matchAll(/\(([^)]*)\)/g)].map(x => x[1]).join(' ');

  return {
    name: normName(left.replace(/\s*\([^)]*\)\s*/g, ' ')),
    num,
    finish: finishToken(parens),
  };
}

/**
 * Pull a card identifier out of the right-hand side of a title, and normalise
 * it the way lib/retailers/match.php does so both sides agree:
 * "075/207" and "75/207" are the same card.
 */
function extractNumber(text) {
  const s = String(text || '').toUpperCase();

  // number over set size, e.g. 12/84, 075/207, 2/PD1
  const slash = s.match(/(?<![A-Z0-9])0*(\d+)([A-Z]?)\s*\/\s*0*([A-Z0-9]+)(?![A-Z0-9])/);
  if (slash) return slash[1] + slash[2] + '/' + slash[3].replace(/^0+(?=[\dA-Z])/, '');

  // set code, e.g. OP16-060, EX12-076, LAVD-ENS36, P-192
  const code = s.match(/(?<![A-Z0-9])([A-Z]{1,6}\d{0,3}-[A-Z0-9]{1,8})(?![A-Z0-9])/);
  if (code) return code[1];

  // bare collector number, e.g. Magic's 7094
  const bare = s.match(/^\s*0*(\d{1,5})(?![A-Z0-9])/);
  if (bare) return bare[1];

  return null;
}

// name | normalised number | finish. The number already carries the set size
// when the game uses one, so there is no separate field for it.
const keyOf = p => `${p.name}|${p.num}|${p.finish}`;

// ------------------------------------------------------------------ crawl ---
/**
 * Read one listing page.
 *
 * The schema.org ItemList is the good path: it carries a clean name, price,
 * availability and an MPN that identifies graded slabs. But Chaos Cards emits
 * an EMPTY ItemList on some category pages while rendering the products
 * perfectly well in the DOM, which is why Magic returned nothing at all on a
 * page the pager said held 456 more like it.
 *
 * So: use the ItemList when it has content, and read the tiles when it does
 * not. The tiles carry the full product name in the link title attribute.
 */
const EXTRACT = `(() => {
  const clean = s => String(s || "").replace(/\\s+/g, " ").trim();

  const ld = [...document.querySelectorAll('script[type="application/ld+json"]')]
    .map(s => { try { return JSON.parse(s.textContent); } catch (e) { return null; } })
    .filter(Boolean);
  const il = ld.find(j => j["@type"] === "ItemList");
  let items = (il?.itemListElement || []).map(e => ({
    name: e.item?.name, mpn: e.item?.mpn, url: e.item?.url,
    price: e.item?.offers?.price,
    avail: (e.item?.offers?.availability || "").split("/").pop(),
  }));

  if (!items.length) {
    items = [...document.querySelectorAll(".prod-el__wrapper")].map(el => {
      const a = el.querySelector('a[href*="/prod/"]');
      const text = clean(el.innerText);
      const price = (text.match(/\\u00a3\\s?([0-9,]+\\.[0-9]{2})/) || [])[1];
      const oos = /out of stock|sold out/i.test(text);
      return {
        name: a ? (a.getAttribute("title") || clean(a.textContent)) : "",
        mpn: "",
        url: a ? a.href : "",
        price: price ? price.replace(/,/g, "") : null,
        avail: oos ? "OutOfStock" : "InStock",
      };
    }).filter(x => x.name && x.price);
  }

  // The "N items" text lies: it reads "0 items" on pages that plainly hold
  // products. The pagination links are honest, so take the highest page
  // number offered and use that as the bound.
  const pages = [...document.querySelectorAll('a[href*="/page/"]')]
    .map(a => parseInt((a.getAttribute("href").match(/\\/page\\/([0-9]+)/) || [])[1] || 0, 10))
    .filter(Boolean);

  return { items, lastPage: pages.length ? Math.max(...pages) : null };
})()`;

const READY = `document.querySelectorAll(".prod-el__wrapper").length > 0 || /"itemListElement"/.test(document.body.innerHTML) || /no products found|no results/i.test(document.body.innerText)`;

const browser = new Browser();

const cards = {};
let carried = 0;
if (RESUME) {
  // Only the shards this run will touch are read back. Resuming a Pokemon-only
  // run no longer pays to load Magic's 24,000 cards.
  for (const section of PLAN) {
    const path = shardPath(section.name);
    if (!existsSync(path)) continue;
    try {
      const prior = JSON.parse(readFileSync(path, 'utf8'));
      const into = (cards[section.name] ??= {});
      for (const [k, v] of Object.entries(prior.cards || {})) {
        // An entry written before seenAt existed inherits the file's stamp,
        // so it ages out rather than looking brand new.
        into[k] = v.seenAt ? v : { ...v, seenAt: prior.generatedAt || null };
        carried++;
      }
    } catch (e) {
      console.log(`  ! could not read ${section.name} (${e.message}); that section starts fresh`);
    }
  }
  if (carried) console.log(`  resuming: ${carried} cards carried over`);
}

let fetched = 0, graded = 0, unparsed = 0, outOfStock = 0;

/**
 * A full crawl takes well over an hour, so each section is written as it
 * finishes rather than everything at the end. Interrupting it costs the
 * section in flight, not the whole run.
 *
 * Writing per section also means a section that was never crawled has no file,
 * which is honest: the reader reports no match rather than quoting a price
 * from whenever that game was last seen.
 */
function save(name) {
  mkdirSync(SHARD_DIR, { recursive: true });
  const rows = cards[name] || {};
  writeFileSync(shardPath(name), JSON.stringify({
    generatedAt: new Date().toISOString(),
    source: 'chaoscards',
    section: name,
    note: 'In-stock singles only. Keyed name|number|finish.',
    cards: rows,
  }));
  saveIndex();
}

/**
 * A small manifest so anything reading the snapshot can see what exists and
 * how old each part of it is without opening six files.
 */
function saveIndex() {
  const sections = {};
  for (const section of SECTIONS) {
    const path = shardPath(section.name);
    if (!existsSync(path)) continue;
    try {
      const shard = JSON.parse(readFileSync(path, 'utf8'));
      sections[section.name] = {
        generatedAt: shard.generatedAt || null,
        cards: Object.keys(shard.cards || {}).length,
      };
    } catch { /* a shard mid-write is not worth failing the run over */ }
  }
  writeFileSync(INDEX_FILE, JSON.stringify({
    generatedAt: new Date().toISOString(),
    source: 'chaoscards',
    sections,
  }, null, 2));
}

const totalCards = () =>
  Object.values(cards).reduce((n, rows) => n + Object.keys(rows).length, 0);

console.log(`Chaos Cards snapshot: ${PLAN.map(s => s.name).join(', ')}`);
await browser.launch();

try {
  for (const section of PLAN) {
    let pages = PAGE_CAP;
    for (let page = 1; page <= pages; page++) {
      // Two things about this URL, both learned the hard way.
      //
      // The `sort` segment is not optional. Without it, /show/64-products/page/N
      // returns an empty list; with it the same page returns 64 products.
      //
      // The `oos/no` in-stock filter used to work and now returns nothing at
      // all, so availability is read per item from the listing instead and
      // out-of-stock cards are dropped when they are stored. Filtering here
      // would have been cheaper, but a filter that silently returns zero is
      // worse than no filter.
      const url = `https://www.chaoscards.co.uk${section.path}`
        + `/sort/release-date-newest-first/show/${PER_PAGE}-products`
        + (page > 1 ? `/page/${page}` : '');

      // A page that does not render is 64 cards missing from the snapshot
      // with nothing to show for it but one line in the log, so give it a
      // second attempt before writing it off. Roughly one page in 150 times
      // out on a long run and almost all of them come back on the retry.
      let ok = await browser.goto(url, READY);
      if (!ok) {
        await sleep(CRAWL_DELAY_MS);
        ok = await browser.goto(url, READY);
      }
      if (!ok) { console.log(`\n  ! ${section.name} p${page} did not render`); await sleep(CRAWL_DELAY_MS); continue; }

      let res;
      try { res = await browser.evaluate(EXTRACT); }
      catch (e) { console.log(`\n  ! ${section.name} p${page}: ${e.message}`); await sleep(CRAWL_DELAY_MS); continue; }

      if (page === 1 && res.lastPage) {
        pages = Math.min(PAGE_CAP, res.lastPage);
        console.log(`  ${section.name}: ${pages} pages`);
      }
      if (!res.items.length) break;

      for (const item of res.items) {
        fetched++;
        // Graded slabs are a different product from the raw single we sell.
        // The MPN prefix identifies them where a title would not.
        if (/^CCG-GRA-/.test(item.mpn || '')) { graded++; continue; }
        const parsed = parseChaosTitle(item.name);
        if (!parsed) { unparsed++; continue; }
        const price = parseFloat(item.price);
        if (!(price > 0)) continue;
        // Out-of-stock cards never enter the snapshot. A price nobody can buy
        // at is not a comparison, and the PHP side treats every entry here as
        // purchasable.
        if (item.avail !== 'InStock') { outOfStock++; continue; }
        (cards[section.name] ??= {})[keyOf(parsed)] = {
          price: Math.round(price * 100) / 100,
          url: item.url || '',
          title: item.name,
          inStock: true,
          seenAt: runStartedAt,
        };
      }
      process.stdout.write(`\r  ${section.name}: page ${page}/${pages}, ${totalCards()} cards  `);
      await sleep(CRAWL_DELAY_MS);
    }
    process.stdout.write('\n');
    save(section.name);
  }
} finally {
  await browser.close();
  // The section in flight when something goes wrong still has whatever it read.
  for (const section of PLAN) save(section.name);
}

console.log(`\nlisted ${fetched}, kept ${totalCards()}`);
console.log(`  out of stock skipped: ${outOfStock}`);
console.log(`  graded slabs skipped: ${graded}`);
console.log(`  titles not parsed:    ${unparsed}`);
if (carried) console.log(`  carried from before:  ${carried}`);
for (const section of PLAN) {
  console.log(`  ${section.name.padEnd(12)} ${String(Object.keys(cards[section.name] || {}).length).padStart(6)}  ${shardPath(section.name)}`);
}
