<?php
declare(strict_types=1);

/**
 * Nightly competitor check, for cron.
 *
 *   php tools/price-monitor.php --set="Pitch Black"
 *   php tools/price-monitor.php --set="Pitch Black" --set="Chaos Rising" --game=pokemon
 *   php tools/price-monitor.php --saved            every set that has a saved run
 *
 * Each run compares every active single in the set against Total Cards, Magic
 * Madhouse and the Chaos Cards snapshot, writes the readings to price history
 * and saves the run so the monitor page opens on it instantly.
 *
 *   30 5 * * * /usr/bin/php /path/to/tools/price-monitor.php --saved
 *
 * Run it after the Chaos Cards snapshot has been refreshed for the day, or the
 * Chaos column is empty (snapshot prices older than 36 hours are ignored).
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/../lib/monitor.php';

$sets = [];
$game = 'pokemon';
$saved = false;
foreach (array_slice($argv, 1) as $arg) {
    if (str_starts_with($arg, '--set=')) $sets[] = trim(substr($arg, 6), "\"' ");
    elseif (str_starts_with($arg, '--game=')) $game = strtolower(trim(substr($arg, 7), "\"' "));
    elseif ($arg === '--saved') $saved = true;
    elseif ($arg === '--help' || $arg === '-h') {
        fwrite(STDOUT, "php tools/price-monitor.php --set=\"Pitch Black\" [--game=pokemon] | --saved\n");
        exit(0);
    }
}
$jobs = [];
foreach ($sets as $set) $jobs[] = ['set' => $set, 'game' => $game];
if ($saved) {
    foreach (monitor_list_runs() as $run) $jobs[] = ['set' => $run['set'], 'game' => $run['game'] ?: $game];
}
if ($jobs === []) {
    fwrite(STDERR, "Nothing to do. Pass --set=\"Set tag\" or --saved.\n");
    exit(1);
}

$exit = 0;
foreach ($jobs as $job) {
    $started = microtime(true);
    $rows = [];
    $after = '';
    $pages = 0;
    try {
        do {
            $page = monitor_compare_page($job['set'], $job['game'], $after, ['record' => true]);
            foreach ($page['rows'] as $row) $rows[] = $row;
            $after = $page['next'];
            $pages++;
        } while ($after !== '' && $pages < 40);
        $counts = monitor_counts($rows);
        monitor_save_run($job['set'], ['set' => $job['set'], 'game' => $job['game'], 'at' => time(), 'counts' => $counts, 'rows' => $rows]);
        fwrite(STDOUT, sprintf(
            "%-32s %4d cards  %3d above the lowest  %3d cheapest  %3d only seller  %.1fs\n",
            $job['set'], $counts['cards'], $counts['above'], $counts['cheapest'], $counts['only'], microtime(true) - $started
        ));
    } catch (Throwable $error) {
        fwrite(STDERR, $job['set'] . ': ' . $error->getMessage() . "\n");
        $exit = 1;
    }
}
exit($exit);
