<?php
declare(strict_types=1);

/**
 * Backfill variant SKUs across the catalogue.
 *
 * Every variant already in the store has an empty SKU, which is why the fast
 * restock path in lib/shopify-inventory.php never fires for existing stock and
 * every intake of a known card falls through to the slower title match. This
 * writes the same SKU the intake tool would mint, so the two agree.
 *
 * Dry run (prints what it would write, changes nothing):
 *   php tools/backfill-skus.php --tag="Pitch Black"
 *   php tools/backfill-skus.php --all --limit=200
 *
 * Write:
 *   php tools/backfill-skus.php --tag="Pitch Black" --apply
 *
 * Options:
 *   --tag=NAME     Only products carrying this tag.
 *   --all          Every product. Use --limit while you are still checking.
 *   --apply        Actually write. Without it nothing is sent to Shopify.
 *   --force        Overwrite variants that already have a SKU.
 *   --limit=N      Stop after N products.
 *   --csv=FILE     Write the full plan to a CSV for review.
 *
 * The dry run is the point. Read the CSV before you pass --apply.
 */

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/backfill.php';
require_once __DIR__ . '/../lib/sku.php';

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "This script is command line only.\n");
    exit(1);
}

$options = getopt('', ['tag:', 'all', 'apply', 'force', 'limit:', 'csv:']);
$setTag = trim((string) ($options['tag'] ?? ''));
$all = array_key_exists('all', $options);
$apply = array_key_exists('apply', $options);
$force = array_key_exists('force', $options);
$limit = isset($options['limit']) ? max(1, (int) $options['limit']) : 0;
$csvPath = trim((string) ($options['csv'] ?? ''));

if ($setTag === '' && !$all) {
    fwrite(STDERR, "Usage: php tools/backfill-skus.php (--tag=\"NAME\" | --all) [--apply] [--force] [--limit=N] [--csv=FILE]\n");
    exit(1);
}

const SKU_BACKFILL_QUERY = <<<'GRAPHQL'
query SkuBackfill($query: String!, $after: String) {
  products(first: 50, query: $query, after: $after) {
    pageInfo { hasNextPage endCursor }
    nodes {
      id
      title
      productType
      tags
      metafields(namespace: "tcg", first: 20) { nodes { key value } }
      variants(first: 25) {
        nodes { id title sku }
      }
    }
  }
}
GRAPHQL;

const SKU_WRITE_MUTATION = <<<'GRAPHQL'
mutation SetVariantSkus($productId: ID!, $variants: [ProductVariantsBulkInput!]!) {
  productVariantsBulkUpdate(productId: $productId, variants: $variants) {
    productVariants { id sku }
    userErrors { field message }
  }
}
GRAPHQL;

/**
 * Work out the SKU for one variant from what the product already stores.
 *
 * @param array $product product node as returned above
 * @param array $variant variant node
 */
function sku_backfill_for_variant(array $product, array $variant): string
{
    $game = (string) ($product['productType'] ?? '');

    $setNames = backfill_set_names($product);
    $setName = $setNames[0] ?? '';

    $number = backfill_card_number($product);

    $finish = backfill_metafield($product, 'finish');
    if ($finish === '') {
        $finish = sku_finish_from_title((string) ($product['title'] ?? ''));
    }

    $condition = (string) ($variant['title'] ?? '');

    return sku_build($game, $setName, $number, $finish, $condition);
}

// ---------------------------------------------------------------- collect ---

$query = $all
    ? 'status:active'
    : sprintf("tag:'%s'", str_replace("'", "\\'", $setTag));

$plan = [];        // productId => [ ['variantId','title','old','new'], ... ]
$byNewSku = [];    // new sku => count, to catch collisions before writing
$seenProducts = 0;
$skippedHaveSku = 0;
$skippedNoNumber = 0;
$cursor = null;

fwrite(STDERR, "Reading products" . ($all ? ' (all active)' : " tagged \"$setTag\"") . "...\n");

do {
    $data = shopify_graphql(SKU_BACKFILL_QUERY, ['query' => $query, 'after' => $cursor]);
    $page = $data['products'] ?? [];
    foreach (($page['nodes'] ?? []) as $product) {
        $seenProducts++;

        // Singles only. The scheme is built from a collector number, which a
        // binder or a sleeve pack does not have: "Celebrations 25 Lightning
        // Tail Stand - (65ct)" parses the sleeve count as a card number and
        // mints nonsense. Sealed and accessories carry real manufacturer
        // codes and want their own scheme.
        if (!in_array('Single Cards', (array) ($product['tags'] ?? []), true)) {
            continue;
        }

        $rows = [];
        foreach (($product['variants']['nodes'] ?? []) as $variant) {
            $existing = trim((string) ($variant['sku'] ?? ''));
            if ($existing !== '' && !$force) { $skippedHaveSku++; continue; }

            $sku = sku_backfill_for_variant($product, $variant);
            // A SKU with no usable number is not a join key, it is a guess.
            if (str_contains($sku, '-NA-')) { $skippedNoNumber++; continue; }
            if ($sku === $existing) { $skippedHaveSku++; continue; }

            $rows[] = [
                'variantId' => (string) $variant['id'],
                'product' => (string) ($product['title'] ?? ''),
                'variant' => (string) ($variant['title'] ?? ''),
                'old' => $existing,
                'new' => $sku,
            ];
            $byNewSku[$sku] = ($byNewSku[$sku] ?? 0) + 1;
        }
        if ($rows !== []) $plan[(string) $product['id']] = $rows;
        if ($limit > 0 && $seenProducts >= $limit) break 2;
    }
    $cursor = ($page['pageInfo']['hasNextPage'] ?? false) ? ($page['pageInfo']['endCursor'] ?? null) : null;
} while ($cursor !== null);

$totalRows = array_sum(array_map('count', $plan));
$collisions = array_filter($byNewSku, static fn(int $n): bool => $n > 1);

// ------------------------------------------------------------------ report ---

printf("products read        %d\n", $seenProducts);
printf("variants to write    %d\n", $totalRows);
printf("already had a SKU    %d\n", $skippedHaveSku);
printf("no usable number     %d\n", $skippedNoNumber);
printf("colliding SKUs       %d\n", count($collisions));

if ($csvPath !== '') {
    $fh = fopen($csvPath, 'w');
    if ($fh) {
        fputcsv($fh, ['product', 'variant', 'old_sku', 'new_sku', 'variant_id']);
        foreach ($plan as $rows) {
            foreach ($rows as $row) {
                fputcsv($fh, [$row['product'], $row['variant'], $row['old'], $row['new'], $row['variantId']]);
            }
        }
        fclose($fh);
        printf("plan written to      %s\n", $csvPath);
    }
}

// A SKU has to identify one variant. Where two products would claim the same
// one, both are held back rather than the whole run being abandoned: across
// the catalogue this affects roughly 0.1% of cards, and most of them are
// genuinely duplicated products that want merging rather than a SKU.
if ($collisions !== []) {
    $held = 0;
    foreach ($plan as $productId => $rows) {
        $keep = array_values(array_filter(
            $rows,
            static function (array $row) use ($collisions, &$held): bool {
                if (isset($collisions[$row['new']])) { $held++; return false; }
                return true;
            }
        ));
        if ($keep === []) unset($plan[$productId]);
        else $plan[$productId] = $keep;
    }
    $totalRows = array_sum(array_map('count', $plan));

    fwrite(STDERR, sprintf("\nHeld back %d variants whose SKU is not unique:\n", $held));
    foreach (array_slice($collisions, 0, 15, true) as $sku => $count) {
        fwrite(STDERR, sprintf("  %-46s %d products\n", $sku, $count));
    }
    if (count($collisions) > 15) {
        fwrite(STDERR, sprintf("  ... and %d more\n", count($collisions) - 15));
    }
    fwrite(STDERR, "These are usually duplicate products. Merge them, then re-run.\n");
    printf("variants to write    %d (after holding collisions back)\n", $totalRows);
}

if ($totalRows === 0) {
    printf("\nNothing to write.\n");
    exit(0);
}

$sample = 0;
foreach ($plan as $rows) {
    foreach ($rows as $row) {
        if ($sample++ >= 12) break 2;
        printf("  %-34s %-18s -> %s\n", substr($row['product'], 0, 34), $row['variant'], $row['new']);
    }
}

if (!$apply) {
    printf("\nDry run. Nothing was sent to Shopify. Add --apply to write.\n");
    exit(0);
}

// ------------------------------------------------------------------- write ---

fwrite(STDERR, "\nWriting...\n");
$written = 0;
$failed = 0;

foreach ($plan as $productId => $rows) {
    $variants = array_map(
        static fn(array $row): array => [
            'id' => $row['variantId'],
            'inventoryItem' => ['sku' => $row['new']],
        ],
        $rows
    );

    try {
        $result = shopify_graphql(SKU_WRITE_MUTATION, [
            'productId' => $productId,
            'variants' => $variants,
        ]);
        $errors = $result['productVariantsBulkUpdate']['userErrors'] ?? [];
        if ($errors !== []) {
            $failed += count($rows);
            fwrite(STDERR, sprintf("  ! %s: %s\n", $productId, (string) ($errors[0]['message'] ?? 'rejected')));
        } else {
            $written += count($rows);
        }
    } catch (Throwable $error) {
        $failed += count($rows);
        fwrite(STDERR, sprintf("  ! %s: %s\n", $productId, $error->getMessage()));
    }

    // Stay inside Shopify's cost-based rate limit.
    usleep(250000);
}

printf("\nwritten %d, failed %d\n", $written, $failed);
exit($failed > 0 ? 1 : 0);
