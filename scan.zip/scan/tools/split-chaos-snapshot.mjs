// Split an existing combined Chaos Cards snapshot into per-game shards.
//
// One-off migration. The collector used to write every game into a single
// cache/chaos-snapshot.json, which reached 13 MB and 41,841 cards, all of it
// decoded by PHP to answer one key. It now writes cache/chaos/<game>.json and
// the reader opens only the file it needs.
//
// A full crawl takes about eighty minutes, so rather than throwing away a good
// snapshot this splits the one already on disk.
//
//   node tools/split-chaos-snapshot.mjs           # report what it would write
//   node tools/split-chaos-snapshot.mjs --apply   # write the shards
//
// The combined file is left in place. Delete it once the shards are confirmed
// working; the reader falls back to it only when no shards exist at all.

import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const SOURCE = join(HERE, '..', 'cache', 'chaos-snapshot.json');
const SHARD_DIR = join(HERE, '..', 'cache', 'chaos');

const APPLY = process.argv.includes('--apply');

// The section a card belongs to is already in its own product URL, which is
// how the collector filed it in the first place:
//   https://www.chaoscards.co.uk/prod/singles-pokemon/<slug>
// Mapping from that is exact. Guessing from the card key would not be.
const SECTION_BY_PATH = {
  'singles-pokemon': 'pokemon',
  'disney-lorcana-single-cards': 'lorcana',
  'single-cards-digimon': 'digimon',
  'one-piece-card-game-single-cards': 'one-piece',
  'singles-magic': 'mtg',
  'singles-yu-gi-oh': 'yu-gi-oh',
};

if (!existsSync(SOURCE)) {
  console.error(`No combined snapshot at ${SOURCE}`);
  console.error('Nothing to split. Run tools/chaos-snapshot.mjs instead.');
  process.exit(1);
}

const snapshot = JSON.parse(readFileSync(SOURCE, 'utf8'));
const cards = snapshot.cards || {};
const total = Object.keys(cards).length;

const shards = {};
let unfiled = 0;
const unfiledSamples = [];

for (const [key, value] of Object.entries(cards)) {
  const segment = String(value.url || '').split('/')[4] || '';
  const section = SECTION_BY_PATH[segment];
  if (!section) {
    unfiled++;
    if (unfiledSamples.length < 5) unfiledSamples.push(`${key}  <-  ${value.url || '(no url)'}`);
    continue;
  }
  (shards[section] ??= {})[key] = value;
}

console.log(`source      ${SOURCE}`);
console.log(`generatedAt ${snapshot.generatedAt || '(none)'}`);
console.log(`cards       ${total}`);
console.log('');

let filed = 0;
for (const [section, rows] of Object.entries(shards).sort((a, b) => b[1].length - a[1].length)) {
  const n = Object.keys(rows).length;
  filed += n;
  console.log(`  ${section.padEnd(12)} ${String(n).padStart(6)}`);
}
console.log(`  ${'TOTAL'.padEnd(12)} ${String(filed).padStart(6)}`);

if (unfiled) {
  // A card with no recognisable section URL cannot be filed, and filing it
  // into the wrong game would make it unfindable rather than merely missing.
  console.log(`\n  ${unfiled} card(s) had no recognisable section and are NOT written:`);
  unfiledSamples.forEach(x => console.log(`    ${x}`));
}

if (!APPLY) {
  console.log('\nDry run. Nothing written. Re-run with --apply to write the shards.');
  process.exit(0);
}

mkdirSync(SHARD_DIR, { recursive: true });

const index = { generatedAt: new Date().toISOString(), source: 'chaoscards', sections: {} };
for (const [section, rows] of Object.entries(shards)) {
  // Each shard inherits the combined file's generatedAt. Per-card seenAt
  // stamps are carried through untouched, and those are what the reader
  // actually judges freshness on, so nothing is aged up or down by the split.
  const payload = {
    generatedAt: snapshot.generatedAt || new Date().toISOString(),
    source: 'chaoscards',
    section,
    note: 'In-stock singles only. Keyed name|number|finish.',
    cards: rows,
  };
  const path = join(SHARD_DIR, section + '.json');
  writeFileSync(path, JSON.stringify(payload));
  index.sections[section] = { generatedAt: payload.generatedAt, cards: Object.keys(rows).length };
  console.log(`written  ${path}`);
}

writeFileSync(join(SHARD_DIR, 'index.json'), JSON.stringify(index, null, 2));
console.log(`written  ${join(SHARD_DIR, 'index.json')}`);
console.log(`\n${filed} of ${total} cards filed into ${Object.keys(shards).length} shards.`);
