<?php
declare(strict_types=1);

/**
 * Remove old cache files.
 *
 * Nothing in the app deleted them for a long time, so the folder only grew:
 * 1,771 entries when it was first measured. cache_write_json() now
 * sweeps occasionally on its own, but a cron entry is the predictable way to
 * keep it flat on shared hosting.
 *
 *   php tools/prune-cache.php                 # dry run, 45 day cutoff
 *   php tools/prune-cache.php --days=14       # dry run, tighter cutoff
 *   php tools/prune-cache.php --apply         # delete
 *
 * Weekly is plenty:
 *
 *   0 4 * * 0 /usr/bin/php /path/to/tools/prune-cache.php --apply
 *
 * Only files named for a sha256 hash are touched, which is how every cache
 * entry is named and how nothing else in that folder is. The Chaos snapshot,
 * the per-game shards, the variant backups and the JustTCG usage counter all
 * live there too and are never candidates.
 */

require_once __DIR__ . '/../lib/bootstrap.php';

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("Command line only.\n");
}

$options = getopt('', ['days::', 'apply', 'help']);
if (isset($options['help'])) {
    echo "Usage: php tools/prune-cache.php [--days=45] [--apply]\n";
    exit(0);
}

$days = isset($options['days']) && is_numeric($options['days']) ? max(1, (int) $options['days']) : 45;
$apply = array_key_exists('apply', $options);
$directory = APP_ROOT . '/cache';

if (!is_dir($directory)) {
    exit("No cache directory at {$directory}\n");
}

$before = cache_directory_report($directory);
printf("cache directory  %s\n", $directory);
printf("files            %d  (%s)\n", $before['files'], human_bytes($before['bytes']));
printf("  disposable     %d  (%s)\n", $before['disposable'], human_bytes($before['disposableBytes']));
printf("  kept always    %d  (%s)\n", $before['protected'], human_bytes($before['protectedBytes']));
printf("cutoff           older than %d days\n\n", $days);

$stats = cache_sweep($days * 86400, $apply);

printf("%s %d file(s), %s\n", $apply ? 'Deleted' : 'Would delete', $stats['removed'], human_bytes($stats['bytes']));

if (!$apply) {
    echo "\nDry run. Nothing deleted. Re-run with --apply.\n";
}

/**
 * @return array{files:int,bytes:int,disposable:int,disposableBytes:int,protected:int,protectedBytes:int}
 */
function cache_directory_report(string $directory): array
{
    $report = ['files' => 0, 'bytes' => 0, 'disposable' => 0, 'disposableBytes' => 0, 'protected' => 0, 'protectedBytes' => 0];
    $handle = @opendir($directory);
    if ($handle === false) return $report;

    while (($name = readdir($handle)) !== false) {
        if ($name === '.' || $name === '..') continue;
        $path = $directory . '/' . $name;
        if (!is_file($path)) continue;

        $size = (int) @filesize($path);
        $report['files']++;
        $report['bytes'] += $size;
        if (cache_is_disposable($name)) {
            $report['disposable']++;
            $report['disposableBytes'] += $size;
        } else {
            $report['protected']++;
            $report['protectedBytes'] += $size;
        }
    }
    closedir($handle);
    return $report;
}

function human_bytes(int $bytes): string
{
    if ($bytes < 1024) return $bytes . ' B';
    if ($bytes < 1048576) return round($bytes / 1024, 1) . ' KB';
    return round($bytes / 1048576, 1) . ' MB';
}
