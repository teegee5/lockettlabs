<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/providers.php';
api_guard();

$game = strtolower(clean_text($_GET['game'] ?? '', 30));
$query = clean_text($_GET['q'] ?? '', 180);
$setQuery = clean_text($_GET['set'] ?? '', 120);
$numberQuery = clean_text($_GET['number'] ?? '', 80);
$language = strtolower(clean_text($_GET['lang'] ?? 'en', 5));
$language = $language === 'ja' ? 'ja' : 'en';
$kind = ($_GET['kind'] ?? '') === 'sealed' ? 'sealed' : 'single';

if ($kind === 'sealed') {
    if (text_length(trim($query . $setQuery)) < 2) {
        json_response(['ok' => false, 'error' => 'Enter a product name or choose a set.'], 422);
    }
    try {
        $results = sealed_search($game, $query, $language, $setQuery);
        json_response([
            'ok' => true,
            'kind' => 'sealed',
            'results' => $results,
            'count' => count($results),
            'usage' => justtcg_usage_snapshot(),
            'search' => ['query' => $query, 'set' => $setQuery, 'language' => $language],
        ]);
    } catch (InvalidArgumentException $error) {
        json_response(['ok' => false, 'error' => $error->getMessage()], 422);
    } catch (Throwable $error) {
        json_response(['ok' => false, 'error' => $error->getMessage()], 502);
    }
}

if (text_length(trim($query . $setQuery . $numberQuery)) < 2) {
    json_response(['ok' => false, 'error' => 'Enter a card name, set, or printed card number.'], 422);
}

try {
    $gameId = justtcg_legacy_game_id($game, $language);
    $results = card_search($game, $query, $language, $setQuery, $numberQuery);
    $numberSource = exact_number_from_search($query, $numberQuery);
    $setId = justtcg_resolve_set_id($gameId, $setQuery);
    $expandedNumber = expand_number_with_set_context($numberSource, $setQuery, $gameId, $setId);
    json_response([
        'ok' => true,
        'kind' => 'single',
        'results' => $results,
        'count' => count($results),
        'usage' => justtcg_usage_snapshot(),
        'search' => [
            'query' => $query,
            'set' => $setQuery,
            'number' => $numberQuery,
            'strictNumber' => $expandedNumber !== '' ? $expandedNumber : $numberSource,
            'language' => $language,
        ],
    ]);
} catch (Throwable $error) {
    json_response(['ok' => false, 'error' => $error->getMessage()], 502);
}
