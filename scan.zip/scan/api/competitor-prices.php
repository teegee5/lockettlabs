<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/retailers/compare.php';
api_guard();

$number = clean_text($_GET['number'] ?? '', 40);
$game = strtolower(clean_text($_GET['game'] ?? 'one-piece-card-game', 80));
$rarity = clean_text($_GET['rarity'] ?? '', 80);
$cardName = clean_text($_GET['name'] ?? '', 120);
// The store's own set name (Pitch Black), and the catalogue's (ME05: Pitch Black).
$setName = clean_text($_GET['set'] ?? '', 120);
$providerSet = clean_text($_GET['providerSet'] ?? '', 120);
// Optional. Without it no printing gate is applied, so a reverse holo can be
// priced against the plain card of the same number.
$finish = clean_text($_GET['finish'] ?? '', 60);
$cardmarketId = preg_replace('/\D+/', '', (string) ($_GET['cardmarketId'] ?? '')) ?? '';
$justTcgNm = null;
if (isset($_GET['justTcgNm']) && is_numeric($_GET['justTcgNm'])) {
    $justTcgNm = (float) $_GET['justTcgNm'];
}
$currentNm = null;
if (isset($_GET['currentNm']) && is_numeric($_GET['currentNm'])) {
    $currentNm = (float) $_GET['currentNm'];
}

if ($number === '') {
    json_response(['ok' => false, 'error' => 'Enter a printed card number.'], 422);
}

try {
    $result = competitor_prices_compare($number, $game, $rarity, $justTcgNm, $currentNm, $cardName, $setName, $finish, [
        'cardmarketId' => $cardmarketId,
        'providerSet' => $providerSet,
        'record' => !empty($_GET['record']),
        'label' => clean_text($_GET['label'] ?? '', 200),
    ]);
    json_response($result);
} catch (Throwable $error) {
    $links = function_exists('price_compare_uk_links')
        ? price_compare_uk_links(retailer_normalize_number($number), $cardName, $setName)
        : [];
    json_response([
        'ok' => true,
        'number' => retailer_normalize_number($number),
        'rarityBand' => competitor_rarity_band($rarity),
        'sources' => [],
        'links' => $links,
        'inStock' => [],
        'lowestInStock' => null,
        'justTcgNm' => $justTcgNm,
        'suggestedNm' => null,
        'action' => 'hold',
        'reason' => 'Price compare failed: ' . clean_text($error->getMessage(), 180),
        'autoFill' => false,
        'existing' => null,
        'error' => clean_text($error->getMessage(), 240),
    ]);
}
