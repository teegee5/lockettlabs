<?php
declare(strict_types=1);

/**
 * Receive a finished scan from the browser and stage it with Shopify.
 *
 * POST multipart: image (file), filename, productId? alt? featured?
 *   - without productId: returns the resourceUrl to create a product with
 *   - with productId:    also adds the image to that existing product
 */

require_once __DIR__ . '/../lib/media.php';
api_guard(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Send the scan as a POST.'], 405);
}
$file = $_FILES['image'] ?? null;
if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    $code = is_array($file) ? (int) ($file['error'] ?? 0) : UPLOAD_ERR_NO_FILE;
    $message = match ($code) {
        UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'The scan is larger than this server accepts.',
        UPLOAD_ERR_PARTIAL => 'The scan only partly arrived. Try again.',
        default => 'No scan was received.',
    };
    json_response(['ok' => false, 'error' => $message], 422);
}

try {
    [$mime, $width, $height] = media_validate_image((string) $file['tmp_name'], (int) $file['size']);
    $filename = media_clean_filename(clean_text($_POST['filename'] ?? 'card-scan', 120), $mime);
    $resourceUrl = shopify_stage_image((string) $file['tmp_name'], $filename, $mime);

    $productId = clean_text($_POST['productId'] ?? '', 120);
    $attached = null;
    if ($productId !== '') {
        $alt = clean_text($_POST['alt'] ?? '', 500);
        $attached = shopify_append_product_media($productId, $resourceUrl, $alt, !empty($_POST['featured']));
    }

    json_response([
        'ok' => true,
        'resourceUrl' => $resourceUrl,
        'filename' => $filename,
        'width' => $width,
        'height' => $height,
        'attached' => $attached,
    ]);
} catch (InvalidArgumentException $error) {
    json_response(['ok' => false, 'error' => $error->getMessage()], 422);
} catch (Throwable $error) {
    json_response(['ok' => false, 'error' => $error->getMessage()], 502);
}
