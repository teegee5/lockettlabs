<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/providers.php';
api_guard();

$game = strtolower(clean_text($_GET['game'] ?? '', 100));
$query = clean_text($_GET['q'] ?? '', 160);

try {
    if ($game !== '') {
        json_response([
            'ok' => true,
            'provider' => 'JustTCG',
            'game' => $game,
            'sets' => justtcg_sets($game, $query),
            'usage' => justtcg_usage_snapshot(),
        ]);
    }
    json_response([
        'ok' => true,
        'provider' => 'JustTCG',
        'games' => justtcg_games(),
        'usage' => justtcg_usage_snapshot(),
    ]);
} catch (Throwable $error) {
    json_response(['ok' => false, 'error' => $error->getMessage()], 502);
}
