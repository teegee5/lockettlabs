<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/intake-log.php';
api_guard();

/**
 * What went into Shopify through this app, most recent first, plus today's
 * totals for the workbar.
 *
 * Read only, so no CSRF token is required, in line with the other read
 * endpoints. It never touches Shopify: everything here comes from the local
 * log written at the moment of each intake.
 */

$limit = isset($_GET['limit']) && is_numeric($_GET['limit']) ? (int) $_GET['limit'] : 12;

json_response([
    'ok' => true,
    'today' => intake_log_today_summary(),
    'recent' => intake_log_recent($limit),
]);
