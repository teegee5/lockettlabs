<?php
declare(strict_types=1);

/**
 * POST JSON { card } -> { images, details, tcgCardId, tcgSetId, printedTotal, releasedAt }
 * One round trip when a card is selected: pictures with their scan or digital
 * label, the printed set size, and the facts for the description.
 */

require_once __DIR__ . '/../lib/card-extras.php';
api_guard(true);

$body = request_json();
$card = is_array($body['card'] ?? null) ? $body['card'] : [];
if (($card['game'] ?? '') === '') {
    json_response(['ok' => false, 'error' => 'Choose a card first.'], 422);
}
try {
    json_response(['ok' => true] + card_extras($card));
} catch (Throwable $error) {
    // Extras are a bonus. A failure here must never stop a card being listed.
    json_response(['ok' => true, 'images' => [], 'details' => [], 'tcgCardId' => '', 'tcgSetId' => '', 'cardmarketId' => '', 'printedTotal' => 0, 'releasedAt' => '', 'sources' => [], 'warning' => clean_text($error->getMessage(), 200)]);
}
