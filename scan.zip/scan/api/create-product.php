<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/shopify-inventory.php';
require_once __DIR__ . '/../lib/tcgdex.php';
require_once __DIR__ . '/../lib/card-extras.php';
require_once __DIR__ . '/../lib/intake-log.php';
require_once __DIR__ . '/../lib/description.php';
require_once __DIR__ . '/../lib/catalogue-links.php';
require_once __DIR__ . '/../lib/media.php';
api_guard(true);

$body = request_json();
$kind = ($body['kind'] ?? '') === 'sealed' ? 'sealed' : 'single';
$title = clean_text($body['title'] ?? '', 255);
$vendor = clean_text($body['vendor'] ?? '', 255);
$productType = clean_text($body['productType'] ?? '', 255);
$locationId = clean_text($body['locationId'] ?? '', 120);
$status = strtoupper((string) ($body['status'] ?? 'DRAFT')) === 'ACTIVE' ? 'ACTIVE' : 'DRAFT';
$categoryId = clean_text($body['categoryId'] ?? '', 160);
// Search engine listing. Google truncates well before these limits, and the
// editor already trims to them, but clamp again so a stale client cannot write
// an over-long title tag.
$seoTitle = truncate_text(clean_text($body['seoTitle'] ?? '', 200), 70);
$seoDescription = truncate_text(clean_text($body['seoDescription'] ?? '', 400), 160);
$seoInput = [];
if ($seoTitle !== '') $seoInput['title'] = $seoTitle;
if ($seoDescription !== '') $seoInput['description'] = $seoDescription;

// The number exactly as printed (25/111, 025/198); the provider's own string
// is kept beside it so the two can always be told apart.
$printedNumber = clean_text($body['printedNumber'] ?? '', 80);
$providerNumber = clean_text($body['cardNumber'] ?? '', 80);

if ($title === '' || $vendor === '' || $productType === '') {
    json_response(['ok' => false, 'error' => 'Title, vendor and product type are required.'], 422);
}
if (!preg_match('#^gid://shopify/Location/\d+$#', $locationId)) {
    json_response(['ok' => false, 'error' => 'Choose a Shopify inventory location.'], 422);
}
if ($categoryId !== '' && !preg_match('#^gid://shopify/TaxonomyCategory/[A-Za-z0-9-]+$#', $categoryId)) {
    json_response(['ok' => false, 'error' => 'The selected Shopify product category is invalid.'], 422);
}

$tags = array_values(array_unique(array_filter(array_map(
    static fn($tag) => clean_text($tag, 80),
    is_array($body['tags'] ?? null) ? $body['tags'] : []
))));
$collections = array_values(array_filter(
    $body['collectionIds'] ?? [],
    static fn($id): bool => is_string($id) && preg_match('#^gid://shopify/Collection/\d+$#', $id)
));
$publicationIds = array_values(array_unique(array_filter(
    $body['publicationIds'] ?? [],
    static fn($id): bool => is_string($id) && preg_match('#^gid://shopify/Publication/\d+$#', $id)
)));

/**
 * The product image: a scan staged through api/scan-upload.php, or a catalogue
 * address. Staged scans carry the card identity in their file name.
 */
$image = is_array($body['image'] ?? null) ? $body['image'] : [];
$imageSource = '';
if (($image['source'] ?? '') === 'staged') {
    $candidate = (string) ($image['url'] ?? '');
    if (preg_match('#^https://[a-z0-9.-]+(?:\.googleapis\.com|\.shopify\.com|shopify-staged-uploads\.storage\.googleapis\.com)/#i', $candidate)) {
        $imageSource = $candidate;
    }
} else {
    $imageSource = safe_https_url($image['url'] ?? ($body['imageUrl'] ?? ''));
}
$imageAlt = truncate_text(clean_text($image['alt'] ?? '', 500), 500);
if ($imageAlt === '') $imageAlt = $title . ($kind === 'sealed' ? '' : ' trading card');

// Single cards carry one variant per condition held. Sealed product is one
// variant with Shopify's own placeholder option, as the store already does.
$variants = [];
$variantRequests = [];
$conditions = [];
foreach (($body['variants'] ?? []) as $variant) {
    if (!is_array($variant) || empty($variant['enabled'])) continue;
    $condition = $kind === 'sealed' ? 'Default Title' : clean_text($variant['condition'] ?? '', 60);
    $price = number_format(max(0, (float) ($variant['price'] ?? 0)), 2, '.', '');
    $quantity = max(0, min(100000, (int) ($variant['quantity'] ?? 0)));
    $sku = clean_text($variant['sku'] ?? '', 100);
    if ($condition === '' || $sku === '') {
        json_response(['ok' => false, 'error' => 'Each selected condition needs a condition name and SKU.'], 422);
    }
    $conditions[] = $condition;
    $variantRequests[] = ['condition' => $condition, 'price' => $price, 'quantity' => $quantity, 'sku' => $sku];
    $variants[] = [
        'optionValues' => [['optionName' => $kind === 'sealed' ? 'Title' : 'Condition', 'name' => $condition]],
        'price' => $price,
        'sku' => $sku,
        'taxable' => true,
        'inventoryItem' => ['tracked' => true, 'requiresShipping' => true],
        'inventoryQuantities' => [[
            'locationId' => $locationId,
            'name' => 'available',
            'quantity' => $quantity,
        ]],
    ];
    if ($kind === 'sealed') break;
}
if (!$variants) {
    json_response(['ok' => false, 'error' => $kind === 'sealed' ? 'Enter the price and quantity.' : 'Select at least one condition variant.'], 422);
}

// The stock lookup is repeated here even though the browser performs a
// preflight check. This server-side result is authoritative and prevents an
// old browser result from overwriting or duplicating current Shopify stock.
try {
    $preferredProductId = clean_text($body['existingProductId'] ?? '', 120);
    $forceCreateNew = !empty($body['forceCreateNew']);
    $resolution = shopify_resolve_card_stock($body, $variantRequests, $locationId, $preferredProductId, $forceCreateNew);
    $stockMode = (string) ($resolution['mode'] ?? '');
    if ($stockMode === 'ambiguous') {
        json_response(['ok' => false, 'error' => 'More than one Shopify variant uses the same SKU. Resolve the duplicate SKU in Shopify before adding stock.'], 409);
    }
    if ($stockMode === 'mixed') {
        json_response(['ok' => false, 'error' => 'Some selected conditions match an existing Shopify product and others do not. To prevent a duplicate product, enable only existing conditions or add the missing variant in Shopify first.'], 409);
    }
    if ($stockMode === 'candidate') {
        json_response(['ok' => false, 'error' => 'A possible existing Shopify product needs confirmation. Run the stock check again, then confirm the matching product or choose to create a new listing.'], 409);
    }
    if ($stockMode === 'existing') {
        $stockMatches = is_array($resolution['matches'] ?? null) ? $resolution['matches'] : [];
        $productIds = array_values(array_unique(array_filter(array_map(
            static fn(array $match): string => (string) ($match['product']['id'] ?? ''),
            $stockMatches
        ))));
        if (count($productIds) !== 1) {
            json_response(['ok' => false, 'error' => 'The matching condition variants belong to different Shopify products. Resolve the duplicate card listings before adding stock.'], 409);
        }
        if ($forceCreateNew && $preferredProductId === '') {
            // Staff said this is not the same product, but it already owns the
            // SKU. Creating another product with it would make every later
            // stock check ambiguous, so the new listing needs its own SKU.
            $takenSkus = implode(', ', array_values(array_filter(array_map(
                static fn(array $match): string => (string) ($match['sku'] ?? ''),
                $stockMatches
            ))));
            $ownerTitle = (string) ($stockMatches[0]['product']['title'] ?? ($resolution['products'][0]['title'] ?? 'another Shopify product'));
            json_response(['ok' => false, 'error' => "SKU {$takenSkus} already belongs to \"{$ownerTitle}\". A separate listing cannot reuse it. Reload the card and choose \"This is not the same product\" again so the tool assigns a new SKU, or confirm that product to restock it."], 409);
        }
        if ($preferredProductId === '' || !hash_equals($productIds[0], $preferredProductId)) {
            json_response(['ok' => false, 'error' => 'Confirm the Shopify product preview before adding stock. The server will not restock an automatically detected product without confirmation.'], 409);
        }

        $operationId = clean_text($body['operationId'] ?? '', 64);
        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $operationId)) {
            $operationId = inventory_operation_uuid(bin2hex(random_bytes(24)));
        }
        $inventory = shopify_add_existing_stock($stockMatches, $variantRequests, $locationId, $operationId);
        $product = is_array($resolution['products'][0] ?? null) ? $resolution['products'][0] : $stockMatches[0]['product'];
        $product['variants'] = ['nodes' => $inventory['variants']];
        $product['adminUrl'] = shopify_admin_product_url((string) $product['id']);

        $priceNote = '';
        $seoRefreshed = false;
        if (!empty($inventory['pricesUpdated'])) {
            $priceNote = ' Variant prices were updated in Shopify.';
            // The SEO title quotes the Near Mint price, so a repriced restock
            // leaves a stale figure in search results unless it is rewritten.
            if ($seoInput !== []) {
                try {
                    $seoData = shopify_graphql(<<<'GRAPHQL'
mutation RefreshCardSeo($product: ProductUpdateInput!) {
  productUpdate(product: $product) {
    product { id }
    userErrors { field message }
  }
}
GRAPHQL, ['product' => ['id' => $product['id'], 'seo' => $seoInput]]);
                    $seoRefreshed = empty($seoData['productUpdate']['userErrors']);
                } catch (Throwable) {
                    $seoRefreshed = false;
                }
            }
        }
        if ($seoRefreshed) {
            $priceNote .= ' The SEO title was rewritten with the new price.';
        }

        // A scan of the card in hand can replace a digital render on the
        // existing listing. Opt-in, appended (never a replace), stock first.
        $scanAttached = null;
        if (!empty($body['attachScanToExisting']) && $imageSource !== '' && ($image['source'] ?? '') === 'staged') {
            try {
                $scanAttached = shopify_append_product_media((string) $product['id'], $imageSource, $imageAlt, true);
            } catch (Throwable $mediaError) {
                $scanAttached = ['error' => clean_text($mediaError->getMessage(), 200)];
            }
        }

        // Write it down before replying. The stock has already moved in
        // Shopify at this point, so the log records what happened whether or
        // not the browser is still listening.
        intake_log_append(intake_log_entry(
            'restocked',
            $product,
            $body,
            $variantRequests,
            (int) ($inventory['added'] ?? 0),
            $locationId,
            (string) ($resolution['matchMethod'] ?? ''),
            $operationId
        ));

        json_response([
            'ok' => true,
            'action' => 'restocked',
            'seoRefreshed' => $seoRefreshed,
            'scanAttached' => $scanAttached,
            'product' => $product,
            'inventory' => $inventory,
            'matchMethod' => $resolution['matchMethod'] ?? 'Shopify match',
            'publication' => ['requested' => 0, 'published' => 0, 'errors' => []],
            'message' => $priceNote,
        ]);
    }
} catch (InvalidArgumentException $error) {
    json_response(['ok' => false, 'error' => $error->getMessage()], 422);
} catch (Throwable $error) {
    json_response(['ok' => false, 'error' => $error->getMessage()], 502);
}

foreach ($variantRequests as $variant) {
    if ($status === 'ACTIVE' && (float) $variant['price'] <= 0) {
        json_response(['ok' => false, 'error' => 'Active products need a price above zero for every enabled condition.'], 422);
    }
}

$meta = [
    'game' => clean_text($body['gameName'] ?? $body['game'] ?? '', 120),
    'game_id' => clean_text($body['game'] ?? '', 100),
    'set_name' => clean_text($body['setName'] ?? '', 220),
    'card_number' => $kind === 'sealed' ? '' : ($printedNumber !== '' ? $printedNumber : $providerNumber),
    'provider_number' => $kind === 'sealed' ? '' : $providerNumber,
    'card_type' => clean_text($body['cardType'] ?? '', 180),
    'rarity' => clean_text($body['rarity'] ?? '', 100),
    'finish' => $kind === 'sealed' ? '' : clean_text($body['finish'] ?? '', 100),
    'database_id' => clean_text($body['externalId'] ?? '', 180),
    'database_provider' => clean_text($body['provider'] ?? 'JustTCG', 80),
    'set_id' => clean_text($body['setId'] ?? '', 180),
    'tcgplayer_id' => clean_text($body['tcgplayerId'] ?? '', 80),
    'scryfall_id' => clean_text($body['scryfallId'] ?? '', 100),
    'mtgjson_id' => clean_text($body['mtgjsonId'] ?? '', 100),
    'language' => clean_text($body['language'] ?? '', 80),
    'original_name' => clean_text($body['name'] ?? '', 220),
    'english_name' => clean_text($body['englishName'] ?? '', 220),
    'english_set_name' => clean_text($body['englishSetName'] ?? '', 220),
    'image_kind' => clean_text($image['kind'] ?? '', 20),
];
$metafields = [];
foreach ($meta as $key => $value) {
    if ($value !== '') {
        $metafields[] = [
            'namespace' => 'tcg',
            'key' => $key,
            'type' => 'single_line_text_field',
            'value' => $value,
        ];
    }
}
// custom.primary_collection drives storefront breadcrumbs; custom.release_date
// feeds the set/era merchandising sections. Both are otherwise left blank on
// every card created here, so fill them from the card that is being listed.
$primaryCollectionId = clean_text($body['primaryCollectionId'] ?? '', 120);
if ($primaryCollectionId !== '' && preg_match('#^gid://shopify/Collection/\d+$#', $primaryCollectionId)) {
    $metafields[] = [
        'namespace' => 'custom',
        'key' => 'primary_collection',
        'type' => 'collection_reference',
        'value' => $primaryCollectionId,
    ];
}
$setReleaseDate = clean_text($body['setReleaseDate'] ?? '', 20);
if ($setReleaseDate !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $setReleaseDate)) {
    $metafields[] = [
        'namespace' => 'custom',
        'key' => 'release_date',
        'type' => 'date',
        'value' => $setReleaseDate,
    ];
}

// The product page reads custom.tcg_card_id before falling back to the image
// filename, and images uploaded here get a Shopify-generated filename, so an
// unresolved id would leave the card-details panel empty. The id found when
// the card was selected is reused if it is well formed; otherwise the server
// resolves it again, failing closed.
$tcgCardId = '';
$tcgSetId = '';
if ($kind === 'single') {
    $offered = clean_text($body['tcgCardId'] ?? '', 80);
    if ($offered !== '' && preg_match('/^[a-z0-9][a-z0-9.\-]{1,40}-[a-z0-9]{1,8}$/i', $offered)) {
        $tcgCardId = $offered;
        $tcgSetId = clean_text($body['tcgSetId'] ?? '', 60);
    } else {
        try {
            $setCandidates = [
                clean_text($body['setTag'] ?? '', 220),
                clean_text($body['englishSetName'] ?? '', 220),
                clean_text($body['setName'] ?? '', 220),
                clean_text($body['setId'] ?? '', 180),
            ];
            $classic = (bool) preg_match('/classic collection/i', implode(' ', $setCandidates) . ' ' . ($body['rarity'] ?? ''));
            $tcgCardId = $classic
                ? tcgdex_classic_card_id($setCandidates, clean_text($body['englishName'] ?? $body['name'] ?? '', 220), clean_text($body['languageCode'] ?? '', 8) === 'ja' ? 'ja' : 'en')
                : tcgdex_resolve_card_id(
                    clean_text($body['game'] ?? '', 100),
                    $setCandidates,
                    $providerNumber,
                    clean_text($body['languageCode'] ?? '', 8),
                    clean_text($body['englishName'] ?? $body['name'] ?? '', 220)
                );
        } catch (Throwable) {
            $tcgCardId = '';
        }
        if ($tcgCardId !== '' && preg_match('/^(.*)-[^-]+$/', $tcgCardId, $m)) $tcgSetId = $m[1];
    }
}
if ($tcgCardId !== '') {
    $metafields[] = ['namespace' => 'custom', 'key' => 'tcg_card_id', 'type' => 'single_line_text_field', 'value' => $tcgCardId];
}
if ($tcgSetId !== '' && preg_match('/^[a-z0-9.\-]{1,40}$/i', $tcgSetId)) {
    $metafields[] = ['namespace' => 'custom', 'key' => 'tcg_set_id', 'type' => 'single_line_text_field', 'value' => $tcgSetId];
}
if ($kind === 'single' && $printedNumber !== '') {
    // The product page prints this instead of pairing TCGdex's running number
    // with the title's total (which is how "007/111" reached a Classic card).
    $metafields[] = ['namespace' => 'custom', 'key' => 'card_number', 'type' => 'single_line_text_field', 'value' => $printedNumber];
}
$setCode = clean_text($body['setCode'] ?? '', 20);
if ($setCode !== '' && preg_match('/^[A-Z0-9]{2,8}$/i', $setCode)) {
    $metafields[] = ['namespace' => 'custom', 'key' => 'set_code', 'type' => 'single_line_text_field', 'value' => strtoupper($setCode)];
}

// Storefront filters: game, product class, series, set and language.
$links = ll_catalogue_link_metafields([
    'game' => clean_text($body['game'] ?? '', 100),
    'kind' => $kind,
    'setTag' => clean_text($body['setTag'] ?? '', 220),
    'eraTag' => clean_text($body['eraTag'] ?? '', 120),
    'languageCode' => clean_text($body['languageCode'] ?? '', 8),
]);
foreach ($links['metafields'] as $field) $metafields[] = $field;

// A single card has no barcode. Telling Google so (identifier_exists = no)
// keeps it eligible in Shopping instead of being limited for a missing GTIN.
if ($kind === 'single' && (app_config()['google_custom_product_for_singles'] ?? true)) {
    $metafields[] = ['namespace' => 'mm-google-shopping', 'key' => 'custom_product', 'type' => 'boolean', 'value' => 'true'];
}

$sourceUrl = safe_https_url($body['sourceUrl'] ?? '');
if ($sourceUrl !== '') {
    $metafields[] = ['namespace' => 'tcg', 'key' => 'source_url', 'type' => 'url', 'value' => $sourceUrl];
}
$marketLowest = $body['marketLowest'] ?? null;
if (is_numeric($marketLowest) && strtoupper((string) ($body['marketCurrency'] ?? '')) === 'GBP') {
    $metafields[] = ['namespace' => 'tcg', 'key' => 'market_price_gbp', 'type' => 'number_decimal', 'value' => number_format(max(0, (float) $marketLowest), 2, '.', '')];
    $marketRateDate = clean_text($body['marketRateDate'] ?? '', 20);
    if ($marketRateDate !== '') {
        $metafields[] = ['namespace' => 'tcg', 'key' => 'market_rate_date', 'type' => 'single_line_text_field', 'value' => $marketRateDate];
    }
}

$allowedCategoryFields = [
    'color-pattern' => 'Color',
    'toy-game-material' => 'Toy/Game material',
    'card-attributes' => 'Card attributes',
    'condition' => 'Condition',
    'grading' => 'Grading',
    'product-use' => 'Product use',
    'rarity' => 'Rarity',
    'age-group' => 'Recommended age group',
    'theme' => 'Theme',
    'trading-card-packaging' => 'Trading card packaging',
];

// Constrained shopify.* category attributes must be written only after the
// product has the matching taxonomy category. Mixing them into productSet can
// fail with "Owner subtype does not match the metafield definition's constraints"
// (e.g. input.metafields.N) even when category is present in the same input.
$shopifyCategoryMetafields = [];
$seenCategoryKeys = [];
foreach (is_array($body['categoryMetafields'] ?? null) ? $body['categoryMetafields'] : [] as $field) {
    if (!is_array($field)) continue;
    $key = clean_text($field['key'] ?? '', 80);
    if ($key === '' || !isset($allowedCategoryFields[$key]) || isset($seenCategoryKeys[$key])) continue;
    $seenCategoryKeys[$key] = true;
    $type = clean_text($field['type'] ?? '', 80);
    $value = trim((string) ($field['value'] ?? ''));
    $displayValue = clean_text($field['displayValue'] ?? '', 500);
    $standardSaved = false;

    // Only write constrained shopify.* attrs when a category is assigned.
    if (
        $categoryId !== ''
        && $value !== ''
        && in_array($type, ['metaobject_reference', 'list.metaobject_reference', 'single_line_text_field', 'list.single_line_text_field'], true)
    ) {
        if ($type === 'metaobject_reference' && preg_match('#^gid://shopify/Metaobject/\d+$#', $value)) {
            $shopifyCategoryMetafields[] = ['namespace' => 'shopify', 'key' => $key, 'type' => $type, 'value' => $value];
            $standardSaved = true;
        } elseif ($type === 'list.metaobject_reference') {
            $decoded = json_decode($value, true);
            if (is_array($decoded) && $decoded !== [] && count(array_filter($decoded, static fn($id): bool => is_string($id) && preg_match('#^gid://shopify/Metaobject/\d+$#', $id))) === count($decoded)) {
                $shopifyCategoryMetafields[] = ['namespace' => 'shopify', 'key' => $key, 'type' => $type, 'value' => json_encode(array_values($decoded), JSON_UNESCAPED_SLASHES)];
                $standardSaved = true;
            }
        } elseif ($type === 'single_line_text_field') {
            $shopifyCategoryMetafields[] = ['namespace' => 'shopify', 'key' => $key, 'type' => $type, 'value' => clean_text($value, 500)];
            $standardSaved = true;
        } elseif ($type === 'list.single_line_text_field') {
            $decoded = json_decode($value, true);
            if (is_array($decoded) && $decoded !== []) {
                $shopifyCategoryMetafields[] = ['namespace' => 'shopify', 'key' => $key, 'type' => $type, 'value' => json_encode(array_map(static fn($item) => clean_text((string) $item, 120), array_values($decoded)), JSON_UNESCAPED_UNICODE)];
                $standardSaved = true;
            }
        }
    }

    // Preserve staff-entered values even when a Shopify standard definition or
    // standard metaobject is not installed on this store yet.
    if (!$standardSaved && $displayValue !== '') {
        $metafields[] = [
            'namespace' => 'tcg_category',
            'key' => $key,
            'type' => 'single_line_text_field',
            'value' => $displayValue,
        ];
    }
}

$descriptionHtml = sanitize_description_html((string) ($body['descriptionHtml'] ?? ''));
if ($descriptionHtml === '') $descriptionHtml = description_from_text((string) ($body['description'] ?? ''));

$input = [
    'title' => $title,
    'descriptionHtml' => $descriptionHtml,
    'vendor' => $vendor,
    'productType' => $productType,
    'status' => $status,
    'tags' => $tags,
    'collections' => $collections,
    'metafields' => $metafields,
    'productOptions' => [[
        'name' => $kind === 'sealed' ? 'Title' : 'Condition',
        'position' => 1,
        'values' => array_map(
            static fn(string $condition): array => ['name' => $condition],
            array_values(array_unique($conditions))
        ),
    ]],
    'variants' => $variants,
];
if ($categoryId !== '') $input['category'] = $categoryId;
if ($seoInput !== []) $input['seo'] = $seoInput;

if ($imageSource !== '') {
    $input['files'] = [[
        'originalSource' => $imageSource,
        'contentType' => 'IMAGE',
        'alt' => $imageAlt,
    ]];
}

// productSet is a FULL REPLACE. With no id and no handle it can only create a
// new product, which is all this endpoint ever does — the restock path returns
// long before here. Never add id or handle to $input: productSet against an
// existing product replaces its options and variants with whatever is in the
// input, which is how the catalogue lost every multi-variant product on
// 28 July 2026. To change an existing product, use productUpdate; to add
// variants, use productVariantsBulkCreate.
if (isset($input['id']) || isset($input['handle'])) {
    json_response(['ok' => false, 'error' => 'Refusing to run productSet against an existing product: it would replace its variants.'], 500);
}

$mutation = <<<'GRAPHQL'
mutation CreateCardProduct($input: ProductSetInput!) {
  productSet(input: $input, synchronous: true) {
    product {
      id title handle status onlineStoreUrl
      seo { title description }
      category { id fullName }
      variants(first: 25) { nodes { id title sku price inventoryQuantity } }
    }
    userErrors { field message code }
  }
}
GRAPHQL;

try {
    $data = shopify_graphql($mutation, ['input' => $input]);
    $payload = $data['productSet'] ?? [];
    if (!empty($payload['userErrors'])) {
        $messages = array_map(
            static fn(array $error): string => implode('.', $error['field'] ?? []) . ': ' . ($error['message'] ?? 'Unknown error'),
            $payload['userErrors']
        );
        json_response(['ok' => false, 'error' => implode("\n", $messages), 'details' => $payload['userErrors']], 422);
    }
    $product = $payload['product'] ?? [];
    if (empty($product['id'])) throw new RuntimeException('Shopify did not return the created product.');

    $categoryMetafieldResult = ['requested' => count($shopifyCategoryMetafields), 'set' => 0, 'errors' => []];
    if ($shopifyCategoryMetafields !== [] && $categoryId !== '') {
        try {
            $metafieldInputs = array_map(
                static function (array $field) use ($product): array {
                    return [
                        'ownerId' => $product['id'],
                        'namespace' => $field['namespace'],
                        'key' => $field['key'],
                        'type' => $field['type'],
                        'value' => $field['value'],
                    ];
                },
                $shopifyCategoryMetafields
            );
            $metaData = shopify_graphql(<<<'GRAPHQL'
mutation SetCategoryMetafields($metafields: [MetafieldsSetInput!]!) {
  metafieldsSet(metafields: $metafields) {
    metafields { id namespace key }
    userErrors { field message code }
  }
}
GRAPHQL, ['metafields' => $metafieldInputs]);
            $metaPayload = $metaData['metafieldsSet'] ?? [];
            $categoryMetafieldResult['set'] = count($metaPayload['metafields'] ?? []);
            $categoryMetafieldResult['errors'] = array_map(
                static fn(array $error): string => implode('.', $error['field'] ?? []) . ': ' . ($error['message'] ?? 'Unknown error'),
                $metaPayload['userErrors'] ?? []
            );
        } catch (Throwable $metaError) {
            $categoryMetafieldResult['errors'][] = $metaError->getMessage();
        }
    }

    $publicationResult = ['requested' => count($publicationIds), 'published' => 0, 'errors' => []];
    if ($status === 'ACTIVE' && $publicationIds !== []) {
        try {
            $publishData = shopify_graphql(<<<'GRAPHQL'
mutation PublishCreatedProduct($id: ID!, $input: [PublicationInput!]!) {
  publishablePublish(id: $id, input: $input) {
    publishable {
      resourcePublicationsCount { count }
    }
    userErrors { field message }
  }
}
GRAPHQL, [
                'id' => $product['id'],
                'input' => array_map(static fn(string $id): array => ['publicationId' => $id], $publicationIds),
            ]);
            $publishPayload = $publishData['publishablePublish'] ?? [];
            $publicationResult['published'] = (int) ($publishPayload['publishable']['resourcePublicationsCount']['count'] ?? 0);
            $publicationResult['errors'] = array_map(
                static fn(array $error): string => ($error['message'] ?? 'Unknown publishing error'),
                $publishPayload['userErrors'] ?? []
            );
            // If Shopify returned no count but also no errors, treat requested channels as published.
            if ($publicationResult['published'] === 0 && $publicationResult['errors'] === [] && $publicationIds !== []) {
                $publicationResult['published'] = count($publicationIds);
            }
        } catch (Throwable $publishError) {
            $publicationResult['errors'][] = $publishError->getMessage();
        }
    }

    $product['adminUrl'] = shopify_admin_product_url((string) $product['id']);

    intake_log_append(intake_log_entry(
        'created',
        $product,
        $body,
        $variantRequests,
        array_sum(array_map(static fn(array $v): int => (int) $v['quantity'], $variantRequests)),
        $locationId,
        'New listing'
    ));

    json_response([
        'ok' => true,
        'action' => 'created',
        'kind' => $kind,
        'product' => $product,
        'publication' => $publicationResult,
        'categoryMetafields' => $categoryMetafieldResult,
        'tcgCardId' => $tcgCardId,
        'primaryCollectionId' => $primaryCollectionId,
        'catalogueLinks' => $links['linked'],
        'catalogueLinksMissing' => $links['missing'],
        'imageKind' => clean_text($image['kind'] ?? '', 20),
    ]);
} catch (Throwable $error) {
    json_response(['ok' => false, 'error' => $error->getMessage()], 502);
}
