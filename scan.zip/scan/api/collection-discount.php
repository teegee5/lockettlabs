<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/collection-discount.php';

api_guard(true);

// The export is a bulk operation taking minutes, so it is started and polled
// rather than waited on inside one request — same shape as the variant
// snapshot. Writing is then chunked because 264 metafieldsSet calls behind the
// IONOS gateway is what produced a 504 on the collection SEO run.
const COLLECTION_DISCOUNT_CACHE_KEY = 'collection-discount-map';
const COLLECTION_DISCOUNT_CACHE_TTL = 3600;
const COLLECTION_DISCOUNT_CHUNK     = 25;

$body   = request_json();
$action = clean_text($body['action'] ?? '', 20);

try {
    if ($action === 'start') {
        $current = variant_backup_poll();
        if (in_array($current['status'], ['CREATED', 'RUNNING'], true)) {
            json_response(['ok' => true, 'started' => false, 'status' => $current['status'],
                'message' => 'An export is already running; watching that one.']);
        }
        collection_discount_start();
        json_response(['ok' => true, 'started' => true, 'status' => 'CREATED']);
    }

    if ($action === 'status') {
        $state = variant_backup_poll();
        if ($state['status'] !== 'COMPLETED') {
            json_response(['ok' => true, 'done' => false, 'status' => $state['status'], 'objectCount' => $state['objectCount']]);
        }
        if ($state['url'] === '') {
            // A catalogue with nothing to report returns no file at all.
            json_response(['ok' => false, 'error' => 'The export completed but returned no file.'], 502);
        }

        $jsonl = file_get_contents($state['url']);
        if ($jsonl === false) {
            json_response(['ok' => false, 'error' => 'The export file could not be downloaded.'], 502);
        }

        $parsed = collection_discount_parse($jsonl);
        cache_write_json(COLLECTION_DISCOUNT_CACHE_KEY, ['collections' => $parsed['collections']]);

        // Only the collections that would actually earn a badge are worth
        // showing; the long tail of zeroes is noise in the panel.
        $preview = [];
        foreach ($parsed['collections'] as $row) {
            if ($row['pct'] > 0) $preview[] = $row;
        }
        usort($preview, static fn(array $a, array $b): int => $b['pct'] <=> $a['pct']);

        json_response([
            'ok'          => true,
            'done'        => true,
            'products'    => $parsed['products'],
            'discounted'  => $parsed['discounted'],
            'collections' => count($parsed['collections']),
            'withBadge'   => count($preview),
            'preview'     => array_slice($preview, 0, 40),
        ]);
    }

    if ($action === 'apply') {
        $cached = cache_read_json(COLLECTION_DISCOUNT_CACHE_KEY, COLLECTION_DISCOUNT_CACHE_TTL);
        $collections = $cached['collections'] ?? null;
        if (!is_array($collections) || $collections === []) {
            json_response(['ok' => false, 'error' => 'No scan stored. Run the scan first, then write.'], 400);
        }

        $offset = max(0, (int) ($body['offset'] ?? 0));
        $result = collection_discount_apply($collections, $offset, COLLECTION_DISCOUNT_CHUNK);
        $next   = $offset + COLLECTION_DISCOUNT_CHUNK;

        json_response([
            'ok'      => $result['errors'] === [],
            'done'    => $next >= count($collections),
            'offset'  => min($next, count($collections)),
            'total'   => count($collections),
            'written' => $result['written'],
            'errors'  => $result['errors'],
        ]);
    }

    json_response(['ok' => false, 'error' => 'Unknown action.'], 422);
} catch (Throwable $error) {
    json_response(['ok' => false, 'error' => $error->getMessage()], 502);
}
