<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/variant-backup.php';
api_guard(true);

$body = request_json();
$action = clean_text($body['action'] ?? '', 20);
// Writing a snapshot file is opt-in. "check" runs the same scan and reports
// collapsed products without leaving anything behind.
$save = ($body['save'] ?? null) === true;
$keepDays = max(0, min(365, (int) ($body['keepDays'] ?? 0)));

try {
    if ($action === 'list') {
        json_response(['ok' => true, 'snapshots' => variant_backup_list()]);
    }

    if ($action === 'start') {
        // A bulk operation already running would be clobbered by starting another.
        $current = variant_backup_poll();
        if ($current['status'] === 'RUNNING' || $current['status'] === 'CREATED') {
            json_response(['ok' => true, 'started' => false, 'status' => $current['status'], 'message' => 'An export is already running; watching that one.']);
        }
        variant_backup_start();
        json_response(['ok' => true, 'started' => true, 'status' => 'CREATED']);
    }

    if ($action === 'status') {
        $state = variant_backup_poll();
        if ($state['status'] !== 'COMPLETED') {
            json_response(['ok' => true, 'done' => false, 'status' => $state['status'], 'objectCount' => $state['objectCount']]);
        }
        if ($state['url'] === '') {
            json_response(['ok' => false, 'error' => 'The export completed but returned no file.'], 502);
        }

        $result = variant_backup_collect($state['url']);
        $path = '';
        if ($save) {
            $path = variant_backup_write($result['payload'], $keepDays);
        }

        json_response([
            'ok' => true,
            'done' => true,
            'status' => 'COMPLETED',
            'saved' => $path !== '',
            'file' => $path !== '' ? basename($path) : '',
            'counts' => [
                'products' => $result['products'],
                'variants' => $result['variants'],
                'collapsed' => count($result['collapsed']),
                'oversellable' => count($result['oversellable']),
            ],
            'collapsed' => $result['collapsed'],
            // Capped: the point is to know whether any exist and see examples,
            // not to stream thousands of rows into a browser panel.
            'oversellable' => array_slice($result['oversellable'], 0, 200),
        ]);
    }

    json_response(['ok' => false, 'error' => 'Unknown action.'], 422);
} catch (Throwable $error) {
    json_response(['ok' => false, 'error' => $error->getMessage()], 502);
}
