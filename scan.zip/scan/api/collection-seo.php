<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/collection-seo.php';

api_guard(true);

// 229 collectionUpdate calls in one request times out behind the IONOS
// gateway, so apply runs in chunks the browser drives. The dry run caches the
// plan it showed and each chunk writes a slice of it: the values still come
// from the server, and a chunk that dies can be retried without redoing the
// work before it.
const COLLECTION_SEO_PLAN_KEY = 'collection-seo-plan';
const COLLECTION_SEO_PLAN_TTL = 3600;
const COLLECTION_SEO_CHUNK    = 20;

$input = request_json();
$mode  = (string)($input['mode'] ?? 'dry-run');
$force = !empty($input['force']);

try {
    if ($mode !== 'apply') {
        $plan = collection_seo_plan($force);

        cache_write_json(COLLECTION_SEO_PLAN_KEY, ['planned' => $plan['planned']]);

        $reasons = [];
        foreach ($plan['skipped'] as $row) {
            $reasons[$row['reason']][] = $row['handle'];
        }

        json_response([
            'ok'      => true,
            'mode'    => 'dry-run',
            'planned' => $plan['planned'],
            'skipped' => count($plan['skipped']),
            'reasons' => array_map(
                static fn(array $handles): array => ['count' => count($handles), 'handles' => array_slice($handles, 0, 25)],
                $reasons
            ),
        ]);
    }

    $cached = cache_read_json(COLLECTION_SEO_PLAN_KEY, COLLECTION_SEO_PLAN_TTL);
    $planned = $cached['planned'] ?? null;
    if (!is_array($planned) || $planned === []) {
        json_response(['ok' => false, 'error' => 'No plan stored. Run a dry run first, then apply.'], 400);
    }

    $offset = max(0, (int)($input['offset'] ?? 0));
    $chunk  = array_slice($planned, $offset, COLLECTION_SEO_CHUNK);

    if ($chunk === []) {
        json_response(['ok' => true, 'mode' => 'apply', 'done' => true, 'offset' => $offset, 'total' => count($planned), 'updated' => 0, 'errors' => []]);
    }

    $result = collection_seo_apply($chunk);
    $next   = $offset + count($chunk);

    json_response([
        'ok'      => $result['errors'] === [],
        'mode'    => 'apply',
        'done'    => $next >= count($planned),
        'offset'  => $next,
        'total'   => count($planned),
        'updated' => $result['updated'],
        'errors'  => $result['errors'],
    ]);
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}
