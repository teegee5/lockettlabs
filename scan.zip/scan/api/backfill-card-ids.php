<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/backfill.php';
api_guard(true);

$body = request_json();
$setTag = clean_text($body['tag'] ?? '', 120);
$language = ($body['language'] ?? '') === 'ja' ? 'ja' : 'en';
$force = !empty($body['force']);
// Writing is never the default. The browser has to ask for it explicitly, and
// the page only sends it after the operator has seen a dry run.
$apply = ($body['apply'] ?? null) === true;
$cursor = clean_text($body['cursor'] ?? '', 500);
if ($cursor === '') $cursor = null;

if ($setTag === '') {
    json_response(['ok' => false, 'error' => 'Enter the set tag to process.'], 422);
}

try {
    $page = backfill_fetch_page($setTag, $cursor);
} catch (Throwable $error) {
    json_response(['ok' => false, 'error' => 'Shopify lookup failed: ' . $error->getMessage()], 502);
}

$outcome = backfill_resolve_page($page['nodes'], $setTag, $language, $force);
$written = 0;
$cleared = 0;
$errors = [];
if ($apply) {
    $result = backfill_write($outcome['resolved']);
    $written = $result['written'];
    $errors = $result['errors'];
    if ($force) {
        $clearResult = backfill_clear($outcome['unresolved']);
        $cleared = $clearResult['cleared'];
        $errors = array_merge($errors, $clearResult['errors']);
    }
}

json_response([
    'ok' => true,
    'applied' => $apply,
    'tag' => $setTag,
    'hasNextPage' => $page['hasNextPage'],
    'cursor' => $page['cursor'],
    'counts' => [
        'seen' => count($page['nodes']),
        'resolved' => count($outcome['resolved']),
        'skipped' => count($outcome['skipped']),
        'unresolved' => count($outcome['unresolved']),
        'written' => $written,
        'cleared' => $cleared,
        'clearable' => $force ? count(array_filter(
            $outcome['unresolved'],
            static fn(array $row): bool => ($row['existing'] ?? '') !== ''
        )) : 0,
    ],
    'resolved' => $outcome['resolved'],
    'unresolved' => $outcome['unresolved'],
    'errors' => $errors,
]);
