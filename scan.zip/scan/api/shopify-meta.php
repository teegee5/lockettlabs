<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
api_guard();

$ttl = max(0, min(21600, (int) (app_config()['shopify_meta_cache_seconds'] ?? 3600)));
$cacheKey = 'shopify-meta-v7:' . (string) (app_config()['shopify_store'] ?? '');
if ($ttl > 0) {
    $cached = cache_read_json($cacheKey, $ttl);
    if (is_array($cached) && !empty($cached['ok'])) {
        $cached['cached'] = true;
        $cached['cacheTtl'] = $ttl;
        json_response($cached);
    }
}

$warnings = [];
$response = [
    'ok' => true,
    'cached' => false,
    'cacheTtl' => $ttl,
    'shop' => null,
    'collections' => [],
    'locations' => [],
    'vendors' => [],
    'productTypes' => [],
    'tags' => [],
    'publications' => [],
    'categories' => [],
    'preferredCategoryId' => '',
    'categoryMetafieldDefinitions' => [],
    'categoryOptions' => [],
];

try {
    $data = shopify_graphql(<<<'GRAPHQL'
query ScannerSetupCore {
  shop { name currencyCode primaryDomain { url } }
  locations(first: 100, sortKey: NAME) { nodes { id name isActive } }
}
GRAPHQL);
    $response['shop'] = $data['shop'] ?? null;
    // The store has more than 250 collections, and the set collections that
    // breadcrumbs and description links point at were past the first page.
    $collections = [];
    $after = null;
    for ($page = 0; $page < 8; $page++) {
        $pageData = shopify_graphql(<<<'GRAPHQL'
query ScannerCollections($after: String) {
  collections(first: 250, sortKey: TITLE, after: $after) {
    nodes { id title handle ruleSet { appliedDisjunctively } }
    pageInfo { hasNextPage endCursor }
  }
}
GRAPHQL, ['after' => $after]);
        foreach ($pageData['collections']['nodes'] ?? [] as $node) $collections[] = $node;
        if (empty($pageData['collections']['pageInfo']['hasNextPage'])) break;
        $after = (string) ($pageData['collections']['pageInfo']['endCursor'] ?? '');
    }
    // Smart collections fill themselves from tag/vendor/type rules and reject
    // manual product adds, so the editor must know which ones to leave alone.
    $response['collections'] = array_map(
        static function (array $collection): array {
            $collection['smart'] = isset($collection['ruleSet']) && is_array($collection['ruleSet']);
            unset($collection['ruleSet']);
            return $collection;
        },
        $collections
    );
    $response['locations'] = array_values(array_filter(
        $data['locations']['nodes'] ?? [],
        static fn(array $location): bool => !empty($location['isActive'])
    ));
} catch (Throwable $error) {
    json_response(['ok' => false, 'error' => $error->getMessage()], 502);
}

try {
    $data = shopify_graphql(<<<'GRAPHQL'
query ScannerLiveProductValues {
  productVendors(first: 1000) { nodes }
  productTypes(first: 1000) { nodes }
  productTags(first: 1000) { nodes }
}
GRAPHQL);
    $response['vendors'] = $data['productVendors']['nodes'] ?? [];
    $response['productTypes'] = $data['productTypes']['nodes'] ?? [];
    $response['tags'] = $data['productTags']['nodes'] ?? [];
} catch (Throwable $error) {
    $warnings[] = 'Shopify vendor/type/tag lists could not load: ' . $error->getMessage();
}

try {
    $data = shopify_graphql(<<<'GRAPHQL'
query ScannerPublications {
  publications(first: 100) {
    nodes { id name autoPublish supportsFuturePublishing catalog { id title } }
  }
}
GRAPHQL);
    $response['publications'] = $data['publications']['nodes'] ?? [];
} catch (Throwable $error) {
    $warnings[] = 'Sales channels could not load. Add read_publications/write_publications to the custom app: ' . $error->getMessage();
}

$preferredCategoryId = '';
try {
    $data = shopify_graphql(<<<'GRAPHQL'
query ScannerTaxonomyCategories {
  taxonomy {
    categories(first: 50, search: "Gaming Cards") {
      nodes {
        id name fullName isLeaf isArchived
      }
    }
  }
}
GRAPHQL);
    $categories = array_values(array_filter(
        $data['taxonomy']['categories']['nodes'] ?? [],
        static fn(array $category): bool => empty($category['isArchived'])
    ));
    $response['categories'] = $categories;

    // Prefer Collectible Trading Cards > Gaming Cards (leaf) over broader matches.
    foreach ($categories as $category) {
        $fullName = (string) ($category['fullName'] ?? '');
        $name = (string) ($category['name'] ?? '');
        if (
            preg_match('/collectible trading cards/i', $fullName)
            && preg_match('/gaming cards/i', $name)
            && !empty($category['isLeaf'])
            && !empty($category['id'])
        ) {
            $preferredCategoryId = (string) $category['id'];
            break;
        }
    }
    if ($preferredCategoryId === '') {
        foreach ($categories as $category) {
            $fullName = (string) ($category['fullName'] ?? '');
            if (
                preg_match('/collectible trading cards.*gaming cards/i', $fullName)
                && !empty($category['id'])
            ) {
                $preferredCategoryId = (string) $category['id'];
                break;
            }
        }
    }
    if ($preferredCategoryId === '') {
        foreach ($categories as $category) {
            if (strcasecmp((string) ($category['name'] ?? ''), 'Gaming Cards') === 0 && !empty($category['id'])) {
                $preferredCategoryId = (string) $category['id'];
                break;
            }
        }
    }
    $response['preferredCategoryId'] = $preferredCategoryId;
} catch (Throwable $error) {
    $warnings[] = 'Shopify taxonomy data could not load: ' . $error->getMessage();
}

try {
    if ($preferredCategoryId !== '') {
        // Only definitions that apply to the Gaming Cards owner subtype.
        // constraintSubtype.value is String! (TaxonomyCategory GID as string), not ID!.
        $data = shopify_graphql(<<<'GRAPHQL'
query ScannerCategoryMetafieldDefinitions($categoryId: String!) {
  metafieldDefinitions(
    first: 100,
    ownerType: PRODUCT,
    query: "namespace:shopify",
    constraintSubtype: { key: "category", value: $categoryId },
    constraintStatus: CONSTRAINED_ONLY
  ) {
    nodes {
      id name namespace key type { name }
      constraints {
        key
        values(first: 50) { nodes { value } }
      }
    }
  }
}
GRAPHQL, ['categoryId' => (string) $preferredCategoryId]);
        $response['categoryMetafieldDefinitions'] = $data['metafieldDefinitions']['nodes'] ?? [];
    } else {
        $warnings[] = 'Could not resolve Gaming Cards taxonomy category; category metafields will stay in manual fallback mode.';
    }
} catch (Throwable $error) {
    $warnings[] = 'Shopify category metafield definitions could not load: ' . $error->getMessage();
}

try {
    $data = shopify_graphql(<<<'GRAPHQL'
query ScannerCategoryOptions {
  colorPattern: metaobjects(type: "shopify--color-pattern", first: 100) { nodes { id displayName } }
  toyGameMaterial: metaobjects(type: "shopify--toy-game-material", first: 100) { nodes { id displayName } }
  cardAttributes: metaobjects(type: "shopify--card-attributes", first: 100) { nodes { id displayName } }
  condition: metaobjects(type: "shopify--condition", first: 100) { nodes { id displayName } }
  grading: metaobjects(type: "shopify--grading", first: 100) { nodes { id displayName } }
  productUse: metaobjects(type: "shopify--product-use", first: 100) { nodes { id displayName } }
  rarity: metaobjects(type: "shopify--rarity", first: 100) { nodes { id displayName } }
  ageGroup: metaobjects(type: "shopify--age-group", first: 100) { nodes { id displayName } }
  theme: metaobjects(type: "shopify--theme", first: 100) { nodes { id displayName } }
  tradingCardPackaging: metaobjects(type: "shopify--trading-card-packaging", first: 100) { nodes { id displayName } }
}
GRAPHQL);
    foreach (is_array($data) ? $data : [] as $key => $connection) {
        $response['categoryOptions'][$key] = is_array($connection) ? ($connection['nodes'] ?? []) : [];
    }
} catch (Throwable $error) {
    $warnings[] = 'Standard category value lists could not load. Add read_metaobjects to the custom app; manual values remain available: ' . $error->getMessage();
}

$response['warnings'] = $warnings;
if ($ttl > 0) cache_write_json($cacheKey, $response);
json_response($response);
