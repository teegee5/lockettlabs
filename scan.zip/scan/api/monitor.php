<?php
declare(strict_types=1);

/**
 * Price monitor API.
 *
 *   GET  ?action=runs                          every saved set run, newest first
 *   GET  ?action=last&set=Pitch Black          the last saved run for a set
 *   GET  ?action=page&set=…&game=…&after=…     compare one page of our listings
 *   GET  ?action=history&key=…                 one printing's price history
 *   POST ?action=save   { set, game, rows }    keep a finished run
 */

require_once __DIR__ . '/../lib/monitor.php';
api_guard();

$action = (string) ($_GET['action'] ?? 'runs');

try {
    if ($action === 'runs') {
        json_response(['ok' => true, 'runs' => monitor_list_runs()]);
    }

    if ($action === 'last') {
        $set = clean_text($_GET['set'] ?? '', 120);
        json_response(['ok' => true, 'run' => $set !== '' ? monitor_load_run($set) : null]);
    }

    if ($action === 'page') {
        $set = clean_text($_GET['set'] ?? '', 120);
        if ($set === '') json_response(['ok' => false, 'error' => 'Choose a set.'], 422);
        $game = strtolower(clean_text($_GET['game'] ?? 'pokemon', 80));
        $after = clean_text($_GET['after'] ?? '', 400);
        @set_time_limit(60);
        $page = monitor_compare_page($set, $game, $after, [
            'setName' => clean_text($_GET['setName'] ?? $set, 120),
            'record' => true,
            'size' => (int) ($_GET['size'] ?? MONITOR_PAGE_SIZE),
        ]);
        json_response(['ok' => true] + $page);
    }

    if ($action === 'history') {
        $key = clean_text($_GET['key'] ?? '', 300);
        json_response(['ok' => true, 'history' => price_history_series($key, max(7, min(180, (int) ($_GET['days'] ?? 90))))]);
    }

    if ($action === 'save') {
        api_guard(true);
        $body = request_json();
        $set = clean_text($body['set'] ?? '', 120);
        $rows = is_array($body['rows'] ?? null) ? array_slice($body['rows'], 0, 2000) : [];
        if ($set === '') json_response(['ok' => false, 'error' => 'Choose a set.'], 422);
        $summary = [
            'set' => $set,
            'game' => clean_text($body['game'] ?? '', 80),
            'at' => time(),
            'counts' => monitor_counts($rows),
            'rows' => $rows,
        ];
        monitor_save_run($set, $summary);
        json_response(['ok' => true, 'counts' => $summary['counts']]);
    }

    json_response(['ok' => false, 'error' => 'Unknown monitor action.'], 400);
} catch (Throwable $error) {
    json_response(['ok' => false, 'error' => $error->getMessage()], 502);
}
