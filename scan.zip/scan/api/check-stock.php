<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/shopify-inventory.php';
api_guard(true);

$body = request_json();
$locationId = clean_text($body['locationId'] ?? '', 120);
$identity = is_array($body['identity'] ?? null) ? $body['identity'] : $body;
$variantRequests = [];
foreach (is_array($body['variants'] ?? null) ? $body['variants'] : [] as $variant) {
    if (!is_array($variant) || (array_key_exists('enabled', $variant) && empty($variant['enabled']))) continue;
    $condition = clean_text($variant['condition'] ?? '', 60);
    $sku = clean_text($variant['sku'] ?? '', 100);
    if ($condition === '' || $sku === '') {
        json_response(['ok' => false, 'error' => 'Each selected condition needs a condition name and SKU.'], 422);
    }
    $variantRequests[] = ['condition' => $condition, 'sku' => $sku, 'quantity' => 0];
}

// Preserve compatibility with older cached clients. Exact-SKU resolution still
// works for these requests, while title matching requires the richer payload.
if ($variantRequests === []) {
    foreach (is_array($body['skus'] ?? null) ? $body['skus'] : [] as $sku) {
        $sku = clean_text($sku, 100);
        if ($sku !== '') $variantRequests[] = ['condition' => '', 'sku' => $sku, 'quantity' => 0];
    }
}
if ($variantRequests === []) {
    json_response(['ok' => false, 'error' => 'Enable at least one condition before checking Shopify stock.'], 422);
}
if (count($variantRequests) > 25) {
    json_response(['ok' => false, 'error' => 'Too many conditions were supplied for one stock check.'], 422);
}

$preferredProductId = clean_text($body['preferredProductId'] ?? $body['existingProductId'] ?? '', 120);
$forceCreateNew = !empty($body['forceCreateNew']);

try {
    $resolution = shopify_resolve_card_stock(
        $identity,
        $variantRequests,
        $locationId,
        $preferredProductId,
        $forceCreateNew
    );
    json_response(['ok' => true] + $resolution);
} catch (InvalidArgumentException $error) {
    json_response(['ok' => false, 'error' => $error->getMessage()], 422);
} catch (Throwable $error) {
    json_response(['ok' => false, 'error' => $error->getMessage()], 502);
}
