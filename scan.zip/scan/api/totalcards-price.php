<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/totalcards.php';
api_guard();

$number = clean_text($_GET['number'] ?? '', 40);
$game = strtolower(clean_text($_GET['game'] ?? 'one-piece-card-game', 80));
$cardName = clean_text($_GET['name'] ?? '', 120);
$setName = clean_text($_GET['set'] ?? '', 120);

if ($number === '') {
    json_response(['ok' => false, 'error' => 'Enter a printed card number.'], 422);
}

try {
    $result = totalcards_lookup($number, $game, $cardName, $setName);
    json_response($result);
} catch (Throwable $error) {
    json_response([
        'ok' => true,
        'matched' => false,
        'priceGbp' => null,
        'priceGbpRaw' => null,
        'title' => '',
        'url' => '',
        'handle' => '',
        'sku' => '',
        'available' => null,
        'rarity' => '',
        'error' => $error->getMessage(),
    ]);
}
