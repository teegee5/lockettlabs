<?php
declare(strict_types=1);

/**
 * Fetch an image from another site so the scan editor can work on it.
 *
 * The browser cannot read pixels from another site's image (and the page's
 * content policy only lets it talk to this server), so a scan found on a
 * card database is pulled through here. Public https addresses only; every
 * redirect is re-checked; the bytes must actually be an image.
 *
 * POST JSON { url } -> the image itself, with its real content type.
 */

require_once __DIR__ . '/../lib/media.php';
api_guard(true);

$body = request_json();
$url = trim((string) ($body['url'] ?? ''));
if ($url === '' || strlen($url) > 2000) {
    json_response(['ok' => false, 'error' => 'Paste the address of an image.'], 422);
}

try {
    [$bytes, $mime] = media_fetch_remote_image($url);
} catch (InvalidArgumentException $error) {
    json_response(['ok' => false, 'error' => $error->getMessage()], 422);
} catch (Throwable $error) {
    json_response(['ok' => false, 'error' => $error->getMessage()], 502);
}

if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif'], true)) {
    json_response(['ok' => false, 'error' => 'That image format cannot be used.'], 422);
}

http_response_code(200);
header('Content-Type: ' . $mime);
header('Content-Length: ' . strlen($bytes));
header('Cache-Control: private, max-age=600');
header('X-Content-Type-Options: nosniff');
header("Content-Security-Policy: default-src 'none'");
echo $bytes;
