<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
api_guard(true);

/**
 * Turn a staff password into a hash to paste into config.php.
 *
 * The same job as tools/hash-password.php, for hosting with no shell. IONOS
 * shared plans generally have no SSH, and telling someone to run a command
 * they cannot run is the same as not offering the fix at all. Every other
 * maintenance job in this project has both a browser and a command line route
 * for exactly that reason.
 *
 * What this does NOT do, deliberately:
 *
 *   - store the password anywhere, in the session, the cache or a log
 *   - store the hash either; it is returned once and forgotten
 *   - accept GET, which would put the password in the URL and therefore in
 *     the server access log and the browser's history
 *
 * It is already behind the staff session and a CSRF token, so the only person
 * who can reach it is someone who is signed in, and all they get back is a
 * hash of a password they typed themselves.
 */

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_response(['ok' => false, 'error' => 'Use POST. A password must never travel in a URL.'], 405);
}

$body = request_json();
$password = (string) ($body['password'] ?? '');

// Not clean_text(): that collapses whitespace, and a space is a perfectly
// good character in a password.
if ($password === '') {
    json_response(['ok' => false, 'error' => 'Enter the staff password.'], 422);
}
if (strlen($password) < 12) {
    // This guards one tool used by the whole shop, reachable from the open
    // internet, with no second factor behind it.
    json_response(['ok' => false, 'error' => 'Use at least 12 characters.'], 422);
}
if (strlen($password) > 4096) {
    // bcrypt truncates at 72 bytes anyway; this is only to refuse something
    // absurd rather than hand it to the hasher.
    json_response(['ok' => false, 'error' => 'That password is unreasonably long.'], 422);
}

$hash = password_hash($password, PASSWORD_DEFAULT);
if (!is_string($hash) || $hash === '' || !password_verify($password, $hash)) {
    json_response(['ok' => false, 'error' => 'This PHP build could not hash the password.'], 500);
}

json_response([
    'ok' => true,
    'hash' => $hash,
    'line' => "    'admin_password' => '" . $hash . "',",
    'algo' => (string) (password_get_info($hash)['algoName'] ?? 'unknown'),
]);
