const CACHE = 'lockett-labs-card-intake-v5.44-sku-collision';
const ASSETS = [
  'assets/app.css?v=5.44-sku-collision',
  'assets/app.js?v=5.44-sku-collision',
  'assets/icon.svg',
  'manifest.webmanifest'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE).then(cache => cache.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  // Never trap HTML navigations or PHP/API — those must hit the network
  // (stale cached index.php / meta endpoints keep pills on "Connecting…").
  if (
    event.request.method !== 'GET' ||
    event.request.mode === 'navigate' ||
    url.origin !== self.location.origin ||
    url.pathname.includes('/api/') ||
    url.pathname.endsWith('.php')
  ) {
    return;
  }

  // Network-first for app shell so same-day boot fixes are not trapped.
  const isAppAsset = /\/assets\/(app\.(js|css)|backfill\.js)$/.test(url.pathname);
  if (isAppAsset) {
    event.respondWith(
      fetch(event.request)
        .then(response => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(CACHE).then(cache => cache.put(event.request, copy));
          }
          return response;
        })
        .catch(() => caches.match(event.request).then(cached => cached || Response.error()))
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
      if (response.ok) {
        caches.open(CACHE).then(cache => cache.put(event.request, response.clone()));
      }
      return response;
    }))
  );
});
