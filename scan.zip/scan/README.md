# Lockett Labs Card Intake v5.43-speed-and-log

Staff-only card catalogue search and Shopify intake for desktop, iPad and mobile.

## What this release does

- searches every supported game through the JustTCG v1 API
- enforces exact printed card numbers before a result can be selected
- keeps the existing eBay UK live and sold searches
- converts JustTCG USD reference prices to GBP on the server
- hides all JustTCG price figures if the GBP reference rate is unavailable
- **pre-fills Shopify descriptions** from JustTCG `details` when present, Scryfall oracle text for Magic cards with a Scryfall ID, plus the catalogue identity (name, set, number, rarity) and the existing packing note
- **suggests GBP market prices** into condition variants so staff only adjust outliers
- **auto-advances to the next card** after create/restock while keeping game, set, location and status
- **auto-selects** a single high-confidence exact match
- **derives tags, collections and product type from the selected card alone**, so nothing carries over between cards (see Autofill rules)
- **fills breadcrumb collection, set release date and the TCGdex card id** so new products land where the storefront expects them
- **writes the SEO title and description** in the store house format, and refreshes the title when a restock changes the price
- caches Shopify setup metadata (collections, taxonomy, channels) to cut boot time
- remembers last game, set, location and status between cards
- collapses tags / taxonomy / channels behind an optional section for faster intake
- checks Shopify by exact SKU first, then by card title, name, set, printed number, finish and condition
- detects older Shopify products whose variants have no SKU
- automatically uses only strong, unambiguous matches and asks staff to confirm close matches
- shows the existing Shopify product image, title, status, location stock and condition variants before confirmation
- requires explicit confirmation for every restock, including exact-SKU matches
- replaces the full listing editor with a condition-and-quantity-only restock view after confirmation
- adds received quantity to matching Shopify stock instead of replacing it
- re-checks inventory on the server before every create or restock action
- uses Shopify idempotency keys for safe inventory retries
- sends Shopify's required `changeFromQuantity` value so concurrent stock changes fail safely instead of applying against stale inventory
- creates a new Shopify product only when no safe existing-product match exists or staff rejects every candidate
- removes camera capture, OCR and the third-party Tesseract dependency
- **writes an intake log** and shows today's count in the workbar, so a card that has been booked in stays findable after the screen resets
- **opens the first connection to each retailer at the same time** rather than one after the other, and reads the Chaos Cards snapshot before attempting a route that is known to be dead
- **prunes the cache**, which had never had anything deleted from it
- **accepts a hashed staff password** and locks an address out after repeated failures

## High-volume intake tips

1. Search by printed number with the set left filled from the previous card.
2. Confirm price against eBay UK only when the suggested GBP figure looks wrong.
3. After upload, the app returns to identify with the same set — press `N` to force next card.
4. Keep JustTCG plan capacity above daily search volume (Free is ~100 requests/day).
5. Optionally raise `justtcg_search_cache_seconds` and `shopify_meta_cache_seconds` in `config.php`.

## Title and SKU rules

Both are derived from the live catalogue (16,557 products), not from taste.

### Title

```
<Card Name> : <SET IN CAPS>[ (<Finish>)] - <local>/<total>
```

- **Collector numbers are zero-padded to three digits.** Every set since
  Evolving Skies is 100% padded (1,096 products, no exceptions). The unpadded
  titles in the store are legacy sets.
- **The finish sits after the set, inside brackets, before the dash.**
- **Finish wording is `Reverse holo`, not `Reverse Holo`.** The store uses the
  lower-case spelling 5,164 times against 19 for the capitalised one. Mixing
  them fragments any collection or filter keyed on the title.

Promos keep their code instead of a number: `Grookey : PROMO (Holo) - SWSH070`.
Disney Lorcana keeps its own house format and is handled separately.

### SKU

```
LL-<GAME>-<SET>-<NUM>-<FINISH>-<CONDITION>     e.g. LL-PKM-LOR-080-RH-NM
```

SKU is the key Shopify restocks match on, so it is built **only from stable
identifiers**. Nothing in it comes from a field staff can edit.

The previous scheme was not stable. It read the set from `titleSet()`, which
falls back to an editable input, so two spellings of a set produced two SKUs for
one card. It passed the collector number through raw, so `080/196` and
`80/196` diverged. And it pasted full names together then cut at 100
characters, which "Dungeons & Dragons: Adventures in the Forgotten Realms"
already exceeds at 102.

**Note:** all 16,557 existing variants have an empty SKU, so the SKU-matched
restock path only fires for products this tool created. A backfill would fix
that for the back catalogue.

## Autofill rules

Tags, collections, vendor and product type are rebuilt from scratch each time a card is selected, from that card only.

Product type comes from the game: `Pokemon`, `MTG`, `Disney`, `One Piece`, `Digimon`, `Yu-Gi-Oh!`. It is never `Single Card` — that is a tag, not a type.

Tags:

| Game | Tags |
| --- | --- |
| Pokémon (English) | `Single Cards`, set tag, era tag — nothing else |
| Pokémon (Japanese) | `Single Cards`, set tag, `Japanese <era>`, `Japanese` |
| Magic | `Single Cards`, set name, `Magic the Gathering` |
| Disney Lorcana | `Single Cards`, set name, `Disney Lorcana` |
| One Piece | `Single Cards`, set name, `One Piece Card Game`, set code, printed language |

Pokémon set and era tags come from the table in `assets/app.js` (`POKEMON_ERAS_EN` / `POKEMON_ERAS_JA`), which uses the store's own tag spellings. So `Pitch Black` gets `Mega Evolution`, `Evolutions` gets `XY`, and `Base Set 2` gets `Base Set`. The base set of an era is tagged `<Era> (Base)`, matching the existing smart collections. An unknown set keeps its own name and gets **no** era tag — a guessed era would file the card into the wrong smart collection.

Rarity, finish and language are no longer tagged (except One Piece, which already used them). Changing the finish no longer rewrites tags, so manual tag edits survive.

### Collections

Almost every set, era and game collection on the store is a **smart** collection driven by `TAG EQUALS`, and the store-wide `POKÉMON` collection is driven by `VENDOR EQUALS Pokémon`. Shopify rejects manual product adds to smart collections, so the picker now lists **manual collections only**. Getting the tags and vendor right is what files a card into the right collections.

Manual collections are auto-selected only on an exact title match against one of the card's own tags. There is no substring matching.

### Metafields filled at creation

| Metafield | Source |
| --- | --- |
| `custom.primary_collection` | The collection matching the card's set tag, else its era tag. Drives storefront breadcrumbs. |
| `custom.release_date` | The JustTCG release date for the card's set. |
| `custom.tcg_card_id` | Resolved live from TCGdex (`lib/tcgdex.php`). Pokémon only. |
| `shopify.*` | Category attributes as before (rarity, condition, card attributes, packaging…). |
| `tcg.*` | Catalogue identity as before (set, number, provider ids, market price…). |

`custom.tcg_card_id` matters because the product page's card-details panel reads it first and only falls back to parsing the image filename — and images uploaded through this app get a Shopify-generated filename, so that fallback does not work for new products. The resolver fails closed: the TCGdex set must match one of the card's set names exactly, and the printed local number must match a card in that set. Anything less leaves the metafield unset rather than pointing at the wrong card. Japanese sets usually will not resolve, because TCGdex indexes them under Japanese names.

The editor shows the resolved product type, breadcrumb collection and set release date under the card image before you submit, and the success message reports the TCGdex id that was stored.

### Backfilling older products

Products created before the app started writing `custom.tcg_card_id` fall back to image-filename parsing on the storefront, which resolves the wrong card on some sets. Both tools below share `lib/backfill.php`, so they behave identically and use the same fail-closed matching as the intake app.

**In the browser** — `backfill.php`, linked as *Card ID backfill* in the intake header. Same staff password, works on any device, no PHP install or SSH needed.

1. Type the set tag (the box suggests tags that exist in Shopify).
2. **Dry run.** Nothing is written. You get counts plus a per-product list of every id it would write and everything it could not resolve.
3. Read the list, then **Apply to Shopify**. Apply stays disabled until a dry run has finished for the set currently in the box, and it asks for confirmation before writing.

Work runs a page of 100 products at a time so it stays inside shared-hosting execution limits, with a **Stop** button between pages.

**On the command line** — the same job for bulk runs over SSH:

```bash
php tools/backfill-tcg-card-id.php --tag="Pitch Black"
```

Dry run by default; add `--apply` to write. Products that already have an id are skipped unless you pass `--force`. Use `--language=ja` for Japanese sets and `--limit=N` to try a handful first.

Always read the dry run before applying. An unresolved product is safe — it is left exactly as it was. Spot-check a couple of resolved ids at `https://api.tcgdex.net/v2/en/cards/<id>` before applying to a set for the first time.

#### How a set is decided

**Each product's set comes from the product itself** — its `tcg.english_set_name` / `tcg.set_name` metafields, else the set segment of its title. The tag you type only chooses which products to process. This matters because era names such as `Sword & Shield` and `Mega Evolution` are themselves real TCGdex sets: trusting the typed tag filed every card in an era against that era's base set. Because the set is now per product, running against an era tag is safe and resolves each card to its own set.

#### Three guards

Every one of these must pass before an id is written, and each alone is enough to stop a wrong set match:

1. **Set name** matches a TCGdex set exactly, with candidates tried in priority order rather than taking whichever set the API lists first.
2. **Printed denominator** matches that set's card count. A card printed `010/198` cannot belong to a 202-card set.
3. **Card name** at that number matches the product's card name. This is what catches a plausible-but-wrong set.

`tests/tcgdex.php` and `tests/backfill.php` cover all three, including the two real regressions that motivated them.

#### Clearing stale ids

With **force**, a product whose id cannot be re-derived has its metafield **deleted** rather than left in place. If a re-run cannot resolve a product, whatever is stored is untrustworthy: an empty metafield lets the storefront fall back cleanly, a wrong one shows another card's details.

Completed so far: **Pitch Black** (106 singles, 29 July 2026).

### Variant snapshots

Shopify has no undo for deleted variants. A `productSet` call without a variants array is a full replace: on 28 July 2026 one collapsed every multi-variant product in the catalogue to a single variant, and recovering 60 products took a day of reconstruction from the Wayback Machine, order history and published set line-ups. Inventory quantities were unrecoverable, because nothing had ever recorded them.

Two ways to run it, sharing `lib/variant-backup.php` so they cannot drift.

**In the browser** — the *Variant snapshots* panel on `backfill.php` (linked as *Card ID backfill* in the intake header). **Scan only** reports collapsed products and writes nothing; **Take snapshot** also saves the file. The export is a bulk operation taking a couple of minutes, so the page starts it and polls, showing the record count as it goes — no PHP timeout. Stored snapshots are listed underneath with their date, counts and size.

**On the command line**, for the unattended nightly copy:

```bash
php tools/backup-variants.php --keep=30
```

It writes every product's variants, SKUs, prices and **inventory quantities** to `cache/variant-backups/`, so the next bad write is a restore from file. Run it nightly:

```text
0 3 * * * /usr/bin/php /path/to/tools/backup-variants.php --keep=30
```

It also reports the damage signature — an option describing a range (`Style`, `Coin Type`, `Tin Type`) with only one variant left. Exit code is `2` when anything is collapsed, `0` when clean, which is enough for cron to email you.

`Title` and `Condition` are ignored, and that exclusion matters. `Title` is Shopify's placeholder for a genuinely single-variant product. `Condition` is the intake app's own option — it creates one variant per condition actually held, so a lone Near Mint variant is the normal state across ~14k card singles. Without that exclusion the first live run flagged 114 products of which only 3 were real, which buries the signal completely.

To check without writing a snapshot:

```bash
php tools/backup-variants.php --check
```

Restoring from a snapshot uses `productVariantsBulkCreate`, which only appends. **Never use `productSet` to repair a product** — that is the mutation that caused the damage.

### Search engine listing

The app owns `seo.title` and `seo.description`. Both are built in the store house format and shown in the optional section, where they can be edited per card; an edited value is kept and not overwritten.

```text
Lampent 037/084 Pitch Black Reverse Holo | £0.65 In Stock UK
Buy Lampent Reverse Holo (037/084) from Pitch Black, a single Pokémon card in mint or near-mint condition. Securely packed, fast UK delivery.
```

The title is `{name} {number} {set} {finish} | £{Near Mint price} In Stock UK`, capped at 70 characters. When it does not fit, trailing detail is dropped in order — finish, then set, then number — so the line is never cut mid-word. The description follows the same drop order and is capped at 160 characters. The set is written in the store's own casing (`Pitch Black`), not the upper-case form used in the product title.

Because the title quotes the Near Mint price, it is rebuilt whenever that price changes: market fill, competitor suggestion, manual edit, or a restock that pulls a different price from Shopify. A restock that changes the price also rewrites the live product's SEO title, so a repriced card does not keep a stale figure in search results.

## Shopify stock behaviour

The app first checks the deterministic SKU generated by earlier releases. If no SKU matches, it searches Shopify product titles and compares the card name, set name and exact printed card number. Existing `tcg` metafields, finish and condition options strengthen the result when available, but older products do not need those fields or a SKU to be detected.

A strong, unique card-number/name/set result is selected automatically as the suggested product, but it is never restocked automatically. The editor displays Shopify's product image, title, status, storefront/admin links, location stock and matched conditions for confirmation. Close results use the same preview. Staff can confirm that none of the title-based suggestions match and create a separate listing; exact-SKU safeguards still run at submission time.

After confirmation, title, pricing, tags, collections, taxonomy, publishing and other product-creation controls are removed from the screen. Only condition selection, received quantity, current/projected stock and the additive stock button remain.

If Shopify contains quantity `3` and the intake quantity is `1`, the app sends a `+1` inventory adjustment and the result is `4`. It never sends `1` as a replacement total.

For safety, submission stops when:

- the same SKU exists more than once in Shopify
- enabled condition SKUs are split across existing and missing variants
- matching SKUs belong to different products
- a possible title match has not yet been confirmed or rejected

The browser check is informative. `api/create-product.php` repeats the lookup and treats the server result as authoritative.

## GBP reference pricing

JustTCG supplies USD market prices for every catalogue game. The server obtains a cached USD/GBP daily reference rate from the key-free Frankfurter v2 API and converts every visible market figure to GBP. The original USD values are not displayed or written to the GBP market-price metafield.

If the rate service cannot be reached and no valid cache exists, JustTCG market prices are removed from the response. eBay UK live and sold links remain available for price checking.

## Market vs UK retail (all TCGs)

On every card select the price board shows:

1. **JustTCG market** (free multi-game API already used for search) — NM and other conditions in GBP.
2. **Total Cards UK retail** — name + number identity (number alone is not enough for Pokémon-style collisions); only **in stock** prices count (Shopify JSON).
3. **Chaos Cards UK retail** — HawkSearch API (`chaoscardsuk.searchapi-na.hawksearch.com`), not Cloudflare HTML. Same name + number filter; in-stock only for pricing.
4. **Magic Madhouse UK retail** — BigCommerce set pages, in-stock only. See below.
5. **UK shop search links** — Total Cards, Chaos Cards, Magic Madhouse, Hills Cards, Unicorn Cards (name + number keyword when known).

Suggested Near Mint uses rarity/demand bands (volume undercuts lowest UK in-stock when present; otherwise lean JustTCG; chase needs Apply). **Price floor £0.15** — match rather than go lower. **Rare/mid cards** at that floor are raised to **£0.19**. LP+ conditions keep JustTCG.

HTML scrapers and RapidAPI are not used.

### Printing gate

Card number plus name is **not** a unique key. The same number exists as a plain
card, a holo, a reverse holo, a Poke Ball reverse and a Master Ball reverse, at
very different prices. The intake form's finish is now sent with the compare
request, and any retailer listing whose printing does not match is shown but
does not count towards the suggested price.

The rules live in `lib/retailers/finish.php`. Each guard exists because it
produced a confident, wrong price during a full-catalogue sweep:

| Guard | What it stops |
| --- | --- |
| Ball patterns tested before the generic reverse rule | A £5.95 Master Ball reverse pricing against a £0.19 plain reverse |
| `non-holo` tested before `holo` | A Holo matching a listing that says Non-Holo |
| Reprint subsets get their own variant token | Celebrations 15/102 matching Base Set 15/102 |
| Rarity finishes never match loosely | A relaxed fallback quietly undoing the first guard |

When no finish is supplied the gate is inert, so behaviour is unchanged.

A card whose printing the retailer does not stock now returns **no price**
rather than the nearest other printing. That is deliberate: a missing
comparison costs a manual check, a wrong one sets a wrong shelf price.

### Magic Madhouse

Their set pages embed a BigCommerce Open Data Layer blob carrying sku, name,
VAT-inclusive price, an exact `stock_level` and a `pre_order` flag. The lookup
resolves the card's set name to a set page, walks its pages (the data layer
caps at 100 products per page whatever `limit` says — Pitch Black is 212 across
three), and caches the whole set for 15 minutes. Because staff work a set at a
time, the first card warms the cache for every card after it.

The previous implementation posted to `/search.php`, which their `robots.txt`
disallows. Set pages are permitted.

## Installation

1. Back up the current folder and `config.php`.
2. Upload this release over the existing application.
3. Keep `config.php` server-side and excluded from source control.
4. Hard-refresh the browser, or reinstall the PWA, to clear the previous cached interface.
5. Optionally add the new cache keys from `config.example.php` into your live `config.php`.

Safe configuration structure:

```php
<?php
return [
    'shopify_store' => 'your-store.myshopify.com',
    'shopify_access_token' => 'shpat_new_token',
    'shopify_api_version' => '2026-07',
    'admin_password' => 'long-unique-password',
    'justtcg_api_key' => 'tcg_your_key_here',
    'justtcg_search_limit' => 20,
    'justtcg_search_cache_seconds' => 900,
    'shopify_meta_cache_seconds' => 3600,
    'app_contact' => 'Lockett Labs Card Intake / https://lockett-labs.com',
];
```

Never expose Shopify or JustTCG credentials in browser JavaScript, screenshots or a public repository.

## Required Shopify scopes

```text
read_products
write_products
read_inventory
write_inventory
read_locations
read_publications
write_publications
read_metaobjects
```

## Maintenance tools

### SKU backfill

Every variant already in the store has an empty SKU, so the fast restock path
in `lib/shopify-inventory.php` never fires for existing stock and every intake
of a known card falls through to the slower title match.

```bash
php tools/backfill-skus.php --tag="Pitch Black"            # dry run
php tools/backfill-skus.php --all --csv=plan.csv           # full dry run to CSV
php tools/backfill-skus.php --tag="Pitch Black" --apply    # write
```

Dry run is the default and prints what it would do. **Read the CSV before
passing `--apply`.** The SKU is built by `lib/sku.php`, which is the PHP twin
of `makeSku()` in `assets/app.js`; if the two drift, the tool and the backfill
mint different SKUs for the same card and the join never closes.

Scope is **singles only**. The scheme is built from a collector number, which a
binder or sleeve pack does not have. Sealed and accessories carry real
manufacturer codes and want their own scheme.

Where two products would claim the same SKU the tool holds both back rather
than abandoning the run, and lists them. Across the catalogue that is about
0.1% of cards, and most are genuinely duplicated products that want merging.

### Chaos Cards snapshot

Chaos Cards has no route a PHP request can take:

- the HawkSearch endpoint the app used returns **403** on every header
  combination; it is gone
- the site now proxies search through `/acts`, which their `robots.txt`
  disallows
- `/prod/` and `/shop/` pages **are** permitted by robots, but the site
  fingerprints the TLS handshake, so cURL cannot reach them
- their CDN serves one static sitemap over plain HTTP, with no prices in it

So prices come from a browser run out of band:

```bash
node tools/chaos-snapshot.mjs                        # all six games, ~80 minutes
node tools/chaos-snapshot.mjs --resume               # keep what is on disk, refresh over it
node tools/chaos-snapshot.mjs --sections=pokemon     # one game only
node tools/chaos-snapshot.mjs --limit=3              # three pages per game, to try it out
```

**The snapshot answers before the live route is attempted.** It used to be the
other way round, which meant every card lookup spent a six second timeout
failing against a dead endpoint before reading the local file that had the
answer. The live route is still tried when the snapshot misses, so if their API
ever returns this picks it up without another change.

**One file per game**, written to `cache/chaos/<game>.json`. The combined file
reached 13 MB and 41,841 cards and was decoded in full to retrieve a single
key; Pokémon is now 0.7 MB. The game the intake form sends chooses the file, and
an unknown game falls back to searching all six. If no shards exist the reader
uses the old combined file, so upgrading does not blank the price panel.

To split a combined snapshot you already have, rather than re-crawling for
eighty minutes:

```bash
node tools/split-chaos-snapshot.mjs            # report what it would write
node tools/split-chaos-snapshot.mjs --apply    # write the shards
```

It honours their 3-second crawl delay and skips graded slabs by MPN prefix.
Their `oos/no` in-stock filter used to work and now returns an empty list, so
availability is read per item from the listing and out-of-stock cards are
dropped before they are stored.

**Sections run in order of what they are worth to us, because a run that is
cut short loses whatever was scheduled last.**

| game | our singles | stock value | their pages |
| --- | ---: | ---: | ---: |
| pokemon | 8,565 | £36,156 | 42 |
| lorcana | 1,545 | £5,507 | 22 |
| digimon | 217 | £182 | 49 |
| one-piece | 32 | £112 | 26 |
| mtg | 851 | £1,074 | 456 |
| yu-gi-oh | 8 | £3 | 175 |

Magic and Yu-Gi-Oh are 631 of the 770 pages and cover £1,077 of stock. Pokemon
is 42 pages and covers £36,156. The first four sections finish in about
fifteen minutes and cover 99% of what we hold.

Run it daily. Every entry carries its own `seenAt`, and
`lib/retailers/chaos-snapshot.php` **ignores any card older than 36 hours**
rather than quoting a stale price. Age is judged per card so that `--resume`
cannot relabel yesterday's prices as today's.

It needs a real browser window, so it runs on a desktop session, not a server
cron. Headless is detected and refused.

### What the snapshot does not cover

Their browse listing is in-stock only, which is what we want, but it means
their catalogue is far narrower than ours: about 7,000 in-stock singles against
our 11,291. Most of the gap is genuine. They stock the plain print of a card
and not its reverse holo, so a name and number will match while the finish does
not, and quoting the plain price against our reverse would be wrong. Expect a
match rate in the low single digits until our two ranges converge.

## Intake log

Nothing used to record what staff did. The success message was the only
evidence a card had been booked in, and the screen clears itself 650ms later to
get ready for the next one, so a quantity typed as `11` instead of `1` was
invisible the moment it was submitted.

Every create and restock now writes one JSON line to `logs/intake-YYYY-MM.jsonl`
at the moment it happens, carrying the time, the Shopify product and its admin
URL, the game, set, printed number and finish, the conditions with quantity and
price, and the units added.

The workbar shows today's total and opens onto the last dozen intakes, each
linking to its product in Shopify admin. The entry appears the instant a card is
submitted rather than waiting on a round trip, so it is on screen before the
form resets.

`logs/` is created with a deny-all `.htaccess` and is in `.gitignore`. Logging
can never fail an intake: by the time it runs the stock has already moved in
Shopify, so every call swallows its own errors.

## Housekeeping

### Cache pruning

Nothing ever deleted a cache file, so the folder only grew: 1,771 entries and
15 MB of them when it was measured, and that number only ever went one way.
`cache_write_json()` now sweeps occasionally on its own, and there is a tool for
a predictable weekly run:

```bash
php tools/prune-cache.php              # dry run, 45 day cutoff
php tools/prune-cache.php --apply      # delete
```

```text
0 4 * * 0 /usr/bin/php /path/to/tools/prune-cache.php --apply
```

Only files named for a sha256 hash are ever removed, which is how every cache
entry is named and how nothing else in that folder is. The Chaos snapshot, the
per-game shards, the variant backups and the JustTCG usage counter all live
there too and can never match. A list of names to spare would have to be
updated every time something durable was added, and forgetting once would
delete it.

### Staff password

The password was stored in `config.php` as itself and compared directly, so
anything that could read that file had it: a backup, an FTP client, a stray
copy sent to someone. Generate a hash instead.

**In the browser** — the *Staff password hash* panel on `backfill.php`, linked
as *Card ID backfill* in the intake header. Type the password, press
**Generate hash**, and paste the line it gives you over the `admin_password`
value. This is the route to use on hosting with no shell, which IONOS shared
plans generally are.

**On the command line**:

```bash
php tools/hash-password.php
```

The password is never stored by either route. The browser one sends it to your
own server over the session you are already signed in with, does not write it
to the session, the cache or any log, refuses `GET` so it cannot land in an
access log or browser history, and clears the field as soon as the hash is
shown.

Staff sign in with the same password as before and the login screen is
unchanged. The plain form keeps working until you make the change, so there is
no window where anyone is locked out, and the sign-in page says so until it is
done.

Repeated failures from one address now back off and then lock out for fifteen
minutes. The previous fixed 0.3 second pause was not a brake on anything
automated.

## Validation

Run the local PHP regression tests:

```text
php tests/exact-number.php
php tests/justtcg-provider.php
php tests/shopify-inventory.php
php tests/competitor-strategy.php
php tests/retailer-finish.php
php tests/chaos-hawksearch.php
php tests/chaos-snapshot-shards.php
php tests/tcgdex.php
php tests/backfill.php
php tests/intake-log.php
php tests/cache-and-login.php
```

Run the local JavaScript regression tests:

```text
node tests/autofill-tags.js
node tests/expand-set-number.js
```

Before publishing live inventory, verify one new card and one existing SKU at the intended Shopify location. Confirm that the stock preview and final quantity both show the additive result, and that the description textarea includes catalogue text above the packing note.
