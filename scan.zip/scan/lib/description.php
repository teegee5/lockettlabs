<?php
declare(strict_types=1);

/**
 * The product description arrives as HTML built by assets/ll-catalogue.js.
 * It is checked again here against a short allow-list before it reaches
 * Shopify: paragraphs, lists, a sub-heading, emphasis, line breaks, and links
 * that stay on this store. Everything else is dropped, attributes included.
 */

const DESCRIPTION_TAGS = ['p', 'ul', 'ol', 'li', 'strong', 'em', 'h3', 'br', 'a'];

function description_link_allowed(string $href): bool
{
    $href = trim($href);
    if ($href === '') return false;
    if (preg_match('#^/(?!/)[A-Za-z0-9/_\-.?=&%]*$#', $href)) return true;
    return (bool) preg_match('#^https://(www\.)?lockett-labs\.com(/[A-Za-z0-9/_\-.?=&%]*)?$#i', $href);
}

function sanitize_description_html(string $html): string
{
    $html = trim($html);
    if ($html === '') return '';
    if (strlen($html) > 40000) $html = substr($html, 0, 40000);

    if (!class_exists('DOMDocument')) {
        // Without the DOM extension: keep the allowed tags, strip every attribute.
        $text = strip_tags($html, '<' . implode('><', DESCRIPTION_TAGS) . '>');
        return (string) preg_replace('/<(\w+)\b[^>]*>/', '<$1>', $text);
    }

    $doc = new DOMDocument('1.0', 'UTF-8');
    $previous = libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="UTF-8"><div id="root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET);
    libxml_clear_errors();
    libxml_use_internal_errors($previous);
    $root = $doc->getElementById('root');
    if (!$root) return '';

    $clean = static function (DOMNode $node) use (&$clean, $doc): void {
        for ($child = $node->firstChild; $child !== null; $child = $next) {
            $next = $child->nextSibling;
            if ($child instanceof DOMElement) {
                $tag = strtolower($child->tagName);
                if (!in_array($tag, DESCRIPTION_TAGS, true)) {
                    if (in_array($tag, ['script', 'style', 'iframe', 'object', 'embed', 'form'], true)) {
                        $node->removeChild($child);
                        continue;
                    }
                    // Unknown wrapper: keep its text, lose the element.
                    $clean($child);
                    while ($child->firstChild) $node->insertBefore($child->firstChild, $child);
                    $node->removeChild($child);
                    continue;
                }
                $href = $tag === 'a' ? $child->getAttribute('href') : '';
                while ($child->attributes->length) $child->removeAttribute($child->attributes->item(0)->nodeName);
                if ($tag === 'a') {
                    if (description_link_allowed($href)) $child->setAttribute('href', $href);
                    else {
                        while ($child->firstChild) $node->insertBefore($child->firstChild, $child);
                        $node->removeChild($child);
                        continue;
                    }
                }
                $clean($child);
            } elseif ($child instanceof DOMComment) {
                $node->removeChild($child);
            }
        }
    };
    $clean($root);

    $out = '';
    foreach ($root->childNodes as $child) $out .= $doc->saveHTML($child);
    return trim($out);
}

/** Plain-text description, for older clients that still send text. */
function description_from_text(string $text): string
{
    return nl2br(htmlspecialchars(truncate_text(trim($text), 20000), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));
}
