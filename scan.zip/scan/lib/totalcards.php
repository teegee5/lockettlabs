<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/retailers/match.php';
require_once __DIR__ . '/retailers/http.php';

const TOTALCARDS_BASE_URL = 'https://totalcards.net';
/** Brief server-side cache so card-select lookups do not hammer Total Cards. */
const TOTALCARDS_CACHE_TTL = 900;
const TOTALCARDS_HTTP_TIMEOUT = 10;

/**
 * Look up a Total Cards (Shopify) product by card number + name/set identity.
 * Number alone is not enough (e.g. Pokémon 135/193 collides across sets/languages).
 *
 * priceGbp is adjusted (next odd pence up); priceGbpRaw is the Total Cards retail.
 *
 * @return array{ok:bool,matched:bool,priceGbp:?float,priceGbpRaw:?float,title:string,url:string,handle:string,sku:string,available:?bool,rarity:string,error?:string}
 */
function totalcards_lookup(string $cardNumber, string $game = 'one-piece-card-game', string $cardName = '', string $setName = ''): array
{
    $number = totalcards_normalize_number($cardNumber);
    $game = strtolower(clean_text($game, 80));
    $cardName = clean_text($cardName, 120);
    $setName = clean_text($setName, 120);
    if ($number === '') {
        return totalcards_empty_result('Enter a printed card number.');
    }

    $cacheKey = 'totalcards:v6:' . strtoupper($number) . ':' . md5(strtolower($cardName . '|' . $setName));
    $cached = cache_read_json($cacheKey, TOTALCARDS_CACHE_TTL);
    if (is_array($cached) && array_key_exists('matched', $cached)) {
        return $cached;
    }

    try {
        $result = totalcards_lookup_live($number, $cardName, $setName);
    } catch (Throwable $error) {
        return [
            'ok' => true,
            'matched' => false,
            'priceGbp' => null,
            'priceGbpRaw' => null,
            'title' => '',
            'url' => '',
            'handle' => '',
            'sku' => '',
            'available' => null,
            'rarity' => '',
            'error' => clean_text($error->getMessage(), 240),
        ];
    }

    cache_write_json($cacheKey, $result);
    return $result;
}

/**
 * @return array{ok:bool,matched:bool,priceGbp:?float,priceGbpRaw:?float,title:string,url:string,handle:string,sku:string,available:?bool,rarity:string,error?:string}
 */
/**
 * The one URL this lookup is certain to request, or '' when it will not need
 * to make a request at all.
 *
 * compare.php uses this to fetch the first round trip of each retailer
 * concurrently. Returning '' on a cache hit matters: priming a URL the lookup
 * will never open is a wasted request against someone else's server.
 */
function totalcards_prime_url(string $cardNumber, string $cardName = '', string $setName = ''): string
{
    $number = totalcards_normalize_number($cardNumber);
    if ($number === '') return '';

    $cacheKey = 'totalcards:v6:' . strtoupper($number) . ':' . md5(strtolower(
        clean_text($cardName, 120) . '|' . clean_text($setName, 120)
    ));
    $cached = cache_read_json($cacheKey, TOTALCARDS_CACHE_TTL);
    if (is_array($cached) && array_key_exists('matched', $cached)) return '';

    $keywords = retailer_search_keywords($number, clean_text($cardName, 120), clean_text($setName, 120));
    if ($keywords === []) return '';

    return TOTALCARDS_BASE_URL . '/search/suggest.json?q=' . rawurlencode($keywords[0])
        . '&resources%5Btype%5D=product';
}

function totalcards_lookup_live(string $number, string $cardName = '', string $setName = ''): array
{
    $keywords = retailer_search_keywords($number, $cardName, $setName);
    $keywords = array_slice($keywords, 0, 5);
    $requireName = $cardName !== '';
    $candidates = [];
    foreach ($keywords as $keyword) {
        $suggestUrl = TOTALCARDS_BASE_URL . '/search/suggest.json?q=' . rawurlencode($keyword)
            . '&resources%5Btype%5D=product';
        try {
            $suggest = http_json($suggestUrl, [], TOTALCARDS_HTTP_TIMEOUT);
        } catch (Throwable) {
            break;
        }
        $products = $suggest['resources']['results']['products'] ?? [];
        if (!is_array($products) || $products === []) {
            continue;
        }

        $batch = [];
        foreach ($products as $product) {
            if (!is_array($product)) continue;
            $title = clean_text($product['title'] ?? '', 260);
            $handle = clean_text($product['handle'] ?? '', 180);
            if ($title === '' && $handle === '') continue;
            if (!totalcards_title_matches_number($title, $number) && !totalcards_handle_matches_number($handle, $number)) {
                continue;
            }
            $hay = $title . ' ' . $handle;
            $nameScore = retailer_name_score($hay, $cardName);
            if ($requireName && $nameScore < 60) {
                continue;
            }
            $setScore = retailer_set_score($hay, $setName);
            $rarity = totalcards_rarity_from_title($title);
            $batch[] = [
                'title' => $title,
                'handle' => $handle,
                'rarity' => $rarity,
                'suggestPrice' => totalcards_parse_price($product['price'] ?? $product['price_min'] ?? null),
                'available' => array_key_exists('available', $product) ? (bool) $product['available'] : null,
                'nameScore' => $nameScore,
                'setScore' => $setScore,
                'preferCommon' => totalcards_is_common_or_uncommon($rarity) ? 1 : 0,
            ];
        }
        if ($batch !== []) {
            $candidates = $batch;
            break;
        }
    }
    if ($candidates === []) {
        return totalcards_empty_result($requireName
            ? 'No Total Cards match for this name + number'
            : '');
    }

    usort($candidates, static function (array $a, array $b): int {
        return [$b['nameScore'], $b['setScore'], $b['preferCommon'], $a['title']]
            <=> [$a['nameScore'], $a['setScore'], $a['preferCommon'], $b['title']];
    });

    $shortlist = array_slice($candidates, 0, 6);

    // Every shortlisted candidate needs its product JSON before it can be
    // scored, and they used to be fetched one at a time, so six candidates
    // meant six round trips in series. Fetch the ones that are not already
    // cached together. The loop below is unchanged: totalcards_fetch_product()
    // still checks its own cache first and still fetches for itself if
    // priming missed.
    $prime = [];
    foreach ($shortlist as $candidate) {
        $handle = clean_text($candidate['handle'] ?? '', 180);
        if ($handle === '' || !preg_match('/^[a-z0-9][a-z0-9\-]*$/i', $handle)) continue;
        if (is_array(cache_read_json('totalcards:product:v2:' . strtolower($handle), TOTALCARDS_CACHE_TTL))) continue;
        $prime[] = TOTALCARDS_BASE_URL . '/products/' . rawurlencode($handle) . '.json';
    }
    retailer_http_prime($prime);

    $best = null;
    foreach ($shortlist as $candidate) {
        try {
            $detail = totalcards_fetch_product($candidate['handle']);
        } catch (Throwable) {
            continue;
        }
        if ($detail === null) continue;

        $detailTitle = $detail['title'] !== '' ? $detail['title'] : $candidate['title'];
        $detailHandle = $detail['handle'] !== '' ? $detail['handle'] : $candidate['handle'];
        $hay = $detailTitle . ' ' . $detailHandle;
        $nameScore = retailer_name_score($hay, $cardName);
        if ($requireName && $nameScore < 60) {
            continue;
        }

        $skuMatch = $detail['sku'] !== '' && totalcards_sku_matches($detail['sku'], $number);
        $titleMatch = totalcards_title_matches_number($detailTitle, $number);
        $handleMatch = totalcards_handle_matches_number($detailHandle, $number);
        if (!$skuMatch && !$titleMatch && !$handleMatch) {
            continue;
        }

        $price = $detail['priceGbp'] ?? $candidate['suggestPrice'];
        if ($price === null || $price <= 0) continue;

        $raw = round((float) $price, 2);
        $setScore = retailer_set_score($hay, $setName);
        $scored = [
            'ok' => true,
            'matched' => true,
            'priceGbp' => totalcards_adjust_nm_price($raw),
            'priceGbpRaw' => $raw,
            'title' => $detailTitle,
            'url' => TOTALCARDS_BASE_URL . '/products/' . rawurlencode($detailHandle),
            'handle' => $detailHandle,
            'sku' => $detail['sku'],
            'available' => $detail['available'] ?? $candidate['available'],
            'rarity' => $detail['rarity'] !== '' ? $detail['rarity'] : $candidate['rarity'],
            'skuMatch' => $skuMatch ? 1 : 0,
            'nameScore' => $nameScore,
            'setScore' => $setScore,
            'preferCommon' => totalcards_is_common_or_uncommon($detail['rarity'] !== '' ? $detail['rarity'] : $candidate['rarity']) ? 1 : 0,
        ];

        if ($best === null
            || $scored['nameScore'] > $best['nameScore']
            || ($scored['nameScore'] === $best['nameScore'] && $scored['setScore'] > $best['setScore'])
            || ($scored['nameScore'] === $best['nameScore'] && $scored['setScore'] === $best['setScore'] && $scored['skuMatch'] > $best['skuMatch'])
        ) {
            $best = $scored;
        }

        if ($skuMatch && $scored['nameScore'] >= 100 && $scored['setScore'] > 0) {
            break;
        }
    }

    if ($best === null) {
        return totalcards_empty_result($requireName
            ? 'No Total Cards match for this name + number'
            : '');
    }

    unset($best['skuMatch'], $best['preferCommon'], $best['nameScore'], $best['setScore']);
    return $best;
}

/**
 * @return array{title:string,handle:string,sku:string,priceGbp:?float,available:?bool,rarity:string}|null
 */
function totalcards_fetch_product(string $handle): ?array
{
    $handle = clean_text($handle, 180);
    if ($handle === '' || !preg_match('/^[a-z0-9][a-z0-9\-]*$/i', $handle)) {
        return null;
    }

    $cacheKey = 'totalcards:product:v2:' . strtolower($handle);
    $cached = cache_read_json($cacheKey, TOTALCARDS_CACHE_TTL);
    if (is_array($cached) && isset($cached['handle'])) {
        return $cached;
    }

    $url = TOTALCARDS_BASE_URL . '/products/' . rawurlencode($handle) . '.json';
    $data = http_json($url, [], TOTALCARDS_HTTP_TIMEOUT);
    $product = is_array($data['product'] ?? null) ? $data['product'] : null;
    if ($product === null) return null;

    $title = clean_text($product['title'] ?? '', 260);
    $variants = is_array($product['variants'] ?? null) ? $product['variants'] : [];
    $sku = '';
    $price = null;
    $available = null;
    foreach ($variants as $variant) {
        if (!is_array($variant)) continue;
        if ($sku === '') {
            $sku = clean_text($variant['sku'] ?? '', 80);
        }
        if ($price === null) {
            $price = totalcards_parse_price($variant['price'] ?? null);
        }
        if ($available === null && array_key_exists('available', $variant)) {
            $available = (bool) $variant['available'];
        }
    }

    // Product .json often omits availability; prefer .js when still unknown.
    if ($available === null) {
        $available = totalcards_fetch_available_from_js($handle);
    }

    $result = [
        'title' => $title,
        'handle' => clean_text($product['handle'] ?? $handle, 180),
        'sku' => $sku,
        'priceGbp' => $price,
        'available' => $available,
        'rarity' => totalcards_rarity_from_title($title),
    ];
    cache_write_json($cacheKey, $result);
    return $result;
}

/**
 * Shopify product .js includes variant available flags that .json may omit.
 */
function totalcards_fetch_available_from_js(string $handle): ?bool
{
    $handle = clean_text($handle, 180);
    if ($handle === '' || !preg_match('/^[a-z0-9][a-z0-9\-]*$/i', $handle)) {
        return null;
    }
    try {
        $url = TOTALCARDS_BASE_URL . '/products/' . rawurlencode($handle) . '.js';
        $data = http_json($url, [], TOTALCARDS_HTTP_TIMEOUT);
    } catch (Throwable) {
        return null;
    }
    if (array_key_exists('available', $data)) {
        return (bool) $data['available'];
    }
    $variants = is_array($data['variants'] ?? null) ? $data['variants'] : [];
    foreach ($variants as $variant) {
        if (is_array($variant) && array_key_exists('available', $variant)) {
            return (bool) $variant['available'];
        }
    }
    return null;
}

function totalcards_normalize_number(string $number): string
{
    return retailer_normalize_number($number);
}

function totalcards_title_matches_number(string $title, string $number): bool
{
    // Trailing match or mid-title (padding-flexible via shared helpers).
    return retailer_title_matches_number($title, $number)
        || retailer_text_contains_exact_number($title, $number);
}

function totalcards_handle_matches_number(string $handle, string $number): bool
{
    return retailer_handle_matches_number($handle, $number);
}

function totalcards_sku_matches(string $sku, string $number): bool
{
    $number = totalcards_normalize_number($number);
    $sku = strtoupper(clean_text($sku, 80));
    if ($number === '' || $sku === '') return false;
    return $sku === 'OPSC-' . $number;
}

function totalcards_rarity_from_title(string $title): string
{
    if (preg_match('/\(([^)]+)\)\s*-\s*[A-Z0-9\-]+$/iu', $title, $match)) {
        return clean_text($match[1], 80);
    }
    if (preg_match('/\((Common|Uncommon|Rare|Super Rare|Secret Rare|Leader|Promo)\)/iu', $title, $match)) {
        return clean_text($match[1], 80);
    }
    return '';
}

function totalcards_is_common_or_uncommon(string $rarity): bool
{
    $text = strtolower(trim($rarity));
    if ($text === '') return false;
    if (in_array($text, ['c', 'uc', 'u', 'common', 'uncommon'], true)) return true;
    if (preg_match('/\buncommon\b/', $text)) return true;
    if (preg_match('/\bcommon\b/', $text) && !preg_match('/\buncommon\b/', $text)) return true;
    return false;
}

function totalcards_parse_price(mixed $value): ?float
{
    if ($value === null || $value === '') return null;
    if (!is_numeric($value)) return null;
    $price = (float) $value;
    return $price > 0 ? $price : null;
}

/**
 * Round Total Cards retail up to the next odd number of pence (strictly greater).
 * Even pence → +1p; odd pence → +2p. e.g. 0.28→0.29, 0.23→0.25, 0.18→0.19.
 */
function totalcards_adjust_nm_price(float $priceGbp): float
{
    $pence = (int) round($priceGbp * 100);
    if ($pence < 1) {
        return round($priceGbp, 2);
    }
    // Next odd integer strictly greater than $pence: +1, then +1 again if still even.
    $adjusted = $pence + 1 + ($pence % 2);
    return round($adjusted / 100, 2);
}

/**
 * @return array{ok:bool,matched:bool,priceGbp:?float,priceGbpRaw:?float,title:string,url:string,handle:string,sku:string,available:?bool,rarity:string,error?:string}
 */
function totalcards_empty_result(string $error = ''): array
{
    $result = [
        'ok' => true,
        'matched' => false,
        'priceGbp' => null,
        'priceGbpRaw' => null,
        'title' => '',
        'url' => '',
        'handle' => '',
        'sku' => '',
        'available' => null,
        'rarity' => '',
    ];
    if ($error !== '') {
        $result['error'] = $error;
    }
    return $result;
}
