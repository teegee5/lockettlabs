<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

const JUSTTCG_BASE_URL = 'https://api.justtcg.com/v1';
const USD_GBP_RATE_URL = 'https://api.frankfurter.dev/v2/rate/USD/GBP';

/**
 * Unified card search. Every catalogue identity, set, number, rarity, variant,
 * language and price comes from JustTCG. Image URLs are derived from the
 * TCGplayer product ID returned by JustTCG because the stable v1 card schema
 * does not currently expose a documented image field.
 */
function card_search(
    string $game,
    string $query,
    string $language = 'en',
    string $setQuery = '',
    string $numberQuery = ''
): array {
    $game = clean_text($game, 80);
    $query = clean_text($query, 180);
    $setQuery = clean_text($setQuery, 160);
    $numberQuery = clean_text($numberQuery, 80);
    $language = $language === 'ja' ? 'ja' : 'en';

    if ($game === '') throw new InvalidArgumentException('Choose a JustTCG game.');

    // Backwards compatibility for installations upgraded from v3.1.
    $game = justtcg_legacy_game_id($game, $language);
    $setId = justtcg_resolve_set_id($game, $setQuery);
    $setCodeHint = extract_bandai_set_code($setQuery);
    // Bare set codes (OP16, BT14) are valid number-expansion context even when
    // JustTCG set names do not include the code.
    if ($setQuery !== '' && $setId === '' && !($setCodeHint !== '' && game_uses_set_prefixed_numbers($game))) {
        throw new RuntimeException('No exact JustTCG set matched “' . $setQuery . '”. Choose a set from the suggestions or leave the set blank.');
    }
    $numberSource = exact_number_from_search($query, $numberQuery);
    $numberSource = expand_number_with_set_context($numberSource, $setQuery, $game, $setId);
    $numberParts = expand_compact_card_number($numberSource, $game);

    $params = [
        'game' => $game,
        'limit' => justtcg_search_limit(),
        'include_null_prices' => 'true',
        'include_price_history' => 'false',
        'include_statistics' => '7d',
    ];
    if ($query !== '') $params['q'] = strip_identifier_from_query($query, $numberSource);
    if ($setId !== '') $params['set'] = $setId;
    if (!empty($numberParts['hasNumber'])) $params['number'] = justtcg_number_query($numberParts);
    // JustTCG v1 has no reliable request-time language filter for most games
    // (confirmed ignored for One Piece). Japanese Pokémon uses game=pokemon-japan.
    // Keep sending language for forward-compat, then enforce via response filtering.
    if ($language === 'ja' && $game !== 'pokemon-japan') $params['language'] = 'Japanese';
    if ($language === 'en' && $game === 'pokemon-japan') $language = 'ja';

    $payload = justtcg_request('/cards', array_filter($params, static fn($value): bool => $value !== ''), justtcg_search_cache_ttl());
    $cards = is_array($payload['data'] ?? null) ? $payload['data'] : [];

    // Bandai catalogues store OP16-002, not bare 002. If expansion could not run
    // before the first request (set-code discovery miss) and JustTCG returned
    // nothing, rediscover and retry once with the full printed id.
    if (
        $cards === []
        && $setId !== ''
        && game_uses_set_prefixed_numbers($game)
        && !empty($numberParts['hasNumber'])
        && ($numberParts['setCode'] ?? '') === ''
        && ($numberParts['denominatorRaw'] ?? '') === ''
    ) {
        $retryExpanded = expand_number_with_set_context(
            (string) ($numberParts['localRaw'] ?? $numberSource),
            $setQuery,
            $game,
            $setId
        );
        $retryParts = expand_compact_card_number($retryExpanded, $game);
        if (($retryParts['setCode'] ?? '') !== '' && justtcg_number_query($retryParts) !== ($params['number'] ?? '')) {
            $numberSource = $retryExpanded;
            $numberParts = $retryParts;
            $params['number'] = justtcg_number_query($retryParts);
            $payload = justtcg_request('/cards', array_filter($params, static fn($value): bool => $value !== ''), justtcg_search_cache_ttl());
            $cards = is_array($payload['data'] ?? null) ? $payload['data'] : [];
        }
    }

    // Some catalogues store only the numerator in `number`. If a full printed
    // number was sent and the API returned nothing, page through exact-numerator
    // results. The strict local filter below still rejects a different total.
    if ($cards === [] && ($numberParts['denominator'] ?? '') !== '') {
        $retry = $params;
        $retry['number'] = (string) ($numberParts['localRaw'] ?? '');
        $retryLimit = justtcg_search_limit();
        for ($offset = 0; $offset < min(100, $retryLimit * 5); $offset += $retryLimit) {
            $retry['offset'] = $offset;
            $page = justtcg_request('/cards', array_filter($retry, static fn($value): bool => $value !== ''), justtcg_search_cache_ttl());
            $pageCards = is_array($page['data'] ?? null) ? $page['data'] : [];
            $cards = array_merge($cards, $pageCards);
            if (count($pageCards) < $retryLimit || empty($page['meta']['hasMore'])) break;
        }
    }

    $results = [];
    foreach ($cards as $card) {
        if (!is_array($card)) continue;
        $results[] = normalize_justtcg_card($card, $game, $language);
    }

    // Do not surface English catalogue rows when staff asked for Japanese.
    // Pokemon Japan is already a separate game; other games must have Japanese
    // variants on the card or they are dropped (JustTCG currently has no OP JP game).
    if ($language === 'ja' && $game !== 'pokemon-japan') {
        $results = array_values(array_filter(
            $results,
            static fn(array $card): bool => ($card['languageCode'] ?? '') === 'ja'
        ));
    }

    $results = rank_card_results($results, $query, $setQuery, $numberSource, $language);
    $results = enrich_card_api_descriptions($results);
    return convert_justtcg_market_prices_to_gbp($results);
}

/** A catalogue row is sealed product when it has no collector number and reads like one. */
function justtcg_row_is_sealed(array $card): bool
{
    $number = strtolower(trim((string) ($card['cardNumber'] ?? $card['number'] ?? '')));
    if ($number !== '' && !in_array($number, ['n/a', 'none', 'null'], true)) return false;
    return (bool) preg_match('/\b(booster|box|bundle|blister|tin|pack|deck|collection|elite trainer|etb|display|case|kit|portfolio|binder|sleeves?|starter|trove|gift set|premium|build\s*&\s*battle|tech sticker|poster|figure)\b/i', (string) ($card['name'] ?? ''));
}

/**
 * Sealed product search: booster boxes, Elite Trainer Boxes, tins, blisters.
 *
 * Same catalogue and same GBP conversion as singles. JustTCG lists sealed
 * items inside each set with the number "N/A", so a set (or a name) narrows
 * the request and the rows are filtered here.
 */
function sealed_search(string $game, string $query, string $language = 'en', string $setQuery = ''): array
{
    $game = justtcg_legacy_game_id(clean_text($game, 80), $language === 'ja' ? 'ja' : 'en');
    $query = clean_text($query, 180);
    $setQuery = clean_text($setQuery, 160);
    if ($game === '') throw new InvalidArgumentException('Choose a game.');
    $setId = justtcg_resolve_set_id($game, $setQuery);
    if ($setQuery !== '' && $setId === '') {
        throw new RuntimeException('No JustTCG set matched "' . $setQuery . '". Choose a set from the suggestions or leave it blank.');
    }
    $params = [
        'game' => $game,
        'limit' => 100,
        'include_null_prices' => 'true',
        'include_price_history' => 'false',
        'include_statistics' => '7d',
    ];
    if ($setId !== '') $params['set'] = $setId;
    if ($query !== '') $params['q'] = $query;
    if ($setId === '' && $query === '') throw new InvalidArgumentException('Enter a product name or choose a set.');
    $payload = justtcg_request('/cards', $params, max(900, justtcg_search_cache_ttl()));
    $rows = [];
    foreach (is_array($payload['data'] ?? null) ? $payload['data'] : [] as $card) {
        if (!is_array($card)) continue;
        $normal = normalize_justtcg_card($card, $game, $language);
        if (!justtcg_row_is_sealed($normal)) continue;
        $normal['kind'] = 'sealed';
        $normal['finishOptions'] = ['Sealed'];
        $rows[] = $normal;
    }
    $needle = normalized_match_text($query);
    foreach ($rows as &$row) {
        $name = normalized_match_text((string) ($row['name'] ?? ''));
        $score = 40;
        if ($needle !== '') {
            if ($name === $needle) $score += 50;
            elseif (str_contains($name, $needle)) $score += 35;
            else { similar_text($needle, $name, $pct); $score += (int) round($pct / 4); }
        }
        if (!empty($row['imageUrl'])) $score += 3;
        if (($row['marketLowest'] ?? null) !== null) $score += 2;
        $row['confidence'] = max(1, min(99, $score));
        $row['matchReasons'] = $needle !== '' && str_contains($name, $needle) ? ['Name match'] : ['Sealed product'];
    }
    unset($row);
    usort($rows, static fn(array $a, array $b): int => [($b['confidence'] ?? 0), ($a['name'] ?? '')] <=> [($a['confidence'] ?? 0), ($b['name'] ?? '')]);
    return convert_justtcg_market_prices_to_gbp(array_slice($rows, 0, 40));
}

/**
 * Prefer JustTCG `details` when present. For Magic cards with a Scryfall ID,
 * pull oracle text so the listing description is ready without staff retyping.
 */
function enrich_card_api_descriptions(array $results): array
{
    $enriched = 0;
    foreach ($results as &$card) {
        if (!is_array($card)) continue;
        $existing = trim((string) ($card['description'] ?? ''));
        if ($existing !== '') {
            $card['apiDescription'] = $existing;
            continue;
        }
        $scryfallId = clean_text($card['scryfallId'] ?? '', 100);
        if ($scryfallId === '' || $enriched >= 8) continue;
        $text = scryfall_oracle_text($scryfallId);
        if ($text === '') continue;
        $card['description'] = $text;
        $card['apiDescription'] = $text;
        if (($card['cardType'] ?? '') === '') $card['cardType'] = truncate_text($text, 180);
        $enriched += 1;
    }
    unset($card);
    return $results;
}

function scryfall_oracle_text(string $scryfallId): string
{
    $scryfallId = clean_text($scryfallId, 100);
    if ($scryfallId === '' || !preg_match('/^[a-f0-9-]{36}$/i', $scryfallId)) return '';
    try {
        $payload = cached_http_json('https://api.scryfall.com/cards/' . rawurlencode($scryfallId), [
            'Accept: application/json',
            'User-Agent: LockettLabsCardIntake/5.4',
        ], 604800);
    } catch (Throwable) {
        return '';
    }

    $parts = [];
    $typeLine = clean_text($payload['type_line'] ?? '', 220);
    if ($typeLine !== '') $parts[] = $typeLine;

    $faces = is_array($payload['card_faces'] ?? null) ? $payload['card_faces'] : null;
    if ($faces) {
        foreach ($faces as $face) {
            if (!is_array($face)) continue;
            $faceName = clean_text($face['name'] ?? '', 180);
            $oracle = trim((string) ($face['oracle_text'] ?? ''));
            $faceType = clean_text($face['type_line'] ?? '', 220);
            $block = array_filter([$faceName, $faceType, $oracle]);
            if ($block) $parts[] = implode("\n", $block);
        }
    } else {
        $oracle = trim((string) ($payload['oracle_text'] ?? ''));
        if ($oracle !== '') $parts[] = $oracle;
    }

    $text = trim(implode("\n\n", array_filter($parts)));
    return truncate_text($text, 4000);
}

function justtcg_games(): array
{
    $payload = justtcg_request('/games', [], 21600);
    $games = [];
    foreach (is_array($payload['data'] ?? null) ? $payload['data'] : [] as $game) {
        if (!is_array($game) || empty($game['id']) || empty($game['name'])) continue;
        $games[] = [
            'id' => clean_text($game['id'], 100),
            'name' => clean_text($game['name'], 160),
            'sealedCount' => max(0, (int) ($game['sealed_count'] ?? 0)),
            'lastUpdated' => clean_text($game['last_updated'] ?? '', 80),
        ];
    }
    usort($games, static function (array $a, array $b): int {
        $priority = static function (string $id): int {
            return match ($id) {
                'pokemon' => 1,
                'pokemon-japan' => 2,
                'one-piece-card-game' => 3,
                'digimon-card-game' => 4,
                'magic-the-gathering' => 5,
                'disney-lorcana' => 6,
                default => 50,
            };
        };
        return [$priority($a['id']), $a['name']] <=> [$priority($b['id']), $b['name']];
    });
    return $games;
}

function justtcg_sets(string $game, string $query = ''): array
{
    $game = justtcg_legacy_game_id(clean_text($game, 80), 'en');
    if ($game === '') return [];
    $params = ['game' => $game];
    if (trim($query) !== '') $params['q'] = clean_text($query, 160);
    $payload = justtcg_request('/sets', $params, 21600);
    $sets = [];
    foreach (is_array($payload['data'] ?? null) ? $payload['data'] : [] as $set) {
        if (!is_array($set) || empty($set['id']) || empty($set['name'])) continue;
        $sets[] = [
            'id' => clean_text($set['id'], 180),
            'name' => clean_text($set['name'], 220),
            'game' => clean_text($set['game'] ?? $game, 100),
            'releaseDate' => clean_text($set['release_date'] ?? '', 40),
            'sealedCount' => max(0, (int) ($set['sealed_count'] ?? 0)),
        ];
    }
    usort($sets, static function (array $a, array $b): int {
        $date = strcmp((string) ($b['releaseDate'] ?? ''), (string) ($a['releaseDate'] ?? ''));
        return $date !== 0 ? $date : strcasecmp($a['name'], $b['name']);
    });
    return $sets;
}

function justtcg_request(string $path, array $params = [], int $ttl = 0): array
{
    $key = trim((string) (app_config()['justtcg_api_key'] ?? ''));
    if ($key === '') throw new RuntimeException('Add justtcg_api_key to config.php before searching cards.');

    $url = JUSTTCG_BASE_URL . $path;
    if ($params !== []) $url .= '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
    $headers = ['x-api-key: ' . $key];
    $cacheKey = $url . "\n" . implode("\n", $headers);

    if ($ttl > 0) {
        $cached = cache_read_json($cacheKey, $ttl);
        if ($cached !== null) {
            // Warm caches still carry last-known JustTCG quota headers. Seed the
            // usage badge when we have never recorded a live response yet.
            if (justtcg_usage_snapshot() === null && is_array($cached['_metadata'] ?? null)) {
                justtcg_remember_usage($cached['_metadata']);
            }
            return $cached;
        }
    }

    $data = http_json($url, $headers);
    justtcg_remember_usage(is_array($data['_metadata'] ?? null) ? $data['_metadata'] : null);
    if ($ttl > 0) cache_write_json($cacheKey, $data);
    return $data;
}

function justtcg_usage_path(): string
{
    return APP_ROOT . '/cache/justtcg-usage.json';
}

function justtcg_remember_usage(?array $meta): void
{
    if ($meta === null || $meta === []) return;

    $dailyLimit = max(0, (int) ($meta['apiDailyLimit'] ?? 0));
    $dailyUsed = max(0, (int) ($meta['apiDailyRequestsUsed'] ?? 0));
    $dailyRemaining = isset($meta['apiDailyRequestsRemaining'])
        ? max(0, (int) $meta['apiDailyRequestsRemaining'])
        : max(0, $dailyLimit - $dailyUsed);
    $planLimit = max(0, (int) ($meta['apiRequestLimit'] ?? 0));
    $planUsed = max(0, (int) ($meta['apiRequestsUsed'] ?? 0));
    $planRemaining = isset($meta['apiRequestsRemaining'])
        ? max(0, (int) $meta['apiRequestsRemaining'])
        : max(0, $planLimit - $planUsed);

    $snapshot = [
        'plan' => clean_text($meta['apiPlan'] ?? '', 80) ?: 'JustTCG',
        'dailyUsed' => $dailyUsed,
        'dailyLimit' => $dailyLimit,
        'dailyRemaining' => $dailyRemaining,
        'planUsed' => $planUsed,
        'planLimit' => $planLimit,
        'planRemaining' => $planRemaining,
        'rateLimit' => max(0, (int) ($meta['apiRateLimit'] ?? 0)),
        'updatedAt' => time(),
    ];

    $directory = APP_ROOT . '/cache';
    if (!(is_dir($directory) || @mkdir($directory, 0750, true)) || !is_writable($directory)) return;
    @file_put_contents(justtcg_usage_path(), json_encode($snapshot, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), LOCK_EX);
}

function justtcg_usage_snapshot(): ?array
{
    $path = justtcg_usage_path();
    if (!is_file($path)) return null;
    $data = json_decode((string) file_get_contents($path), true);
    return is_array($data) && isset($data['dailyLimit']) ? $data : null;
}

function justtcg_search_limit(): int
{
    $limit = (int) (app_config()['justtcg_search_limit'] ?? 20);
    return max(1, min(100, $limit));
}

function justtcg_search_cache_ttl(): int
{
    $ttl = (int) (app_config()['justtcg_search_cache_seconds'] ?? 300);
    return max(0, min(3600, $ttl));
}

/**
 * JustTCG supplies USD only. Convert on the server so USD never reaches the
 * staff pricing UI. If the daily reference rate is unavailable, remove market
 * pricing entirely and leave eBay UK as the pricing check.
 */
function convert_justtcg_market_prices_to_gbp(array $results, ?array $rateData = null): array
{
    $hasPrice = false;
    foreach ($results as $card) {
        if (is_numeric($card['marketLowest'] ?? null)) { $hasPrice = true; break; }
    }
    if (!$hasPrice) return hide_justtcg_market_prices($results);

    if ($rateData === null) {
        try {
            $rateData = cached_http_json(USD_GBP_RATE_URL, [], 43200);
        } catch (Throwable) {
            return hide_justtcg_market_prices($results);
        }
    }

    $rate = is_numeric($rateData['rate'] ?? null) ? (float) $rateData['rate'] : 0.0;
    $base = strtoupper(clean_text($rateData['base'] ?? '', 3));
    $quote = strtoupper(clean_text($rateData['quote'] ?? '', 3));
    $date = clean_text($rateData['date'] ?? '', 20);
    if ($rate <= 0 || $base !== 'USD' || $quote !== 'GBP') return hide_justtcg_market_prices($results);

    foreach ($results as &$card) {
        $card['marketCurrency'] = 'GBP';
        $card['marketPricingAvailable'] = true;
        $card['marketFxRate'] = $rate;
        $card['marketRateDate'] = $date;
        $card['marketLowest'] = is_numeric($card['marketLowest'] ?? null)
            ? round((float) $card['marketLowest'] * $rate, 2)
            : null;
        foreach (is_array($card['marketVariants'] ?? null) ? $card['marketVariants'] : [] as &$variant) {
            $variant['price'] = is_numeric($variant['price'] ?? null)
                ? round((float) $variant['price'] * $rate, 2)
                : null;
        }
        unset($variant);
    }
    unset($card);
    return $results;
}

function hide_justtcg_market_prices(array $results): array
{
    foreach ($results as &$card) {
        $card['marketCurrency'] = 'GBP';
        $card['marketPricingAvailable'] = false;
        $card['marketLowest'] = null;
        $card['marketVariants'] = [];
        unset($card['marketFxRate'], $card['marketRateDate']);
    }
    unset($card);
    return $results;
}

function justtcg_resolve_set_id(string $game, string $setQuery): string
{
    $setQuery = trim($setQuery);
    if ($setQuery === '') return '';

    // Bare Bandai codes (OP16, BT14) are number-expansion context, not JustTCG set
    // names. JustTCG set ids never include those codes, so do not fuzzy-match
    // q=OP16 onto an unrelated set (that yields set=<wrong>&number=OP16-002).
    $bareCode = extract_bandai_set_code($setQuery);
    $compactQuery = strtoupper(preg_replace('/[^A-Z0-9]/i', '', $setQuery) ?? '');
    if ($bareCode !== '' && $compactQuery === $bareCode) {
        return '';
    }

    $sets = justtcg_sets($game, $setQuery);
    if ($sets === []) return '';
    $wanted = normalized_match_text($setQuery);
    foreach ($sets as $set) {
        if (normalized_match_text((string) $set['id']) === $wanted || normalized_match_text((string) $set['name']) === $wanted) {
            return (string) $set['id'];
        }
    }
    foreach ($sets as $set) {
        $candidate = normalized_match_text((string) $set['name']);
        if ($wanted !== '' && (str_contains($candidate, $wanted) || str_contains($wanted, $candidate))) return (string) $set['id'];
    }
    return count($sets) === 1 ? (string) $sets[0]['id'] : '';
}

function justtcg_legacy_game_id(string $game, string $language): string
{
    return match (strtolower(trim($game))) {
        'pokemon' => $language === 'ja' ? 'pokemon-japan' : 'pokemon',
        'onepiece', 'one-piece' => 'one-piece-card-game',
        'digimon' => 'digimon-card-game',
        'mtg', 'magic' => 'magic-the-gathering',
        'lorcana' => 'disney-lorcana',
        default => strtolower(trim($game)),
    };
}

function strip_identifier_from_query(string $query, string $identifier): string
{
    if ($identifier === '') return trim($query);
    return trim(str_ireplace($identifier, '', $query));
}

function justtcg_number_query(array $parts): string
{
    $setCode = (string) ($parts['setCode'] ?? '');
    $localRaw = (string) ($parts['localRaw'] ?? '');
    $denominatorRaw = (string) ($parts['denominatorRaw'] ?? '');
    if ($setCode !== '' && $localRaw !== '') {
        $out = $setCode . '-' . $localRaw;
        if ($denominatorRaw !== '') $out .= '/' . $denominatorRaw;
        return $out;
    }
    if ($localRaw !== '' && $denominatorRaw !== '') {
        // Lorcana promo collector codes (14/P4) are printed on-card but JustTCG
        // only indexes the bare numerator — search without the P-code.
        if (preg_match('/^P\d+$/i', $denominatorRaw)) {
            return $localRaw;
        }
        return $localRaw . '/' . $denominatorRaw;
    }
    $raw = (string) ($parts['raw'] ?? '');
    if ($raw !== '') return $raw;
    return $localRaw;
}

function normalize_justtcg_card(array $card, string $requestedGame, string $requestedLanguage): array
{
    $gameName = clean_text($card['game'] ?? '', 160);
    $setName = clean_text($card['set_name'] ?? $card['setName'] ?? '', 220);
    $setId = clean_text($card['set'] ?? '', 180);
    $number = clean_text($card['number'] ?? '', 80);
    $tcgplayerId = preg_replace('/\D+/', '', (string) ($card['tcgplayerId'] ?? '')) ?? '';
    $variants = normalize_justtcg_variants(is_array($card['variants'] ?? null) ? $card['variants'] : []);
    // Prefer language-matching price rows when present; never invent Japanese
    // identity from the UI request alone (that caused EN OP images to show as JP).
    if ($requestedLanguage === 'ja' && $requestedGame !== 'pokemon-japan') {
        $japaneseOnly = array_values(array_filter(
            $variants,
            static fn(array $variant): bool => strcasecmp((string) ($variant['language'] ?? ''), 'Japanese') === 0
        ));
        if ($japaneseOnly !== []) $variants = $japaneseOnly;
    }
    $languages = array_values(array_unique(array_filter(array_column($variants, 'language'))));
    // Only the requested language decides identity. Magic (and other games)
    // return Japanese price rows alongside English ones, which used to flip an
    // English card to Japanese and tag it as such.
    $isJapanese = $requestedGame === 'pokemon-japan'
        || ($requestedLanguage === 'ja' && in_array('Japanese', $languages, true));
    $languageCode = $isJapanese ? 'ja' : 'en';
    $name = clean_text($card['name'] ?? '', 220);
    $hasJapaneseName = preg_match('/[\x{3040}-\x{30ff}\x{3400}-\x{9fff}]/u', $name) === 1;
    $finishOptions = justtcg_finish_options($variants, $requestedGame);
    $imageUrls = justtcg_image_urls($tcgplayerId);
    $details = clean_text($card['details'] ?? '', 2000);
    $lowest = null;
    foreach ($variants as $variant) {
        if (!is_numeric($variant['price'] ?? null)) continue;
        $price = (float) $variant['price'];
        if ($lowest === null || $price < $lowest) $lowest = $price;
    }

    return normalized_card(
        $requestedGame,
        $card['uuid'] ?? $card['id'] ?? '',
        $name,
        $setName,
        $number,
        $details,
        $details,
        $imageUrls[0] ?? '',
        $card['rarity'] ?? '',
        $tcgplayerId !== '' ? 'https://www.tcgplayer.com/product/' . rawurlencode($tcgplayerId) : 'https://justtcg.com/',
        [
            'gameName' => $gameName,
            'language' => $isJapanese ? 'Japanese' : 'English',
            'languageCode' => $languageCode,
            'englishName' => $isJapanese && $hasJapaneseName ? '' : $name,
            'englishSetName' => $setName,
            'setCode' => justtcg_set_code($setId, $number),
            'setId' => $setId,
            'finishOptions' => $finishOptions,
            'provider' => 'JustTCG',
            'tcgplayerId' => $tcgplayerId,
            'scryfallId' => clean_text($card['scryfallId'] ?? '', 100),
            'mtgjsonId' => clean_text($card['mtgjsonId'] ?? '', 100),
            'apiDescription' => $details,
            'marketCurrency' => 'USD',
            'marketLowest' => $lowest,
            'marketVariants' => $variants,
            'imageFallbackUrls' => array_slice($imageUrls, 1),
        ]
    );
}

function normalize_justtcg_variants(array $variants): array
{
    $output = [];
    foreach ($variants as $variant) {
        if (!is_array($variant)) continue;
        $price = isset($variant['price']) && is_numeric($variant['price']) ? (float) $variant['price'] : null;
        $output[] = [
            'id' => clean_text($variant['uuid'] ?? $variant['id'] ?? '', 180),
            'condition' => clean_text($variant['condition'] ?? '', 80),
            'printing' => clean_text($variant['printing'] ?? '', 120),
            'language' => clean_text($variant['language'] ?? '', 80),
            'price' => $price,
            'priceChange24hr' => isset($variant['priceChange24hr']) && is_numeric($variant['priceChange24hr']) ? (float) $variant['priceChange24hr'] : null,
            'priceChange7d' => isset($variant['priceChange7d']) && is_numeric($variant['priceChange7d']) ? (float) $variant['priceChange7d'] : null,
            'lastUpdated' => max(0, (int) ($variant['lastUpdated'] ?? 0)),
        ];
    }
    usort($output, static function (array $a, array $b): int {
        $conditionOrder = ['Near Mint' => 1, 'NM' => 1, 'Lightly Played' => 2, 'LP' => 2, 'Moderately Played' => 3, 'MP' => 3, 'Heavily Played' => 4, 'HP' => 4, 'Damaged' => 5, 'DMG' => 5];
        return [($conditionOrder[$a['condition']] ?? 99), ($a['price'] ?? PHP_FLOAT_MAX)] <=> [($conditionOrder[$b['condition']] ?? 99), ($b['price'] ?? PHP_FLOAT_MAX)];
    });
    return $output;
}

function justtcg_finish_options(array $variants, string $game = ''): array
{
    // Disney Lorcana and Magic never use "Holo" in house titles/tags — JustTCG's
    // Holofoil / Cold Foil printings are listed as Foil.
    $foilOnlyGame = game_uses_foil_not_holo($game);
    $finishes = [];
    foreach ($variants as $variant) {
        $printing = trim((string) ($variant['printing'] ?? ''));
        if ($printing === '') continue;
        $lower = strtolower($printing);
        $finishes[] = match (true) {
            str_contains($lower, 'reverse') => $foilOnlyGame ? 'Foil' : 'Reverse Holo',
            str_contains($lower, 'etched') => 'Etched Foil',
            $foilOnlyGame && (str_contains($lower, 'holo') || str_contains($lower, 'foil')) => 'Foil',
            str_contains($lower, 'holo') => 'Holo',
            str_contains($lower, 'foil') => 'Foil',
            default => 'Standard',
        };
    }
    return array_values(array_unique($finishes ?: ['Standard']));
}

/** Games whose foil printings are never labelled "Holo" on the storefront. */
function game_uses_foil_not_holo(string $game): bool
{
    $game = strtolower(trim($game));
    return str_contains($game, 'disney')
        || str_contains($game, 'lorcana')
        || str_contains($game, 'magic')
        || $game === 'mtg';
}

function justtcg_image_urls(string $tcgplayerId): array
{
    if ($tcgplayerId === '') return [];
    return [
        'https://tcgplayer-cdn.tcgplayer.com/product/' . rawurlencode($tcgplayerId) . '_in_1000x1000.jpg',
        'https://product-images.tcgplayer.com/fit-in/437x437/' . rawurlencode($tcgplayerId) . '.jpg',
    ];
}

function justtcg_set_code(string $setId, string $number): string
{
    $parsed = parsed_card_number($number);
    if (($parsed['setCode'] ?? '') !== '') return (string) $parsed['setCode'];
    if (preg_match('/\b((?:SV|S|SM|XY|BW|OP|BT|EX|ST|EB|PRB|RB|LM|P)\d+[A-Z]?)\b/i', $setId, $match)) return strtoupper($match[1]);
    return '';
}

/** Parse common TCG identifiers without allowing substring matches. */
function parsed_card_number(string $value): array
{
    $value = trim($value);
    if (function_exists('mb_convert_kana')) $value = mb_convert_kana($value, 'as', 'UTF-8');
    $value = strtoupper(strtr($value, [
        '／' => '/', '⁄' => '/', '∕' => '/',
        '－' => '-', '–' => '-', '—' => '-', '−' => '-',
    ]));
    $value = preg_replace('/\s+/u', '', $value) ?? '';

    $setCode = '';
    $localRaw = '';
    $denominatorRaw = '';
    if (preg_match('/^([A-Z]{1,12}\d{0,6}[A-Z]?)\-([A-Z]*\d{1,6}[A-Z]*)(?:\/(\d{1,6}))?$/', $value, $match)) {
        $setCode = canonical_set_code($match[1]);
        $localRaw = $match[2];
        $denominatorRaw = $match[3] ?? '';
    } elseif (preg_match('/^((?:PRB|OP|BT|EX|ST|EB|RB|LM)\d{2}[A-Z]?|(?:SV|SM|XY|BW)\d{1,2}[A-Z]?)(\d{2,4})$/i', $value, $match)) {
        // Compact Bandai / Pokémon set codes: OP16043 → OP16-043
        $setCode = canonical_set_code($match[1]);
        $localRaw = $match[2];
    } elseif (preg_match('/^([A-Z]*\d{1,6}[A-Z]*)(?:\/([A-Z]*\d{1,6}[A-Z]*))?$/', $value, $match)) {
        // Includes Lorcana promo forms like 14/P4 (P-code denominator).
        $localRaw = $match[1];
        $denominatorRaw = $match[2] ?? '';
    }

    return [
        'raw' => $value,
        'setCode' => $setCode,
        'localRaw' => $localRaw,
        'local' => canonical_number_token($localRaw),
        'denominatorRaw' => $denominatorRaw,
        'denominator' => canonical_number_token($denominatorRaw),
        'hasNumber' => $localRaw !== '',
    ];
}

/** Strip separators so OP16-043 and OP16043 compare equal. */
function compact_card_number(string $value): string
{
    $value = trim($value);
    if (function_exists('mb_convert_kana')) $value = mb_convert_kana($value, 'as', 'UTF-8');
    $value = strtoupper(strtr($value, [
        '／' => '/', '⁄' => '/', '∕' => '/',
        '－' => '-', '–' => '-', '—' => '-', '−' => '-',
    ]));
    return preg_replace('/[^A-Z0-9]/i', '', $value) ?? '';
}

/**
 * Expand separator-less printed numbers for API queries.
 * Pokémon: 054245 → 054/245. Other games keep parsed_card_number output.
 */
function expand_compact_card_number(string $value, string $game = ''): array
{
    $parts = parsed_card_number($value);
    $raw = (string) ($parts['raw'] ?? '');
    if ($raw === '' || preg_match('/[-\/]/', $value)) return $parts;

    $game = strtolower($game);
    if (str_contains($game, 'pokemon') && preg_match('/^\d{4,8}$/', $raw) && ($parts['denominatorRaw'] ?? '') === '') {
        $len = strlen($raw);
        if ($len % 2 === 0) {
            $half = intdiv($len, 2);
            $parts['localRaw'] = substr($raw, 0, $half);
            $parts['denominatorRaw'] = substr($raw, $half);
        } else {
            $parts['denominatorRaw'] = substr($raw, -3);
            $parts['localRaw'] = substr($raw, 0, -3);
        }
        if ($parts['localRaw'] !== '') {
            $parts['local'] = canonical_number_token($parts['localRaw']);
            $parts['denominator'] = canonical_number_token($parts['denominatorRaw']);
            $parts['hasNumber'] = true;
        }
    }
    return $parts;
}

/** Bandai-style TCGs that print SETCODE-### identifiers. */
function game_uses_set_prefixed_numbers(string $game): bool
{
    return (bool) preg_match('/one-piece|digimon|gundam|dragon-ball|union-arena/i', $game);
}

/** Pull OP16 / BT14 / ST14-style codes from a set field or set id. */
function extract_bandai_set_code(string $value): string
{
    $value = strtoupper(trim($value));
    if ($value === '') return '';
    if (preg_match('/^(?:PRB|OP|BT|EX|ST|EB|RB|LM|GD|UA|P)\d{1,3}[A-Z]{0,3}$/', $value)) {
        return canonical_set_code($value);
    }
    if (preg_match('/\b((?:PRB|OP|BT|EX|ST|EB|RB|LM|GD|UA)\d{1,3}[A-Z]{0,3})\b/', $value, $match)) {
        return canonical_set_code($match[1]);
    }
    return '';
}

/** Pad the numeric portion of a local number (65 → 065, 65A → 065A). */
function pad_local_card_number(string $localRaw, int $width = 3): string
{
    $localRaw = strtoupper(trim($localRaw));
    if ($localRaw === '' || $width < 1) return $localRaw;
    if (!preg_match('/^([A-Z]*)(\d+)([A-Z]*)$/', $localRaw, $match)) return $localRaw;
    return $match[1] . str_pad($match[2], $width, '0', STR_PAD_LEFT) . $match[3];
}

/**
 * Learn the printed set code for a JustTCG set by sampling card numbers
 * (set ids like the-time-of-battle-one-piece-card-game do not include OP16).
 */
function discover_set_code_for_set(string $game, string $setId): string
{
    static $memo = [];
    $key = strtolower($game) . '|' . $setId;
    if (array_key_exists($key, $memo)) return $memo[$key];
    if ($setId === '' || !game_uses_set_prefixed_numbers($game)) return $memo[$key] = '';

    $persisted = bandai_set_code_cache_get($key);
    if ($persisted !== null && $persisted !== '') return $memo[$key] = $persisted;

    $alias = bandai_set_code_alias($setId);
    if ($alias !== '') {
        bandai_set_code_cache_put($key, $alias);
        return $memo[$key] = $alias;
    }

    $counts = [];
    try {
        // Prefer priced singles over sealed SKUs (often number=N/A). Sample enough
        // cards that reprints from other sets cannot outvote the true set code.
        $payload = justtcg_request('/cards', [
            'game' => $game,
            'set' => $setId,
            'limit' => 40,
            'include_null_prices' => 'true',
            'include_price_history' => 'false',
        ], 86400);
        foreach (is_array($payload['data'] ?? null) ? $payload['data'] : [] as $card) {
            if (!is_array($card)) continue;
            $code = (string) (parsed_card_number((string) ($card['number'] ?? ''))['setCode'] ?? '');
            if ($code === '') continue;
            $counts[$code] = ($counts[$code] ?? 0) + 1;
        }
    } catch (Throwable) {
        // Do not memoize failures — a transient API miss should not stick.
        return '';
    }

    if ($counts === []) return '';
    arsort($counts);
    $code = (string) array_key_first($counts);
    bandai_set_code_cache_put($key, $code);
    return $memo[$key] = $code;
}

/** Known English set-id / name → printed set code when sampling is unavailable. */
function bandai_set_code_alias(string $setIdOrName): string
{
    $wanted = normalized_match_text($setIdOrName);
    if ($wanted === '') return '';
    $aliases = [
        'thetimeofbattle' => 'OP16',
        'thetimeofbattleonepiececardgame' => 'OP16',
        'thetimeofbattlereleaseeventcards' => 'OP16',
        'thetimeofbattlereleaseeventcardsonepiececardgame' => 'OP16',
    ];
    foreach ($aliases as $needle => $code) {
        if ($wanted === $needle || str_contains($wanted, $needle)) {
            return $code;
        }
    }
    return '';
}

function bandai_set_code_cache_path(): string
{
    return APP_ROOT . '/cache/bandai-set-codes.json';
}

function bandai_set_code_cache_get(string $key): ?string
{
    $path = bandai_set_code_cache_path();
    if (!is_file($path)) return null;
    try {
        $decoded = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
    } catch (Throwable) {
        return null;
    }
    if (!is_array($decoded)) return null;
    $value = $decoded[$key] ?? null;
    return is_string($value) && $value !== '' ? strtoupper($value) : null;
}

function bandai_set_code_cache_put(string $key, string $code): void
{
    $code = strtoupper(trim($code));
    if ($key === '' || $code === '') return;
    $path = bandai_set_code_cache_path();
    $decoded = [];
    if (is_file($path)) {
        try {
            $existing = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
            if (is_array($existing)) $decoded = $existing;
        } catch (Throwable) {
            $decoded = [];
        }
    }
    $decoded[$key] = $code;
    $dir = dirname($path);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    @file_put_contents($path, json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
}

function resolve_set_code_for_search(string $game, string $setQuery, string $setId = ''): string
{
    $direct = extract_bandai_set_code($setQuery);
    if ($direct !== '') return $direct;
    $alias = bandai_set_code_alias($setQuery);
    if ($alias !== '') return $alias;
    if ($setId === '' && trim($setQuery) !== '') {
        $setId = justtcg_resolve_set_id($game, $setQuery);
    }
    if ($setId === '') return '';
    $fromId = extract_bandai_set_code($setId);
    if ($fromId !== '') return $fromId;
    $aliasFromId = bandai_set_code_alias($setId);
    if ($aliasFromId !== '') return $aliasFromId;
    return discover_set_code_for_set($game, $setId);
}

/**
 * Expand bare local numbers with set context: 065 + OP16 / The Time of Battle → OP16-065.
 * Leaves full ids, Pokémon slash numbers, and non-SET-NUMBER games unchanged.
 */
function expand_number_with_set_context(
    string $numberQuery,
    string $setQuery,
    string $game,
    string $setId = ''
): string {
    $numberQuery = trim($numberQuery);
    $setQuery = trim($setQuery);
    if ($numberQuery === '' || $setQuery === '') return $numberQuery;
    if (!game_uses_set_prefixed_numbers($game)) return $numberQuery;

    $parts = parsed_card_number($numberQuery);
    if (empty($parts['hasNumber'])) return $numberQuery;
    if (($parts['setCode'] ?? '') !== '') return $numberQuery;
    if (($parts['denominatorRaw'] ?? '') !== '') return $numberQuery;

    $localRaw = (string) ($parts['localRaw'] ?? '');
    if (!preg_match('/^[A-Z]*\d{1,6}[A-Z]*$/i', $localRaw)) return $numberQuery;

    $setCode = resolve_set_code_for_search($game, $setQuery, $setId);
    if ($setCode === '') return $numberQuery;

    return $setCode . '-' . pad_local_card_number($localRaw, 3);
}

function canonical_number_token(string $value): string
{
    $value = strtoupper(preg_replace('/[^A-Z0-9]/i', '', $value) ?? '');
    if ($value === '') return '';
    if (!preg_match('/^([A-Z]*)(\d+)([A-Z]*)$/', $value, $match)) return $value;
    $number = ltrim($match[2], '0');
    if ($number === '') $number = '0';
    return $match[1] . $number . $match[3];
}

function canonical_set_code(string $value): string
{
    return strtoupper(preg_replace('/[^A-Z0-9.]/i', '', $value) ?? '');
}

function exact_number_from_search(string $query, string $numberQuery): string
{
    if (!empty(parsed_card_number($numberQuery)['hasNumber'])) return trim($numberQuery);
    $patterns = [
        '/(?:[A-Z]{1,12}\d{0,6}[A-Z]?[- ])?[A-Z]*\d{1,6}[A-Z]?[\/／][A-Z]*\d{1,6}[A-Z]*/i',
        '/\b[A-Z]{1,12}\d{0,6}[A-Z]?[- ][A-Z]*\d{1,6}[A-Z]*\b/i',
        '/\b(?:PRB|OP|BT|EX|ST|EB|RB|LM)\d{2}[A-Z]?\d{2,4}\b/i',
        '/\b(?:SV|SM|XY|BW)\d{1,2}[A-Z]?\d{2,4}\b/i',
        '/\b\d{1,4}\/P\d{1,3}\b/i',
        '/\b\d{2,4}\/\d{2,4}\b/',
        '/\b\d{4,8}\b/',
    ];
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $query, $match) && !empty(parsed_card_number($match[0])['hasNumber'])) return trim($match[0]);
    }
    if (preg_match('/^\s*[A-Z]*\d{1,6}[A-Z]*\s*$/i', $query) && !empty(parsed_card_number($query)['hasNumber'])) return trim($query);
    return '';
}

function exact_card_number_match(array $card, string $needle): bool
{
    $cardNumber = (string) ($card['cardNumber'] ?? '');
    $wantedCompact = compact_card_number($needle);
    $candidateCompact = compact_card_number($cardNumber);
    // Allow OP16043 ≡ OP16-043 and 054245 ≡ 054/245
    if ($wantedCompact !== '' && $wantedCompact === $candidateCompact) return true;

    $wanted = parsed_card_number($needle);
    if (empty($wanted['hasNumber'])) return true;
    $candidate = parsed_card_number($cardNumber);
    if (empty($candidate['hasNumber'])) return false;
    if (($wanted['local'] ?? '') !== ($candidate['local'] ?? '')) return false;
    if (($wanted['denominator'] ?? '') !== '') {
        // JustTCG often stores Lorcana promos as bare "14" while the printed
        // collector number is "14/P4". Allow the fuller search form when the
        // catalogue row has no denominator; require an exact match when both do.
        if (($candidate['denominator'] ?? '') !== ''
            && ($wanted['denominator'] ?? '') !== ($candidate['denominator'] ?? '')) {
            return false;
        }
    }
    if (($wanted['setCode'] ?? '') !== '') {
        $candidateSet = canonical_set_code((string) first_non_empty([$card['setCode'] ?? '', $candidate['setCode'] ?? '']));
        if ($candidateSet === '' || $candidateSet !== ($wanted['setCode'] ?? '')) return false;
    }
    return true;
}

function rank_card_results(array $results, string $query, string $setQuery, string $numberQuery, string $language): array
{
    $needleName = normalized_match_text(strip_identifier_from_query($query, $numberQuery));
    $needleSet = normalized_match_text($setQuery);
    $strictNumber = parsed_card_number($numberQuery);

    if (!empty($strictNumber['hasNumber'])) {
        $results = array_values(array_filter($results, static fn(array $card): bool => exact_card_number_match($card, $numberQuery)));
        // Prefer the fuller printed form staff typed (14/P4) over JustTCG's bare "14".
        if (($strictNumber['denominatorRaw'] ?? '') !== '') {
            $preferred = trim($numberQuery);
            foreach ($results as &$card) {
                $cand = parsed_card_number((string) ($card['cardNumber'] ?? ''));
                if (($cand['local'] ?? '') === ($strictNumber['local'] ?? '')
                    && ($cand['denominatorRaw'] ?? '') === ''
                    && $preferred !== '') {
                    $card['cardNumber'] = $preferred;
                }
            }
            unset($card);
        }
    }

    $seen = [];
    foreach ($results as &$card) {
        $key = implode('|', [$card['game'] ?? '', $card['externalId'] ?? '', $card['cardNumber'] ?? '']);
        if (isset($seen[$key])) { $card['_duplicate'] = true; continue; }
        $seen[$key] = true;
        $score = 15;
        $reasons = [];
        $cardName = normalized_match_text(implode(' ', array_filter([$card['name'] ?? '', $card['englishName'] ?? ''])));
        $cardSet = normalized_match_text(implode(' ', array_filter([$card['setName'] ?? '', $card['englishSetName'] ?? '', $card['setCode'] ?? '', $card['setId'] ?? ''])));
        if (!empty($strictNumber['hasNumber'])) { $score += 58; $reasons[] = ($strictNumber['denominator'] ?? '') !== '' ? 'Exact printed number' : 'Exact card number'; }
        if ($needleSet !== '') {
            if ($cardSet === $needleSet) { $score += 32; $reasons[] = 'Exact set'; }
            elseif (str_contains($cardSet, $needleSet) || str_contains($needleSet, $cardSet)) { $score += 24; $reasons[] = 'Set match'; }
        }
        if ($needleName !== '') {
            if ($cardName === $needleName) { $score += 30; $reasons[] = 'Exact name'; }
            elseif (str_contains($cardName, $needleName) || str_contains($needleName, $cardName)) { $score += 20; $reasons[] = 'Name match'; }
            else {
                similar_text($needleName, $cardName, $similarity);
                $score += (int) round(min(18, $similarity / 5));
                if ($similarity >= 65) $reasons[] = 'Close name';
            }
        }
        if (($card['languageCode'] ?? '') === $language) $score += 4;
        if (!empty($card['imageUrl'])) $score += 3;
        if (($card['marketLowest'] ?? null) !== null) $score += 2;
        $card['confidence'] = max(1, min(99, $score));
        $card['matchReasons'] = $reasons ?: ['JustTCG catalogue match'];
    }
    unset($card);
    $results = array_values(array_filter($results, static fn(array $item): bool => empty($item['_duplicate'])));
    usort($results, static fn(array $a, array $b): int => ($b['confidence'] ?? 0) <=> ($a['confidence'] ?? 0));
    return array_slice($results, 0, 30);
}

function normalized_match_text(string $value): string
{
    $value = trim($value);
    $value = function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
    return preg_replace('/[^\p{L}\p{N}]+/u', '', $value) ?? '';
}

function first_non_empty(array $values): mixed
{
    foreach ($values as $value) if ($value !== null && $value !== '' && $value !== []) return $value;
    return '';
}

function normalized_card(
    string $game,
    mixed $id,
    mixed $name,
    mixed $setName,
    mixed $number,
    mixed $type,
    mixed $description,
    mixed $image,
    mixed $rarity,
    mixed $source,
    array $extra = []
): array {
    return array_merge([
        'game' => $game,
        'gameName' => '',
        'externalId' => clean_text($id, 180),
        'name' => clean_text($name, 220),
        'setName' => clean_text($setName, 220),
        'cardNumber' => clean_text($number, 80),
        'cardType' => clean_text($type, 180),
        'description' => trim((string) $description),
        'imageUrl' => safe_https_url($image),
        'imageFallbackUrls' => [],
        'rarity' => clean_text($rarity, 100),
        'sourceUrl' => safe_https_url($source),
        'language' => 'English',
        'languageCode' => 'en',
        'englishName' => '',
        'englishSetName' => '',
        'setCode' => '',
        'setId' => '',
        'finishOptions' => ['Standard'],
        'provider' => 'JustTCG',
        'tcgplayerId' => '',
        'scryfallId' => '',
        'mtgjsonId' => '',
        'apiDescription' => '',
        'marketCurrency' => 'USD',
        'marketLowest' => null,
        'marketVariants' => [],
        'confidence' => 0,
        'matchReasons' => [],
    ], $extra);
}
