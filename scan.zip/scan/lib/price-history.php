<?php
declare(strict_types=1);

/**
 * Price history: what each shop charged for a printing, day by day.
 *
 * Every comparison the app makes (a card selected at intake, a set run on the
 * monitor page, the nightly tool) writes what it saw here, so a price can be
 * judged against its own past and not just against today: a competitor that
 * dropped 40% this week reads very differently from one that has always been
 * cheap.
 *
 * One small JSON file per printing under cache/prices/, one point per shop
 * per day (the last reading of the day wins), 180 days kept. The folder sits
 * inside cache/, which the web server refuses to serve, and the files are not
 * named for a sha256 hash so the cache sweep never removes them.
 */

require_once __DIR__ . '/bootstrap.php';

const PRICE_HISTORY_DAYS = 180;
const PRICE_HISTORY_SHOPS = ['lockett', 'totalcards', 'chaoscards', 'magicmadhouse', 'justtcg'];

function price_history_dir(): string
{
    return APP_ROOT . '/cache/prices';
}

/** Canonical number: "025/111" and "25/111" are one printing. */
function price_history_number(string $number): string
{
    $n = strtoupper(preg_replace('/\s+/', '', $number) ?? '');
    return (string) preg_replace_callback('/\d+/', static fn(array $m): string => ltrim($m[0], '0') ?: '0', $n);
}

/**
 * The identity of one printing: game, set, number and finish. Name is left
 * out on purpose; it is spelled too many ways to be a key.
 */
function price_history_key(string $game, string $set, string $number, string $finish): string
{
    $g = strtolower((string) preg_replace('/[^a-z0-9]+/i', '', $game));
    if (str_contains($g, 'pokemon')) $g = 'pokemon';
    $s = strtolower((string) preg_replace('/[^a-z0-9]+/i', '', (string) preg_replace('/^[A-Z]{1,4}\d*[A-Z]?(?:\.\d+[a-z]?)?:\s*/i', '', $set)));
    $f = function_exists('retailer_finish_token') ? retailer_finish_token($finish) : strtolower(trim($finish));
    if (in_array($f, ['normal', 'holo', 'foil'], true)) $f = 'base';
    return implode('|', [$g, $s, price_history_number($number), $f]);
}

function price_history_path(string $key): string
{
    $hash = sha1($key);
    return price_history_dir() . '/' . substr($hash, 0, 2) . '/' . $hash . '.ph.json';
}

function price_history_load(string $key): array
{
    $path = price_history_path($key);
    if (!is_file($path)) return ['key' => $key, 'label' => '', 'points' => []];
    $data = json_decode((string) @file_get_contents($path), true);
    return is_array($data) && isset($data['points']) ? $data : ['key' => $key, 'label' => '', 'points' => []];
}

/**
 * Record today's readings for one printing.
 *
 * @param array<string,array{price:?float,available:?bool,stock?:?int}> $readings shop id => reading
 */
function price_history_record(string $key, string $label, array $readings, ?string $day = null): void
{
    $day = $day ?? gmdate('Y-m-d');
    $dir = dirname(price_history_path($key));
    if (!(is_dir($dir) || @mkdir($dir, 0750, true)) || !is_writable($dir)) return;

    $data = price_history_load($key);
    if ($label !== '') $data['label'] = $label;
    $points = is_array($data['points']) ? $data['points'] : [];
    foreach ($readings as $shop => $reading) {
        if (!in_array($shop, PRICE_HISTORY_SHOPS, true) || !is_array($reading)) continue;
        $price = isset($reading['price']) && is_numeric($reading['price']) ? round((float) $reading['price'], 2) : null;
        $available = array_key_exists('available', $reading) ? $reading['available'] : null;
        if ($price === null && $available === null) continue;
        // One point per shop per day: today's newest reading replaces today's older one.
        $points = array_values(array_filter($points, static fn(array $p): bool => !($p['d'] === $day && $p['r'] === $shop)));
        $points[] = array_filter([
            'd' => $day,
            'r' => $shop,
            'p' => $price,
            'a' => $available === null ? null : (bool) $available,
            's' => isset($reading['stock']) && is_numeric($reading['stock']) ? (int) $reading['stock'] : null,
        ], static fn($v) => $v !== null);
    }
    $cutoff = gmdate('Y-m-d', time() - PRICE_HISTORY_DAYS * 86400);
    $points = array_values(array_filter($points, static fn(array $p): bool => ($p['d'] ?? '') >= $cutoff));
    usort($points, static fn(array $a, array $b): int => [$a['d'], $a['r']] <=> [$b['d'], $b['r']]);
    $data['points'] = $points;
    $data['updated'] = time();
    @file_put_contents(price_history_path($key), json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), LOCK_EX);
}

/**
 * Series per shop for the last $days, plus the change over that window.
 *
 * @return array{key:string,label:string,series:array<string,list<array{d:string,p:?float,a:?bool,s:?int}>>,change:array<string,?float>,days:int}
 */
function price_history_series(string $key, int $days = 90): array
{
    $data = price_history_load($key);
    $cutoff = gmdate('Y-m-d', time() - $days * 86400);
    $series = [];
    foreach ($data['points'] as $point) {
        if (!is_array($point) || ($point['d'] ?? '') < $cutoff) continue;
        $series[$point['r']][] = ['d' => $point['d'], 'p' => $point['p'] ?? null, 'a' => $point['a'] ?? null, 's' => $point['s'] ?? null];
    }
    $change = [];
    foreach ($series as $shop => $points) {
        $priced = array_values(array_filter($points, static fn(array $p): bool => $p['p'] !== null));
        if (count($priced) < 2) { $change[$shop] = null; continue; }
        $first = (float) $priced[0]['p'];
        $last = (float) $priced[count($priced) - 1]['p'];
        $change[$shop] = $first > 0 ? round(($last - $first) / $first * 100, 1) : null;
    }
    return ['key' => $key, 'label' => (string) ($data['label'] ?? ''), 'series' => $series, 'change' => $change, 'days' => $days];
}

/** Readings a compare result can hand to price_history_record(). */
function price_history_readings_from_compare(array $compare, ?float $ours): array
{
    $readings = [];
    foreach ($compare['sources'] ?? [] as $source) {
        if (!is_array($source) || empty($source['matched'])) continue;
        $id = (string) ($source['id'] ?? '');
        if ($id === '') continue;
        $readings[$id] = [
            'price' => $source['priceGbp'] ?? null,
            'available' => $source['available'] ?? null,
            'stock' => $source['stock'] ?? null,
        ];
    }
    if ($ours !== null && $ours > 0) $readings['lockett'] = ['price' => $ours, 'available' => true];
    return $readings;
}
