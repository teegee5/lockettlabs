<?php
declare(strict_types=1);

/**
 * Shared page furniture: the hex nut from the Lockett Labs logo (the store's
 * only marker), the brand lock-up and the top bar with its navigation.
 */

function ui_nut(string $class = ''): string
{
    return '<svg class="nut' . ($class !== '' ? ' ' . htmlspecialchars($class, ENT_QUOTES) : '') . '" viewBox="-50 -50 100 100" aria-hidden="true" focusable="false"><polygon points="44,0 22,38.1 -22,38.1 -44,0 -22,-38.1 22,-38.1"/><circle r="16"/></svg>';
}

function ui_brand_mark(string $class = ''): string
{
    return '<span class="brand-mark' . ($class !== '' ? ' ' . htmlspecialchars($class, ENT_QUOTES) : '') . '">' . ui_nut('brand-nut') . '<span class="brand-word">Lockett Labs</span></span>';
}

/**
 * @param string $active 'intake' | 'monitor' | 'tools'
 */
function ui_topbar(string $active, string $csrf): string
{
    $links = [
        ['intake', './', 'Intake'],
        ['monitor', 'monitor.php', 'Price monitor'],
        ['tools', 'backfill.php', 'Tools'],
    ];
    $nav = '';
    foreach ($links as [$id, $href, $label]) {
        $nav .= '<a class="topnav-link" href="' . $href . '"' . ($id === $active ? ' aria-current="page"' : '') . '>' . $label . '</a>';
    }
    $csrfAttr = htmlspecialchars($csrf, ENT_QUOTES);
    return '<header class="topbar">'
        . '<a class="brand" href="./" aria-label="Lockett Labs intake home">' . ui_brand_mark('topbar-mark') . '<span class="brand-app">Intake</span></a>'
        . '<nav class="topnav" aria-label="Sections">' . $nav . '</nav>'
        . '<div class="top-status" aria-label="Connections">'
        . '<span id="provider-badge" class="status-pill" title="Card catalogue">Catalogue…</span>'
        . '<span id="api-usage-badge" class="status-pill usage-pill" hidden title="JustTCG API usage">API</span>'
        . '<span id="shop-badge" class="status-pill" title="Shopify">Shopify…</span>'
        . '</div>'
        . '<form method="post" class="signout" action="./">'
        . '<input type="hidden" name="action" value="logout">'
        . '<input type="hidden" name="csrf" value="' . $csrfAttr . '">'
        . '<button class="icon-button" type="submit" aria-label="Sign out" title="Sign out">'
        . '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 17l5-5-5-5M15 12H3m9-9h7a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-7"/></svg>'
        . '</button></form>'
        . '</header>';
}
