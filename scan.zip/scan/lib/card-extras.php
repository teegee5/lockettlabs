<?php
declare(strict_types=1);

/**
 * Everything about a card beyond the price catalogue: which pictures exist
 * and whether each is a real scan, the printed set size, and the facts the
 * product description is built from.
 *
 *   Pokemon  TCGdex: card text, illustrator, HP, attacks, and an image that is
 *            a true scan for sets up to HeartGold & SoulSilver (2011) and an
 *            official digital render after that.
 *   Magic    Scryfall: oracle text, artist, printed set size, and a scan
 *            whenever Scryfall marks the image "highres_scan".
 *   All      TCGplayer's product image, which for modern printings is a
 *            digital render and is labelled as one.
 *
 * Nothing here invents a fact. A field the source does not give is left out.
 */

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/tcgdex.php';

const CARD_EXTRAS_TTL = 604800; // 7 days: printed facts do not change

/**
 * TCGdex set ids whose images are scans of printed cards. From Black & White
 * onward TCGdex carries the official digital images instead.
 */
function tcgdex_set_is_scanned(string $setId): bool
{
    return (bool) preg_match('/^(base\d*|basep|gym\d|neo\d|lc|si\d?|ecard\d|ex\d+|exu|pop\d+|np|dp\d*|dpp|pl\d*|hgss\d*|hgssp|col\d|wp|bog|tk-?\w*)$/i', $setId);
}

/**
 * Classic Collection reprints carry their original number, so TCGdex (which
 * indexes them by running order) can only find them by name.
 */
const TCGDEX_CLASSIC_SETS = [
    '30thcelebration' => '30th-c',
    'celebrations' => 'cel25cc',
];

function tcgdex_classic_card_id(array $setNames, string $name, string $language = 'en'): string
{
    $setId = '';
    foreach ($setNames as $setName) {
        $key = tcgdex_normalize((string) preg_replace(['/classic\s*collection/i', '/^[A-Z]{1,4}\d*[A-Z]?(?:\.\d+[a-z]?)?:\s*/i'], '', (string) $setName));
        foreach (TCGDEX_CLASSIC_SETS as $needle => $id) {
            if ($key !== '' && str_contains($key, $needle)) { $setId = $id; break 2; }
        }
    }
    if ($setId === '' || trim($name) === '') return '';
    $matches = [];
    foreach (tcgdex_set_cards($language, $setId) as $card) {
        if (is_array($card) && tcgdex_normalize((string) ($card['name'] ?? '')) === tcgdex_normalize($name)) $matches[] = (string) ($card['id'] ?? '');
    }
    // Pikachu appears more than once; a guess would show another card's details.
    return count($matches) === 1 ? $matches[0] : '';
}

function tcgdex_card(string $language, string $id): ?array
{
    if ($id === '') return null;
    try {
        $card = cached_http_json(TCGDEX_BASE . '/' . $language . '/cards/' . rawurlencode($id), [], 2592000);
    } catch (Throwable) {
        return null;
    }
    return is_array($card) && !empty($card['id']) ? $card : null;
}

function scryfall_card(string $id): ?array
{
    if (!preg_match('/^[a-f0-9-]{36}$/i', $id)) return null;
    try {
        $card = cached_http_json('https://api.scryfall.com/cards/' . rawurlencode($id), [
            'Accept: application/json',
            'User-Agent: LockettLabsCardIntake/6.0',
        ], CARD_EXTRAS_TTL);
    } catch (Throwable) {
        return null;
    }
    return is_array($card) && ($card['object'] ?? '') === 'card' ? $card : null;
}

function scryfall_set_printed_size(string $setCode): int
{
    if (!preg_match('/^[a-z0-9]{2,6}$/i', $setCode)) return 0;
    try {
        $set = cached_http_json('https://api.scryfall.com/sets/' . rawurlencode(strtolower($setCode)), [
            'Accept: application/json',
            'User-Agent: LockettLabsCardIntake/6.0',
        ], 2592000);
    } catch (Throwable) {
        return 0;
    }
    return (int) ($set['printed_size'] ?? 0);
}

/** Strip TCGdex's occasional HTML (energy spans, <em>) to plain text. */
function card_extras_plain(mixed $value): string
{
    $text = html_entity_decode(strip_tags((string) $value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    return trim((string) preg_replace('/\s+/u', ' ', $text));
}

/**
 * @param array $card selected catalogue card plus the editor's plan
 * @return array{images:list<array>,details:array,tcgCardId:string,tcgSetId:string,printedTotal:int,releasedAt:string,sources:list<string>}
 */
function card_extras(array $card): array
{
    $game = strtolower(clean_text($card['game'] ?? '', 80));
    $language = (($card['languageCode'] ?? '') === 'ja' || $game === 'pokemon-japan') ? 'ja' : 'en';
    $out = ['images' => [], 'details' => [], 'tcgCardId' => '', 'tcgSetId' => '', 'cardmarketId' => '', 'printedTotal' => 0, 'releasedAt' => '', 'sources' => []];

    $cacheKey = 'card-extras:v2:' . sha1(json_encode([
        $game, $language, $card['externalId'] ?? '', $card['setName'] ?? '', $card['cardNumber'] ?? '', $card['name'] ?? '',
        $card['scryfallId'] ?? '', $card['setTag'] ?? '',
    ]));
    $cached = cache_read_json($cacheKey, CARD_EXTRAS_TTL);
    if (is_array($cached) && isset($cached['images'])) return $cached;

    if (str_contains($game, 'pokemon')) {
        $name = clean_text($card['englishName'] ?? '', 220) ?: clean_text($card['name'] ?? '', 220);
        $name = trim((string) preg_replace('/\s*[-(\[].*$/', '', $name));
        $sets = array_values(array_filter([
            clean_text($card['setTag'] ?? '', 220),
            clean_text($card['englishSetName'] ?? '', 220),
            clean_text($card['setName'] ?? '', 220),
            (string) preg_replace('/^[A-Za-z0-9.]{1,8}:\s*/', '', clean_text($card['setName'] ?? '', 220)),
            clean_text($card['setId'] ?? '', 180),
        ]));
        $classic = (bool) preg_match('/classic collection/i', implode(' ', $sets) . ' ' . ($card['rarity'] ?? ''));
        $id = '';
        try {
            $id = $classic
                ? tcgdex_classic_card_id($sets, $name, $language)
                : tcgdex_resolve_card_id($game, $sets, clean_text($card['cardNumber'] ?? '', 80), $language, $name);
        } catch (Throwable) {
            $id = '';
        }
        $tc = tcgdex_card($language, $id);
        if ($tc) {
            $out['tcgCardId'] = (string) $tc['id'];
            $out['tcgSetId'] = (string) ($tc['set']['id'] ?? '');
            // Total Cards puts the Cardmarket product id in its SKUs: an exact join.
            $out['cardmarketId'] = (string) preg_replace('/\D+/', '', (string) ($tc['pricing']['cardmarket']['idProduct'] ?? ''));
            $out['sources'][] = 'TCGdex';
            if (!empty($tc['image'])) {
                $scanned = tcgdex_set_is_scanned($out['tcgSetId']);
                $out['images'][] = [
                    'id' => 'tcgdex',
                    'url' => rtrim((string) $tc['image'], '/') . '/high.png',
                    'thumb' => rtrim((string) $tc['image'], '/') . '/low.webp',
                    'kind' => $scanned ? 'scan' : 'digital',
                    'label' => $scanned ? 'TCGdex scan' : 'TCGdex render',
                    'note' => $scanned ? 'A scan of the printed card.' : 'Official digital image: the printed foil and texture are not shown.',
                ];
            }
            $d = [
                'category' => card_extras_plain($tc['category'] ?? ''),
                'stage' => card_extras_plain($tc['stage'] ?? ''),
                'hp' => isset($tc['hp']) ? (int) $tc['hp'] : null,
                'types' => array_values(array_map('card_extras_plain', is_array($tc['types'] ?? null) ? $tc['types'] : [])),
                'illustrator' => card_extras_plain($tc['illustrator'] ?? ''),
                'rarity' => strcasecmp((string) ($tc['rarity'] ?? ''), 'None') === 0 ? '' : card_extras_plain($tc['rarity'] ?? ''),
                'regulationMark' => card_extras_plain($tc['regulationMark'] ?? ''),
                'evolveFrom' => card_extras_plain($tc['evolveFrom'] ?? ''),
                'flavor' => card_extras_plain($tc['description'] ?? ''),
                'attacks' => [],
                'abilities' => [],
            ];
            foreach (is_array($tc['abilities'] ?? null) ? $tc['abilities'] : [] as $ability) {
                if (!is_array($ability) || empty($ability['name'])) continue;
                $d['abilities'][] = ['type' => card_extras_plain($ability['type'] ?? 'Ability'), 'name' => card_extras_plain($ability['name']), 'effect' => card_extras_plain($ability['effect'] ?? '')];
            }
            foreach (is_array($tc['attacks'] ?? null) ? $tc['attacks'] : [] as $attack) {
                if (!is_array($attack) || empty($attack['name'])) continue;
                $d['attacks'][] = [
                    'name' => card_extras_plain($attack['name']),
                    'cost' => array_values(array_map('card_extras_plain', is_array($attack['cost'] ?? null) ? $attack['cost'] : [])),
                    'damage' => card_extras_plain($attack['damage'] ?? ''),
                    'effect' => card_extras_plain($attack['effect'] ?? ''),
                ];
            }
            if (!empty($tc['effect'])) $d['rulesText'] = card_extras_plain($tc['effect']);
            if ($classic && !empty($card['cardNumber'])) $d['originalNumber'] = clean_text($card['cardNumber'], 40);
            $out['details'] = array_filter($d, static fn($v) => $v !== '' && $v !== null && $v !== []);
        }
    }

    if (str_contains($game, 'magic')) {
        $sf = scryfall_card(clean_text($card['scryfallId'] ?? '', 100));
        if ($sf) {
            $out['sources'][] = 'Scryfall';
            $faces = is_array($sf['card_faces'] ?? null) ? $sf['card_faces'] : [];
            $uris = is_array($sf['image_uris'] ?? null) ? $sf['image_uris'] : (is_array($faces[0]['image_uris'] ?? null) ? $faces[0]['image_uris'] : []);
            $scan = ($sf['image_status'] ?? '') === 'highres_scan';
            if (!empty($uris['png']) || !empty($uris['large'])) {
                $out['images'][] = [
                    'id' => 'scryfall',
                    'url' => (string) ($uris['png'] ?? $uris['large']),
                    'thumb' => (string) ($uris['small'] ?? $uris['normal'] ?? $uris['large'] ?? ''),
                    'kind' => $scan ? 'scan' : 'digital',
                    'label' => $scan ? 'Scryfall scan' : 'Scryfall image',
                    'note' => $scan ? 'A high-resolution scan of the printed card.' : 'Placeholder or low-resolution image.',
                ];
            }
            $out['releasedAt'] = clean_text($sf['released_at'] ?? '', 20);
            $out['printedTotal'] = scryfall_set_printed_size((string) ($sf['set'] ?? ''));
            $text = [];
            if ($faces) {
                foreach ($faces as $face) {
                    if (!is_array($face)) continue;
                    $text[] = trim(implode("\n", array_filter([clean_text($face['name'] ?? '', 200), clean_text($face['type_line'] ?? '', 200), trim((string) ($face['oracle_text'] ?? ''))])));
                }
            } elseif (!empty($sf['oracle_text'])) {
                $text[] = trim((string) $sf['oracle_text']);
            }
            $out['details'] = array_filter([
                'typeLine' => clean_text($sf['type_line'] ?? '', 200),
                'rulesText' => implode("\n\n", array_filter($text)),
                'flavor' => clean_text($sf['flavor_text'] ?? '', 500),
                'illustrator' => clean_text($sf['artist'] ?? '', 120),
                'rarity' => ucfirst(clean_text($sf['rarity'] ?? '', 40)),
                'cost' => clean_text($sf['mana_cost'] ?? ($faces[0]['mana_cost'] ?? ''), 60),
            ], static fn($v) => $v !== '' && $v !== null);
        }
    }

    $tcgplayerId = preg_replace('/\D+/', '', (string) ($card['tcgplayerId'] ?? '')) ?? '';
    if ($tcgplayerId !== '') {
        $out['images'][] = [
            'id' => 'tcgplayer',
            'url' => 'https://tcgplayer-cdn.tcgplayer.com/product/' . $tcgplayerId . '_in_1000x1000.jpg',
            'thumb' => 'https://tcgplayer-cdn.tcgplayer.com/product/' . $tcgplayerId . '_in_200x200.jpg',
            'kind' => 'digital',
            'label' => 'TCGplayer image',
            'note' => 'Usually a digital render for modern cards: borders and foil can differ from the printed card.',
        ];
    }

    // Scans first, then the rest in the order found.
    usort($out['images'], static fn(array $a, array $b): int => ($a['kind'] === 'scan' ? 0 : 1) <=> ($b['kind'] === 'scan' ? 0 : 1));
    cache_write_json($cacheKey, $out);
    return $out;
}
