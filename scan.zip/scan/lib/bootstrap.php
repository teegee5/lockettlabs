<?php
declare(strict_types=1);

const APP_ROOT = __DIR__ . '/..';

// Command line tools and tests share this bootstrap but have no browser session
// to attach to, and an unwritable session save path would abort them on load.
if (PHP_SAPI !== 'cli' && session_status() !== PHP_SESSION_ACTIVE) {
    session_name('carddock_staff');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}

function app_config(): array
{
    static $config;
    if ($config !== null) {
        return $config;
    }

    $path = APP_ROOT . '/config.php';
    $config = is_file($path) ? (require $path) : [];
    return is_array($config) ? $config : [];
}

function app_is_configured(): bool
{
    $config = app_config();
    return !empty($config['shopify_store'])
        && !empty($config['shopify_access_token'])
        && !empty($config['admin_password'])
        && !empty($config['justtcg_api_key']);
}

function app_csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(24));
    }
    return (string) $_SESSION['csrf'];
}

function app_is_authenticated(): bool
{
    return !empty($_SESSION['authenticated']);
}

/**
 * True when admin_password is a stored hash rather than the password itself.
 *
 * Kept separate so the login screen can say so. A plaintext secret in
 * config.php is readable by anything that can read the file, including a
 * backup, a misconfigured directory listing or anyone with FTP.
 */
function app_password_is_hashed(): bool
{
    $stored = (string) (app_config()['admin_password'] ?? '');
    if ($stored === '') return false;
    $info = password_get_info($stored);
    return ($info['algo'] ?? null) !== null && $info['algo'] !== 0 && $info['algo'] !== '';
}

const LOGIN_MAX_ATTEMPTS = 8;
const LOGIN_LOCKOUT_SECONDS = 900;
const LOGIN_ATTEMPT_WINDOW = 900;

function app_login_attempt_key(): string
{
    // Per client address. The session cannot be the only counter, because a
    // script guessing passwords simply discards the cookie each time.
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? 'cli');
    return 'login-attempts:' . hash('sha256', $ip);
}

/**
 * @return array{count:int,first:int,until:int}
 */
function app_login_attempts(): array
{
    $state = cache_read_json(app_login_attempt_key(), LOGIN_ATTEMPT_WINDOW + LOGIN_LOCKOUT_SECONDS);
    return [
        'count' => max(0, (int) ($state['count'] ?? 0)),
        'first' => max(0, (int) ($state['first'] ?? 0)),
        'until' => max(0, (int) ($state['until'] ?? 0)),
    ];
}

/**
 * Seconds remaining before another attempt is accepted, or 0.
 */
function app_login_lockout_remaining(): int
{
    $state = app_login_attempts();
    return $state['until'] > time() ? $state['until'] - time() : 0;
}

function app_login_record_failure(): void
{
    $state = app_login_attempts();

    // Start a fresh window once the old one has passed, so an occasional typo
    // never accumulates into a lockout days later.
    if ($state['first'] === 0 || $state['first'] < time() - LOGIN_ATTEMPT_WINDOW) {
        $state = ['count' => 0, 'first' => time(), 'until' => 0];
    }
    $state['count']++;
    if ($state['count'] >= LOGIN_MAX_ATTEMPTS) {
        $state['until'] = time() + LOGIN_LOCKOUT_SECONDS;
    }
    cache_write_json(app_login_attempt_key(), $state);
}

function app_login_clear_failures(): void
{
    cache_write_json(app_login_attempt_key(), ['count' => 0, 'first' => 0, 'until' => 0]);
}

function app_attempt_login(string $password): bool
{
    if (app_login_lockout_remaining() > 0) {
        return false;
    }

    $expected = (string) (app_config()['admin_password'] ?? '');
    if ($expected === '') {
        app_login_record_failure();
        return false;
    }

    // A hashed password is verified properly. A plaintext one still works, so
    // that upgrading this file does not lock staff out before someone has had
    // a chance to run tools/hash-password.php and edit config.php.
    $ok = app_password_is_hashed()
        ? password_verify($password, $expected)
        : hash_equals($expected, $password);

    if (!$ok) {
        // Slow every failure down, and slow repeated ones down further. The
        // previous fixed 0.3s was not a brake on anything automated.
        $state = app_login_attempts();
        usleep(min(2000000, 300000 + $state['count'] * 250000));
        app_login_record_failure();
        return false;
    }

    app_login_clear_failures();
    session_regenerate_id(true);
    $_SESSION['authenticated'] = true;
    $_SESSION['csrf'] = bin2hex(random_bytes(24));
    return true;
}

function app_logout(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'] ?? '', $params['secure'], $params['httponly']);
    }
    session_destroy();
}

function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function api_guard(bool $requireCsrf = false): void
{
    if (!app_is_configured()) {
        json_response(['ok' => false, 'error' => 'The server configuration is incomplete.'], 503);
    }
    if (!app_is_authenticated()) {
        json_response(['ok' => false, 'error' => 'Your staff session has expired. Sign in again.'], 401);
    }
    if ($requireCsrf) {
        $provided = (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        if ($provided === '' || !hash_equals(app_csrf_token(), $provided)) {
            json_response(['ok' => false, 'error' => 'The security token is invalid. Refresh and try again.'], 419);
        }
    }
}

function request_json(): array
{
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw ?: '', true);
    if (!is_array($decoded)) {
        json_response(['ok' => false, 'error' => 'Invalid JSON request.'], 400);
    }
    return $decoded;
}

/**
 * Responses fetched ahead of time, keyed by URL, for this request only.
 *
 * The price panel asks two or three retailers about the same card, and each of
 * them used to open its own connection one after the other. Their first URL is
 * predictable, so compare.php fetches those together with curl_multi and parks
 * the bodies here. The lookups then run unchanged and find their answer already
 * waiting.
 *
 * Deliberately one-shot: a primed body is handed over once and forgotten, so a
 * retailer that re-requests the same URL later in the same run gets a fresh
 * response rather than a copy of an older one.
 */
function http_prime_store(string $url, string $body): void
{
    $GLOBALS['__http_primed'][$url] = $body;
}

function http_primed_take(string $url): ?string
{
    if (!isset($GLOBALS['__http_primed'][$url])) return null;
    $body = (string) $GLOBALS['__http_primed'][$url];
    unset($GLOBALS['__http_primed'][$url]);
    return $body;
}

function http_json(string $url, array $headers = [], int $timeout = 18): array
{
    $primed = http_primed_take($url);
    if ($primed !== null) {
        $decoded = json_decode($primed, true);
        if (is_array($decoded)) return $decoded;
        // A primed body that will not decode is not worth failing over. Fall
        // through and fetch it properly.
    }

    if (!function_exists('curl_init')) {
        throw new RuntimeException('PHP cURL is required on this hosting plan.');
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_HTTPHEADER => array_merge(['Accept: application/json'], $headers),
        CURLOPT_USERAGENT => (string) (app_config()['app_contact'] ?? 'TCG Card Scanner'),
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $body = curl_exec($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($body === false || $error !== '') {
        throw new RuntimeException('The card database could not be reached: ' . $error);
    }

    $data = json_decode((string) $body, true);
    if ($status >= 400) {
        $message = is_array($data) ? ($data['error'] ?? $data['message'] ?? null) : null;
        throw new RuntimeException(is_string($message) ? $message : "The card database returned HTTP {$status}.");
    }
    if (!is_array($data)) {
        throw new RuntimeException('The card database returned an unreadable response.');
    }
    return $data;
}

function cache_file_path(string $key): string
{
    return APP_ROOT . '/cache/' . hash('sha256', $key) . '.json';
}

function cache_read_json(string $key, int $ttl): ?array
{
    if ($ttl <= 0) return null;
    $path = cache_file_path($key);
    if (!is_file($path) || filemtime($path) === false || filemtime($path) <= time() - $ttl) return null;
    $cached = json_decode((string) file_get_contents($path), true);
    return is_array($cached) ? $cached : null;
}

/**
 * How long a cache file is kept before the sweep below will remove it.
 *
 * Well past the longest TTL anything actually asks for (cached_http_json
 * defaults to 30 days), so a sweep can never delete something a caller would
 * still have accepted.
 */
const CACHE_MAX_AGE_SECONDS = 45 * 86400;

/**
 * Every cache entry is named for the sha256 of its key, so this matches a
 * cache file and nothing else.
 *
 * Deleting by pattern rather than sparing a list of known names matters: the
 * same folder holds the Chaos snapshot, the per-game shards, the variant
 * backups that are the only defence against the productSet incident in the
 * README, and the JustTCG usage counter. A denylist would have to be updated
 * every time something durable was added, and forgetting once would delete it.
 * Nothing durable is named for a hash, so nothing durable can match.
 */
function cache_is_disposable(string $name): bool
{
    return (bool) preg_match('/^[0-9a-f]{64}\.json$/', $name);
}

/**
 * Remove cache files older than the cutoff.
 *
 * @return array{scanned:int,removed:int,bytes:int,skipped:int}
 */
function cache_sweep(int $maxAgeSeconds = CACHE_MAX_AGE_SECONDS, bool $apply = true): array
{
    $stats = ['scanned' => 0, 'removed' => 0, 'bytes' => 0, 'skipped' => 0];
    $directory = APP_ROOT . '/cache';
    $handle = @opendir($directory);
    if ($handle === false) return $stats;

    $cutoff = time() - max(3600, $maxAgeSeconds);
    while (($name = readdir($handle)) !== false) {
        if ($name === '.' || $name === '..') continue;
        $stats['scanned']++;
        if (!cache_is_disposable($name)) { $stats['skipped']++; continue; }

        $path = $directory . '/' . $name;
        if (!is_file($path)) { $stats['skipped']++; continue; }

        $mtime = @filemtime($path);
        if ($mtime === false || $mtime > $cutoff) continue;

        $size = (int) @filesize($path);
        if (!$apply || @unlink($path)) {
            $stats['removed']++;
            $stats['bytes'] += $size;
        }
    }
    closedir($handle);
    return $stats;
}

function cache_write_json(string $key, array $data): void
{
    $directory = APP_ROOT . '/cache';
    if (!(is_dir($directory) || @mkdir($directory, 0750, true)) || !is_writable($directory)) return;

    // Nothing ever removed a cache file, so the folder only grew: 1,771 cache
    // entries by the time it was measured, on shared hosting. Sweeping on
    // roughly one write in a hundred keeps it bounded without putting a
    // directory scan in front of the common path.
    if (random_int(1, 100) === 1) {
        cache_sweep();
    }

    @file_put_contents(cache_file_path($key), json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), LOCK_EX);
}

function cached_http_json(string $url, array $headers = [], int $ttl = 2592000): array
{
    $key = $url . "\n" . implode("\n", $headers);
    $cached = cache_read_json($key, $ttl);
    if ($cached !== null) return $cached;

    $data = http_json($url, $headers);
    cache_write_json($key, $data);
    return $data;
}

function shopify_graphql(string $query, array $variables = []): array
{
    $config = app_config();
    $shop = strtolower(trim((string) ($config['shopify_store'] ?? '')));
    $shop = preg_replace('#^https?://#', '', $shop);
    $shop = rtrim((string) $shop, '/');
    if (!preg_match('/^[a-z0-9][a-z0-9-]*\.myshopify\.com$/', $shop)) {
        throw new RuntimeException('shopify_store must be the permanent store.myshopify.com domain.');
    }

    $version = preg_match('/^\d{4}-\d{2}$/', (string) ($config['shopify_api_version'] ?? ''))
        ? (string) $config['shopify_api_version']
        : '2026-07';
    $url = "https://{$shop}/admin/api/{$version}/graphql.json";
    // Shopify's GraphQL endpoint requires variables to be a JSON object.
    // json_encode([]) produces an array ([]) and Shopify rejects it with
    // "Invalid variables parameter", so represent the empty case as {}.
    $graphqlVariables = $variables === [] ? new stdClass() : $variables;
    $payload = json_encode(['query' => $query, 'variables' => $graphqlVariables], JSON_UNESCAPED_SLASHES);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 25,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Accept: application/json',
            'X-Shopify-Access-Token: ' . (string) $config['shopify_access_token'],
        ],
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $body = curl_exec($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($body === false || $error !== '') {
        throw new RuntimeException('Shopify could not be reached: ' . $error);
    }
    $decoded = json_decode((string) $body, true);
    if (!is_array($decoded)) {
        throw new RuntimeException("Shopify returned an unreadable response (HTTP {$status}).");
    }
    if ($status >= 400 || !empty($decoded['errors'])) {
        $message = $decoded['errors'][0]['message'] ?? "Shopify returned HTTP {$status}.";
        throw new RuntimeException((string) $message);
    }
    return $decoded['data'] ?? [];
}

function clean_text(mixed $value, int $max = 5000): string
{
    $value = trim(preg_replace('/\s+/u', ' ', (string) $value) ?? '');
    return function_exists('mb_substr') ? mb_substr($value, 0, $max) : substr($value, 0, $max);
}

function text_length(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
}

function truncate_text(string $value, int $max): string
{
    return function_exists('mb_substr') ? mb_substr($value, 0, $max) : substr($value, 0, $max);
}

function safe_https_url(mixed $value): string
{
    $url = trim((string) $value);
    return filter_var($url, FILTER_VALIDATE_URL) && str_starts_with(strtolower($url), 'https://') ? $url : '';
}
