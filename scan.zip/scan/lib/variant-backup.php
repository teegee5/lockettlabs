<?php
declare(strict_types=1);

/**
 * Variant snapshots and collapsed-product detection.
 *
 * Shopify has no undo for deleted variants. A productSet call without a
 * variants array is a full replace: on 28 July 2026 one collapsed every
 * multi-variant product in the catalogue to a single variant, and inventory
 * quantities were unrecoverable because nothing had recorded them.
 *
 * Shared by tools/backup-variants.php (cron) and api/variant-backup.php (the
 * browser panel) so the two cannot drift.
 *
 * The catalogue export is a bulk operation, which takes minutes. The work is
 * therefore split: start it, poll it, then collect. The browser drives those
 * three steps across separate requests so nothing runs into a PHP timeout.
 */

require_once __DIR__ . '/bootstrap.php';

function variant_backup_dir(): string
{
    return APP_ROOT . '/cache/variant-backups';
}

/**
 * Option names that tell us nothing when only one variant is present.
 *
 * "Title" is Shopify's placeholder for a genuinely single-variant product.
 * "Condition" is the intake app's own option: it creates one variant per
 * condition actually held, so a single Near Mint variant is the normal and
 * overwhelmingly common state across ~14k card singles. Flagging those buries
 * the real damage — the first live run reported 114 products of which 111 were
 * ordinary singles.
 */
const VARIANT_BACKUP_IGNORED_OPTIONS = ['title', 'condition'];

/**
 * A product carrying a meaningful option name but a single variant is the
 * damage signature: "Style", "Coin Type", "Tin Type" and the like describe a
 * range, so one value left means the rest were removed.
 */
function variant_backup_is_collapsed(array $product, int $variantCount): bool
{
    if ($variantCount !== 1) return false;
    foreach ($product['options'] ?? [] as $option) {
        $name = strtolower(trim((string) ($option['name'] ?? '')));
        if ($name === '' || in_array($name, VARIANT_BACKUP_IGNORED_OPTIONS, true)) continue;
        return true;
    }
    return false;
}

/** @return string Bulk operation id. */
function variant_backup_start(): string
{
    $query = <<<'GRAPHQL'
{
  products {
    edges {
      node {
        id
        title
        handle
        status
        totalInventory
        options { name optionValues { name } }
        variants {
          edges {
            node { id title sku price compareAtPrice inventoryQuantity inventoryPolicy inventoryItem { tracked } }
          }
        }
      }
    }
  }
}
GRAPHQL;

    $data = shopify_graphql(<<<'GRAPHQL'
mutation StartVariantBackup($query: String!) {
  bulkOperationRunQuery(query: $query) {
    bulkOperation { id status }
    userErrors { field message }
  }
}
GRAPHQL, ['query' => $query]);

    $errors = $data['bulkOperationRunQuery']['userErrors'] ?? [];
    if ($errors !== []) {
        throw new RuntimeException('Could not start the export: ' . ($errors[0]['message'] ?? 'unknown error'));
    }
    $id = (string) ($data['bulkOperationRunQuery']['bulkOperation']['id'] ?? '');
    if ($id === '') throw new RuntimeException('Shopify did not return an export id.');
    return $id;
}

/** @return array{status: string, url: string, objectCount: int} */
function variant_backup_poll(): array
{
    $data = shopify_graphql('{ currentBulkOperation(type: QUERY) { status errorCode url objectCount } }');
    $op = $data['currentBulkOperation'] ?? [];
    $status = (string) ($op['status'] ?? 'UNKNOWN');
    if (in_array($status, ['FAILED', 'CANCELED', 'EXPIRED'], true)) {
        throw new RuntimeException('Export ' . strtolower($status) . ': ' . (string) ($op['errorCode'] ?? ''));
    }
    return [
        'status' => $status,
        'url' => (string) ($op['url'] ?? ''),
        'objectCount' => (int) ($op['objectCount'] ?? 0),
    ];
}

/** @return array{products: array, variants: int} */
function variant_backup_parse(string $jsonl): array
{
    $products = [];
    $variantsByParent = [];
    foreach (explode("\n", $jsonl) as $line) {
        if (trim($line) === '') continue;
        $row = json_decode($line, true);
        if (!is_array($row)) continue;
        if (isset($row['__parentId'])) {
            $variantsByParent[$row['__parentId']][] = $row;
        } elseif (isset($row['id']) && str_contains((string) $row['id'], '/Product/')) {
            $products[$row['id']] = $row;
        }
    }

    $out = [];
    $variantTotal = 0;
    foreach ($products as $id => $product) {
        $variants = $variantsByParent[$id] ?? [];
        $variantTotal += count($variants);
        $product['variants'] = array_map(static fn(array $v): array => [
            'id' => $v['id'] ?? '',
            'title' => $v['title'] ?? '',
            'sku' => $v['sku'] ?? '',
            'price' => $v['price'] ?? '',
            'compareAtPrice' => $v['compareAtPrice'] ?? null,
            'inventoryQuantity' => $v['inventoryQuantity'] ?? 0,
            'inventoryPolicy' => $v['inventoryPolicy'] ?? '',
            // Kept flat: the oversell check needs it, and a snapshot restore
            // should put a variant back on the same inventory gate it had.
            'tracked' => $v['inventoryItem']['tracked'] ?? null,
        ], $variants);
        $out[] = $product;
    }
    return ['products' => $out, 'variants' => $variantTotal];
}

/**
 * Variants a shopper could add to cart while out of stock.
 *
 * Hiding the Add to basket button is presentation only: anyone can POST to
 * /cart/add.js. The single thing that actually refuses the add is Shopify's own
 * inventory gate, and it needs BOTH tracked inventory and a DENY policy. A
 * CONTINUE policy is an explicit "allow overselling", and untracked inventory
 * means Shopify has no count to check, so both are addable at zero no matter
 * what the theme renders.
 *
 * @return array<int, array{title: string, variant: string, policy: string, tracked: bool, quantity: int}>
 */
function variant_backup_oversellable(array $products): array
{
    $out = [];
    foreach ($products as $product) {
        if (($product['status'] ?? '') !== 'ACTIVE') continue;
        foreach ($product['variants'] ?? [] as $variant) {
            $policy = strtoupper((string) ($variant['inventoryPolicy'] ?? ''));
            $tracked = $variant['inventoryItem']['tracked'] ?? $variant['tracked'] ?? null;
            $qty = (int) ($variant['inventoryQuantity'] ?? 0);
            $loose = ($policy === 'CONTINUE') || ($tracked === false);
            if (!$loose) continue;
            $out[] = [
                'title' => (string) ($product['title'] ?? ''),
                'variant' => (string) ($variant['title'] ?? ''),
                'policy' => $policy === '' ? '?' : $policy,
                'tracked' => $tracked !== false,
                'quantity' => $qty,
            ];
        }
    }
    return $out;
}

/**
 * Download the finished export and summarise it.
 *
 * @return array{products: int, variants: int, collapsed: array, oversellable: array, payload: array}
 */
function variant_backup_collect(string $url): array
{
    $jsonl = @file_get_contents($url);
    if ($jsonl === false) throw new RuntimeException('Could not download the export file.');

    $parsed = variant_backup_parse($jsonl);
    $collapsed = [];
    foreach ($parsed['products'] as $product) {
        if (!variant_backup_is_collapsed($product, count($product['variants']))) continue;
        $collapsed[] = [
            'title' => (string) ($product['title'] ?? ''),
            'handle' => (string) ($product['handle'] ?? ''),
            'option' => (string) ($product['options'][0]['name'] ?? ''),
            'survivor' => (string) ($product['variants'][0]['title'] ?? ''),
        ];
    }

    $oversellable = variant_backup_oversellable($parsed['products']);

    return [
        'products' => count($parsed['products']),
        'variants' => $parsed['variants'],
        'collapsed' => $collapsed,
        'oversellable' => $oversellable,
        'payload' => [
            'takenAt' => gmdate('c'),
            'productCount' => count($parsed['products']),
            'variantCount' => $parsed['variants'],
            'collapsed' => count($collapsed),
            'oversellable' => count($oversellable),
            'products' => $parsed['products'],
        ],
    ];
}

/** @return string Path written. */
function variant_backup_write(array $payload, int $keepDays = 0): string
{
    $dir = variant_backup_dir();
    if (!is_dir($dir) && !@mkdir($dir, 0750, true)) {
        throw new RuntimeException('Could not create ' . $dir);
    }
    $path = $dir . '/variants-' . gmdate('Y-m-d-His') . '.json';
    $bytes = @file_put_contents($path, json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    if ($bytes === false) throw new RuntimeException('Could not write ' . $path);

    if ($keepDays > 0) {
        $cutoff = time() - ($keepDays * 86400);
        foreach (glob($dir . '/variants-*.json') ?: [] as $file) {
            if (filemtime($file) < $cutoff) @unlink($file);
        }
    }
    return $path;
}

/** @return array<int, array{name: string, takenAt: string, products: int, variants: int, collapsed: int, bytes: int}> */
function variant_backup_list(int $limit = 20): array
{
    $files = glob(variant_backup_dir() . '/variants-*.json') ?: [];
    rsort($files);
    $out = [];
    foreach (array_slice($files, 0, $limit) as $file) {
        // Read only the head: these files are megabytes and the summary is at the top.
        $head = (string) @file_get_contents($file, false, null, 0, 400);
        preg_match('/"takenAt":"([^"]*)"/', $head, $t);
        preg_match('/"productCount":(\d+)/', $head, $p);
        preg_match('/"variantCount":(\d+)/', $head, $v);
        preg_match('/"collapsed":(\d+)/', $head, $c);
        $out[] = [
            'name' => basename($file),
            'takenAt' => $t[1] ?? '',
            'products' => (int) ($p[1] ?? 0),
            'variants' => (int) ($v[1] ?? 0),
            'collapsed' => (int) ($c[1] ?? 0),
            'bytes' => (int) @filesize($file),
        ];
    }
    return $out;
}
