<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

/**
 * Look up the exact Shopify variants created by this app. SKUs are the stable
 * join key because every card/finish/condition combination receives one.
 */
function shopify_variants_by_sku(array $skus, string $locationId): array
{
    if (!preg_match('#^gid://shopify/Location/\d+$#', $locationId)) {
        throw new InvalidArgumentException('Choose a Shopify inventory location.');
    }

    $cleanSkus = [];
    foreach ($skus as $sku) {
        $sku = clean_text($sku, 100);
        if ($sku === '') continue;
        $key = strtoupper($sku);
        if (!isset($cleanSkus[$key])) $cleanSkus[$key] = $sku;
    }
    $cleanSkus = array_values($cleanSkus);
    if ($cleanSkus === []) return [];
    if (count($cleanSkus) > 25) throw new InvalidArgumentException('Too many SKUs were supplied for one stock check.');

    $declarations = ['$locationId: ID!'];
    $fields = [];
    $variables = ['locationId' => $locationId];
    foreach ($cleanSkus as $index => $sku) {
        $variable = 'search' . $index;
        $alias = 'sku' . $index;
        $searchVariable = '$' . $variable;
        $locationVariable = '$locationId';
        $declarations[] = '$' . $variable . ': String!';
        $variables[$variable] = 'sku:"' . addcslashes($sku, '\\"') . '"';
        $fields[] = <<<GRAPHQL
  {$alias}: productVariants(first: 10, query: {$searchVariable}) {
    nodes {
      id title sku price inventoryQuantity
      product {
        id title handle status onlineStoreUrl onlineStorePreviewUrl
        featuredMedia { preview { image { url altText width height } } }
      }
      inventoryItem {
        id tracked
        inventoryLevel(locationId: {$locationVariable}, includeInactive: true) {
          isActive
          quantities(names: ["available"]) { name quantity }
        }
      }
    }
  }
GRAPHQL;
    }

    $query = 'query ExistingCardStock(' . implode(', ', $declarations) . ") {\n" . implode("\n", $fields) . "\n}";
    $data = shopify_graphql($query, $variables);
    return normalize_shopify_stock_matches($data, $cleanSkus);
}

/** Pure response normalizer, kept separate so matching can be regression-tested. */
function normalize_shopify_stock_matches(array $data, array $skus): array
{
    $matches = [];
    foreach (array_values($skus) as $index => $sku) {
        $nodes = is_array($data['sku' . $index]['nodes'] ?? null) ? $data['sku' . $index]['nodes'] : [];
        $exact = array_values(array_filter($nodes, static fn($node): bool =>
            is_array($node) && strcasecmp(trim((string) ($node['sku'] ?? '')), trim((string) $sku)) === 0
        ));

        $match = [
            'sku' => (string) $sku,
            'found' => count($exact) === 1,
            'ambiguous' => count($exact) > 1,
            'existingQuantity' => 0,
            'totalQuantity' => 0,
            'inventoryActive' => false,
            'variant' => null,
            'product' => null,
        ];

        if (count($exact) === 1) {
            $node = $exact[0];
            $inventoryItem = is_array($node['inventoryItem'] ?? null) ? $node['inventoryItem'] : [];
            $level = is_array($inventoryItem['inventoryLevel'] ?? null) ? $inventoryItem['inventoryLevel'] : null;
            $available = 0;
            foreach (is_array($level['quantities'] ?? null) ? $level['quantities'] : [] as $quantity) {
                if (($quantity['name'] ?? '') === 'available') $available = (int) ($quantity['quantity'] ?? 0);
            }
            $match['existingQuantity'] = $available;
            $match['totalQuantity'] = (int) ($node['inventoryQuantity'] ?? 0);
            $match['inventoryActive'] = $level !== null && !empty($level['isActive']);
            $match['variant'] = [
                'id' => (string) ($node['id'] ?? ''),
                'title' => clean_text($node['title'] ?? '', 180),
                'sku' => clean_text($node['sku'] ?? '', 100),
                'price' => (string) ($node['price'] ?? ''),
                'inventoryItemId' => (string) ($inventoryItem['id'] ?? ''),
            ];
            $match['product'] = is_array($node['product'] ?? null) ? [
                'id' => (string) ($node['product']['id'] ?? ''),
                'title' => clean_text($node['product']['title'] ?? '', 255),
                'handle' => clean_text($node['product']['handle'] ?? '', 255),
                'status' => clean_text($node['product']['status'] ?? '', 40),
                'adminUrl' => shopify_admin_product_url((string) ($node['product']['id'] ?? '')),
                'onlineStoreUrl' => safe_https_url($node['product']['onlineStoreUrl'] ?? $node['product']['onlineStorePreviewUrl'] ?? ''),
                'image' => normalize_shopify_product_image($node['product']),
            ] : null;
        }
        $matches[] = $match;
    }
    return $matches;
}

function shopify_stock_mode(array $matches): string
{
    if (array_filter($matches, static fn(array $match): bool => !empty($match['ambiguous']))) return 'ambiguous';
    $found = count(array_filter($matches, static fn(array $match): bool => !empty($match['found'])));
    if ($found === 0) return 'new';
    return $found === count($matches) ? 'existing' : 'mixed';
}

function shopify_card_identity(array $source): array
{
    return [
        'externalId' => clean_text($source['externalId'] ?? '', 180),
        'title' => clean_text($source['title'] ?? '', 255),
        'name' => clean_text($source['name'] ?? '', 220),
        'englishName' => clean_text($source['englishName'] ?? '', 220),
        'setName' => clean_text($source['setName'] ?? '', 220),
        'englishSetName' => clean_text($source['englishSetName'] ?? '', 220),
        'cardNumber' => clean_text($source['cardNumber'] ?? '', 80),
        'finish' => clean_text($source['finish'] ?? '', 100),
        'game' => clean_text($source['game'] ?? '', 120),
        'gameName' => clean_text($source['gameName'] ?? '', 120),
    ];
}

function shopify_product_selection(): string
{
    return <<<'GRAPHQL'
id title handle status onlineStoreUrl onlineStorePreviewUrl
featuredMedia { preview { image { url altText width height } } }
databaseId: metafield(namespace: "tcg", key: "database_id") { value }
cardNumber: metafield(namespace: "tcg", key: "card_number") { value }
setName: metafield(namespace: "tcg", key: "set_name") { value }
englishSetName: metafield(namespace: "tcg", key: "english_set_name") { value }
originalName: metafield(namespace: "tcg", key: "original_name") { value }
englishName: metafield(namespace: "tcg", key: "english_name") { value }
finish: metafield(namespace: "tcg", key: "finish") { value }
gameId: metafield(namespace: "tcg", key: "game_id") { value }
variants(first: 10) {
  nodes {
    id title sku price inventoryQuantity
    selectedOptions { name value }
    inventoryItem {
      id tracked
      inventoryLevel(locationId: $locationId, includeInactive: true) {
        isActive
        quantities(names: ["available"]) { name quantity }
      }
    }
  }
}
GRAPHQL;
}

function shopify_product_by_id(string $productId, string $locationId): ?array
{
    if (!preg_match('#^gid://shopify/Product/\d+$#', $productId)) return null;
    $selection = shopify_product_selection();
    $data = shopify_graphql(<<<GRAPHQL
query ExistingCardProduct(\$id: ID!, \$locationId: ID!) {
  product(id: \$id) {
    {$selection}
  }
}
GRAPHQL, ['id' => $productId, 'locationId' => $locationId]);
    return is_array($data['product'] ?? null) ? normalize_shopify_product_record($data['product']) : null;
}

function shopify_search_card_products(array $identity, string $locationId): array
{
    $queries = shopify_card_search_queries($identity);
    if ($queries === []) return [];

    $selection = shopify_product_selection();
    $declarations = ['$locationId: ID!'];
    $fields = [];
    $variables = ['locationId' => $locationId];
    foreach (array_values($queries) as $index => $search) {
        $variable = 'search' . $index;
        $searchVariable = '$' . $variable;
        $declarations[] = '$' . $variable . ': String!';
        $variables[$variable] = $search;
        $fields[] = <<<GRAPHQL
  result{$index}: products(first: 15, query: {$searchVariable}) {
    nodes {
      {$selection}
    }
  }
GRAPHQL;
    }

    $query = 'query SimilarCardProducts(' . implode(', ', $declarations) . ") {\n" . implode("\n", $fields) . "\n}";
    $data = shopify_graphql($query, $variables);
    $products = [];
    foreach (array_values($queries) as $index => $_search) {
        foreach (is_array($data['result' . $index]['nodes'] ?? null) ? $data['result' . $index]['nodes'] : [] as $node) {
            if (!is_array($node) || empty($node['id'])) continue;
            $products[(string) $node['id']] = normalize_shopify_product_record($node);
        }
    }
    return array_values($products);
}

/**
 * Shopify's title field filter can behave like an exact phrase lookup for
 * punctuation-heavy card titles. Broad search terms reliably return those
 * products, after which the local scorer enforces name/set/number safety.
 */
function shopify_card_search_queries(array $identity): array
{
    $name = trim((string) (($identity['englishName'] ?? '') ?: ($identity['name'] ?? '')));
    $set = trim((string) (($identity['englishSetName'] ?? '') ?: ($identity['setName'] ?? '')));
    $number = trim((string) ($identity['cardNumber'] ?? ''));
    $rawQueries = [
        trim($name . ' ' . $number),
        $number,
        trim($set . ' ' . $number),
        trim($name . ' ' . $set),
        $name,
    ];

    $queries = [];
    foreach ($rawQueries as $value) {
        if ($value === '') continue;
        $escaped = strtr($value, ['\\' => '\\\\', ':' => '\\:', '(' => '\\(', ')' => '\\)']);
        $queries[$escaped] = $escaped;
        if (count($queries) >= 5) break;
    }
    return array_values($queries);
}

function normalize_shopify_product_record(array $node): array
{
    $metadata = [];
    foreach (['databaseId', 'cardNumber', 'setName', 'englishSetName', 'originalName', 'englishName', 'finish', 'gameId'] as $key) {
        $metadata[$key] = clean_text($node[$key]['value'] ?? '', $key === 'cardNumber' ? 80 : 255);
    }
    $variants = [];
    foreach (is_array($node['variants']['nodes'] ?? null) ? $node['variants']['nodes'] : [] as $variant) {
        if (!is_array($variant) || empty($variant['id'])) continue;
        $inventoryItem = is_array($variant['inventoryItem'] ?? null) ? $variant['inventoryItem'] : [];
        $level = is_array($inventoryItem['inventoryLevel'] ?? null) ? $inventoryItem['inventoryLevel'] : null;
        $available = 0;
        foreach (is_array($level['quantities'] ?? null) ? $level['quantities'] : [] as $quantity) {
            if (($quantity['name'] ?? '') === 'available') $available = (int) ($quantity['quantity'] ?? 0);
        }
        $variants[] = [
            'id' => (string) $variant['id'],
            'title' => clean_text($variant['title'] ?? '', 180),
            'sku' => clean_text($variant['sku'] ?? '', 100),
            'price' => (string) ($variant['price'] ?? ''),
            'inventoryQuantity' => (int) ($variant['inventoryQuantity'] ?? 0),
            'inventoryItemId' => (string) ($inventoryItem['id'] ?? ''),
            'existingQuantity' => $available,
            'inventoryActive' => $level !== null && !empty($level['isActive']),
            'selectedOptions' => array_values(array_filter(array_map(
                static fn($option): string => is_array($option) ? clean_text($option['value'] ?? '', 100) : '',
                is_array($variant['selectedOptions'] ?? null) ? $variant['selectedOptions'] : []
            ))),
        ];
    }
    return [
        'id' => (string) ($node['id'] ?? ''),
        'title' => clean_text($node['title'] ?? '', 255),
        'handle' => clean_text($node['handle'] ?? '', 255),
        'status' => clean_text($node['status'] ?? '', 40),
        'onlineStoreUrl' => safe_https_url($node['onlineStoreUrl'] ?? $node['onlineStorePreviewUrl'] ?? ''),
        'image' => normalize_shopify_product_image($node),
        'metadata' => $metadata,
        'variants' => $variants,
    ];
}

function normalize_shopify_product_image(array $node): ?array
{
    $image = is_array($node['featuredMedia']['preview']['image'] ?? null) ? $node['featuredMedia']['preview']['image'] : [];
    $url = safe_https_url($image['url'] ?? '');
    if ($url === '') return null;
    return [
        'url' => $url,
        'altText' => clean_text($image['altText'] ?? '', 255),
        'width' => max(0, (int) ($image['width'] ?? 0)),
        'height' => max(0, (int) ($image['height'] ?? 0)),
    ];
}

function shopify_match_text(string $value): string
{
    $value = trim($value);
    $value = function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
    return preg_replace('/[^\p{L}\p{N}]+/u', '', $value) ?? '';
}

function shopify_condition_key(string $value): string
{
    $key = shopify_match_text($value);
    return match ($key) {
        'nm', 'mint', 'nearmint' => 'nearmint',
        'lp', 'lightplay', 'lightlyplayed' => 'lightlyplayed',
        'mp', 'moderateplay', 'moderatelyplayed' => 'moderatelyplayed',
        'hp', 'heavyplay', 'heavilyplayed' => 'heavilyplayed',
        'dmg', 'damage', 'damaged' => 'damaged',
        default => $key,
    };
}

function shopify_number_signature(string $value): array
{
    $value = strtoupper(trim($value));
    $value = preg_replace('/[\x{FF0F}\x{2044}\x{2215}]/u', '/', $value) ?? $value;
    $value = preg_replace('/[\x{FF0D}\x{2013}\x{2014}\x{2212}]/u', '-', $value) ?? $value;
    $token = '';
    $patterns = [
        '/(?:[A-Z]{1,12}\d{0,6}[A-Z]?[- ])?[A-Z]*\d{1,6}[A-Z]*\/\d{1,6}/',
        '/\b[A-Z]{1,12}\d{0,6}[A-Z]?-[A-Z]*\d{1,6}[A-Z]*\b/',
        '/(?:\s[-#]\s*|#)([A-Z]*\d{1,6}[A-Z]*)\s*$/',
    ];
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $value, $match)) { $token = $match[1] ?? $match[0]; break; }
    }
    if ($token === '' && preg_match('/^[A-Z]*\d{1,6}[A-Z]*(?:\/\d{1,6})?$/', $value)) $token = $value;
    $token = preg_replace('/\s+/', '', $token) ?? '';

    $setCode = '';
    $local = '';
    $denominator = '';
    if (preg_match('/^([A-Z]{1,12}\d{0,6}[A-Z]?)-([A-Z]*\d{1,6}[A-Z]*)(?:\/(\d{1,6}))?$/', $token, $match)) {
        $setCode = $match[1];
        $local = $match[2];
        $denominator = $match[3] ?? '';
    } elseif (preg_match('/^([A-Z]*\d{1,6}[A-Z]*)(?:\/(\d{1,6}))?$/', $token, $match)) {
        $local = $match[1];
        $denominator = $match[2] ?? '';
    }
    $canonical = static function (string $part): string {
        if (!preg_match('/^([A-Z]*)(\d+)([A-Z]*)$/', $part, $match)) return $part;
        $number = ltrim($match[2], '0');
        return $match[1] . ($number === '' ? '0' : $number) . $match[3];
    };
    return ['setCode' => $setCode, 'local' => $canonical($local), 'denominator' => $canonical($denominator), 'hasNumber' => $local !== ''];
}

function shopify_card_numbers_equal(string $expected, string $candidate): bool
{
    $wanted = shopify_number_signature($expected);
    $found = shopify_number_signature($candidate);
    if (empty($wanted['hasNumber']) || empty($found['hasNumber']) || $wanted['local'] !== $found['local']) return false;
    if ($wanted['denominator'] !== '' && $wanted['denominator'] !== $found['denominator']) return false;
    if ($wanted['setCode'] !== '' && $wanted['setCode'] !== $found['setCode']) return false;
    return true;
}

function shopify_fuzzy_phrase_score(string $needle, string $candidate): float
{
    $needleTokens = array_values(array_filter(preg_split('/[^a-z0-9]+/', strtolower($needle)) ?: [], static fn(string $token): bool => strlen($token) > 1));
    $candidateTokens = array_values(array_filter(preg_split('/[^a-z0-9]+/', strtolower($candidate)) ?: [], static fn(string $token): bool => strlen($token) > 1));
    if ($needleTokens === [] || $candidateTokens === []) return 0.0;
    $total = 0.0;
    foreach ($needleTokens as $needleToken) {
        $best = 0.0;
        foreach ($candidateTokens as $candidateToken) {
            $length = max(strlen($needleToken), strlen($candidateToken));
            if ($length === 0) continue;
            $best = max($best, 1 - (levenshtein($needleToken, $candidateToken) / $length));
        }
        $total += $best;
    }
    return $total / count($needleTokens);
}

function shopify_basic_product(array $product): array
{
    return [
        'id' => (string) ($product['id'] ?? ''),
        'title' => clean_text($product['title'] ?? '', 255),
        'handle' => clean_text($product['handle'] ?? '', 255),
        'status' => clean_text($product['status'] ?? '', 40),
        'adminUrl' => shopify_admin_product_url((string) ($product['id'] ?? '')),
        'onlineStoreUrl' => safe_https_url($product['onlineStoreUrl'] ?? ''),
        'image' => is_array($product['image'] ?? null) ? $product['image'] : null,
    ];
}

function shopify_match_product_variants(array $product, array $variantRequests): array
{
    $matches = [];
    $used = [];
    $allowSingle = count($variantRequests) === 1 && count($product['variants'] ?? []) === 1;
    $basicProduct = shopify_basic_product($product);
    foreach ($variantRequests as $request) {
        $requestedSku = clean_text($request['sku'] ?? '', 100);
        $condition = clean_text($request['condition'] ?? '', 60);
        $availableVariants = array_values(array_filter($product['variants'] ?? [], static fn(array $variant): bool => empty($used[$variant['id'] ?? ''])));
        $exactSku = array_values(array_filter($availableVariants, static fn(array $variant): bool =>
            trim((string) ($variant['sku'] ?? '')) !== '' && strcasecmp((string) $variant['sku'], $requestedSku) === 0
        ));
        $candidates = $exactSku;
        $matchType = 'sku';
        if ($candidates === []) {
            $conditionKey = shopify_condition_key($condition);
            $candidates = array_values(array_filter($availableVariants, static function (array $variant) use ($conditionKey): bool {
                foreach (array_merge([(string) ($variant['title'] ?? '')], $variant['selectedOptions'] ?? []) as $value) {
                    $candidate = shopify_condition_key((string) $value);
                    if ($candidate !== '' && ($candidate === $conditionKey || str_contains($candidate, $conditionKey) || str_contains($conditionKey, $candidate))) return true;
                }
                return false;
            }));
            $matchType = 'condition';
        }
        if ($candidates === [] && $allowSingle) {
            $candidates = $availableVariants;
            $matchType = 'single variant';
        }

        $match = [
            'sku' => $requestedSku,
            'found' => count($candidates) === 1,
            'ambiguous' => count($candidates) > 1,
            'existingQuantity' => 0,
            'totalQuantity' => 0,
            'inventoryActive' => false,
            'matchType' => $matchType,
            'variant' => null,
            'product' => $basicProduct,
        ];
        if (count($candidates) === 1) {
            $variant = $candidates[0];
            $used[(string) $variant['id']] = true;
            $match['existingQuantity'] = (int) ($variant['existingQuantity'] ?? 0);
            $match['totalQuantity'] = (int) ($variant['inventoryQuantity'] ?? 0);
            $match['inventoryActive'] = !empty($variant['inventoryActive']);
            $match['variant'] = [
                'id' => (string) ($variant['id'] ?? ''),
                'title' => clean_text($variant['title'] ?? '', 180),
                'sku' => clean_text($variant['sku'] ?? '', 100),
                'price' => (string) ($variant['price'] ?? ''),
                'inventoryItemId' => (string) ($variant['inventoryItemId'] ?? ''),
            ];
        }
        $matches[] = $match;
    }
    return $matches;
}

function score_shopify_card_product(array $identity, array $product, array $variantRequests): array
{
    $metadata = $product['metadata'] ?? [];
    $title = (string) ($product['title'] ?? '');
    $titleKey = shopify_match_text($title);
    $score = 0;
    $reasons = [];

    $databaseExact = ($identity['externalId'] ?? '') !== '' && strcasecmp((string) ($identity['externalId'] ?? ''), (string) ($metadata['databaseId'] ?? '')) === 0;
    if ($databaseExact) { $score += 100; $reasons[] = 'Exact database ID'; }

    $numberExpected = (string) ($identity['cardNumber'] ?? '');
    $numberCandidate = (string) (($metadata['cardNumber'] ?? '') ?: $title);
    $numberExact = $numberExpected !== '' && (
        shopify_card_numbers_equal($numberExpected, (string) ($metadata['cardNumber'] ?? ''))
        || shopify_card_numbers_equal($numberExpected, $title)
    );
    if ($numberExact) { $score += 42; $reasons[] = 'Exact card number'; }
    $candidateNumberSignature = shopify_number_signature($numberCandidate);
    $numberConflict = $numberExpected !== '' && !empty($candidateNumberSignature['hasNumber']) && !$numberExact;
    if ($numberConflict) $reasons[] = 'Different card number';

    $names = array_values(array_unique(array_filter([(string) ($identity['englishName'] ?? ''), (string) ($identity['name'] ?? '')])));
    $candidateNames = array_values(array_unique(array_filter([(string) ($metadata['englishName'] ?? ''), (string) ($metadata['originalName'] ?? '')])));
    $nameMatch = false;
    foreach ($names as $name) {
        $nameKey = shopify_match_text($name);
        if ($nameKey === '') continue;
        if (array_filter($candidateNames, static fn(string $candidate): bool => shopify_match_text($candidate) === $nameKey)) {
            $score += 28; $reasons[] = 'Exact card name'; $nameMatch = true; break;
        }
        if (str_contains($titleKey, $nameKey)) {
            $score += 24; $reasons[] = 'Card name in title'; $nameMatch = true; break;
        }
        $similarity = shopify_fuzzy_phrase_score($name, $title);
        if ($similarity >= .84) { $score += 18; $reasons[] = 'Close card name'; $nameMatch = true; break; }
        if ($similarity >= .70) { $score += 10; $reasons[] = 'Possible card name'; $nameMatch = true; break; }
    }

    $sets = array_values(array_unique(array_filter([(string) ($identity['englishSetName'] ?? ''), (string) ($identity['setName'] ?? '')])));
    $candidateSets = array_values(array_unique(array_filter([(string) ($metadata['englishSetName'] ?? ''), (string) ($metadata['setName'] ?? '')])));
    $setMatch = false;
    foreach ($sets as $set) {
        $setKey = shopify_match_text($set);
        if ($setKey === '') continue;
        if (array_filter($candidateSets, static fn(string $candidate): bool => shopify_match_text($candidate) === $setKey)) {
            $score += 20; $reasons[] = 'Exact set'; $setMatch = true; break;
        }
        if (str_contains($titleKey, $setKey)) {
            $score += 16; $reasons[] = 'Set in title'; $setMatch = true; break;
        }
        if (shopify_fuzzy_phrase_score($set, $title) >= .82) { $score += 11; $reasons[] = 'Close set'; $setMatch = true; break; }
    }

    $finishKey = shopify_match_text((string) ($identity['finish'] ?? ''));
    $candidateFinish = shopify_match_text(implode(' ', [(string) ($metadata['finish'] ?? ''), $title]));
    if ($finishKey !== '' && str_contains($candidateFinish, $finishKey)) { $score += 6; $reasons[] = 'Finish match'; }

    $gameKey = shopify_match_text((string) (($identity['game'] ?? '') ?: ($identity['gameName'] ?? '')));
    $candidateGame = shopify_match_text((string) ($metadata['gameId'] ?? ''));
    if ($gameKey !== '' && $candidateGame !== '' && ($gameKey === $candidateGame || str_contains($candidateGame, $gameKey) || str_contains($gameKey, $candidateGame))) {
        $score += 4; $reasons[] = 'Game match';
    }

    $matches = shopify_match_product_variants($product, $variantRequests);
    $usable = shopify_stock_mode($matches) === 'existing';
    $eligible = !$numberConflict && (
        $databaseExact
        || ($numberExact && ($nameMatch || $setMatch) && $score >= 60)
        || ($numberExpected === '' && $nameMatch && $setMatch && $score >= 55)
    );
    return [
        'product' => shopify_basic_product($product),
        'score' => min(100, $score),
        'reasons' => array_values(array_unique($reasons)),
        'numberExact' => $numberExact,
        'numberConflict' => $numberConflict,
        'eligible' => $eligible,
        'usable' => $usable,
        'matches' => $matches,
    ];
}

function shopify_card_product_candidates(array $identity, array $variantRequests, string $locationId): array
{
    $candidates = array_map(
        static fn(array $product): array => score_shopify_card_product($identity, $product, $variantRequests),
        shopify_search_card_products($identity, $locationId)
    );
    $candidates = array_values(array_filter($candidates, static fn(array $candidate): bool => $candidate['score'] >= 35));
    usort($candidates, static fn(array $a, array $b): int => [$b['score'], $b['product']['title']] <=> [$a['score'], $a['product']['title']]);
    return array_slice($candidates, 0, 5);
}

function shopify_resolve_card_stock(
    array $identity,
    array $variantRequests,
    string $locationId,
    string $preferredProductId = '',
    bool $forceCreateNew = false
): array {
    $identity = shopify_card_identity($identity);
    $skuMatches = shopify_variants_by_sku(array_column($variantRequests, 'sku'), $locationId);
    $skuMode = shopify_stock_mode($skuMatches);
    if ($skuMode === 'ambiguous') return ['mode' => 'ambiguous', 'matches' => $skuMatches, 'products' => [], 'candidates' => [], 'matchMethod' => 'sku'];

    $foundProductIds = array_values(array_unique(array_filter(array_map(
        static fn(array $match): string => !empty($match['found']) ? (string) ($match['product']['id'] ?? '') : '',
        $skuMatches
    ))));
    if (count($foundProductIds) > 1) return ['mode' => 'ambiguous', 'matches' => $skuMatches, 'products' => [], 'candidates' => [], 'matchMethod' => 'sku'];
    if ($skuMode === 'existing' && count($foundProductIds) === 1) {
        $product = $skuMatches[0]['product'];
        $product['adminUrl'] = shopify_admin_product_url((string) $product['id']);
        return ['mode' => 'existing', 'matches' => $skuMatches, 'products' => [$product], 'candidates' => [], 'matchMethod' => 'Exact SKU'];
    }
    if (count($foundProductIds) === 1) {
        $product = shopify_product_by_id($foundProductIds[0], $locationId);
        if ($product !== null) {
            $matches = shopify_match_product_variants($product, $variantRequests);
            if (shopify_stock_mode($matches) === 'existing') {
                return ['mode' => 'existing', 'matches' => $matches, 'products' => [shopify_basic_product($product)], 'candidates' => [], 'matchMethod' => 'SKU and condition'];
            }
        }
        return ['mode' => 'mixed', 'matches' => $skuMatches, 'products' => [], 'candidates' => [], 'matchMethod' => 'sku'];
    }

    // A deliberate staff rejection can create a new listing, but only after
    // the exact-SKU safeguards above have proved that no SKU is already used.
    if ($forceCreateNew) return ['mode' => 'new', 'matches' => $skuMatches, 'products' => [], 'candidates' => [], 'matchMethod' => 'staff choice'];

    if ($preferredProductId !== '') {
        $preferred = shopify_product_by_id($preferredProductId, $locationId);
        if ($preferred !== null) {
            $candidate = score_shopify_card_product($identity, $preferred, $variantRequests);
            if ($candidate['usable'] && $candidate['score'] >= 35) {
                return ['mode' => 'existing', 'matches' => $candidate['matches'], 'products' => [$candidate['product']], 'candidates' => [], 'matchMethod' => 'Confirmed title match', 'score' => $candidate['score'], 'reasons' => $candidate['reasons']];
            }
        }
        return ['mode' => 'candidate', 'matches' => [], 'products' => [], 'candidates' => [], 'matchMethod' => 'confirmation expired'];
    }

    $candidates = shopify_card_product_candidates($identity, $variantRequests, $locationId);
    $best = $candidates[0] ?? null;
    $secondScore = (int) ($candidates[1]['score'] ?? 0);
    if ($best && $best['usable'] && $best['eligible'] && $best['score'] >= 75 && ($best['score'] - $secondScore >= 8 || count($candidates) === 1)) {
        return ['mode' => 'existing', 'matches' => $best['matches'], 'products' => [$best['product']], 'candidates' => $candidates, 'matchMethod' => 'Card title and identity', 'score' => $best['score'], 'reasons' => $best['reasons']];
    }
    if ($candidates !== []) return ['mode' => 'candidate', 'matches' => [], 'products' => [], 'candidates' => $candidates, 'matchMethod' => 'possible title match'];
    return ['mode' => 'new', 'matches' => $skuMatches, 'products' => [], 'candidates' => [], 'matchMethod' => 'no match'];
}

/** Pure quantity projection used by the UI contract and regression tests. */
function shopify_inventory_preview(array $matches, array $variantRequests): array
{
    $bySku = [];
    foreach ($matches as $match) $bySku[strtoupper((string) ($match['sku'] ?? ''))] = $match;
    $previous = 0;
    $added = 0;
    foreach ($variantRequests as $request) {
        $match = $bySku[strtoupper((string) ($request['sku'] ?? ''))] ?? null;
        if (!$match || empty($match['found']) || !empty($match['ambiguous'])) {
            throw new RuntimeException('Every stock projection needs one exact existing Shopify SKU.');
        }
        $previous += (int) ($match['existingQuantity'] ?? 0);
        $added += max(0, (int) ($request['quantity'] ?? 0));
    }
    return ['previous' => $previous, 'added' => $added, 'current' => $previous + $added];
}

function shopify_admin_product_url(string $productId): string
{
    $shop = strtolower(trim((string) (app_config()['shopify_store'] ?? '')));
    $shop = preg_replace('#\.myshopify\.com$#', '', preg_replace('#^https?://#', '', $shop));
    $numericId = preg_replace('/\D+/', '', $productId);
    return $shop !== '' && $numericId !== '' ? "https://admin.shopify.com/store/{$shop}/products/{$numericId}" : '';
}

function inventory_operation_uuid(string $seed): string
{
    $hex = substr(hash('sha256', $seed), 0, 32);
    $hex[12] = '5';
    $hex[16] = dechex((hexdec($hex[16]) & 0x3) | 0x8);
    return substr($hex, 0, 8) . '-' . substr($hex, 8, 4) . '-' . substr($hex, 12, 4) . '-' . substr($hex, 16, 4) . '-' . substr($hex, 20, 12);
}

/** Build Shopify's concurrency-safe incremental inventory change. */
function shopify_inventory_change(string $inventoryItemId, string $locationId, int $delta, int $fromQuantity): array
{
    return [
        'delta' => $delta,
        'inventoryItemId' => $inventoryItemId,
        'locationId' => $locationId,
        'changeFromQuantity' => $fromQuantity,
    ];
}

/** Add received quantities to existing variants without replacing current stock. Optionally updates prices. */
function shopify_add_existing_stock(array $matches, array $variantRequests, string $locationId, string $operationId): array
{
    $bySku = [];
    foreach ($matches as $match) $bySku[strtoupper((string) ($match['sku'] ?? ''))] = $match;

    $changes = [];
    $updatedVariants = [];
    $priceUpdatesByProduct = [];
    $preview = shopify_inventory_preview($matches, $variantRequests);

    foreach ($variantRequests as $request) {
        $sku = strtoupper((string) ($request['sku'] ?? ''));
        $match = $bySku[$sku] ?? null;
        if (!$match || empty($match['found']) || !empty($match['ambiguous'])) {
            throw new RuntimeException('Shopify stock changed during the check. Refresh the card and try again.');
        }
        $quantity = max(0, (int) ($request['quantity'] ?? 0));
        $inventoryItemId = (string) ($match['variant']['inventoryItemId'] ?? '');
        if (!preg_match('#^gid://shopify/InventoryItem/\d+$#', $inventoryItemId)) {
            throw new RuntimeException('The existing Shopify variant is missing a valid inventory item.');
        }

        $before = (int) ($match['existingQuantity'] ?? 0);
        $after = $before + $quantity;
        if ($quantity > 0 && empty($match['inventoryActive'])) {
            $activationKey = inventory_operation_uuid($operationId . '|activate|' . $inventoryItemId . '|' . $locationId);
            $activation = shopify_graphql(<<<'GRAPHQL'
mutation ActivateCardInventory($inventoryItemId: ID!, $locationId: ID!, $available: Int, $idempotencyKey: String!) {
  inventoryActivate(inventoryItemId: $inventoryItemId, locationId: $locationId, available: $available) @idempotent(key: $idempotencyKey) {
    inventoryLevel { id quantities(names: ["available"]) { name quantity } }
    userErrors { field message }
  }
}
GRAPHQL, [
                'inventoryItemId' => $inventoryItemId,
                'locationId' => $locationId,
                'available' => $after,
                'idempotencyKey' => $activationKey,
            ]);
            $activationPayload = $activation['inventoryActivate'] ?? [];
            if (!empty($activationPayload['userErrors'])) {
                throw new RuntimeException(implode(' ', array_map(static fn(array $error): string => (string) ($error['message'] ?? 'Inventory activation failed.'), $activationPayload['userErrors'])));
            }
        } elseif ($quantity > 0) {
            $changes[] = shopify_inventory_change($inventoryItemId, $locationId, $quantity, $before);
        }

        $variantId = (string) ($match['variant']['id'] ?? '');
        $productId = (string) ($match['product']['id'] ?? '');
        $currentPrice = number_format(max(0, (float) ($match['variant']['price'] ?? 0)), 2, '.', '');
        $nextPrice = number_format(max(0, (float) ($request['price'] ?? $currentPrice)), 2, '.', '');
        $appliedPrice = $currentPrice;
        if ($variantId !== '' && $productId !== '' && $nextPrice !== $currentPrice) {
            $priceUpdatesByProduct[$productId][] = [
                'id' => $variantId,
                'price' => $nextPrice,
            ];
            $appliedPrice = $nextPrice;
        }

        $updatedVariants[] = [
            'id' => $variantId,
            'title' => (string) ($match['variant']['title'] ?? ''),
            'sku' => (string) ($match['variant']['sku'] ?? ''),
            'price' => $appliedPrice,
            'inventoryQuantity' => (int) ($match['totalQuantity'] ?? 0) + $quantity,
            'previousQuantity' => $before,
            'addedQuantity' => $quantity,
            'currentQuantity' => $after,
            'priceUpdated' => $appliedPrice !== $currentPrice,
        ];
    }

    $pricesUpdated = 0;
    foreach ($priceUpdatesByProduct as $productId => $variants) {
        $pricesUpdated += shopify_update_variant_prices($productId, $variants);
    }

    if ($changes !== []) {
        $adjustmentKey = inventory_operation_uuid($operationId . '|adjust|' . $locationId);
        $adjustment = shopify_graphql(<<<'GRAPHQL'
mutation AddCardInventory($input: InventoryAdjustQuantitiesInput!, $idempotencyKey: String!) {
  inventoryAdjustQuantities(input: $input) @idempotent(key: $idempotencyKey) {
    inventoryAdjustmentGroup { createdAt reason referenceDocumentUri changes { name delta } }
    userErrors { field message code }
  }
}
GRAPHQL, [
            'input' => [
                'reason' => 'correction',
                'name' => 'available',
                'referenceDocumentUri' => 'card-intake://restock/' . rawurlencode($operationId),
                'changes' => $changes,
            ],
            'idempotencyKey' => $adjustmentKey,
        ]);
        $adjustmentPayload = $adjustment['inventoryAdjustQuantities'] ?? [];
        if (!empty($adjustmentPayload['userErrors'])) {
            foreach ($adjustmentPayload['userErrors'] as $error) {
                if (($error['code'] ?? '') === 'CHANGE_FROM_QUANTITY_STALE') {
                    throw new RuntimeException('Shopify stock changed after the preview. Check the product again before adding quantity.');
                }
            }
            throw new RuntimeException(implode(' ', array_map(static fn(array $error): string => (string) ($error['message'] ?? 'Inventory adjustment failed.'), $adjustmentPayload['userErrors'])));
        }
    }

    return [
        'previous' => $preview['previous'],
        'added' => $preview['added'],
        'current' => $preview['current'],
        'locationId' => $locationId,
        'variants' => $updatedVariants,
        'pricesUpdated' => $pricesUpdated,
    ];
}

/**
 * @param list<array{id:string,price:string}> $variants
 */
function shopify_update_variant_prices(string $productId, array $variants): int
{
    if ($productId === '' || $variants === []) {
        return 0;
    }
    if (!preg_match('#^gid://shopify/Product/\d+$#', $productId)) {
        throw new RuntimeException('Cannot update prices: invalid Shopify product id.');
    }

    $payload = shopify_graphql(<<<'GRAPHQL'
mutation UpdateRestockVariantPrices($productId: ID!, $variants: [ProductVariantsBulkInput!]!) {
  productVariantsBulkUpdate(productId: $productId, variants: $variants) {
    productVariants { id price }
    userErrors { field message }
  }
}
GRAPHQL, [
        'productId' => $productId,
        'variants' => array_values($variants),
    ]);

    $result = $payload['productVariantsBulkUpdate'] ?? [];
    if (!empty($result['userErrors'])) {
        throw new RuntimeException(implode(' ', array_map(
            static fn(array $error): string => (string) ($error['message'] ?? 'Variant price update failed.'),
            $result['userErrors']
        )));
    }

    return count($variants);
}
