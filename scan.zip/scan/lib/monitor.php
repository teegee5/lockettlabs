<?php
declare(strict_types=1);

/**
 * Price monitor: a whole set of our listings against Total Cards, Magic
 * Madhouse and Chaos Cards.
 *
 * Intake compares one card at the moment it is listed. Prices move after
 * that, so this compares what is already on the shelf: every single carrying
 * a set tag, its Near Mint price and stock, against each shop's in-stock price
 * for the same printing.
 *
 * Each shop's set is fetched once and reused for every card (Total Cards and
 * Magic Madhouse publish a set per page; Chaos comes from the local snapshot),
 * so a 200-card set costs a handful of requests, not hundreds. Work is paged
 * through our own products so a request stays inside shared hosting's time
 * limit, and every reading is written to price history.
 */

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/shopify-inventory.php';
require_once __DIR__ . '/retailers/compare.php';

const MONITOR_PAGE_SIZE = 50;

/**
 * Split one of our titles back into its parts. Brackets can sit on the name
 * (Magic "(FOIL)", Lorcana "(Foil)") or after the set (Pokemon "(Reverse holo)").
 *
 * @return array{name:string,set:string,finish:string,number:string}
 */
function monitor_parse_title(string $title): array
{
    $title = trim($title);
    $number = '';
    if (preg_match('/\s-\s*([A-Z]*\d+[a-z]?\/[A-Z]*\d+|[A-Z]{1,6}\d{0,3}-[A-Z]?\d{2,4}|(?:SWSH|SVP|MEP|ME|SM|XY|BW|SV)\s?\d{1,3})\s*$/i', $title, $m)) {
        $number = strtoupper(str_replace(' ', '', $m[1]));
        $title = trim(substr($title, 0, -strlen($m[0])));
    }
    $brackets = [];
    if (preg_match_all('/\(([^)]*)\)/', $title, $mm)) $brackets = array_map('trim', $mm[1]);
    $plain = trim((string) preg_replace('/\s*\([^)]*\)/', '', $title));
    $name = $plain;
    $set = '';
    if (str_contains($plain, ' : ')) {
        [$name, $set] = array_map('trim', explode(' : ', $plain, 2));
    }
    $finish = implode(' ', array_filter($brackets, static fn(string $b): bool => !preg_match('/^(\d+(st|nd|rd|th) place|art card|extended art|showcase|borderless|sp)$/i', $b)));
    return ['name' => $name, 'set' => $set, 'finish' => $finish, 'number' => $number];
}

/**
 * One page of our singles for a set tag.
 *
 * @return array{products:list<array>,next:string}
 */
function monitor_our_products(string $setTag, string $after = '', int $size = MONITOR_PAGE_SIZE): array
{
    $tag = str_replace(['\\', '"'], ['\\\\', '\\"'], $setTag);
    $query = 'tag:"Single Cards" AND tag:"' . $tag . '" AND status:active';
    $data = shopify_graphql(<<<'GRAPHQL'
query MonitorProducts($query: String!, $first: Int!, $after: String) {
  products(first: $first, after: $after, query: $query, sortKey: TITLE) {
    nodes {
      id title handle status onlineStoreUrl productType
      featuredMedia { preview { image { url } } }
      rarity: metafield(namespace: "tcg", key: "rarity") { value }
      gameId: metafield(namespace: "tcg", key: "game_id") { value }
      variants(first: 10) { nodes { title sku price inventoryQuantity } }
    }
    pageInfo { hasNextPage endCursor }
  }
}
GRAPHQL, ['query' => $query, 'first' => max(1, min(100, $size)), 'after' => $after !== '' ? $after : null]);
    $conn = $data['products'] ?? [];
    $products = [];
    foreach (is_array($conn['nodes'] ?? null) ? $conn['nodes'] : [] as $node) {
        if (!is_array($node) || empty($node['id'])) continue;
        $nm = null;
        $first = null;
        $qty = 0;
        foreach (is_array($node['variants']['nodes'] ?? null) ? $node['variants']['nodes'] : [] as $variant) {
            if (!is_array($variant)) continue;
            $qty += max(0, (int) ($variant['inventoryQuantity'] ?? 0));
            $first ??= $variant;
            $label = strtolower(trim((string) ($variant['title'] ?? '')));
            if ($nm === null && (str_contains($label, 'near mint') || $label === 'nm' || $label === 'default title')) $nm = $variant;
        }
        $nm ??= $first;
        $products[] = [
            'id' => (string) $node['id'],
            'title' => clean_text($node['title'] ?? '', 255),
            'handle' => (string) ($node['handle'] ?? ''),
            'url' => safe_https_url($node['onlineStoreUrl'] ?? ''),
            'adminUrl' => shopify_admin_product_url((string) $node['id']),
            'image' => safe_https_url($node['featuredMedia']['preview']['image']['url'] ?? ''),
            'rarity' => clean_text($node['rarity']['value'] ?? '', 80),
            'gameId' => clean_text($node['gameId']['value'] ?? '', 80),
            'productType' => clean_text($node['productType'] ?? '', 80),
            'nmPrice' => $nm !== null && is_numeric($nm['price'] ?? null) ? round((float) $nm['price'], 2) : null,
            'nmQty' => $nm !== null ? max(0, (int) ($nm['inventoryQuantity'] ?? 0)) : 0,
            'qty' => $qty,
            'sku' => clean_text($nm['sku'] ?? '', 100),
        ];
    }
    return [
        'products' => $products,
        'next' => !empty($conn['pageInfo']['hasNextPage']) ? (string) ($conn['pageInfo']['endCursor'] ?? '') : '',
    ];
}

/** The game id for a product, from its metafield or its product type. */
function monitor_game(array $product, string $fallback): string
{
    if ($product['gameId'] !== '') return $product['gameId'];
    return match (strtolower($product['productType'])) {
        'pokemon' => 'pokemon',
        'mtg' => 'magic-the-gathering',
        'disney' => 'disney-lorcana',
        'one piece' => 'one-piece-card-game',
        'digimon' => 'digimon-card-game',
        default => $fallback,
    };
}

/** The best Magic Madhouse row for one card, from a set already fetched. */
function monitor_madhouse_pick(array $rows, string $number, string $name, string $finish): ?array
{
    $want = retailer_intake_finish_token($finish);
    $best = null;
    $bestScore = -1;
    foreach ($rows as $row) {
        if (!retailer_text_contains_exact_number($row['title'], $number)) continue;
        $nameScore = retailer_name_score($row['title'], $name);
        if ($nameScore < 60) continue;
        if (!retailer_base_printing_compatible($want === '' ? 'normal' : $want, retailer_title_finish_token($row['title']))) continue;
        $score = $nameScore + ($row['available'] === true ? 5 : 0);
        if ($score > $bestScore) { $bestScore = $score; $best = $row + ['nameScore' => $nameScore]; }
    }
    return $best;
}

/**
 * Compare one page of our listings for a set.
 *
 * @return array{rows:list<array>,next:string,shops:array}
 */
function monitor_compare_page(string $setTag, string $game, string $after = '', array $options = []): array
{
    $page = monitor_our_products($setTag, $after, (int) ($options['size'] ?? MONITOR_PAGE_SIZE));
    $setName = clean_text((string) ($options['setName'] ?? $setTag), 120);
    $setName = trim((string) preg_replace('/\s*\(Base\)$/', '', $setName));

    // Each shop's set, fetched once for the whole page (and cached for the
    // pages after it).
    $tcHandle = totalcards_collection_for_set($game, $setName);
    $tcRows = $tcHandle !== '' ? totalcards_collection_rows($tcHandle) : [];
    $mmPath = retailer_madhouse_game_key($game) !== '' ? retailer_madhouse_pick_set($setName, $game) : '';
    $mmRows = $mmPath !== '' ? retailer_madhouse_set_products($mmPath) : [];

    $rows = [];
    foreach ($page['products'] as $product) {
        $parsed = monitor_parse_title($product['title']);
        $number = $parsed['number'];
        $name = $parsed['name'];
        if (str_contains(strtolower($game), 'lorcana') && $parsed['set'] !== '') $name = $parsed['name'] . ' ' . $parsed['set'];
        $name = trim((string) preg_replace('/\s*\([^)]*\)/', '', $name));
        $finish = $parsed['finish'];
        $productGame = monitor_game($product, $game);
        $shops = [];

        if ($number !== '' && $tcRows) {
            $pick = totalcards_pick($tcRows, ['name' => $name, 'number' => $number, 'finish' => $finish, 'variant' => '']);
            if ($pick['row']) {
                $nm = $pick['row']['nm'] ?? $pick['row']['any'];
                $shops['totalcards'] = ['price' => $nm['price'] ?? null, 'available' => $nm['available'] ?? null, 'stock' => null, 'url' => $pick['row']['url'], 'title' => $pick['row']['title'], 'confidence' => $pick['confidence']];
            }
        }
        if ($number !== '' && $mmRows) {
            $row = monitor_madhouse_pick($mmRows, $number, $name, $finish);
            if ($row) {
                $shops['magicmadhouse'] = ['price' => $row['price'], 'available' => $row['available'], 'stock' => $row['stock'] ?? null, 'url' => $row['url'], 'title' => $row['title'], 'confidence' => ($row['nameScore'] ?? 0) >= 100 ? 'strong' : 'likely'];
            }
        }
        if ($number !== '') {
            $chaos = retailer_chaos_from_snapshot($number, $name, $finish, $productGame);
            if (!empty($chaos['matched'])) {
                $shops['chaoscards'] = ['price' => $chaos['priceGbp'], 'available' => $chaos['available'], 'stock' => null, 'url' => $chaos['url'], 'title' => $chaos['title'] ?? '', 'confidence' => 'strong', 'seenAt' => $chaos['seenAt'] ?? ''];
            }
        }

        $inStock = [];
        foreach ($shops as $id => $shop) {
            if (($shop['available'] ?? null) === true && is_numeric($shop['price'] ?? null) && (float) $shop['price'] > 0) {
                $inStock[] = ['id' => $id, 'priceGbp' => round((float) $shop['price'], 2), 'url' => (string) $shop['url']];
            }
        }
        usort($inStock, static fn(array $a, array $b): int => $a['priceGbp'] <=> $b['priceGbp']);
        $band = competitor_rarity_band($product['rarity']);
        $suggestion = competitor_suggest_nm($band, null, array_column($inStock, 'priceGbp'), $product['nmPrice']);
        $existing = competitor_compare_existing($product['nmPrice'], $inStock[0]['priceGbp'] ?? null, $suggestion['suggestedNm'], $band);

        $key = price_history_key($productGame, $setName, $number, $finish);
        $readings = [];
        foreach ($shops as $id => $shop) $readings[$id] = ['price' => $shop['price'], 'available' => $shop['available'], 'stock' => $shop['stock']];
        if ($product['nmPrice'] !== null) $readings['lockett'] = ['price' => $product['nmPrice'], 'available' => $product['nmQty'] > 0, 'stock' => $product['nmQty']];
        if (!empty($options['record']) && $number !== '') price_history_record($key, $product['title'], $readings);
        $history = $number !== '' ? price_history_series($key, 60) : ['series' => [], 'change' => []];

        $rows[] = [
            'product' => $product,
            'number' => $number,
            'finish' => $finish,
            'band' => $band,
            'shops' => $shops,
            'lowest' => $inStock[0] ?? null,
            'position' => competitor_position($product['nmPrice'], $inStock),
            'action' => $existing['action'],
            'reason' => $existing['reason'],
            'suggestedNm' => $suggestion['suggestedNm'],
            'history' => ['change' => $history['change'], 'series' => $history['series']],
        ];
    }

    return [
        'rows' => $rows,
        'next' => $page['next'],
        'shops' => [
            'totalcards' => ['found' => $tcRows !== [], 'url' => $tcHandle !== '' ? TOTALCARDS_ORIGIN . '/collections/' . $tcHandle : '', 'listings' => count($tcRows)],
            'magicmadhouse' => ['found' => $mmRows !== [], 'url' => $mmPath !== '' ? MADHOUSE_ORIGIN . $mmPath : '', 'listings' => count($mmRows)],
            'chaoscards' => ['found' => true, 'url' => '', 'listings' => null],
        ],
    ];
}

/** Where a finished run is kept, so the page can show the last result at once. */
function monitor_run_path(string $setTag): string
{
    return APP_ROOT . '/cache/monitor/' . substr(sha1(strtolower($setTag)), 0, 16) . '.run.json';
}

function monitor_save_run(string $setTag, array $summary): void
{
    $dir = APP_ROOT . '/cache/monitor';
    if (!(is_dir($dir) || @mkdir($dir, 0750, true)) || !is_writable($dir)) return;
    @file_put_contents(monitor_run_path($setTag), json_encode($summary, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), LOCK_EX);
}

function monitor_load_run(string $setTag): ?array
{
    $path = monitor_run_path($setTag);
    if (!is_file($path)) return null;
    $data = json_decode((string) @file_get_contents($path), true);
    return is_array($data) ? $data : null;
}

/** Every run on disk, newest first: the monitor's front page. */
function monitor_list_runs(): array
{
    $runs = [];
    foreach (glob(APP_ROOT . '/cache/monitor/*.run.json') ?: [] as $path) {
        $data = json_decode((string) @file_get_contents($path), true);
        if (!is_array($data)) continue;
        $runs[] = [
            'set' => (string) ($data['set'] ?? ''),
            'game' => (string) ($data['game'] ?? ''),
            'at' => (int) ($data['at'] ?? 0),
            'counts' => $data['counts'] ?? [],
        ];
    }
    usort($runs, static fn(array $a, array $b): int => $b['at'] <=> $a['at']);
    return $runs;
}

/** Headline numbers for a finished run. */
function monitor_counts(array $rows): array
{
    $counts = ['cards' => 0, 'above' => 0, 'cheapest' => 0, 'matched' => 0, 'only' => 0, 'unpriced' => 0, 'raise' => 0, 'lower' => 0, 'stockValue' => 0.0];
    foreach ($rows as $row) {
        $counts['cards']++;
        $state = (string) ($row['position']['state'] ?? '');
        if (isset($counts[$state])) $counts[$state]++;
        $action = (string) ($row['action'] ?? '');
        if (isset($counts[$action])) $counts[$action]++;
        $price = (float) ($row['product']['nmPrice'] ?? 0);
        $counts['stockValue'] += $price * (int) ($row['product']['qty'] ?? 0);
    }
    $counts['stockValue'] = round($counts['stockValue'], 2);
    return $counts;
}
