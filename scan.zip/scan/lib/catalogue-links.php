<?php
declare(strict_types=1);

/**
 * Link a new product to the store's own catalogue metaobjects.
 *
 * The storefront's filters (game, set, series, product class, language) read
 * custom.* metaobject references. Products listed through this tool used to
 * carry none, so a new card was missing from every filter until someone
 * backfilled it. This looks the values up by name and links them at creation.
 *
 * It only ever links to metaobjects that already exist. A set the store has
 * not created yet is left unlinked rather than guessed or invented.
 */

require_once __DIR__ . '/bootstrap.php';

const LL_METAOBJECT_TYPES = ['ll_game', 'll_product_class', 'll_series', 'll_set', 'll_language'];
const LL_METAOBJECT_TTL = 21600; // 6 hours

function ll_link_key(string $value): string
{
    $value = strtolower(trim($value));
    $value = str_replace(['(base set)', '(base)'], ' base set ', $value);
    $value = str_replace('&', ' and ', $value);
    $value = (string) preg_replace('/\b(pokemon|pok\x{e9}mon)\b/u', 'pokemon', $value);
    return (string) preg_replace('/[^a-z0-9]+/', '', $value);
}

/**
 * name key => gid, per type. Cached for six hours: the list only grows when
 * someone adds a set in Shopify admin.
 *
 * @return array<string,array<string,string>>
 */
function ll_metaobject_index(bool $refresh = false): array
{
    $cacheKey = 'll-metaobjects:v1';
    if (!$refresh) {
        $cached = cache_read_json($cacheKey, LL_METAOBJECT_TTL);
        if (is_array($cached) && isset($cached['ll_set'])) return $cached;
    }
    $index = array_fill_keys(LL_METAOBJECT_TYPES, []);
    foreach (LL_METAOBJECT_TYPES as $type) {
        $after = null;
        for ($page = 0; $page < 8; $page++) {
            $data = shopify_graphql(<<<'GRAPHQL'
query LinkTargets($type: String!, $after: String) {
  metaobjects(type: $type, first: 250, after: $after) {
    nodes { id handle displayName }
    pageInfo { hasNextPage endCursor }
  }
}
GRAPHQL, ['type' => $type, 'after' => $after]);
            $conn = $data['metaobjects'] ?? [];
            foreach (is_array($conn['nodes'] ?? null) ? $conn['nodes'] : [] as $node) {
                if (!is_array($node) || empty($node['id'])) continue;
                foreach ([(string) ($node['displayName'] ?? ''), (string) ($node['handle'] ?? '')] as $name) {
                    $key = ll_link_key($name);
                    if ($key !== '' && !isset($index[$type][$key])) $index[$type][$key] = (string) $node['id'];
                }
            }
            if (empty($conn['pageInfo']['hasNextPage'])) break;
            $after = (string) ($conn['pageInfo']['endCursor'] ?? '');
        }
    }
    cache_write_json($cacheKey, $index);
    return $index;
}

/** Map an intake game id onto the ll_game handle the store uses. */
function ll_game_handle(string $game): string
{
    $g = strtolower($game);
    return match (true) {
        str_contains($g, 'pokemon') => 'pokemon',
        str_contains($g, 'lorcana'), str_contains($g, 'disney') => 'lorcana',
        str_contains($g, 'magic'), $g === 'mtg' => 'mtg',
        str_contains($g, 'one-piece'), str_contains($g, 'one piece') => 'one-piece',
        str_contains($g, 'digimon') => 'digimon',
        str_contains($g, 'yu-gi-oh'), str_contains($g, 'yugioh') => 'yu-gi-oh',
        default => '',
    };
}

/**
 * Metafields linking a product to game, class, series, set and language.
 *
 * @param array{game:string,kind:string,setTag:string,eraTag:string,languageCode:string} $plan
 * @return array{metafields:list<array>,linked:array<string,string>,missing:list<string>}
 */
function ll_catalogue_link_metafields(array $plan): array
{
    try {
        $index = ll_metaobject_index();
    } catch (Throwable) {
        return ['metafields' => [], 'linked' => [], 'missing' => ['catalogue metaobjects unavailable']];
    }
    $wanted = [
        'game' => ['ll_game', ll_game_handle((string) ($plan['game'] ?? ''))],
        'product_class' => ['ll_product_class', ($plan['kind'] ?? '') === 'sealed' ? 'sealed' : 'single'],
        'series' => ['ll_series', (string) preg_replace('/^Japanese\s+/i', '', (string) ($plan['eraTag'] ?? ''))],
        'set_name' => ['ll_set', (string) ($plan['setTag'] ?? '')],
        'language' => ['ll_language', ($plan['languageCode'] ?? '') === 'ja' ? 'ja' : 'en'],
    ];
    // Store tags whose metaobject was named differently.
    $setAliases = ['pokemonplay' => 'Play! Pokemon Promos', 'futsal' => 'Futsal Promos'];
    $setKey = ll_link_key($wanted['set_name'][1]);
    if (isset($setAliases[$setKey])) $wanted['set_name'][1] = $setAliases[$setKey];

    $metafields = [];
    $linked = [];
    $missing = [];
    foreach ($wanted as $key => [$type, $name]) {
        if (trim($name) === '') continue;
        $gid = $index[$type][ll_link_key($name)] ?? '';
        if ($gid === '') { $missing[] = "{$key}: {$name}"; continue; }
        $metafields[] = ['namespace' => 'custom', 'key' => $key, 'type' => 'metaobject_reference', 'value' => $gid];
        $linked[$key] = $name;
    }
    return ['metafields' => $metafields, 'linked' => $linked, 'missing' => $missing];
}
