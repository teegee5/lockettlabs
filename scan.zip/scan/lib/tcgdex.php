<?php
declare(strict_types=1);

/**
 * TCGdex lookup for the exact Pokémon card id.
 *
 * The storefront product page reads custom.tcg_card_id first and only falls
 * back to parsing the image filename, so a card created here must carry the
 * real TCGdex id (for example "sv08-125"). A wrong id would show the wrong
 * card details, so every step below fails closed: unless the set matches
 * exactly and the printed local number matches a card in that set, this
 * returns an empty string and the metafield is simply left unset.
 */

require_once __DIR__ . '/bootstrap.php';

const TCGDEX_BASE = 'https://api.tcgdex.net/v2';
const TCGDEX_SETS_TTL = 604800;   // 7 days
const TCGDEX_SET_TTL = 2592000;   // 30 days

function tcgdex_supports_game(string $game): bool
{
    return (bool) preg_match('/pokemon/i', $game);
}

function tcgdex_language(string $game, string $languageCode = ''): string
{
    if ($game === 'pokemon-japan' || $languageCode === 'ja') return 'ja';
    return 'en';
}

function tcgdex_normalize(string $value): string
{
    $trimmed = trim($value);
    $lower = function_exists('mb_strtolower') ? mb_strtolower($trimmed, 'UTF-8') : strtolower($trimmed);
    $ascii = preg_replace('/[^\p{L}\p{N}]+/u', '', $lower);
    return is_string($ascii) ? $ascii : '';
}

/** Printed numbers arrive as "037/084", "SV107" or "OP16-026". Take the local part. */
function tcgdex_local_number(string $cardNumber): string
{
    $raw = strtoupper(trim($cardNumber));
    if ($raw === '') return '';
    $raw = preg_replace('#\s+#', '', $raw) ?? $raw;
    // Numerator of "037/084".
    if (str_contains($raw, '/')) {
        $raw = explode('/', $raw)[0];
    }
    // Trailing part of a set-prefixed id such as "OP16-026".
    if (str_contains($raw, '-')) {
        $parts = explode('-', $raw);
        $raw = (string) end($parts);
    }
    return $raw;
}

/** Denominator of "037/084". Empty when the number does not carry one. */
function tcgdex_printed_denominator(string $cardNumber): string
{
    $raw = preg_replace('#\s+#', '', strtoupper(trim($cardNumber))) ?? '';
    if (!str_contains($raw, '/')) return '';
    $parts = explode('/', $raw);
    $denominator = preg_replace('/\D+/', '', (string) end($parts)) ?? '';
    return $denominator;
}

/**
 * The printed set total is an independent check on the set match. Chilling
 * Reign prints /198 and TCGdex records 198 official cards; the Sword & Shield
 * base set records 202, so a card printed /198 can never belong to it.
 */
function tcgdex_set_count_matches(array $set, string $denominator): bool
{
    if ($denominator === '') return true;
    $wanted = (int) $denominator;
    if ($wanted <= 0) return true;
    $official = (int) ($set['cardCount']['official'] ?? 0);
    $total = (int) ($set['cardCount']['total'] ?? 0);
    if ($official === 0 && $total === 0) return true;
    return $wanted === $official || $wanted === $total;
}

/**
 * Independent check that the card found is the card asked for. Tolerates
 * punctuation and suffix wording, but rejects an outright different Pokémon,
 * which is what a wrong set match looks like.
 */
function tcgdex_names_match(string $wanted, string $found): bool
{
    $a = tcgdex_normalize($wanted);
    $b = tcgdex_normalize($found);
    if ($a === '' || $b === '') return true;
    return $a === $b || str_contains($a, $b) || str_contains($b, $a);
}

/** TCGdex stores "37" where the card prints "037"; compare both ways. */
function tcgdex_local_matches(string $wanted, string $localId): bool
{
    $a = strtoupper(trim($wanted));
    $b = strtoupper(trim($localId));
    if ($a === '' || $b === '') return false;
    if ($a === $b) return true;
    return ltrim($a, '0') !== '' && ltrim($a, '0') === ltrim($b, '0');
}

function tcgdex_sets(string $language): array
{
    try {
        $sets = cached_http_json(TCGDEX_BASE . '/' . $language . '/sets', [], TCGDEX_SETS_TTL);
    } catch (Throwable) {
        return [];
    }
    return is_array($sets) ? $sets : [];
}

function tcgdex_set_cards(string $language, string $setId): array
{
    try {
        $set = cached_http_json(TCGDEX_BASE . '/' . $language . '/sets/' . rawurlencode($setId), [], TCGDEX_SET_TTL);
    } catch (Throwable) {
        return [];
    }
    return is_array($set['cards'] ?? null) ? $set['cards'] : [];
}

/**
 * Pick one set from a TCGdex set list.
 *
 * Candidate order is priority order — the most specific name the caller knows
 * comes first. This must not be reversed to "first set in the list that matches
 * any candidate": an era name like "Mega Evolution" is itself a real set (me01)
 * and would then beat the actual set (me05, Pitch Black) purely on list order,
 * silently filing every card in the era under the wrong set.
 *
 * Matching is exact (normalised). A fuzzy set match is how a card ends up
 * showing another card's details on the storefront.
 */
function tcgdex_pick_set(array $sets, array $candidates): ?array
{
    $byKey = [];
    foreach ($sets as $set) {
        if (!is_array($set)) continue;
        foreach ([$set['id'] ?? '', $set['name'] ?? ''] as $key) {
            $normalized = tcgdex_normalize((string) $key);
            if ($normalized !== '' && !isset($byKey[$normalized])) $byKey[$normalized] = $set;
        }
    }
    if ($byKey === []) return null;

    foreach ($candidates as $candidate) {
        $normalized = tcgdex_normalize((string) $candidate);
        if ($normalized !== '' && isset($byKey[$normalized])) return $byKey[$normalized];
    }
    return null;
}

function tcgdex_find_set(string $language, array $candidates): ?array
{
    return tcgdex_pick_set(tcgdex_sets($language), $candidates);
}

/**
 * Resolve one card id, with three independent guards. Each one on its own is
 * enough to stop a wrong set match reaching the storefront:
 *
 *   1. the set name must match a TCGdex set exactly (candidates in priority order)
 *   2. the printed denominator must match that set's card count
 *   3. the card found at that number must carry the expected card name
 *
 * Failing any of them returns '' and leaves the metafield alone.
 *
 * @param string $cardName Expected card name. Strongly recommended — it is the
 *                         check that catches a plausible-but-wrong set.
 * @return string TCGdex card id such as "sv08-125", or '' when unresolved.
 */
function tcgdex_resolve_card_id(
    string $game,
    array $setCandidates,
    string $cardNumber,
    string $languageCode = '',
    string $cardName = ''
): string {
    if (!tcgdex_supports_game($game)) return '';
    $local = tcgdex_local_number($cardNumber);
    if ($local === '') return '';

    $language = tcgdex_language($game, $languageCode);
    $set = tcgdex_find_set($language, $setCandidates);
    if ($set === null || !is_string($set['id'] ?? null) || $set['id'] === '') return '';

    if (!tcgdex_set_count_matches($set, tcgdex_printed_denominator($cardNumber))) return '';

    foreach (tcgdex_set_cards($language, $set['id']) as $card) {
        if (!is_array($card)) continue;
        if (!tcgdex_local_matches($local, (string) ($card['localId'] ?? ''))) continue;
        if (!tcgdex_names_match($cardName, (string) ($card['name'] ?? ''))) return '';
        return clean_text($card['id'] ?? '', 80);
    }
    return '';
}
