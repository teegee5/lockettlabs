<?php
declare(strict_types=1);

/**
 * Shared card-id backfill logic.
 *
 * Used by both tools/backfill-tcg-card-id.php (command line) and
 * api/backfill-card-ids.php (the browser runner) so the two cannot drift.
 * Work is done one page of products at a time, so the browser runner stays
 * inside shared-hosting execution limits and can report progress as it goes.
 */

require_once __DIR__ . '/tcgdex.php';

const BACKFILL_PAGE_SIZE = 100;
const BACKFILL_WRITE_CHUNK = 25;

/**
 * Printed number for one product. The tcg.card_number metafield is preferred
 * because the intake app writes it; older imported products only have it in
 * the title, e.g. "Lampent : PITCH BLACK (Reverse holo) - 037/084".
 */
function backfill_card_number(array $product): string
{
    $metafield = backfill_metafield($product, 'card_number');
    if ($metafield !== '') return $metafield;
    $title = (string) ($product['title'] ?? '');
    $position = strrpos($title, ' - ');
    return $position === false ? '' : trim(substr($title, $position + 3));
}

function backfill_metafield(array $product, string $key): string
{
    foreach ($product['metafields']['nodes'] ?? [] as $metafield) {
        if (($metafield['key'] ?? '') === $key) {
            return trim((string) ($metafield['value'] ?? ''));
        }
    }
    return '';
}

/** "Abomasnow : CHILLING REIGN (Reverse holo) - 010/198" -> "Abomasnow". */
function backfill_card_name(array $product): string
{
    $name = backfill_metafield($product, 'english_name');
    if ($name !== '') return $name;
    $title = (string) ($product['title'] ?? '');
    $position = strpos($title, ' : ');
    return $position === false ? '' : trim(substr($title, 0, $position));
}

/**
 * Set names for one product, most trustworthy first.
 *
 * These come from the product, never from the tag the operator typed to select
 * it. An era tag such as "Sword & Shield" selects every card in the era but is
 * also a real TCGdex set, so trusting it filed a whole era against the era's
 * base set.
 *
 * "Abomasnow : CHILLING REIGN (Reverse holo) - 010/198" -> "CHILLING REIGN".
 *
 * @return string[]
 */
function backfill_set_names(array $product): array
{
    $candidates = [
        backfill_metafield($product, 'english_set_name'),
        backfill_metafield($product, 'set_name'),
    ];

    $title = (string) ($product['title'] ?? '');
    $start = strpos($title, ' : ');
    if ($start !== false) {
        $rest = substr($title, $start + 3);
        $end = strrpos($rest, ' - ');
        if ($end !== false) $rest = substr($rest, 0, $end);
        // Drop the finish suffix, e.g. "CHILLING REIGN (Reverse holo)".
        $rest = trim((string) preg_replace('/\s*\([^)]*\)\s*$/', '', $rest));
        if ($rest !== '') $candidates[] = $rest;
    }

    return array_values(array_filter($candidates, static fn(string $value): bool => $value !== ''));
}

function backfill_product_query(string $setTag): string
{
    return sprintf("tag:'%s' AND tag:'Single Cards'", str_replace("'", "\\'", $setTag));
}

/** @return array{nodes: array, hasNextPage: bool, cursor: ?string} */
function backfill_fetch_page(string $setTag, ?string $after = null): array
{
    $data = shopify_graphql(<<<'GRAPHQL'
query BackfillCards($query: String!, $after: String, $size: Int!) {
  products(first: $size, query: $query, after: $after, sortKey: TITLE) {
    pageInfo { hasNextPage endCursor }
    nodes {
      id
      title
      tags
      cardId: metafield(namespace: "custom", key: "tcg_card_id") { value }
      metafields(namespace: "tcg", first: 20) { nodes { key value } }
    }
  }
}
GRAPHQL, ['query' => backfill_product_query($setTag), 'after' => $after, 'size' => BACKFILL_PAGE_SIZE]);

    $page = $data['products'] ?? [];
    return [
        'nodes' => $page['nodes'] ?? [],
        'hasNextPage' => !empty($page['pageInfo']['hasNextPage']),
        'cursor' => isset($page['pageInfo']['endCursor']) ? (string) $page['pageInfo']['endCursor'] : null,
    ];
}

/**
 * Resolve one page. Nothing is written here.
 *
 * @return array{resolved: array, skipped: array, unresolved: array}
 */
function backfill_resolve_page(array $nodes, string $setTag, string $language, bool $force): array
{
    $resolved = [];
    $skipped = [];
    $unresolved = [];

    foreach ($nodes as $product) {
        if (!is_array($product)) continue;
        $title = (string) ($product['title'] ?? '');
        $existing = trim((string) ($product['cardId']['value'] ?? ''));
        if ($existing !== '' && !$force) {
            $skipped[] = ['title' => $title, 'cardId' => $existing];
            continue;
        }

        $number = backfill_card_number($product);
        $setNames = backfill_set_names($product);
        $cardName = backfill_card_name($product);
        $cardId = tcgdex_resolve_card_id('pokemon', $setNames, $number, $language, $cardName);

        if ($cardId === '') {
            $unresolved[] = [
                'id' => (string) ($product['id'] ?? ''),
                'title' => $title,
                'number' => $number,
                'set' => $setNames[0] ?? '',
                // Only ever non-empty under force, where an id already on the
                // product could not be re-derived and is therefore suspect.
                'existing' => $existing,
            ];
            continue;
        }
        $resolved[] = [
            'id' => (string) ($product['id'] ?? ''),
            'title' => $title,
            'number' => $number,
            'cardId' => $cardId,
            'replaces' => $existing,
        ];
    }

    return ['resolved' => $resolved, 'skipped' => $skipped, 'unresolved' => $unresolved];
}

/**
 * Write resolved ids. Called only when the caller explicitly asked to apply.
 *
 * @return array{written: int, errors: array}
 */
function backfill_write(array $resolved): array
{
    if ($resolved === []) return ['written' => 0, 'errors' => []];

    $mutation = <<<'GRAPHQL'
mutation BackfillCardIds($metafields: [MetafieldsSetInput!]!) {
  metafieldsSet(metafields: $metafields) {
    metafields { id }
    userErrors { field message code }
  }
}
GRAPHQL;

    $written = 0;
    $errors = [];
    foreach (array_chunk($resolved, BACKFILL_WRITE_CHUNK) as $batch) {
        $inputs = array_map(static fn(array $row): array => [
            'ownerId' => $row['id'],
            'namespace' => 'custom',
            'key' => 'tcg_card_id',
            'type' => 'single_line_text_field',
            'value' => $row['cardId'],
        ], $batch);

        try {
            $result = shopify_graphql($mutation, ['metafields' => $inputs]);
            $payload = $result['metafieldsSet'] ?? [];
            $written += count($payload['metafields'] ?? []);
            foreach ($payload['userErrors'] ?? [] as $error) {
                $errors[] = implode('.', $error['field'] ?? []) . ': ' . ($error['message'] ?? 'Unknown error');
            }
        } catch (Throwable $error) {
            $errors[] = $error->getMessage();
        }
    }

    return ['written' => $written, 'errors' => $errors];
}

/**
 * Remove ids that could not be re-derived.
 *
 * Only reachable under force, and only for products that already carried an id.
 * If a re-run cannot resolve a product, whatever is stored is untrustworthy —
 * an empty metafield lets the storefront fall back cleanly, a wrong one shows
 * another card's details.
 *
 * @return array{cleared: int, errors: array}
 */
function backfill_clear(array $unresolved): array
{
    $targets = array_values(array_filter(
        $unresolved,
        static fn(array $row): bool => ($row['existing'] ?? '') !== '' && ($row['id'] ?? '') !== ''
    ));
    if ($targets === []) return ['cleared' => 0, 'errors' => []];

    $mutation = <<<'GRAPHQL'
mutation ClearCardIds($metafields: [MetafieldIdentifierInput!]!) {
  metafieldsDelete(metafields: $metafields) {
    deletedMetafields { ownerId namespace key }
    userErrors { field message }
  }
}
GRAPHQL;

    $cleared = 0;
    $errors = [];
    foreach (array_chunk($targets, BACKFILL_WRITE_CHUNK) as $batch) {
        $inputs = array_map(static fn(array $row): array => [
            'ownerId' => $row['id'],
            'namespace' => 'custom',
            'key' => 'tcg_card_id',
        ], $batch);

        try {
            $result = shopify_graphql($mutation, ['metafields' => $inputs]);
            $payload = $result['metafieldsDelete'] ?? [];
            $cleared += count($payload['deletedMetafields'] ?? []);
            foreach ($payload['userErrors'] ?? [] as $error) {
                $errors[] = implode('.', $error['field'] ?? []) . ': ' . ($error['message'] ?? 'Unknown error');
            }
        } catch (Throwable $error) {
            $errors[] = $error->getMessage();
        }
    }

    return ['cleared' => $cleared, 'errors' => $errors];
}
