<?php
declare(strict_types=1);

/**
 * A written record of every card that went into Shopify through this app.
 *
 * Why this exists
 * ---------------
 * There was no record of any kind. The only evidence an intake had happened
 * was the success message, and the screen clears itself 650ms later to get
 * ready for the next card. So a quantity typed as 11 instead of 1 was invisible
 * the moment it was submitted, there was no way to review a day's work, and
 * nobody could answer "what did we take in this morning" without going through
 * Shopify's own activity feed.
 *
 * One JSON object per line, one file per month. Append-only, and read back by
 * seeking to the end rather than loading the file, so it stays cheap as it
 * grows.
 *
 * Nothing here may ever break an intake. A card that made it into Shopify but
 * failed to log is a lost line in a log; an exception thrown from the logger
 * after the inventory has already moved is a far worse outcome. Every public
 * function swallows its own errors.
 */

const INTAKE_LOG_DIR = __DIR__ . '/../logs';

/**
 * Keep the log out of the webroot's reach. The folder sits under the document
 * root on shared hosting, so the deny rule travels with it.
 */
function intake_log_prepare_dir(): ?string
{
    $dir = INTAKE_LOG_DIR;
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return null;
    if (!is_writable($dir)) return null;

    $guard = $dir . '/.htaccess';
    if (!is_file($guard)) {
        @file_put_contents($guard, <<<'HTACCESS'
<IfModule mod_authz_core.c>
  Require all denied
</IfModule>
<IfModule !mod_authz_core.c>
  Order allow,deny
  Deny from all
</IfModule>

HTACCESS);
    }
    return $dir;
}

function intake_log_path(?string $month = null): string
{
    $month ??= gmdate('Y-m');
    return INTAKE_LOG_DIR . '/intake-' . $month . '.jsonl';
}

/**
 * Append one intake. Returns false when it could not be written, which the
 * caller is free to ignore.
 */
function intake_log_append(array $entry): bool
{
    try {
        $dir = intake_log_prepare_dir();
        if ($dir === null) return false;

        $entry['at'] = gmdate('c');
        $line = json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($line === false) return false;

        // LOCK_EX so two staff submitting at the same moment cannot interleave
        // half-lines into the file.
        return @file_put_contents(intake_log_path(), $line . "\n", FILE_APPEND | LOCK_EX) !== false;
    } catch (Throwable) {
        return false;
    }
}

/**
 * Read the last complete lines of a file without loading all of it.
 *
 * @return list<string>
 */
function intake_log_tail_lines(string $path, int $limit): array
{
    if (!is_file($path) || $limit < 1) return [];

    $size = @filesize($path);
    if ($size === false || $size === 0) return [];

    $handle = @fopen($path, 'rb');
    if ($handle === false) return [];

    // Roughly 600 bytes a line, so this reads back enough for the limit asked
    // for and then some, and falls back to the whole file when it is small.
    $want = min($size, max(64 * 1024, $limit * 1200));
    @fseek($handle, -$want, SEEK_END);
    $chunk = (string) @fread($handle, $want);
    @fclose($handle);

    $lines = preg_split('/\r?\n/', $chunk) ?: [];
    // A partial first line when the read started mid-file is not valid JSON and
    // is dropped by the decode below, so there is nothing special to do here.
    $lines = array_values(array_filter($lines, static fn(string $l): bool => trim($l) !== ''));

    return array_slice($lines, -$limit);
}

/**
 * Most recent intakes, newest first.
 *
 * @return list<array<string,mixed>>
 */
function intake_log_recent(int $limit = 20): array
{
    try {
        $limit = max(1, min(200, $limit));
        $lines = intake_log_tail_lines(intake_log_path(), $limit);

        // Early in a month the current file may hold fewer than asked for.
        if (count($lines) < $limit) {
            $previous = intake_log_tail_lines(
                intake_log_path(gmdate('Y-m', strtotime('first day of last month', time()))),
                $limit - count($lines)
            );
            $lines = array_merge($previous, $lines);
        }

        $rows = [];
        foreach ($lines as $line) {
            $decoded = json_decode($line, true);
            if (is_array($decoded) && isset($decoded['at'])) $rows[] = $decoded;
        }
        return array_slice(array_reverse($rows), 0, $limit);
    } catch (Throwable) {
        return [];
    }
}

/**
 * Counts for today, in UTC to match the stamps written above.
 *
 * @return array{cards:int,units:int,created:int,restocked:int,day:string}
 */
function intake_log_today_summary(): array
{
    $summary = ['cards' => 0, 'units' => 0, 'created' => 0, 'restocked' => 0, 'day' => gmdate('Y-m-d')];

    try {
        $path = intake_log_path();
        if (!is_file($path)) return $summary;

        $handle = @fopen($path, 'rb');
        if ($handle === false) return $summary;

        $today = $summary['day'];
        while (($line = fgets($handle)) !== false) {
            // Cheap reject before paying for a JSON decode. Every stamp is
            // written by gmdate('c'), so the date is a plain prefix match.
            if (!str_contains($line, '"at":"' . $today)) continue;
            $row = json_decode($line, true);
            if (!is_array($row)) continue;

            $summary['cards']++;
            $summary['units'] += max(0, (int) ($row['units'] ?? 0));
            if (($row['action'] ?? '') === 'restocked') $summary['restocked']++;
            else $summary['created']++;
        }
        @fclose($handle);
    } catch (Throwable) {
        // A summary that reads zero is a cosmetic loss, not a failure worth
        // surfacing to someone trying to book in a card.
    }

    return $summary;
}

/**
 * Build a log entry from what the create/restock endpoint already has.
 *
 * Kept here rather than in the endpoint so both call sites record the same
 * shape and cannot drift apart.
 */
function intake_log_entry(
    string $action,
    array $product,
    array $card,
    array $variants,
    int $units,
    string $locationId,
    string $matchMethod = '',
    string $operationId = ''
): array {
    $conditions = [];
    foreach ($variants as $variant) {
        if (!is_array($variant)) continue;
        $conditions[] = [
            'condition' => (string) ($variant['condition'] ?? ''),
            'qty' => (int) ($variant['quantity'] ?? 0),
            'price' => isset($variant['price']) ? round((float) $variant['price'], 2) : null,
            'sku' => (string) ($variant['sku'] ?? ''),
        ];
    }

    return [
        'action' => $action,
        'productId' => (string) ($product['id'] ?? ''),
        'productTitle' => (string) ($product['title'] ?? ''),
        'adminUrl' => (string) ($product['adminUrl'] ?? ''),
        'handle' => (string) ($product['handle'] ?? ''),
        // The client posts the JustTCG card object spread into the payload, so
        // the printed number arrives as cardNumber and the set may be carried
        // on either the English or the original-language field.
        'game' => (string) ($card['game'] ?? ''),
        'setName' => (string) (($card['englishSetName'] ?? '') ?: ($card['setName'] ?? '')),
        'number' => (string) (($card['cardNumber'] ?? '') ?: ($card['number'] ?? '')),
        'finish' => (string) ($card['finish'] ?? ''),
        'conditions' => $conditions,
        'units' => max(0, $units),
        'locationId' => $locationId,
        'matchMethod' => $matchMethod,
        'operationId' => $operationId,
    ];
}
