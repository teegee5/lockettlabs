<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

/**
 * Product images: staged uploads for scans, and a guarded fetch for an image
 * address pasted from another site.
 *
 * A scan made in the browser has no public URL, so it goes through Shopify's
 * staged uploads: ask for a target, post the file there, then hand the
 * returned resourceUrl to productSet as the image's originalSource. Shopify
 * keeps the file name we choose, which is why it carries the card identity.
 */

const MEDIA_MAX_BYTES = 15 * 1024 * 1024;
const MEDIA_ALLOWED_MIME = ['image/jpeg', 'image/png', 'image/webp'];

/**
 * Validate an uploaded image file and return [mime, width, height].
 *
 * @throws InvalidArgumentException when it is not a usable product image
 */
function media_validate_image(string $path, int $size): array
{
    if ($size <= 0 || !is_file($path)) {
        throw new InvalidArgumentException('No image was received.');
    }
    if ($size > MEDIA_MAX_BYTES) {
        throw new InvalidArgumentException('That image is over 15 MB.');
    }
    $mime = '';
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = $finfo ? (string) finfo_file($finfo, $path) : '';
        if ($finfo) finfo_close($finfo);
    }
    $info = @getimagesize($path);
    if ($mime === '' && is_array($info)) $mime = (string) ($info['mime'] ?? '');
    if (!in_array($mime, MEDIA_ALLOWED_MIME, true)) {
        throw new InvalidArgumentException('Only JPEG, PNG and WebP images can be uploaded.');
    }
    $width = is_array($info) ? (int) $info[0] : 0;
    $height = is_array($info) ? (int) $info[1] : 0;
    if ($width < 500 || $height < 500) {
        // Merchant Center rejects images under 500 x 500.
        throw new InvalidArgumentException('That image is under 500 x 500 pixels. Scan it larger.');
    }
    return [$mime, $width, $height];
}

/** A safe file name: lower-case words joined by hyphens, keeping the extension. */
function media_clean_filename(string $name, string $mime): string
{
    $ext = match ($mime) {
        'image/png' => 'png',
        'image/webp' => 'webp',
        default => 'jpg',
    };
    $base = strtolower(preg_replace('/\.[a-z0-9]{2,4}$/i', '', $name) ?? '');
    $base = preg_replace('/[^a-z0-9]+/', '-', $base) ?? '';
    $base = trim(substr($base, 0, 90), '-');
    return ($base !== '' ? $base : 'card-scan') . '.' . $ext;
}

/**
 * Stage a local file with Shopify and return its resourceUrl.
 *
 * @throws RuntimeException when Shopify refuses or the upload fails
 */
function shopify_stage_image(string $path, string $filename, string $mime): string
{
    $size = (int) filesize($path);
    $data = shopify_graphql(<<<'GRAPHQL'
mutation StageScan($input: [StagedUploadInput!]!) {
  stagedUploadsCreate(input: $input) {
    stagedTargets { url resourceUrl parameters { name value } }
    userErrors { field message }
  }
}
GRAPHQL, ['input' => [[
        'resource' => 'IMAGE',
        'filename' => $filename,
        'mimeType' => $mime,
        'httpMethod' => 'POST',
        'fileSize' => (string) $size,
    ]]]);

    $payload = $data['stagedUploadsCreate'] ?? [];
    if (!empty($payload['userErrors'])) {
        throw new RuntimeException('Shopify refused the upload: ' . implode(' ', array_map(
            static fn(array $e): string => (string) ($e['message'] ?? ''),
            $payload['userErrors']
        )));
    }
    $target = $payload['stagedTargets'][0] ?? null;
    if (!is_array($target) || empty($target['url']) || empty($target['resourceUrl'])) {
        throw new RuntimeException('Shopify did not return an upload target.');
    }

    $fields = [];
    foreach ($target['parameters'] ?? [] as $param) {
        if (is_array($param) && isset($param['name'])) $fields[(string) $param['name']] = (string) ($param['value'] ?? '');
    }
    // The file must be the last field of the form.
    $fields['file'] = new CURLFile($path, $mime, $filename);

    $ch = curl_init((string) $target['url']);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $fields,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 60,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $body = curl_exec($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    if ($body === false || $error !== '' || $status < 200 || $status >= 300) {
        throw new RuntimeException('The image upload to Shopify failed' . ($status ? " (HTTP {$status})" : '') . '.');
    }
    return (string) $target['resourceUrl'];
}

/**
 * Add an image to an existing product, optionally as the first image.
 *
 * Uses productUpdate's media argument, which only appends. It never touches
 * variants or options.
 *
 * @return array{mediaId:string, featured:bool}
 */
function shopify_append_product_media(string $productId, string $source, string $alt, bool $makeFeatured): array
{
    if (!preg_match('#^gid://shopify/Product/\d+$#', $productId)) {
        throw new InvalidArgumentException('That is not a Shopify product id.');
    }
    $data = shopify_graphql(<<<'GRAPHQL'
mutation AddScanToProduct($product: ProductUpdateInput!, $media: [CreateMediaInput!]) {
  productUpdate(product: $product, media: $media) {
    product { id media(last: 1) { nodes { id } } }
    userErrors { field message }
  }
}
GRAPHQL, [
        'product' => ['id' => $productId],
        'media' => [[
            'originalSource' => $source,
            'mediaContentType' => 'IMAGE',
            'alt' => truncate_text($alt, 500),
        ]],
    ]);
    $payload = $data['productUpdate'] ?? [];
    if (!empty($payload['userErrors'])) {
        throw new RuntimeException(implode(' ', array_map(static fn(array $e): string => (string) ($e['message'] ?? ''), $payload['userErrors'])));
    }
    $mediaId = (string) ($payload['product']['media']['nodes'][0]['id'] ?? '');
    $featured = false;
    if ($makeFeatured && $mediaId !== '') {
        try {
            $move = shopify_graphql(<<<'GRAPHQL'
mutation FeatureScan($id: ID!, $moves: [MoveInput!]!) {
  productReorderMedia(id: $id, moves: $moves) {
    job { id }
    mediaUserErrors { field message }
  }
}
GRAPHQL, ['id' => $productId, 'moves' => [['id' => $mediaId, 'newPosition' => '0']]]);
            $featured = empty($move['productReorderMedia']['mediaUserErrors']);
        } catch (Throwable) {
            $featured = false;
        }
    }
    return ['mediaId' => $mediaId, 'featured' => $featured];
}

// --------------------------------------------------------------- fetching

/**
 * The address to connect to for a host, or '' when any address it resolves
 * to is private, reserved or local. The fetch is pinned to the address that
 * passed, so a second lookup (DNS rebinding) cannot swap in a private one.
 */
function media_public_ip(string $host): string
{
    $host = strtolower(trim($host, '[]'));
    if ($host === '' || $host === 'localhost' || str_ends_with($host, '.local') || str_ends_with($host, '.internal')) return '';
    $ips = [];
    if (filter_var($host, FILTER_VALIDATE_IP)) {
        $ips[] = $host;
    } else {
        $resolved = gethostbynamel($host);
        if (is_array($resolved)) $ips = $resolved;
    }
    if ($ips === []) return '';
    foreach ($ips as $ip) {
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return '';
    }
    return (string) $ips[0];
}

/**
 * Fetch an image from a public https address, following at most three
 * redirects and re-checking each hop. Returns [bytes, mime].
 *
 * @throws InvalidArgumentException|RuntimeException
 */
function media_fetch_remote_image(string $url): array
{
    for ($hop = 0; $hop < 4; $hop++) {
        $parts = parse_url($url);
        if (!is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https' || empty($parts['host'])) {
            throw new InvalidArgumentException('Only https image addresses can be fetched.');
        }
        if (isset($parts['user']) || isset($parts['pass'])) {
            throw new InvalidArgumentException('Image addresses with a user name are not fetched.');
        }
        if (isset($parts['port']) && (int) $parts['port'] !== 443) {
            throw new InvalidArgumentException('Only the standard https port is allowed.');
        }
        $host = (string) $parts['host'];
        $ip = media_public_ip($host);
        if ($ip === '') {
            throw new InvalidArgumentException('That address is not a public website.');
        }

        $bytes = '';
        $tooBig = false;
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_HEADER => false,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
            CURLOPT_RESOLVE => [$host . ':443:' . $ip],
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER => ['Accept: image/avif,image/webp,image/png,image/jpeg;q=0.9,*/*;q=0.5'],
            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; LockettLabsIntake/6.0; +https://lockett-labs.com)',
            CURLOPT_WRITEFUNCTION => static function ($curl, string $chunk) use (&$bytes, &$tooBig): int {
                $bytes .= $chunk;
                if (strlen($bytes) > MEDIA_MAX_BYTES) { $tooBig = true; return 0; }
                return strlen($chunk);
            },
        ]);
        curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $redirect = (string) curl_getinfo($ch, CURLINFO_REDIRECT_URL);
        curl_close($ch);

        if ($tooBig) throw new InvalidArgumentException('That image is over 15 MB.');
        if ($status >= 300 && $status < 400 && $redirect !== '') { $url = $redirect; continue; }
        if ($status === 403 || $status === 401) throw new RuntimeException('That site blocks downloads. Save the image to your device and drop the file in instead.');
        if ($status >= 400 || $status === 0) throw new RuntimeException('The image could not be fetched' . ($status ? " (HTTP {$status})" : '') . '.');

        $sniff = media_sniff_mime($bytes);
        if ($sniff === '') throw new InvalidArgumentException('That address is a web page, not an image. Right-click the picture and copy the image address.');
        return [$bytes, $sniff];
    }
    throw new RuntimeException('Too many redirects.');
}

/** Identify an image by its first bytes, never by what the server claims. */
function media_sniff_mime(string $bytes): string
{
    if (strncmp($bytes, "\xFF\xD8\xFF", 3) === 0) return 'image/jpeg';
    if (strncmp($bytes, "\x89PNG\r\n\x1A\n", 8) === 0) return 'image/png';
    if (strncmp($bytes, 'RIFF', 4) === 0 && substr($bytes, 8, 4) === 'WEBP') return 'image/webp';
    if (substr($bytes, 4, 8) === 'ftypavif' || substr($bytes, 4, 8) === 'ftypheic') return 'image/avif';
    if (strncmp($bytes, 'GIF8', 4) === 0) return 'image/gif';
    return '';
}
