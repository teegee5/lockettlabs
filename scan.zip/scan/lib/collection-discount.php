<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/variant-backup.php';

/**
 * Biggest in-stock saving per collection, written to custom.max_discount_pct.
 *
 * The deals deck on the homepage shows a "Save up to X%" badge on each
 * collection card. Liquid alone cannot produce an honest number: collection.products
 * is capped at 50 items, so on the Pokémon collection (8,000+ products) the
 * badge would read the best saving among an arbitrary first fifty.
 *
 * This walks the entire catalogue through one bulk export and writes the real
 * figure to each collection, which the theme reads in preference to counting.
 *
 * Two rules the theme also follows, kept identical here so the two never
 * disagree:
 *   - Percentages are floored. "Up to 75%" is a claim about the best deal
 *     actually obtainable, so 74.6 must not advertise as 75.
 *   - Only purchasable variants count. A 60% saving on a sold-out variant is a
 *     promise the collection breaks the moment a shopper clicks in.
 */

const COLLECTION_DISCOUNT_NAMESPACE = 'custom';
const COLLECTION_DISCOUNT_KEY       = 'max_discount_pct';

function collection_discount_start(): string
{
    // Two sibling connections under products. Bulk emits every child row with
    // __parentId set to its product, so rows are told apart by shape: a
    // product row has no __parentId, a variant row carries `price`, and a
    // collection row carries `handle`. The product node deliberately does NOT
    // select handle, so that test stays unambiguous.
    $query = <<<'GRAPHQL'
{
  products {
    edges {
      node {
        id
        variants { edges { node { price compareAtPrice availableForSale } } }
        collections { edges { node { id handle } } }
      }
    }
  }
}
GRAPHQL;

    $data = shopify_graphql(<<<'GRAPHQL'
mutation StartDiscountScan($query: String!) {
  bulkOperationRunQuery(query: $query) {
    bulkOperation { id status }
    userErrors { field message }
  }
}
GRAPHQL, ['query' => $query]);

    $errors = $data['bulkOperationRunQuery']['userErrors'] ?? [];
    if ($errors !== []) {
        throw new RuntimeException('Could not start the discount scan: ' . ($errors[0]['message'] ?? 'unknown error'));
    }
    $id = (string) ($data['bulkOperationRunQuery']['bulkOperation']['id'] ?? '');
    if ($id === '') throw new RuntimeException('Shopify did not return an export id.');
    return $id;
}

/**
 * @return array{collections: array<string, array{handle: string, pct: int}>, products: int, discounted: int}
 */
function collection_discount_parse(string $jsonl): array
{
    $collections = [];   // gid => ['handle' => string, 'pct' => int]
    $bestByProduct = []; // product gid => int
    $memberships = [];   // product gid => list of [gid, handle]
    $products = 0;
    $discounted = 0;

    foreach (explode("\n", $jsonl) as $line) {
        $line = trim($line);
        if ($line === '') continue;
        $row = json_decode($line, true);
        if (!is_array($row)) continue;

        $parent = $row['__parentId'] ?? null;

        if ($parent === null) {
            $products++;
            continue;
        }

        if (array_key_exists('price', $row)) {
            // Variant. compareAtPrice is null on anything not discounted.
            if (empty($row['availableForSale'])) continue;
            $price = (float) ($row['price'] ?? 0);
            $compare = (float) ($row['compareAtPrice'] ?? 0);
            if ($compare <= $price || $compare <= 0) continue;

            $pct = (int) floor((($compare - $price) / $compare) * 100);
            if ($pct > ($bestByProduct[$parent] ?? 0)) {
                $bestByProduct[$parent] = $pct;
            }
            continue;
        }

        if (isset($row['handle'])) {
            $memberships[$parent][] = [(string) $row['id'], (string) $row['handle']];
        }
    }

    // Membership rows and variant rows arrive interleaved, so the roll-up runs
    // only once both are fully read.
    foreach ($memberships as $productId => $rows) {
        $pct = $bestByProduct[$productId] ?? 0;
        if ($pct > 0) $discounted++;
        foreach ($rows as [$gid, $handle]) {
            if (!isset($collections[$gid]) || $pct > $collections[$gid]['pct']) {
                $collections[$gid] = ['handle' => $handle, 'pct' => max($pct, $collections[$gid]['pct'] ?? 0)];
            }
        }
    }

    return ['collections' => $collections, 'products' => $products, 'discounted' => $discounted];
}

/**
 * Writes every collection, including the zeroes. A collection whose sale has
 * ended must be set back to 0 or the theme keeps showing a badge for a
 * discount that no longer exists.
 *
 * @param array<string, array{handle: string, pct: int}> $collections
 * @return array{written: int, errors: array}
 */
function collection_discount_apply(array $collections, int $offset = 0, int $limit = 25): array
{
    $slice = array_slice($collections, $offset, $limit, true);
    if ($slice === []) return ['written' => 0, 'errors' => []];

    $inputs = [];
    foreach ($slice as $gid => $row) {
        $inputs[] = [
            'ownerId'   => $gid,
            'namespace' => COLLECTION_DISCOUNT_NAMESPACE,
            'key'       => COLLECTION_DISCOUNT_KEY,
            'type'      => 'number_integer',
            'value'     => (string) $row['pct'],
        ];
    }

    $result = shopify_graphql(<<<'GRAPHQL'
mutation SetDiscountPct($metafields: [MetafieldsSetInput!]!) {
  metafieldsSet(metafields: $metafields) {
    metafields { id }
    userErrors { field message }
  }
}
GRAPHQL, ['metafields' => $inputs]);

    $payload = $result['metafieldsSet'] ?? [];
    $errors = [];
    foreach ($payload['userErrors'] ?? [] as $error) {
        $errors[] = $error['message'] ?? 'unknown error';
    }

    return ['written' => count($payload['metafields'] ?? []), 'errors' => $errors];
}
