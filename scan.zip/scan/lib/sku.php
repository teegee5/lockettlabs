<?php
declare(strict_types=1);

/**
 * SKU construction, shared by the intake tool and the backfill.
 *
 * This is the PHP twin of makeSku() in assets/app.js. The two must agree
 * exactly or the backfill is pointless: a card listed by the intake tool and
 * the same card backfilled would carry different SKUs and never join.
 *
 *   LL-<GAME>-<SET>-<LOCAL>-<TOTAL>-<FINISH>-<CONDITION>
 *   LL-PKM-LOSTORIGIN-080-196-STD-NM
 *
 * Every component is derived from something already stored on the product.
 * Nothing comes from a field an operator can retype, because the SKU is the
 * key Shopify restocks match on and it has to be reproducible.
 */

const SKU_GAME_CODES = [
    'pokemon' => 'PKM',
    'pokémon' => 'PKM',
    'mtg' => 'MTG',
    'magic' => 'MTG',
    'magic the gathering' => 'MTG',
    'magic-the-gathering' => 'MTG',
    'disney' => 'LOR',
    'lorcana' => 'LOR',
    'disney lorcana' => 'LOR',
    'one piece' => 'OPC',
    'one piece card game' => 'OPC',
    'digimon' => 'DGM',
    'yu-gi-oh!' => 'YGO',
    'yu-gi-oh' => 'YGO',
    'yugioh' => 'YGO',
    'star wars unlimited' => 'SWU',
];

const SKU_FINISH_CODES = [
    '' => 'STD',
    'standard' => 'STD',
    'normal' => 'STD',
    'holo' => 'HOLO',
    'holofoil' => 'HOLO',
    'reverse holo' => 'RH',
    'reverse foil' => 'RH',
    'foil' => 'FOIL',
    'cold foil' => 'FOIL',
    'sealed' => 'SLD',
    'non-holo' => 'NH',
    'pokeball reverse holo' => 'PBRH',
    'masterball reverse holo' => 'MBRH',
    'ball reverse holo' => 'BRH',
    'energy reverse holo' => 'ERH',
    'rocket reverse holo' => 'RRH',
];

const SKU_CONDITION_CODES = [
    'near mint' => 'NM',
    'lightly played' => 'LP',
    'moderately played' => 'MP',
    'heavily played' => 'HP',
    'damaged' => 'DMG',
];

/** Uppercase alphanumerics only, capped. Keeps spellings of a set in step. */
function sku_slug(string $value, int $max): string
{
    $value = (string) preg_replace('/[^a-z0-9]+/i', '', $value);
    return strtoupper(substr($value, 0, $max));
}

function sku_game_code(string $game): string
{
    $key = strtolower(trim($game));
    return SKU_GAME_CODES[$key] ?? (sku_slug($key, 4) ?: 'TCG');
}

function sku_finish_code(string $finish): string
{
    $key = strtolower(trim($finish));
    if ($key === 'default title') $key = '';
    return SKU_FINISH_CODES[$key] ?? (sku_slug($key, 5) ?: 'STD');
}

function sku_condition_code(string $condition): string
{
    $key = strtolower(trim($condition));
    if ($key === '' || $key === 'default title') return 'NM';
    return SKU_CONDITION_CODES[$key] ?? (sku_slug($key, 4) ?: 'NM');
}

/**
 * "080/196" and "80/196" both become "080-196". A promo code passes through.
 */
function sku_number_code(string $number): string
{
    $raw = trim($number);
    if ($raw === '') return 'NA';
    if (preg_match('/^0*(\d+)([a-z]?)\s*\/\s*0*(\d+)([a-z]?)$/i', $raw, $m)) {
        $local = str_pad($m[1], 3, '0', STR_PAD_LEFT) . strtoupper($m[2]);
        return $local . '-' . $m[3] . strtoupper($m[4]);
    }
    return sku_slug($raw, 14) ?: 'NA';
}

/**
 * Build a SKU from already-derived parts.
 */
function sku_build(string $game, string $setName, string $number, string $finish, string $condition): string
{
    $parts = [
        'LL',
        sku_game_code($game),
        sku_slug($setName, 16) ?: 'SET',
        sku_number_code($number),
        sku_finish_code($finish),
        sku_condition_code($condition),
    ];
    return substr(implode('-', $parts), 0, 100);
}

/**
 * Read the finish out of a product title.
 *
 * The bracket sits on either side of the colon depending on the game. Pokemon
 * puts it after the set:
 *
 *   Armarouge : PITCH BLACK (Reverse holo) - 012/084
 *
 * Magic puts it on the card name:
 *
 *   Sawblade Slinger (FOIL) : INNISTRAD CRIMSON VOW - 217/277
 *
 * Reading only the set half missed 344 products and made every Magic foil
 * collide with its non-foil twin, so this takes brackets from anywhere.
 */
function sku_finish_from_title(string $title): string
{
    if (preg_match_all('/\(([^)]*)\)/', $title, $matches) && $matches[1] !== []) {
        return trim(implode(' ', $matches[1]));
    }
    return '';
}

/**
 * Sealed products have no collector number or condition, so the key is the
 * game, the set and the product itself:
 *
 *   LL-PKM-SLD-PITCHBLACK-ELITETRAINERBOX
 *
 * Twin of makeSealedSku() in assets/app.js.
 */
function sku_build_sealed(string $game, string $setName, string $product): string
{
    $parts = [
        'LL',
        sku_game_code($game),
        'SLD',
        sku_slug($setName, 16) ?: 'SET',
        sku_slug($product, 24) ?: 'ITEM',
    ];
    return substr(implode('-', $parts), 0, 100);
}
