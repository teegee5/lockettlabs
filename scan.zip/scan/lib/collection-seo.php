<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

/**
 * Templated SEO titles and descriptions for collections.
 *
 * A page gets ONE title tag, so "capturing more searches" is not a matter of
 * cramming games into the homepage — it is a matter of every collection page
 * carrying a title built for the query that page answers. This derives those
 * from the collection itself so there is nothing to hand-write.
 *
 * Locality is carried in the description rather than the title: the title has
 * ~60 usable characters and the set/game name earns more of them than the town
 * does. Local intent is won by the store page and LocalBusiness schema, not by
 * a town name repeated across hundreds of titles, which reads as spam.
 */

const COLLECTION_SEO_BRAND = 'Lockett Labs';
const COLLECTION_SEO_TOWN  = 'Lowestoft';
const COLLECTION_SEO_TITLE_MAX = 60;
const COLLECTION_SEO_DESC_MAX  = 160;

/**
 * The game comes from the products, NOT the collection title.
 *
 * Around 200 of the 264 collections are bare set names with no game word in
 * them ("Azurite Sea", "Pitch Black", "Fabled", "Crimson Vow"), and several
 * actively mislead a title reader: "Dungeons & Dragons", "Teenage Mutant Ninja
 * Turtles" and "Avatar: The Last Airbender" are all Magic Universes Beyond
 * sets, "Disney" and "Ravensburger Ltd" are Lorcana, "Konami" is Yu-Gi-Oh!.
 *
 * productType is set consistently across the catalogue, so it decides.
 */
const COLLECTION_SEO_TYPE_GAMES = [
    'pokemon'    => 'Pokémon',
    'mtg'        => 'Magic: The Gathering',
    'disney'     => 'Disney Lorcana',
    'one piece'  => 'One Piece',
    'digimon'    => 'Digimon',
    'yu-gi-oh!'  => 'Yu-Gi-Oh!',
    'pkmontoys'  => 'Pokémon',
];

/**
 * Last-resort title matching, used only when productType cannot decide — which
 * in practice means the legacy "Single Card" type still on the One Piece range.
 */
const COLLECTION_SEO_TITLE_GAMES = [
    'Disney Lorcana'       => ['lorcana'],
    'One Piece'            => ['one piece', 'one-piece', 'opcg'],
    'Pokémon'              => ['pokemon', 'pokémon'],
    'Magic: The Gathering' => ['magic the gathering', 'magic:', 'mtg'],
    'Digimon'              => ['digimon'],
    'Yu-Gi-Oh!'            => ['yu-gi-oh', 'yugioh'],
];

/**
 * Collections that must never be given an SEO title, because they should not
 * be earning search traffic at all. Three groups: app-generated indexes that
 * mirror the whole catalogue, internal bookkeeping, and store-wide listings.
 * Each is a crawlable /collections/ URL holding near-identical content, so
 * writing good titles for them would make a duplicate-content problem worse.
 */
const COLLECTION_SEO_SKIP_TITLES = [
    'all', 'newest products', 'best selling products', 'featured products',
    'our latest deals', 'single cards', 'other singles', 'sealed product',
    'digital goods vat tax', 'tcg products', 'lockett labs uk',
];

const COLLECTION_SEO_SKIP_PATTERNS = [
    'avada', 'seguno', 'cloudsearch', 'orderly emails', 'do not delete',
    'recommended products', 'smart products filter',
];

/**
 * Collections named after the range they hold rather than a set or a brand.
 * Their title IS the noun, so it must not also be used as a qualifier or the
 * title reads "ACCESSORIES TCG Card Sleeves & Accessories". Anything not
 * listed here is treated as a brand ("Vault X", "Ultra Pro") and kept.
 */
const COLLECTION_SEO_RANGE_NOUNS = [
    'accessories'         => 'TCG Card Sleeves & Accessories',
    'accessory'           => 'TCG Card Sleeves & Accessories',
    'sleeves'             => 'TCG Card Sleeves',
    'binders'             => 'TCG Card Binders',
    'deck boxes'          => 'Deck Boxes',
    'playmats'            => 'Playmats',
    'pkmontoys'           => 'Toys & Plushies',
    'figurines / plushes' => 'Figures & Plushies',
    'promos'              => 'Promo Cards',
    'pre-orders'          => 'Pre-Orders',
];

/** Non-card ranges, which need their own phrasing rather than "{x} Cards". */
const COLLECTION_SEO_KINDS = [
    'plush'       => ['plush', 'plushie', 'soft toy', 'teddy'],
    'accessories' => ['sleeve', 'accessor', 'binder', 'deck box', 'playmat', 'toploader', 'top loader'],
    'sealed'      => ['booster', 'sealed', 'box', 'etb', 'elite trainer', 'bundle', 'tin', 'blister', 'pack'],
];

function collection_seo_norm(string $value): string
{
    return mb_strtolower(trim($value));
}

/**
 * Reason a collection should be left alone, or '' if it should be processed.
 */
function collection_seo_skip_reason(array $collection): string
{
    $title = collection_seo_norm((string)($collection['title'] ?? ''));
    $count = (int)($collection['productsCount']['count'] ?? 0);

    if ($count === 0) {
        return 'empty collection';
    }
    if (in_array($title, COLLECTION_SEO_SKIP_TITLES, true)) {
        return 'store-wide or internal listing';
    }
    foreach (COLLECTION_SEO_SKIP_PATTERNS as $pattern) {
        if (str_contains($title, $pattern)) {
            return 'app-generated index';
        }
    }
    // A collection holding most of the catalogue is an index, whatever it is
    // called. 5000 sits well above the largest real range (Pokémon, ~8500 —
    // which is named explicitly below so it survives this rule).
    if ($count >= 5000 && !in_array($title, ['pokémon', 'pokemon', 'disney'], true)) {
        return 'holds most of the catalogue';
    }
    return '';
}

/**
 * Majority productType across a sample of the collection's products. Mixed
 * collections exist (Bandai carries both Digimon and One Piece), so one
 * product is not enough to decide.
 */
function collection_seo_game(array $collection): ?string
{
    $tally = [];
    foreach ($collection['products']['nodes'] ?? [] as $product) {
        $type = collection_seo_norm((string)($product['productType'] ?? ''));
        if ($type === '' || $type === 'accessory') continue;
        $label = COLLECTION_SEO_TYPE_GAMES[$type] ?? null;
        if ($label !== null) {
            $tally[$label] = ($tally[$label] ?? 0) + 1;
        }
    }

    if ($tally !== []) {
        arsort($tally);
        return array_key_first($tally);
    }

    // productType could not decide — the legacy "Single Card" type is still on
    // the One Piece range. Fall back to the title, and return null rather than
    // guessing if that cannot decide either.
    $haystack = collection_seo_norm(($collection['title'] ?? '') . ' ' . ($collection['handle'] ?? ''));
    foreach (COLLECTION_SEO_TITLE_GAMES as $label => $needles) {
        foreach ($needles as $needle) {
            if (str_contains($haystack, $needle)) return $label;
        }
    }
    return null;
}

function collection_seo_kind(array $collection): string
{
    // A collection of accessories is decided by its products, not its name:
    // "Vault X" and "Dragon Shield" are brands, "SLEEVES" is a range.
    $types = array_map(
        static fn(array $p): string => collection_seo_norm((string)($p['productType'] ?? '')),
        $collection['products']['nodes'] ?? []
    );
    if ($types !== [] && count(array_filter($types, static fn($t) => $t === 'accessory')) > count($types) / 2) {
        return 'accessories';
    }
    // Majority, not presence: a single stray toy in a card set was enough to
    // label "Black Bolt JP" a plush range.
    if ($types !== [] && count(array_filter($types, static fn($t) => $t === 'pkmontoys')) > count($types) / 2) {
        return 'plush';
    }

    $haystack = collection_seo_norm(($collection['title'] ?? '') . ' ' . ($collection['handle'] ?? ''));
    foreach (COLLECTION_SEO_KINDS as $kind => $needles) {
        foreach ($needles as $needle) {
            // Word-bounded: a bare str_contains matched "tin" inside
            // "Next Destinies" and made a card set a sealed range.
            if (preg_match('/\b' . preg_quote($needle, '/') . '/iu', $haystack) === 1) {
                return $kind;
            }
        }
    }
    return 'cards';
}

/**
 * The set name is the collection title with any game words removed. Because
 * titles here are overwhelmingly bare set names, that usually returns the
 * title unchanged — "Pitch Black", "Azurite Sea", "Crimson Vow". It comes back
 * empty only for a game hub such as "POKÉMON", where nothing is left over.
 */
function collection_seo_set_name(array $collection, ?string $game): string
{
    $title = trim(preg_replace('/[\s–—]+/u', ' ', (string)($collection['title'] ?? '')) ?? '');
    if ($game === null) return $title;

    $needles = COLLECTION_SEO_TITLE_GAMES[$game] ?? [];
    $stripped = $title;
    foreach ($needles as $needle) {
        $stripped = preg_replace('/' . preg_quote($needle, '/') . '/iu', ' ', $stripped) ?? $stripped;
    }
    // Leftover connective words that never constitute a set name on their own.
    $stripped = preg_replace('/\b(singles?|tcg|sealed|collection|and)\b/iu', ' ', $stripped) ?? $stripped;
    $stripped = trim(preg_replace('/[\s\-:|]+/u', ' ', $stripped) ?? '');

    // Nothing left: this is the game's own hub, so the caller supplies the
    // label and no qualifier.
    if ($stripped === '') return '';

    // The title still carries the game word ("Pokémon GO", "Pokemon 151"), so
    // it is returned whole and the caller must not add the label again — the
    // alternative is "GO Pokémon Cards", or worse, dropping "GO" entirely and
    // colliding with the hub's own title.
    $haystack = collection_seo_norm($title);
    foreach ($needles as $needle) {
        if (str_contains($haystack, $needle)) return $title;
    }

    return $stripped;
}

/** True when the set name already contains the game, so the label is redundant. */
function collection_seo_set_has_game(string $set, ?string $game): bool
{
    if ($game === null || $set === '') return false;
    $haystack = collection_seo_norm($set);
    foreach (COLLECTION_SEO_TITLE_GAMES[$game] ?? [] as $needle) {
        if (str_contains($haystack, $needle)) return true;
    }
    return false;
}

/**
 * Titles are assembled longest-first, then shortened by dropping the least
 * valuable part, so a long set name never pushes the brand off the end.
 */
function collection_seo_title(array $collection, ?string $game, string $kind, string $set): string
{
    $brand = COLLECTION_SEO_BRAND;
    $label = $game ?? 'TCG';

    $rangeNoun = COLLECTION_SEO_RANGE_NOUNS[collection_seo_norm((string)($collection['title'] ?? ''))] ?? null;

    $noun = $rangeNoun ?? match ($kind) {
        'plush'       => 'Plushies',
        'accessories' => 'Card Sleeves & Accessories',
        'sealed'      => 'Booster Boxes & Sealed',
        default       => $game ? 'Cards' : 'Trading Cards',
    };

    // When the title supplied the noun it must not also be the qualifier, and
    // a range noun already says "TCG", so the game label is dropped too unless
    // the products actually pin one down ("Pokémon Toys & Plushies").
    if ($rangeNoun !== null) {
        $set = '';
        $label = $game ?? '';
    }
    if (collection_seo_set_has_game($set, $game)) {
        $label = '';
    }

    $subject = trim(preg_replace('/\s+/u', ' ', "$set $label $noun") ?? "$label $noun");

    $candidates = [
        "$subject UK | $brand",
        "$subject | $brand",
        trim(preg_replace('/\s+/u', ' ', $set !== '' ? "$set $label | $brand" : "$label $noun | $brand") ?? ''),
        // A long set name ("The Lord of the Rings: Tales of Middle-Earth")
        // needs a form with no game label at all, or the only thing left to
        // cut is the brand.
        $set !== '' ? "$set | $brand" : $subject,
        $subject,
    ];

    foreach ($candidates as $candidate) {
        if (text_length($candidate) <= COLLECTION_SEO_TITLE_MAX) {
            return $candidate;
        }
    }

    // Nothing fits. Cut on a word boundary rather than mid-word, which is how
    // "Magic: The Gathering" became "Magic: The Gathe".
    $last = end($candidates);
    $cut = mb_substr($last, 0, COLLECTION_SEO_TITLE_MAX);
    $space = mb_strrpos($cut, ' ');
    return rtrim($space !== false ? mb_substr($cut, 0, $space) : $cut, " |-–—:,");
}

function collection_seo_description(array $collection, ?string $game, string $kind, string $set): string
{
    $label = $game ?? 'trading card';
    $town  = COLLECTION_SEO_TOWN;
    $brand = COLLECTION_SEO_BRAND;

    // The product count makes each description genuinely distinct. Without it
    // all 229 read identically, which is the duplicate-copy problem the
    // catalogue audit already found on product bodies.
    // Only above a threshold: "Browse 2 GG End Pokémon singles" advertises
    // thin stock in the result snippet, which costs more than the distinctness
    // is worth. Below it, the set name alone keeps the description unique.
    $count = (int)($collection['productsCount']['count'] ?? 0);
    $n = $count >= 25 ? number_format($count) . ' ' : '';

    // "Pokémon GO" already names the game, so drop the label to avoid
    // "Browse 99 Pokémon GO Pokémon singles".
    if (collection_seo_set_has_game($set, $game)) {
        $label = '';
    }

    $opening = match (true) {
        $kind === 'plush'       => "{$n}$label plushies, figures and soft toys in stock",
        $kind === 'accessories' => "{$n}sleeves, binders, deck boxes and playmats in stock",
        $kind === 'sealed'      => ($set !== '' ? "{$n}$set booster boxes, ETBs and tins" : "{$n}$label booster boxes, ETBs and tins"),
        $set !== ''             => "Browse {$n}$set $label singles and sealed",
        default                 => "Browse {$n}$label singles, sealed and accessories",
    };

    // An emptied label leaves a double space mid-sentence.
    $opening = trim(preg_replace('/\s+/u', ' ', $opening) ?? $opening);

    // "Shop in Lowestoft" would imply premises customers can visit; there are
    // none, so the town is attached to dispatch instead. Longest form first,
    // each fallback dropping the least load-bearing clause.
    // Sleeving and top-loading only mean anything for cards.
    $handling = in_array($kind, ['plush', 'accessories'], true)
        ? "Dispatched from $town, UK within 2 working days."
        : "Every card sleeved, top-loaded and dispatched from $town, UK within 2 working days.";

    $candidates = [
        "$opening at $brand. $handling",
        "$opening at $brand. Dispatched from $town, UK within 2 working days.",
        "$opening at $brand. UK dispatch within 2 working days.",
    ];

    foreach ($candidates as $candidate) {
        if (text_length($candidate) <= COLLECTION_SEO_DESC_MAX) {
            return $candidate;
        }
    }
    return truncate_text(end($candidates), COLLECTION_SEO_DESC_MAX);
}

function collection_seo_build(array $collection): array
{
    $game = collection_seo_game($collection);
    $kind = collection_seo_kind($collection);
    $set  = collection_seo_set_name($collection, $game);

    return [
        'title'       => collection_seo_title($collection, $game, $kind, $set),
        'description' => collection_seo_description($collection, $game, $kind, $set),
        'game'        => $game ?? '',
        'kind'        => $kind,
        'set'         => $set,
    ];
}

/** Every collection, smart and manual alike — both render a collection page. */
function collection_seo_fetch_all(): array
{
    $collections = [];
    $cursor = null;

    do {
        $result = shopify_graphql(<<<'GRAPHQL'
        query($cursor: String) {
          collections(first: 25, after: $cursor) {
            pageInfo { hasNextPage endCursor }
            nodes {
              id handle title productsCount { count }
              seo { title description }
              products(first: 10) { nodes { productType } }
            }
          }
        }
        GRAPHQL, ['cursor' => $cursor]);

        // shopify_graphql() returns the contents of `data`, not the envelope.
        $page = $result['collections'] ?? null;
        if ($page === null) {
            throw new RuntimeException('Collection query returned no data: ' . json_encode($result));
        }

        foreach ($page['nodes'] as $node) {
            $collections[] = $node;
        }
        $cursor = $page['pageInfo']['hasNextPage'] ? $page['pageInfo']['endCursor'] : null;
    } while ($cursor !== null);

    return $collections;
}

/**
 * Without $force, only collections with no seo.title are touched, so anything
 * written by hand survives. With $force, a generated value is replaced but a
 * hand-written one is still reported rather than silently overwritten.
 */
function collection_seo_plan(bool $force = false): array
{
    $planned = [];
    $skipped = [];

    foreach (collection_seo_fetch_all() as $collection) {
        $skip = collection_seo_skip_reason($collection);
        if ($skip !== '') {
            $skipped[] = ['handle' => $collection['handle'], 'reason' => $skip];
            continue;
        }

        $built = collection_seo_build($collection);

        // Fail closed, as the card-id backfill does: a collection whose game
        // cannot be established would get a vague "Trading Cards" title that
        // is worse than the Shopify default, so it is reported instead.
        if ($built['game'] === '' && $built['kind'] === 'cards') {
            $skipped[] = ['handle' => $collection['handle'], 'reason' => 'game could not be determined'];
            continue;
        }

        $currentTitle = trim((string)($collection['seo']['title'] ?? ''));
        $currentDesc  = trim((string)($collection['seo']['description'] ?? ''));

        $hasTitle = $currentTitle !== '';
        if ($hasTitle && !$force) {
            $skipped[] = ['handle' => $collection['handle'], 'reason' => 'already has an SEO title'];
            continue;
        }
        if ($currentTitle === $built['title'] && $currentDesc === $built['description']) {
            $skipped[] = ['handle' => $collection['handle'], 'reason' => 'already matches the template'];
            continue;
        }

        $planned[] = [
            'id'          => $collection['id'],
            'handle'      => $collection['handle'],
            'title'       => $collection['title'],
            'products'    => $collection['productsCount']['count'] ?? 0,
            'game'        => $built['game'],
            'kind'        => $built['kind'],
            'set'         => $built['set'],
            'from_title'  => $currentTitle,
            'from_desc'   => $currentDesc,
            'seo_title'   => $built['title'],
            'seo_desc'    => $built['description'],
        ];
    }

    return ['planned' => $planned, 'skipped' => $skipped];
}

function collection_seo_apply(array $planned): array
{
    $updated = 0;
    $errors  = [];

    foreach ($planned as $row) {
        $result = shopify_graphql(<<<'GRAPHQL'
        mutation($input: CollectionInput!) {
          collectionUpdate(input: $input) {
            collection { id }
            userErrors { field message }
          }
        }
        GRAPHQL, ['input' => [
            'id'  => $row['id'],
            'seo' => ['title' => $row['seo_title'], 'description' => $row['seo_desc']],
        ]]);

        $userErrors = $result['collectionUpdate']['userErrors'] ?? [];
        if ($userErrors !== []) {
            $errors[] = ['handle' => $row['handle'], 'message' => $userErrors[0]['message'] ?? 'unknown error'];
            continue;
        }
        $updated++;
    }

    return ['updated' => $updated, 'errors' => $errors];
}
