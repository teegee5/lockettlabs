<?php
declare(strict_types=1);

require_once __DIR__ . '/match.php';
require_once __DIR__ . '/finish.php';

/**
 * Read the Chaos Cards price snapshot.
 *
 * Chaos Cards cannot be reached from PHP at all. Their HawkSearch endpoint
 * returns 403 and is gone, the /acts route they replaced it with is disallowed
 * by their own robots.txt, and their product pages fingerprint the TLS
 * handshake so curl never gets through however the headers are set. Their CDN
 * serves a sitemap with no prices in it.
 *
 * So the prices come from tools/chaos-snapshot.mjs, which drives a real
 * browser once a day and writes cache/chaos/<game>.json. This reads that.
 *
 * A snapshot older than the limit below is ignored rather than quoted: a stale
 * price is worse than no price, because staff would act on it.
 */

const CHAOS_SNAPSHOT_DIR = __DIR__ . '/../../cache/chaos';
const CHAOS_SNAPSHOT_LEGACY_FILE = __DIR__ . '/../../cache/chaos-snapshot.json';
const CHAOS_SNAPSHOT_MAX_AGE_HOURS = 36;

/**
 * The collector's section names. A lookup opens one of these files, not all of
 * them, which is the whole point of sharding: the combined file is 13 MB and
 * 41,841 cards, and a lookup needs exactly one key out of it.
 */
const CHAOS_SNAPSHOT_SHARDS = ['pokemon', 'lorcana', 'digimon', 'one-piece', 'mtg', 'yu-gi-oh'];

/**
 * Map the game vocabulary the intake form uses onto a shard name.
 *
 * The form and JustTCG between them produce "pokemon", "disney", "mtg",
 * "one piece", "digimon" and "yu-gi-oh!", plus longer forms like "disney
 * lorcana" and "magic-the-gathering", so this matches on substrings rather
 * than an exact table that would silently miss a spelling.
 *
 * Returns null when the game is unknown, which makes the lookup try every
 * shard. That is no worse than the single combined file it replaced.
 */
function retailer_chaos_shard_for_game(string $game): ?string
{
    $g = strtolower(trim($game));
    if ($g === '') return null;

    // Lorcana before "disney": the form sends the game as "disney" alone.
    if (str_contains($g, 'lorcana') || str_contains($g, 'disney')) return 'lorcana';
    if (str_contains($g, 'pokemon') || str_contains($g, 'pokémon')) return 'pokemon';
    if (str_contains($g, 'one piece') || str_contains($g, 'one-piece')) return 'one-piece';
    if (str_contains($g, 'digimon')) return 'digimon';
    if (str_contains($g, 'yu-gi-oh') || str_contains($g, 'yugioh')) return 'yu-gi-oh';
    if (str_contains($g, 'magic') || $g === 'mtg') return 'mtg';

    return null;
}

/**
 * Load one shard, or the legacy combined file when no shards exist.
 *
 * Each shard is cached separately for the life of the request, so a lookup
 * that falls through several shards decodes each at most once.
 *
 * @return array{cards:array<string,array>,generatedAt:string,ageHours:float}|null
 */
function retailer_chaos_snapshot(?string $shard = null): ?array
{
    static $cache = [];

    $key = $shard ?? '(legacy)';
    if (array_key_exists($key, $cache)) return $cache[$key];

    $path = $shard === null
        ? CHAOS_SNAPSHOT_LEGACY_FILE
        : CHAOS_SNAPSHOT_DIR . '/' . $shard . '.json';

    if (!is_file($path)) return $cache[$key] = null;

    $raw = @file_get_contents($path);
    if ($raw === false || $raw === '') return $cache[$key] = null;

    $data = json_decode($raw, true);
    if (!is_array($data) || !isset($data['cards']) || !is_array($data['cards'])) {
        return $cache[$key] = null;
    }

    $generated = (string) ($data['generatedAt'] ?? '');
    $stamp = $generated !== '' ? strtotime($generated) : @filemtime($path);
    $ageHours = $stamp ? (time() - $stamp) / 3600 : PHP_FLOAT_MAX;

    return $cache[$key] = [
        'cards' => $data['cards'],
        'generatedAt' => $generated,
        'ageHours' => $ageHours,
    ];
}

/**
 * True when the collector has written sharded files.
 *
 * Checked so an older combined snapshot keeps working untouched. Upgrading the
 * reader should not blank the price panel until someone re-runs the crawl.
 */
function retailer_chaos_snapshot_is_sharded(): bool
{
    static $sharded = null;
    if ($sharded !== null) return $sharded;

    foreach (CHAOS_SNAPSHOT_SHARDS as $shard) {
        if (is_file(CHAOS_SNAPSHOT_DIR . '/' . $shard . '.json')) return $sharded = true;
    }
    return $sharded = false;
}

/**
 * Which shards to search, in order, for a given game.
 *
 * @return array<int,string|null> a null entry means the legacy combined file
 */
function retailer_chaos_snapshot_search_order(string $game): array
{
    if (!retailer_chaos_snapshot_is_sharded()) return [null];

    $shard = retailer_chaos_shard_for_game($game);
    if ($shard !== null) return [$shard];

    // Unknown game. Search every shard, largest catalogue overlap first so the
    // common case still finds its answer in the first file it opens.
    return CHAOS_SNAPSHOT_SHARDS;
}

/**
 * Normalise a card name exactly as normName() does in the collector.
 * Keeps apostrophes and ampersands, which the retailer's titles carry.
 */
function retailer_chaos_name_key(string $cardName): string
{
    $name = str_replace(['&#039;', '&#39;', '&amp;'], ["'", "'", '&'], $cardName);
    $name = mb_strtolower(trim($name));
    $name = (string) preg_replace('/[\x{2018}\x{2019}`]/u', "'", $name);
    $name = (string) preg_replace('/\band\b/', '&', $name);
    $name = (string) preg_replace("/[^a-z0-9&' ]+/", ' ', $name);
    return trim((string) preg_replace('/\s+/', ' ', $name));
}

/**
 * Normalise a card identifier the way the collector does.
 *
 * Three of the six games Chaos Cards stocks identify cards with a code rather
 * than a number over a set size, so this handles both:
 *
 *   080/196  -> 80/196      leading zeros are not part of the identity
 *   OP16-060 -> OP16-060    One Piece, Digimon and Yu-Gi-Oh use codes
 */
function retailer_chaos_number_key(string $number): ?string
{
    $raw = strtoupper(trim(str_replace([' ', '_'], '', $number)));
    if ($raw === '') return null;

    if (preg_match('#^0*(\d+)([A-Z]?)/0*([A-Z0-9]+)$#', $raw, $m)) {
        return $m[1] . $m[2] . '/' . $m[3];
    }
    if (preg_match('/^[A-Z]{1,6}\d{0,3}-[A-Z0-9]{1,8}$/', $raw)) {
        return $raw;
    }
    if (preg_match('/^0*(\d{1,5})$/', $raw, $m)) {
        return $m[1];
    }
    return $raw;
}

/**
 * Key a card the same way tools/chaos-snapshot.mjs does:
 * normalised name | normalised number | finish.
 */
function retailer_chaos_snapshot_key(string $cardName, string $number, string $finish): ?string
{
    $name = retailer_chaos_name_key($cardName);
    if ($name === '') return null;

    $num = retailer_chaos_number_key($number);
    if ($num === null) return null;

    $finishToken = $finish === '' ? 'normal' : retailer_finish_token($finish);

    return $name . '|' . $num . '|' . $finishToken;
}

/**
 * Look a card up in the snapshot.
 *
 * @return array{id:string,label:string,matched:bool,available:?bool,priceGbp:?float,url:string,note:string,title:string}
 */
function retailer_chaos_from_snapshot(
    string $number,
    string $cardName,
    string $finish = '',
    string $game = ''
): array {
    $id = 'chaoscards';
    $label = 'Chaos Cards';

    $key = retailer_chaos_snapshot_key($cardName, $number, $finish);
    if ($key === null) {
        return retailer_source_no_match($id, $label, 'Not in the snapshot');
    }
    // The base printing is one card whatever the shop calls it: Chaos writes
    // nothing after a holo rare, this store writes "(Holo)". Try the other
    // base spellings before calling it missing.
    $keys = [$key];
    $finishToken = $finish === '' ? 'normal' : retailer_finish_token($finish);
    if (in_array($finishToken, ['normal', 'holo', 'foil'], true)) {
        $stem = substr($key, 0, (int) strrpos($key, '|'));
        foreach (['normal', 'holo', 'foil'] as $alt) {
            if ($alt !== $finishToken) $keys[] = $stem . '|' . $alt;
        }
    }

    $anySnapshot = false;
    $hit = null;
    $snapshot = null;
    foreach (retailer_chaos_snapshot_search_order($game) as $shard) {
        $candidate = retailer_chaos_snapshot($shard);
        if ($candidate === null) continue;
        $anySnapshot = true;
        foreach ($keys as $tryKey) {
            if (isset($candidate['cards'][$tryKey])) {
                $hit = $candidate['cards'][$tryKey];
                $snapshot = $candidate;
                break 2;
            }
        }
    }

    if (!$anySnapshot) {
        return retailer_source_no_match($id, $label, 'No price snapshot. Run tools/chaos-snapshot.mjs');
    }
    if ($hit === null) {
        return retailer_source_no_match($id, $label, 'Not in the snapshot');
    }

    // Age is judged per card, not per file.
    //
    // A full crawl is 770 pages and runs for well over an hour, so it gets
    // interrupted, and picking it up with --resume mixes cards read minutes
    // ago with cards read yesterday. Stamping the whole file at the moment it
    // was last written would relabel every carried-over price as fresh, which
    // is the one thing this file exists to prevent. Entries written before
    // seenAt existed fall back to the file stamp and age out as they did.
    $seen = isset($hit['seenAt']) && is_string($hit['seenAt']) ? strtotime($hit['seenAt']) : false;
    $ageHours = $seen !== false ? (time() - $seen) / 3600 : $snapshot['ageHours'];

    if ($ageHours > CHAOS_SNAPSHOT_MAX_AGE_HOURS) {
        return retailer_source_no_match(
            $id,
            $label,
            sprintf('Snapshot price is %d hours old, ignored', (int) $ageHours)
        );
    }

    $price = isset($hit['price']) && is_numeric($hit['price']) ? round((float) $hit['price'], 2) : null;
    if ($price === null || $price <= 0) {
        return retailer_source_no_match($id, $label, 'Snapshot has no usable price');
    }

    $result = retailer_source_result(
        $id,
        $label,
        true,
        true,   // the snapshot only ever holds in-stock cards
        $price,
        (string) ($hit['url'] ?? ''),
        sprintf('In stock (snapshot, %dh old)', (int) $ageHours)
    );
    $result['title'] = (string) ($hit['title'] ?? '');
    $result['seenAt'] = (string) ($hit['seenAt'] ?? ($snapshot['generatedAt'] ?? ''));
    $result['condition'] = 'NM';
    $result['confidence'] = 'strong';
    $result['evidence'] = ['Same name', 'Same printed number', 'Same finish', sprintf('Browser snapshot, %dh old', (int) $ageHours)];
    return $result;
}
