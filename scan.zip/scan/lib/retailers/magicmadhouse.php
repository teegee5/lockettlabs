<?php
declare(strict_types=1);

require_once __DIR__ . '/match.php';
require_once __DIR__ . '/http.php';
require_once __DIR__ . '/finish.php';

/**
 * Magic Madhouse (BigCommerce).
 *
 * The old implementation posted to /search.php, which their robots.txt
 * explicitly disallows, and which is also the route most likely to be rate
 * limited. This one reads their set pages instead, which robots.txt permits.
 *
 * Every BigCommerce category page embeds an Open Data Layer blob:
 *
 *   var BODL = JSON.parse("{ ... categoryProducts: [ ... ] }");
 *
 * carrying sku, name, url, VAT-inclusive price, an exact stock_level integer
 * and a pre_order flag for up to 250 products in one request. That is far
 * cheaper than a request per card, and it suits intake: staff work through a
 * set at a time, so the first card in a set warms the cache for all the rest.
 *
 * Their singles are titled "<set words> <number>/<total> <Card Name> (Finish)",
 * e.g. "ME Pitch Black 020/084 Primarina (Reverse Holo)".
 */

const MADHOUSE_ORIGIN = 'https://magicmadhouse.co.uk';
const MADHOUSE_SET_INDEXES = [
    'pokemon' => '/pokemon/pokemon-sets',
    'mtg' => '/magic-the-gathering/sets',
];
const MADHOUSE_INDEX_TTL = 86400;   // set list changes rarely
const MADHOUSE_SET_TTL = 900;       // prices change daily; 15 minutes is plenty
const MADHOUSE_PAGE_SIZE = 100;     // the data layer caps here whatever limit says
const MADHOUSE_MAX_PAGES = 6;       // 600 products covers any single set

/**
 * Discover the set pages Magic Madhouse publishes for a game.
 *
 * @return list<array{path:string,slug:string}>
 */
/**
 * The set index URL this lookup will open, or '' when it is already cached.
 *
 * Used by compare.php to fetch the first round trip of each retailer at the
 * same time rather than one after the other. The set index is the right thing
 * to prime because every Madhouse lookup starts there, and which set page it
 * then wants is not known until the index comes back.
 */
function retailer_madhouse_prime_url(string $game): string
{
    $index = MADHOUSE_SET_INDEXES[retailer_madhouse_game_key($game)] ?? '';
    if ($index === '') return '';
    if (is_array(cache_read_json('retailer:madhouse:index:v1:' . $index, MADHOUSE_INDEX_TTL))) return '';
    return MADHOUSE_ORIGIN . $index;
}

function retailer_madhouse_set_index(string $game): array
{
    $index = MADHOUSE_SET_INDEXES[retailer_madhouse_game_key($game)] ?? '';
    if ($index === '') return [];

    $cacheKey = 'retailer:madhouse:index:v1:' . $index;
    $cached = cache_read_json($cacheKey, MADHOUSE_INDEX_TTL);
    if (is_array($cached)) return $cached;

    $response = retailer_http_get(MADHOUSE_ORIGIN . $index);
    $sets = [];
    if ($response['ok'] && $response['status'] < 400 && $response['body'] !== '') {
        $quoted = preg_quote(MADHOUSE_ORIGIN . $index, '#');
        if (preg_match_all('#href="(' . $quoted . '/([a-z0-9\-]+))/?"#i', $response['body'], $matches, PREG_SET_ORDER)) {
            $seen = [];
            foreach ($matches as $match) {
                $slug = strtolower($match[2]);
                if ($slug === '' || isset($seen[$slug])) continue;
                $seen[$slug] = true;
                $sets[] = ['path' => $index . '/' . $slug, 'slug' => $slug];
            }
        }
    }

    cache_write_json($cacheKey, $sets);
    return $sets;
}

function retailer_madhouse_game_key(string $game): string
{
    $game = strtolower(trim($game));
    if ($game === '') return '';
    if (str_contains($game, 'pokemon') || str_contains($game, 'pokémon')) return 'pokemon';
    if (str_contains($game, 'magic') || str_contains($game, 'mtg')) return 'mtg';
    return '';
}

/**
 * Pick the set page whose slug best matches the card's set name.
 * Returns '' when nothing scores well enough to trust.
 */
function retailer_madhouse_pick_set(string $setName, string $game): string
{
    $tokens = retailer_name_tokens($setName);
    if ($tokens === []) return '';

    $best = '';
    $bestScore = 0;
    foreach (retailer_madhouse_set_index($game) as $set) {
        $slugWords = str_replace('-', ' ', $set['slug']);
        $hay = ' ' . retailer_normalize_match_text($slugWords) . ' ';
        $hit = 0;
        foreach ($tokens as $token) {
            if (strlen($token) < 3) continue;
            if (str_contains($hay, ' ' . $token . ' ')) $hit++;
        }
        if ($hit === 0) continue;
        // Prefer slugs that account for most of the set name, not just one word.
        $score = ($hit * 100) - abs(count($tokens) - $hit);
        if ($score > $bestScore) {
            $bestScore = $score;
            $best = $set['path'];
        }
    }
    return $best;
}

/**
 * Read a set's products out of the BigCommerce data layer.
 *
 * The data layer holds 100 products per page whatever `limit` says, and a set
 * with reverse holos runs well past that (Pitch Black is 212 across 3 pages),
 * so this walks pages until a short one comes back. Reverse holos live on the
 * later pages, which is exactly where the finish-sensitive matches are.
 *
 * @return list<array{title:string,sku:string,price:?float,available:?bool,url:string}>
 */
function retailer_madhouse_set_products(string $path): array
{
    $cacheKey = 'retailer:madhouse:set:v2:' . md5($path);
    $cached = cache_read_json($cacheKey, MADHOUSE_SET_TTL);
    if (is_array($cached)) return $cached;

    $pageUrl = static fn(int $page): string => MADHOUSE_ORIGIN . $path . '?limit=100&page=' . $page;

    // Page 1 has to come back before anything else is known: a short page means
    // the set is one page and there is nothing more to ask for.
    $first = retailer_http_get($pageUrl(1));
    if (!$first['ok'] || $first['status'] >= 400 || $first['body'] === '') {
        // Deliberately not cached. The serial version stored an empty result
        // for fifteen minutes when a request failed, so one dropped connection
        // blanked Magic Madhouse for every card after it.
        return [];
    }
    $pages = [1 => retailer_madhouse_parse_bodl($first['body'])];

    // A full page means there is at least one more, so fetch the next couple
    // together rather than waiting for each in turn. Pitch Black is 212
    // products across three pages: that was three round trips in series and is
    // now two.
    //
    // In batches, not all five remaining pages at once. Speculating costs
    // requests against someone else's server, and almost every set fits in
    // three pages, so asking for six every time would roughly double the load
    // to save a round trip that is almost never needed. Two wasted requests is
    // the most this can spend.
    $batches = [[2, 3], [4, 5, 6]];
    $lastFetched = 1;
    foreach ($batches as $batch) {
        if (count($pages[$lastFetched] ?? []) < MADHOUSE_PAGE_SIZE) break;

        $urls = [];
        foreach ($batch as $page) {
            if ($page <= MADHOUSE_MAX_PAGES) $urls[$page] = $pageUrl($page);
        }
        if ($urls === []) break;

        foreach (retailer_http_get_multi($urls) as $page => $response) {
            if (!$response['ok'] || $response['status'] >= 400 || $response['body'] === '') continue;
            $pages[(int) $page] = retailer_madhouse_parse_bodl($response['body']);
        }
        $lastFetched = max(array_keys($urls));
    }

    // Stop at the first gap or short page, exactly as the serial walk did, so
    // a page that failed cannot pull products from beyond it into the set.
    $rows = [];
    for ($page = 1; $page <= MADHOUSE_MAX_PAGES; $page++) {
        $products = $pages[$page] ?? [];
        if ($products === []) break;

        foreach ($products as $product) {
            $row = retailer_madhouse_row($product);
            if ($row !== null) $rows[] = $row;
        }
        if (count($products) < MADHOUSE_PAGE_SIZE) break;
    }

    cache_write_json($cacheKey, $rows);
    return $rows;
}

/**
 * @param array<string,mixed> $product
 * @return array{title:string,sku:string,price:?float,available:?bool,url:string}|null
 */
function retailer_madhouse_row(array $product): ?array
{
    $title = clean_text((string) ($product['name'] ?? ''), 260);
    if ($title === '') return null;

    $price = retailer_parse_gbp(
        $product['price']['with_tax']['value']
        ?? $product['price']['without_tax']['value']
        ?? null
    );

    // stock_level is an exact integer when tracked and null when it is not.
    // An out_of_stock_message is only present when the item is genuinely out.
    $available = true;
    if (!empty($product['out_of_stock_message'])) $available = false;
    if (isset($product['stock_level']) && is_numeric($product['stock_level'])
        && (int) $product['stock_level'] <= 0) {
        $available = false;
    }
    if (!empty($product['pre_order'])) $available = false;

    $url = clean_text((string) ($product['url'] ?? ''), 300);
    if ($url !== '' && !preg_match('#^https?://#i', $url)) {
        $url = MADHOUSE_ORIGIN . (str_starts_with($url, '/') ? $url : '/' . $url);
    }

    return [
        'title' => $title,
        'sku' => clean_text((string) ($product['sku'] ?? ''), 80),
        'price' => $price,
        'available' => $available,
        'stock' => isset($product['stock_level']) && is_numeric($product['stock_level']) ? max(0, (int) $product['stock_level']) : null,
        'preOrder' => !empty($product['pre_order']),
        'url' => $url,
    ];
}

/**
 * Pull the Open Data Layer object out of a BigCommerce page.
 *
 * @return list<array<string,mixed>>
 */
function retailer_madhouse_parse_bodl(string $html): array
{
    if (!preg_match('/var BODL = JSON\.parse\("((?:\\\\.|[^"\\\\])*)"\)/s', $html, $match)) {
        return [];
    }
    // The captured text is a JSON string literal; decode it once to get the
    // JSON document, then decode that.
    $inner = json_decode('"' . $match[1] . '"');
    if (!is_string($inner) || $inner === '') return [];
    $data = json_decode($inner, true);
    if (!is_array($data)) return [];
    $products = $data['categoryProducts'] ?? [];
    return is_array($products) ? array_values(array_filter($products, 'is_array')) : [];
}

/**
 * Look a card up on Magic Madhouse.
 *
 * @return array{id:string,label:string,matched:bool,available:?bool,priceGbp:?float,url:string,note:string}
 */
function retailer_magicmadhouse_lookup(
    string $cardNumber,
    string $cardName = '',
    string $setName = '',
    string $game = '',
    string $finish = ''
): array {
    $id = 'magicmadhouse';
    $label = 'Magic Madhouse';
    $number = retailer_normalize_number($cardNumber);
    $cardName = clean_text($cardName, 120);
    $setName = clean_text($setName, 120);

    if ($number === '') {
        return retailer_source_no_match($id, $label);
    }
    if (retailer_madhouse_game_key($game) === '') {
        return retailer_source_no_match($id, $label, 'Set pages only cover Pokemon and Magic');
    }
    if ($setName === '') {
        return retailer_source_no_match($id, $label, 'Set needed to find the right page');
    }

    $path = retailer_madhouse_pick_set($setName, $game);
    if ($path === '') {
        return retailer_source_no_match($id, $label, 'No matching set page');
    }

    $wantFinish = retailer_intake_finish_token($finish);
    $best = null;
    $bestScore = -1;

    foreach (retailer_madhouse_set_products($path) as $row) {
        if (!retailer_text_contains_exact_number($row['title'], $number)) continue;
        if (!retailer_identity_matches($row['title'], $cardName, $setName)) continue;
        if (!retailer_base_printing_compatible($wantFinish, retailer_title_finish_token($row['title']))) continue;

        $score = retailer_name_score($row['title'], $cardName);
        if ($row['available'] === true) $score += 5;   // prefer a live price
        if ($score > $bestScore) {
            $bestScore = $score;
            $best = $row;
        }
    }

    if ($best === null) {
        return retailer_source_no_match($id, $label, 'No exact card on the set page');
    }

    $note = $best['available'] === true
        ? (isset($best['stock']) && $best['stock'] !== null ? 'In stock (' . $best['stock'] . ')' : 'In stock')
        : (!empty($best['preOrder']) ? 'Pre-order (ignored)' : 'Out of stock (ignored)');

    $result = retailer_source_result(
        $id,
        $label,
        true,
        $best['available'],
        $best['price'],
        $best['url'],
        $note
    );
    $result['title'] = $best['title'];
    $result['stock'] = $best['stock'] ?? null;
    $result['condition'] = 'NM';
    $result['finishFound'] = retailer_title_finish_token($best['title']);
    $result['confidence'] = $bestScore >= 100 ? 'strong' : 'likely';
    $result['evidence'] = ['Same printed number', $bestScore >= 100 ? 'Same name' : 'Close name', 'Same finish', 'Same set page'];
    $result['setUrl'] = MADHOUSE_ORIGIN . $path;
    return $result;
}
