<?php
declare(strict_types=1);

require_once __DIR__ . '/http.php';
require_once __DIR__ . '/match.php';
require_once __DIR__ . '/chaos-snapshot.php';

/**
 * Chaos Cards via HawkSearch (not Cloudflare HTML).
 *
 * POST https://chaoscardsuk.searchapi-na.hawksearch.com/api/v2/search
 * {"ClientGuid":"…","Keyword":"OP16-045","PageNo":1}
 *
 * Returns title, price, code, in_stock, url — enough for UK retail compare.
 */

const CHAOS_HAWKSEARCH_URL = 'https://chaoscardsuk.searchapi-na.hawksearch.com/api/v2/search';
const CHAOS_CLIENT_GUID = 'b96d1a754a0a4b9d95c885c6f560f146';
const CHAOS_SITE_ORIGIN = 'https://www.chaoscards.co.uk';

/**
 * Chaos Cards path/search URL. Prefer name+number so browsers don't land on collisions.
 * Example: /search/tyranitar-135-193
 */
function retailer_chaos_search_url(string $number, string $cardName = ''): string
{
    $keyword = retailer_search_keyword($number, $cardName);
    $slug = strtolower(trim($keyword));
    $slug = str_replace(['/', ' '], '-', $slug);
    $slug = preg_replace('/[^a-z0-9.-]+/', '-', $slug) ?? $slug;
    $slug = trim($slug, '-.');
    if ($slug === '') {
        return CHAOS_SITE_ORIGIN . '/search/';
    }
    return CHAOS_SITE_ORIGIN . '/search/' . rawurlencode($slug);
}

/**
 * Alias used by deep-link helpers / tests.
 */
function price_compare_chaos_search_url(string $number, string $cardName = ''): string
{
    return retailer_chaos_search_url($number, $cardName);
}

/**
 * @return array{id:string,label:string,matched:bool,available:?bool,priceGbp:?float,url:string,note:string,title:string,sku:string}
 */
function retailer_chaos_lookup(
    string $cardNumber,
    string $cardName = '',
    string $setName = '',
    string $finish = '',
    string $game = ''
): array {
    $id = 'chaoscards';
    $label = 'Chaos Cards';
    $number = retailer_normalize_number($cardNumber);
    $cardName = clean_text($cardName, 120);
    $setName = clean_text($setName, 120);
    if ($number === '') {
        return retailer_source_no_match($id, $label);
    }

    $cacheKey = 'chaos:hawk:v5:' . $number . ':' . md5(strtolower($cardName . '|' . $setName . '|' . $finish));
    $cached = retailer_cache_get($cacheKey);
    if ($cached !== null) {
        return $cached;
    }

    // The snapshot answers first, and it answers from a local file.
    //
    // This used to be the other way round: try HawkSearch, then fall back here.
    // But HawkSearch is gone. It returns 403 on every header combination, the
    // /acts route that replaced it is disallowed by their robots.txt, and the
    // product pages fingerprint the TLS handshake. So the old order spent a
    // six second timeout failing, on every card, before reading the file that
    // had the answer the whole time.
    //
    // The live route is still attempted when the snapshot misses, so if their
    // API ever comes back this picks it up again without another change.
    $result = retailer_chaos_from_snapshot($number, $cardName, $finish, $game);

    if (empty($result['matched'])) {
        try {
            $live = retailer_chaos_lookup_live($number, $cardName, $setName);
        } catch (Throwable $error) {
            $live = retailer_source_blocked($id, $label, 'Blocked: ' . clean_text($error->getMessage(), 120));
        }
        // Only a live match replaces the snapshot's answer. Its failure note is
        // discarded on purpose: "Not in the snapshot" tells staff something
        // they can act on, "Blocked" on a dead endpoint does not.
        if (!empty($live['matched'])) {
            $result = $live;
        }
    }

    retailer_cache_set($cacheKey, $result);
    return $result;
}

/**
 * @return array{id:string,label:string,matched:bool,available:?bool,priceGbp:?float,url:string,note:string,title:string,sku:string}
 */
function retailer_chaos_lookup_live(string $number, string $cardName = '', string $setName = ''): array
{
    $id = 'chaoscards';
    $label = 'Chaos Cards';
    $searchUrl = retailer_chaos_search_url($number, $cardName);
    $base = [
        'id' => $id,
        'label' => $label,
        'matched' => false,
        'available' => null,
        'priceGbp' => null,
        'url' => $searchUrl,
        'note' => 'No match',
        'title' => '',
        'sku' => '',
    ];

    $keywords = retailer_search_keywords($number, $cardName, $setName);
    if ($keywords === []) {
        return array_merge($base, ['note' => 'No match']);
    }
    // Cap retries so padding/set variants do not hammer HawkSearch.
    $keywords = array_slice($keywords, 0, 5);

    $requireName = $cardName !== '';
    $response = null;
    $matches = [];
    $sawOk = false;
    foreach ($keywords as $keyword) {
        $response = retailer_http_post_json(CHAOS_HAWKSEARCH_URL, [
            'ClientGuid' => CHAOS_CLIENT_GUID,
            'Keyword' => $keyword,
            'PageNo' => 1,
        ], [], 6);
        if (!$response['ok'] || !is_array($response['json'])) {
            // Transport/API failure — stop retrying alternate keywords.
            break;
        }
        $sawOk = true;
        $rows = retailer_chaos_extract_rows($response['json']);
        if ($rows === []) {
            continue;
        }

        // Dedupe on Chaos product code before matching.
        $byCode = [];
        foreach ($rows as $row) {
            $code = strtoupper((string) ($row['code'] ?? ''));
            $key = $code !== '' ? $code : ('url:' . ($row['url'] ?? uniqid('r', true)));
            if (!isset($byCode[$key])) {
                $byCode[$key] = $row;
            }
        }

        $batch = [];
        foreach (array_values($byCode) as $row) {
            if (!retailer_chaos_row_matches_number($row, $number)) {
                continue;
            }
            $hay = trim(($row['title'] ?? '') . ' ' . ($row['code'] ?? '') . ' ' . ($row['url'] ?? ''));
            $nameScore = retailer_name_score($hay, $cardName);
            if ($requireName && $nameScore < 60) {
                continue;
            }
            $row['nameScore'] = $nameScore;
            $row['setScore'] = retailer_set_score($hay, $setName);
            $batch[] = $row;
        }
        if ($batch !== []) {
            $matches = $batch;
            break;
        }
    }

    if (!$sawOk) {
        $err = is_array($response) ? (string) ($response['error'] ?? '') : '';
        $note = $err !== '' ? ('Blocked: ' . $err) : 'Blocked';
        return array_merge($base, ['note' => $note, 'url' => $searchUrl]);
    }

    if ($matches === []) {
        return array_merge($base, [
            'note' => $requireName ? 'No match for name + number' : 'No match',
        ]);
    }

    // Prefer name/set score, then in-stock, then lowest price.
    usort($matches, static function (array $a, array $b): int {
        $aIn = (($a['inStock'] ?? null) === true) ? 1 : 0;
        $bIn = (($b['inStock'] ?? null) === true) ? 1 : 0;
        $pa = $a['priceGbp'] ?? PHP_FLOAT_MAX;
        $pb = $b['priceGbp'] ?? PHP_FLOAT_MAX;
        return [$b['nameScore'], $b['setScore'], $bIn, -$pa] <=> [$a['nameScore'], $a['setScore'], $aIn, -$pb];
    });

    $best = $matches[0];
    $available = $best['inStock'] ?? null;
    $price = $best['priceGbp'] ?? null;
    $url = (string) ($best['url'] ?? $searchUrl);
    $title = (string) ($best['title'] ?? '');
    $sku = (string) ($best['code'] ?? '');

    if ($available === true && $price !== null && $price > 0) {
        return array_merge($base, [
            'matched' => true,
            'available' => true,
            'priceGbp' => $price,
            'url' => $url,
            'note' => 'In stock',
            'title' => $title,
            'sku' => $sku,
        ]);
    }

    if ($available === false) {
        return array_merge($base, [
            'matched' => true,
            'available' => false,
            'priceGbp' => $price,
            'url' => $url,
            'note' => 'Out of stock (ignored)',
            'title' => $title,
            'sku' => $sku,
        ]);
    }

    return array_merge($base, [
        'matched' => true,
        'available' => $available,
        'priceGbp' => $price,
        'url' => $url,
        'note' => 'Availability unknown (ignored for pricing)',
        'title' => $title,
        'sku' => $sku,
    ]);
}

/**
 * @return list<array{title:string,priceGbp:?float,code:string,inStock:?bool,url:string}>
 */
function retailer_chaos_extract_rows(array $json): array
{
    $results = $json['Results'] ?? $json['results'] ?? [];
    if (!is_array($results)) {
        return [];
    }

    $rows = [];
    foreach ($results as $result) {
        if (!is_array($result)) continue;
        $doc = $result['Document'] ?? $result['document'] ?? $result;
        if (!is_array($doc)) continue;

        $title = retailer_chaos_doc_string($doc, ['title', 'name']);
        $code = retailer_chaos_doc_string($doc, ['code', 'sku', 'Sku']);
        $urlPath = retailer_chaos_doc_string($doc, ['url', 'Url', 'link']);
        $price = retailer_parse_gbp(retailer_chaos_doc_value($doc, ['price', 'Price', 'sale_price']));
        $inStock = retailer_chaos_parse_stock(retailer_chaos_doc_value($doc, ['in_stock', 'inStock', 'instock', 'stock']));

        $url = '';
        if ($urlPath !== '') {
            $url = str_starts_with($urlPath, 'http')
                ? $urlPath
                : (CHAOS_SITE_ORIGIN . (str_starts_with($urlPath, '/') ? $urlPath : '/' . $urlPath));
        }

        $rows[] = [
            'title' => $title,
            'priceGbp' => $price,
            'code' => $code,
            'inStock' => $inStock,
            'url' => $url,
        ];
    }
    return $rows;
}

function retailer_chaos_doc_value(array $doc, array $keys): mixed
{
    foreach ($keys as $key) {
        if (!array_key_exists($key, $doc)) continue;
        $value = $doc[$key];
        if (is_array($value)) {
            return $value[0] ?? null;
        }
        return $value;
    }
    return null;
}

function retailer_chaos_doc_string(array $doc, array $keys): string
{
    $value = retailer_chaos_doc_value($doc, $keys);
    if ($value === null || $value === '') return '';
    return clean_text((string) $value, 255);
}

function retailer_chaos_parse_stock(mixed $value): ?bool
{
    if ($value === null || $value === '') return null;
    if (is_bool($value)) return $value;
    if (is_numeric($value)) return ((float) $value) > 0;
    $text = strtolower(trim((string) $value));
    if (in_array($text, ['1', 'true', 'yes', 'y', 'in stock', 'instock', 'available'], true)) return true;
    if (in_array($text, ['0', 'false', 'no', 'n', 'out of stock', 'oos', 'unavailable'], true)) return false;
    return null;
}

function retailer_chaos_row_matches_number(array $row, string $number): bool
{
    $number = retailer_normalize_number($number);
    if ($number === '') return false;

    $title = (string) ($row['title'] ?? '');
    $code = (string) ($row['code'] ?? '');
    $url = (string) ($row['url'] ?? '');

    if (retailer_title_matches_number($title, $number)) return true;
    if (retailer_text_contains_exact_number($title, $number)) return true;
    if (retailer_text_contains_exact_number($code, $number)) return true;
    if (retailer_text_contains_exact_number($url, $number)) return true;

    // Chaos path/slug form: op16-040 or wugtrio-53-182 (padding-flexible for slash IDs).
    $parts = retailer_slash_number_parts($number);
    $hay = strtolower($title . ' ' . $code . ' ' . $url);
    if ($parts !== null) {
        $slugBody = '0*' . preg_quote($parts[0], '/') . '-' . '0*' . preg_quote($parts[1], '/');
        if (preg_match('/(?<![a-z0-9])' . $slugBody . '(?![a-z0-9])/', $hay)) {
            return true;
        }
        return false;
    }

    $slug = strtolower(str_replace(['/', ' '], '-', $number));
    if ($slug !== '' && preg_match('/(?<![a-z0-9])' . preg_quote($slug, '/') . '(?![a-z0-9])/', $hay)) {
        return true;
    }

    return false;
}
