<?php
declare(strict_types=1);

require_once __DIR__ . '/match.php';
require_once __DIR__ . '/http.php';

/**
 * Unicorn Cards (nopCommerce) — autocomplete for match, product HTML for price/stock.
 */
function retailer_unicorn_lookup(string $cardNumber): array
{
    $number = retailer_normalize_number($cardNumber);
    if ($number === '') return retailer_source_no_match('unicorn', 'Unicorn Cards');
    $cacheKey = 'unicorn:v1:' . $number;
    $cached = retailer_cache_get($cacheKey);
    if ($cached !== null) return $cached;

    $autoUrl = 'https://unicorncards.co.uk/catalog/searchtermautocomplete?term=' . rawurlencode($number);
    $result = retailer_unicorn_from_response($number, retailer_http_get($autoUrl, ['Accept: application/json']));
    retailer_cache_set($cacheKey, $result);
    return $result;
}

/**
 * @param array{ok:bool,status:int,body:string,error:string} $response
 */
function retailer_unicorn_from_response(string $number, array $response): array
{
    $id = 'unicorn';
    $label = 'Unicorn Cards';
    $number = retailer_normalize_number($number);

    if (!$response['ok']) {
        if (in_array($response['status'], [403, 429], true) || $response['status'] >= 500 || $response['status'] === 0) {
            return retailer_source_blocked($id, $label, 'Blocked');
        }
        return retailer_source_no_match($id, $label);
    }
    if ($response['status'] >= 400) {
        if (in_array($response['status'], [403, 429], true)) {
            return retailer_source_blocked($id, $label, 'Blocked');
        }
        return retailer_source_no_match($id, $label);
    }

    $items = json_decode($response['body'], true);
    if (!is_array($items) || $items === []) {
        return retailer_source_no_match($id, $label);
    }

    $candidate = null;
    foreach ($items as $item) {
        if (!is_array($item)) continue;
        $labelText = clean_text($item['label'] ?? '', 260);
        $path = clean_text($item['producturl'] ?? '', 300);
        if (preg_match('/booster|display|box|bundle|case|pack set/i', $labelText)
            && !retailer_text_contains_exact_number($labelText, $number)) {
            continue;
        }
        if (!retailer_text_contains_exact_number($labelText, $number) && !retailer_text_contains_exact_number($path, $number)) {
            continue;
        }
        if (preg_match('/' . preg_quote($number, '/') . '[A-Z]/i', $labelText . ' ' . $path)) {
            continue;
        }
        $candidate = [
            'title' => $labelText,
            'url' => $path !== '' && preg_match('#^https?://#i', $path)
                ? $path
                : 'https://unicorncards.co.uk' . (str_starts_with($path, '/') ? $path : '/' . ltrim($path, '/')),
        ];
        if (retailer_title_matches_number($labelText, $number) || retailer_text_contains_exact_number($path, $number)) {
            break;
        }
    }

    if ($candidate === null) {
        return retailer_source_no_match($id, $label);
    }

    // Optional product page for price/stock — short timeout; fail soft to matched-without-price.
    $page = retailer_http_get($candidate['url'], [], 3);
    if (!$page['ok'] || $page['status'] >= 400) {
        return retailer_source_result($id, $label, true, null, null, $candidate['url'], 'Matched (product page unavailable)');
    }

    $html = $page['body'];
    $price = null;
    if (preg_match('/itemprop="price"[^>]*content="([^"]+)"/i', $html, $pm)
        || preg_match('/content="([^"]+)"[^>]*itemprop="price"/i', $html, $pm)) {
        $price = retailer_parse_gbp($pm[1]);
    }
    if ($price === null && preg_match('/£\s*(\d+(?:\.\d{1,2})?)/u', $html, $pm)) {
        $price = retailer_parse_gbp($pm[1]);
    }

    $available = null;
    if (preg_match('/out\s*of\s*stock|sold\s*out/i', $html)) $available = false;
    elseif (preg_match('/add-to-cart|add to cart|in stock/i', $html) && !preg_match('/out\s*of\s*stock/i', $html)) {
        $available = true;
    }

    $note = 'Matched (availability unclear — ignored)';
    if ($available === false) $note = 'Out of stock (ignored)';
    elseif ($available === true) $note = 'In stock';

    return retailer_source_result($id, $label, true, $available, $price, $candidate['url'], $note);
}
