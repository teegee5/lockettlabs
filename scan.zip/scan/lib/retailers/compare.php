<?php
declare(strict_types=1);

require_once __DIR__ . '/match.php';
require_once __DIR__ . '/finish.php';
require_once __DIR__ . '/strategy.php';
require_once __DIR__ . '/totalcards.php';
require_once __DIR__ . '/chaos.php';
require_once __DIR__ . '/magicmadhouse.php';
require_once __DIR__ . '/totalcards-set.php';
require_once __DIR__ . '/../price-history.php';

/**
 * Price compare for every catalogue game:
 * - JustTCG market GBP (from selected card)
 * - Total Cards UK retail (Shopify JSON, in-stock only)
 * - Chaos Cards UK retail (HawkSearch API, in-stock only)
 * - Magic Madhouse UK retail (BigCommerce set pages, in-stock only)
 * - Deep links to other UK shops (manual check)
 *
 * Every retail source is passed through a finish gate before its price counts.
 * Card number plus name is not a unique key: the same number exists as a plain
 * card, a holo, a reverse holo and a Master Ball reverse at wildly different
 * prices, so a match on number alone can price a card at a thirtieth of its
 * worth. See lib/retailers/finish.php.
 *
 * @return array{
 *   ok:bool,
 *   number:string,
 *   rarityBand:string,
 *   sources:list<array>,
 *   links:list<array{id:string,label:string,url:string}>,
 *   inStock:list<array{id:string,priceGbp:float,url:string}>,
 *   lowestInStock:?float,
 *   justTcgNm:?float,
 *   suggestedNm:?float,
 *   action:string,
 *   reason:string,
 *   autoFill:bool,
 *   existing:?array
 * }
 */
function competitor_prices_compare(
    string $cardNumber,
    string $game = '',
    string $rarity = '',
    ?float $justTcgNm = null,
    ?float $currentNm = null,
    string $cardName = '',
    string $setName = '',
    string $finish = '',
    array $extra = []
): array {
    // $extra: cardmarketId (exact Total Cards match), providerSet (the
    // catalogue's own set label, tried after the store's), record (write the
    // readings to price history) and label (a readable name for the history).
    $number = retailer_normalize_number($cardNumber);
    $game = strtolower(clean_text($game, 80));
    $rarity = clean_text($rarity, 80);
    $cardName = clean_text($cardName, 120);
    $setName = clean_text($setName, 120);
    $band = competitor_rarity_band($rarity);
    $just = ($justTcgNm !== null && $justTcgNm > 0) ? round($justTcgNm, 2) : null;
    $links = price_compare_uk_links($number, $cardName, $setName);

    if ($number === '') {
        return competitor_prices_empty($number, $band, $just, $links, 'Enter a printed card number.');
    }

    $sources = [];

    // Market (JustTCG) — always surface when the card already has GBP NM.
    if ($just !== null) {
        $sources[] = array_merge(
            retailer_source_result(
                'justtcg',
                'JustTCG market',
                true,
                true,
                $just,
                '',
                'Market · £' . number_format($just, 2)
            ),
            ['market' => true]
        );
    } else {
        $sources[] = array_merge(
            retailer_source_no_match('justtcg', 'JustTCG market', 'No JustTCG NM price on this card'),
            ['market' => true]
        );
    }

    // UK retail — name + number identity, finish-gated, in-stock only for pricing.
    $wantFinish = retailer_intake_finish_token($finish);

    // Open the first connection to each retailer at the same time rather than
    // in turn. Each lookup below is unchanged and still fetches for itself if
    // nothing was primed; this only removes the waiting. Chaos Cards is not
    // here because it reads a local snapshot and has no request to make.
    retailer_http_prime(array_filter([
        totalcards_prime_url($number, $cardName, $setName),
        retailer_madhouse_prime_url($game),
    ]));

    // Total Cards: the whole set page first (exact by Cardmarket id where the
    // SKU carries it, otherwise number, name and finish), the old per-card
    // search only when the set page cannot be found.
    $identity = [
        'name' => $cardName,
        'number' => $number,
        'finish' => $finish,
        'cardmarketId' => (string) ($extra['cardmarketId'] ?? ''),
        'variant' => '',
    ];
    $tc = null;
    foreach (array_unique(array_filter([$setName, clean_text((string) ($extra['providerSet'] ?? ''), 120)])) as $trySet) {
        $tc = retailer_totalcards_set_lookup($identity, $game, (string) preg_replace('/^[A-Z]{1,4}\d*[A-Z]?(?:\.\d+[a-z]?)?:\s*/i', '', $trySet));
        if ($tc !== null) break;
    }
    if ($tc === null) {
        $tc = competitor_apply_finish_gate(
            retailer_totalcards_lookup($number, $game, $cardName, $setName),
            $wantFinish
        );
        $tc['confidence'] = !empty($tc['matched']) ? 'likely' : 'none';
        $tc['evidence'] = !empty($tc['matched']) ? ['Search result', 'Same printed number', 'Same name'] : [];
    }
    // The game picks which snapshot shard is opened. Without it the lookup has
    // to try all six, which is what the single combined file used to cost.
    $chaos = competitor_apply_finish_gate(
        retailer_chaos_lookup($number, $cardName, $setName, $finish, $game),
        $wantFinish
    );
    $madhouse = retailer_magicmadhouse_lookup($number, $cardName, $setName, $game, $finish);

    $sources[] = $tc;
    $sources[] = $chaos;
    $sources[] = $madhouse;

    // Prefer matched product URLs over generic search deep links.
    $links = price_compare_prefer_product_urls($links, [$tc, $chaos, $madhouse]);

    $inStock = [];
    foreach ([$tc, $chaos, $madhouse] as $source) {
        if (!empty($source['matched']) && ($source['available'] ?? null) === true
            && isset($source['priceGbp']) && is_numeric($source['priceGbp']) && (float) $source['priceGbp'] > 0) {
            $inStock[] = [
                'id' => (string) ($source['id'] ?? ''),
                'priceGbp' => round((float) $source['priceGbp'], 2),
                'url' => (string) ($source['url'] ?? ''),
            ];
        }
    }
    usort($inStock, static fn(array $a, array $b): int => $a['priceGbp'] <=> $b['priceGbp']);

    $lowest = $inStock[0]['priceGbp'] ?? null;
    $ukPrices = array_column($inStock, 'priceGbp');
    $suggestion = competitor_suggest_nm($band, $just, $ukPrices, $currentNm);

    $existing = null;
    if ($currentNm !== null && $currentNm > 0) {
        $existing = competitor_compare_existing(
            $currentNm,
            $lowest,
            $suggestion['suggestedNm'],
            $band
        );
    }

    $result = [
        'ok' => true,
        'number' => $number,
        'rarityBand' => $band,
        'sources' => $sources,
        'links' => $links,
        'inStock' => $inStock,
        'lowestInStock' => $lowest,
        'justTcgNm' => $just,
        'suggestedNm' => $suggestion['suggestedNm'],
        'action' => $suggestion['action'],
        'reason' => $suggestion['reason'],
        'autoFill' => (bool) $suggestion['autoFill'],
        'existing' => $existing,
        'position' => competitor_position($currentNm, $inStock),
        'checkedAt' => gmdate('c'),
    ];

    // Write what was seen, then hand back the printing's recent history so the
    // panel can show whether a price is moving or has always been there.
    $key = price_history_key($game, $setName !== '' ? $setName : (string) ($extra['providerSet'] ?? ''), $number, $finish);
    if (!empty($extra['record'])) {
        $readings = price_history_readings_from_compare($result, $currentNm);
        if ($just !== null) $readings['justtcg'] = ['price' => $just, 'available' => null];
        price_history_record($key, clean_text((string) ($extra['label'] ?? ''), 200), $readings);
    }
    $result['history'] = price_history_series($key, 90);
    return $result;
}

/**
 * Where our Near Mint price sits against the in-stock competition.
 *
 * @param list<array{id:string,priceGbp:float}> $inStock sorted cheapest first
 * @return array{state:string,rank:?int,of:int,deltaToLowest:?float,deltaPct:?float}
 */
function competitor_position(?float $ours, array $inStock): array
{
    $of = count($inStock);
    if ($ours === null || $ours <= 0) {
        return ['state' => $of ? 'unpriced' : 'alone', 'rank' => null, 'of' => $of, 'deltaToLowest' => null, 'deltaPct' => null];
    }
    if ($of === 0) {
        return ['state' => 'only', 'rank' => 1, 'of' => 0, 'deltaToLowest' => null, 'deltaPct' => null];
    }
    $lowest = (float) $inStock[0]['priceGbp'];
    $rank = 1;
    foreach ($inStock as $row) if ((float) $row['priceGbp'] < $ours - 0.004) $rank++;
    $delta = round($ours - $lowest, 2);
    $state = abs($delta) < 0.005 ? 'matched' : ($delta < 0 ? 'cheapest' : 'above');
    return [
        'state' => $state,
        'rank' => $rank,
        'of' => $of + 1,
        'deltaToLowest' => $delta,
        'deltaPct' => $lowest > 0 ? round($delta / $lowest * 100, 1) : null,
    ];
}

/**
 * Reject a matched listing whose printing does not match the card being taken in.
 *
 * A retailer lookup matches on card number and name, which is not enough: the
 * same number exists as a plain card, a holo, a reverse holo and a Master Ball
 * reverse. Pricing a Master Ball reverse against a plain reverse understates it
 * by roughly thirty times. The match is kept visible so staff can see what was
 * found, but it stops counting towards the suggested price.
 *
 * When the caller supplies no finish, nothing is gated and behaviour is
 * unchanged.
 *
 * @param array $source
 * @return array
 */
function competitor_apply_finish_gate(array $source, string $wantFinish): array
{
    if ($wantFinish === '' || empty($source['matched'])) {
        return $source;
    }

    $title = (string) ($source['title'] ?? '');
    if ($title === '') {
        return $source;
    }

    $found = retailer_title_finish_token($title);
    if (retailer_base_printing_compatible($wantFinish, $found)) {
        return $source;
    }

    $source['matched'] = false;
    $source['available'] = null;
    $source['priceGbp'] = null;
    if (array_key_exists('priceGbpRaw', $source)) {
        $source['priceGbpRaw'] = null;
    }
    $source['note'] = sprintf(
        'Different printing (%s, not %s) — ignored',
        competitor_finish_label($found),
        competitor_finish_label($wantFinish)
    );
    return $source;
}

/** Human wording for a finish token, for staff-facing notes. */
function competitor_finish_label(string $token): string
{
    return match ($token) {
        'normal' => 'plain',
        'holo' => 'holo',
        'foil' => 'foil',
        'reverse' => 'reverse holo',
        'nonholo' => 'non-holo',
        'masterball' => 'Master Ball',
        'masterball-reverse' => 'Master Ball reverse',
        'pokeball' => 'Poke Ball',
        'pokeball-reverse' => 'Poke Ball reverse',
        'ball-reverse' => 'Ball reverse',
        'energy-reverse' => 'Energy reverse',
        'rocket-reverse' => 'Rocket reverse',
        'snowflake' => 'Snowflake stamp',
        'stamped' => 'stamped',
        'artcard' => 'art card',
        'cosmos' => 'cosmos holo',
        'cosmos-reverse' => 'cosmos reverse',
        'fullart' => 'full art',
        'halfart' => 'half art',
        'sealed' => 'sealed',
        default => $token,
    };
}

/**
 * Manual UK shop search links (no scrape). Uses name+number when known.
 *
 * @return list<array{id:string,label:string,url:string}>
 */
function price_compare_uk_links(string $number, string $cardName = '', string $setName = ''): array
{
    $keyword = retailer_search_keyword($number, $cardName, $setName);
    if ($keyword === '') {
        $keyword = 'trading card';
    }
    $q = rawurlencode($keyword);

    return [
        [
            'id' => 'totalcards',
            'label' => 'Total Cards',
            'url' => 'https://totalcards.net/search?q=' . $q . '&type=product',
        ],
        [
            'id' => 'chaoscards',
            'label' => 'Chaos Cards',
            'url' => retailer_chaos_search_url($number, $cardName),
        ],
        [
            'id' => 'magicmadhouse',
            'label' => 'Magic Madhouse',
            'url' => 'https://magicmadhouse.co.uk/search.php?search_query=' . $q,
        ],
        [
            'id' => 'hillscards',
            'label' => 'Hills Cards',
            'url' => 'https://www.hillscards.co.uk/search/?q=' . $q,
        ],
        [
            'id' => 'unicorn',
            'label' => 'Unicorn Cards',
            'url' => 'https://unicorncards.co.uk/search?q=' . $q,
        ],
    ];
}

/**
 * Replace search deep links with matched product URLs when available.
 *
 * @param list<array{id:string,label:string,url:string}> $links
 * @param list<array> $sources
 * @return list<array{id:string,label:string,url:string}>
 */
function price_compare_prefer_product_urls(array $links, array $sources): array
{
    $byId = [];
    foreach ($sources as $source) {
        if (!is_array($source)) continue;
        $id = (string) ($source['id'] ?? '');
        $url = trim((string) ($source['url'] ?? ''));
        if ($id === '' || $url === '' || empty($source['matched'])) continue;
        // Keep generic /search/ URLs as search links; prefer real product pages.
        if (preg_match('#/search(/|\?|$)#i', $url)) continue;
        $byId[$id] = $url;
    }
    if ($byId === []) {
        return $links;
    }
    foreach ($links as &$link) {
        $id = (string) ($link['id'] ?? '');
        if ($id !== '' && isset($byId[$id])) {
            $link['url'] = $byId[$id];
        }
    }
    unset($link);
    return $links;
}

/**
 * @param list<array{id:string,label:string,url:string}> $links
 * @return array{ok:bool,number:string,rarityBand:string,sources:list,links:list,inStock:list,lowestInStock:null,justTcgNm:?float,suggestedNm:null,action:string,reason:string,autoFill:bool,existing:null}
 */
function competitor_prices_empty(string $number, string $band, ?float $justTcgNm, array $links, string $reason): array
{
    $sources = [];
    if ($justTcgNm !== null && $justTcgNm > 0) {
        $sources[] = array_merge(
            retailer_source_result(
                'justtcg',
                'JustTCG market',
                true,
                true,
                round($justTcgNm, 2),
                '',
                'Market · £' . number_format($justTcgNm, 2)
            ),
            ['market' => true]
        );
    } else {
        $sources[] = array_merge(
            retailer_source_no_match('justtcg', 'JustTCG market', 'No JustTCG NM price on this card'),
            ['market' => true]
        );
    }
    $sources[] = retailer_source_no_match('totalcards', 'Total Cards', $reason);
    $sources[] = retailer_source_no_match('chaoscards', 'Chaos Cards', $reason);
    $sources[] = retailer_source_no_match('magicmadhouse', 'Magic Madhouse', $reason);

    return [
        'ok' => true,
        'number' => $number,
        'rarityBand' => $band,
        'sources' => $sources,
        'links' => $links,
        'inStock' => [],
        'lowestInStock' => null,
        'justTcgNm' => ($justTcgNm !== null && $justTcgNm > 0) ? round($justTcgNm, 2) : null,
        'suggestedNm' => null,
        'action' => 'hold',
        'reason' => $reason,
        'autoFill' => false,
        'existing' => null,
    ];
}
