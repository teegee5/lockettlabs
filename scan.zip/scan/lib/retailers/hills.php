<?php
declare(strict_types=1);

require_once __DIR__ . '/match.php';
require_once __DIR__ . '/http.php';

/**
 * Hills Cards (Visualsoft) — best-effort search HTML; fail soft.
 */
function retailer_hills_lookup(string $cardNumber): array
{
    $number = retailer_normalize_number($cardNumber);
    if ($number === '') return retailer_source_no_match('hills', 'Hills Cards');
    $cacheKey = 'hills:v1:' . $number;
    $cached = retailer_cache_get($cacheKey);
    if ($cached !== null) return $cached;

    $url = 'https://www.hillscards.co.uk/search/' . rawurlencode(strtolower($number));
    $result = retailer_hills_from_response($number, retailer_http_get($url));
    retailer_cache_set($cacheKey, $result);
    return $result;
}

/**
 * @param array{ok:bool,status:int,body:string,error:string} $response
 */
function retailer_hills_from_response(string $number, array $response): array
{
    $id = 'hills';
    $label = 'Hills Cards';
    $number = retailer_normalize_number($number);

    if (!$response['ok'] || in_array($response['status'], [403, 429], true) || $response['status'] >= 500) {
        return retailer_source_blocked($id, $label, 'Blocked');
    }
    if ($response['status'] >= 400 || $response['body'] === '') {
        return retailer_source_blocked($id, $label, 'Blocked');
    }

    $html = $response['body'];
    if (!retailer_text_contains_exact_number($html, $number)) {
        return retailer_source_no_match($id, $label);
    }

    $best = null;
    if (preg_match_all('/<(?:a|div|li|article)[^>]+>([\s\S]{0,1200}?OP\d{1,3}-\d{2,4}[A-Za-z]?[\s\S]{0,800}?)<\/(?:a|div|li|article)>/i', $html, $blocks, PREG_SET_ORDER)) {
        foreach ($blocks as $block) {
            $chunk = $block[0];
            if (!retailer_text_contains_exact_number($chunk, $number)) continue;
            $title = trim(html_entity_decode(strip_tags($chunk), ENT_QUOTES | ENT_HTML5));
            $title = preg_replace('/\s+/', ' ', $title) ?? $title;
            if (!retailer_text_contains_exact_number($title, $number)) continue;

            $price = null;
            if (preg_match('/£\s*(\d+(?:\.\d{1,2})?)/u', $chunk, $pm)) {
                $price = retailer_parse_gbp($pm[1]);
            }
            $oos = (bool) preg_match('/out[\s-]*of[\s-]*stock|sold[\s-]*out|product-out-of-stock/i', $chunk);
            $instock = (bool) preg_match('/\bin[\s-]*stock\b|add[\s-]*to[\s-]*basket|add[\s-]*to[\s-]*cart/i', $chunk);
            $available = $oos ? false : ($instock ? true : null);
            $href = '';
            if (preg_match('/href="([^"]+)"/i', $chunk, $hm)) {
                $href = html_entity_decode($hm[1], ENT_QUOTES | ENT_HTML5);
                if ($href !== '' && !preg_match('#^https?://#i', $href)) {
                    $href = 'https://www.hillscards.co.uk' . (str_starts_with($href, '/') ? $href : '/' . $href);
                }
            }
            $best = retailer_source_result(
                $id,
                $label,
                true,
                $available,
                $price,
                $href,
                $available === false ? 'Out of stock (ignored)' : ($available === true ? 'In stock' : 'Matched (availability unclear — ignored)')
            );
            if ($available === true && $price !== null) break;
        }
    }

    return $best ?? retailer_source_no_match($id, $label);
}
