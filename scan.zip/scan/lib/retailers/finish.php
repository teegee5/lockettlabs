<?php
declare(strict_types=1);

/**
 * Finish and printing-variant discrimination for retailer matching.
 *
 * Card number plus name is not a unique key. The same Pokemon, same number and
 * same set exists as a plain card, a holo, a reverse holo, a Poke Ball reverse,
 * a Master Ball reverse and more, at wildly different prices. Matching on
 * number+name alone will happily price a Master Ball reverse against a plain
 * reverse worth a thirtieth as much.
 *
 * These rules were derived from real mis-matches found while building the
 * catalogue-wide price sweep. Each guard below exists because it produced a
 * confident, plausible-looking, completely wrong price:
 *
 *   1. "Masterball Reverse Holo" collapsing into plain "reverse"
 *      (GBP 5.95 card matched a GBP 0.19 one) because the generic /reverse/
 *      test ran before the specific one. Specific patterns are tested first.
 *
 *   2. "Non-Holo" classifying as "Holo", because "non-holo" contains "holo".
 *      Tested before the generic holo rule.
 *
 *   3. Reprint subsets reusing the original card's collector number, so a
 *      Celebrations 15/102 matched a Base Set 15/102 worth three times more.
 *      Those subsets get their own variant token.
 *
 *   4. A relaxed "ignore the finish" fallback quietly undoing guard 1. Relaxed
 *      matching is only ever allowed for ordinary finishes.
 */

/**
 * Finishes where ignoring the finish would match cards of very different value.
 *
 * The ball-pattern and stamped entries come from the store's own catalogue:
 * "Ball Reverse holo" (105 products), "Energy Reverse holo" (100),
 * "Rocket Reverse holo" (8), "Snowflake Stamp" (32), "Art card" (23) and
 * "Stamped" (3) are all distinct treatments. Without them the first three
 * collapse into plain reverse and the last three into a plain card.
 */
const RETAILER_RARITY_FINISHES = [
    'masterball', 'masterball-reverse',
    'pokeball', 'pokeball-reverse',
    'ball-reverse', 'energy-reverse', 'rocket-reverse',
    'cosmos', 'cosmos-reverse',
    'snowflake', 'stamped', 'artcard',
    'fullart', 'halfart', 'nonholo', 'sealed',
];

/**
 * Reduce any finish wording to a strict token.
 *
 * Accepts either a bare finish ("Reverse Holo") or a whole listing title
 * ("Litleo : PRISMATIC EVOLUTIONS (Masterball Reverse holo) - 009/131").
 * Unrecognised wording gets its own token rather than collapsing into
 * "normal", so an unknown treatment can never silently match a plain card.
 */
function retailer_finish_token(string $text): string
{
    $t = strtolower(trim($text));
    if ($t === '') return 'normal';
    $t = preg_replace('/[^a-z0-9]+/', ' ', $t) ?? $t;
    $t = trim(preg_replace('/\s+/', ' ', $t) ?? $t);
    if ($t === '') return 'normal';

    $reverse = str_contains($t, 'reverse');

    // Order matters. See guards 1 and 2 above.
    if (preg_match('/\bsealed\b/', $t))                 return 'sealed';
    if (preg_match('/\bnon ?holo\b/', $t))              return 'nonholo';
    if (preg_match('/\bart card\b/', $t))               return 'artcard';
    if (preg_match('/\bsnowflake\b/', $t))              return 'snowflake';
    if (preg_match('/\bmaster ?ball\b/', $t))           return $reverse ? 'masterball-reverse' : 'masterball';
    if (preg_match('/\bpoke ?ball\b/', $t))             return $reverse ? 'pokeball-reverse' : 'pokeball';
    // The store also writes bare "Ball", "Energy" and "Rocket" reverse holos.
    // These are pattern cards, not plain reverses, and must not collapse.
    if (preg_match('/\benergy\b/', $t) && $reverse)     return 'energy-reverse';
    if (preg_match('/\brocket\b/', $t) && $reverse)     return 'rocket-reverse';
    if (preg_match('/\bball\b/', $t) && $reverse)       return 'ball-reverse';
    // Total Cards spells it "Cosmo Holo".
    if (preg_match('/\bcosmos?\b/', $t))                return $reverse ? 'cosmos-reverse' : 'cosmos';
    if (preg_match('/\bstamped\b/', $t))                return 'stamped';
    if (preg_match('/\b(full art|alt(ernate|ernative)? art|special art|illustration rare)\b/', $t)) return 'fullart';
    if (preg_match('/\bhalf art\b/', $t))               return 'halfart';
    if ($reverse)                                       return 'reverse';
    if (preg_match('/\bfoil\b/', $t))                   return 'foil';
    if (preg_match('/\bholo(graphic|foil)?\b/', $t))    return 'holo';
    if (preg_match('/\b(standard|normal|regular|non foil)\b/', $t)) return 'normal';

    return 'normal';
}

/**
 * The finish token for a listing title, considering only parenthesised
 * treatments. A title with no parenthetical is a plain card.
 *
 * "Armarouge : PITCH BLACK (Reverse holo) - 012/084" -> reverse
 * "Armarouge : PITCH BLACK - 012/084"                -> normal
 */
function retailer_title_finish_token(string $title): string
{
    if (preg_match_all('/\(([^)]*)\)/', $title, $matches) && $matches[1] !== []) {
        return retailer_finish_token(implode(' ', $matches[1]));
    }
    // Some retailers put the treatment inline rather than in brackets.
    if (preg_match('/\b(master ?ball|poke ?ball|cosmos?|reverse\s+holo|non[\s-]?holo|full art|half art)\b/i', $title, $inline)) {
        return retailer_finish_token($inline[1]);
    }
    return 'normal';
}

/**
 * Printing variants that reuse the base set's collector numbering.
 * Without this, a promo or a reprint subset matches the ordinary card.
 */
function retailer_variant_token(string $text): string
{
    $t = strtolower(trim($text));
    $t = preg_replace('/[^a-z0-9]+/', ' ', $t) ?? $t;
    $t = trim(preg_replace('/\s+/', ' ', $t) ?? $t);
    if ($t === '') return 'base';

    if (preg_match('/\b(celebrations?|classic collection)\b/', $t)) return 'celebrations';
    if (preg_match('/\bshiny vault\b/', $t))                        return 'shinyvault';
    if (preg_match('/\b(trainer|galarian) gallery\b/', $t))         return 'gallery';
    if (preg_match('/\bpre ?release\b/', $t))                       return 'prerelease';
    if (preg_match('/\bstaff\b/', $t))                              return 'staff';
    if (preg_match('/\bworld championships?\b/', $t))               return 'champs';
    if (preg_match('/\b(jumbo|oversized)\b/', $t))                  return 'jumbo';
    if (preg_match('/\b(promo|alternate art promo)\b/', $t))        return 'promo';
    if (preg_match('/\b(league|prize pack)\b/', $t))                return 'league';

    return 'base';
}

/** True when this finish must match exactly and can never be matched loosely. */
function retailer_finish_is_rarity(string $token): bool
{
    return in_array($token, RETAILER_RARITY_FINISHES, true);
}

/**
 * Map the app's own finish vocabulary onto tokens.
 * The intake form offers Standard / Holo / Reverse Holo / Foil.
 */
function retailer_intake_finish_token(string $finish): string
{
    $finish = trim($finish);
    if ($finish === '') return '';   // caller did not say; do not constrain
    return retailer_finish_token($finish);
}

/**
 * Can a listing with $found finish be used to price an intake of $wanted?
 *
 * Empty $wanted means the caller did not supply a finish, so no constraint is
 * applied and behaviour is unchanged from before finish awareness existed.
 */
function retailer_finish_compatible(string $wanted, string $found): bool
{
    if ($wanted === '') return true;
    if ($wanted === $found) return true;

    // A rarity-bearing finish on either side must match exactly.
    if (retailer_finish_is_rarity($wanted) || retailer_finish_is_rarity($found)) {
        return false;
    }

    // Foil-only games label their foil printing inconsistently across shops:
    // One Piece "Foil" is the same card a rival lists as "Holo".
    $foilish = ['foil', 'holo'];
    if (in_array($wanted, $foilish, true) && in_array($found, $foilish, true)) {
        return true;
    }

    // A plain card and a holo of the same number are different products, and
    // "normal" is our fallback for silence, so treat the pair as usable only
    // when the intake itself is plain and the listing says nothing either.
    return false;
}

/**
 * Same as retailer_finish_compatible(), but treating the base printing as one
 * product whatever a shop calls it.
 *
 * Total Cards and Chaos Cards write nothing after a holo rare ("Lurantis ex -
 * 004/084") while this store writes "(Holo)". Within a modern set a printed
 * number is either a holo or a plain card, never both, so for the base print
 * "holo", "foil" and "normal" all describe the same card. Reverse, ball,
 * cosmos and non-holo printings stay strict: those really are different cards
 * at different prices.
 */
function retailer_base_printing_compatible(string $wanted, string $found): bool
{
    if ($wanted === '') return true;
    $base = ['normal', 'holo', 'foil'];
    if (in_array($wanted, $base, true) && in_array($found, $base, true)) return true;
    return retailer_finish_compatible($wanted, $found);
}

/**
 * Guard against reprint/promo collisions.
 * Empty $wanted applies no constraint.
 */
function retailer_variant_compatible(string $wanted, string $found): bool
{
    if ($wanted === '') return true;
    return $wanted === $found;
}
