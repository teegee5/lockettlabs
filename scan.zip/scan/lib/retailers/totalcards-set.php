<?php
declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/http.php';
require_once __DIR__ . '/match.php';
require_once __DIR__ . '/finish.php';

/**
 * Total Cards, a whole set at a time.
 *
 * The old lookup searched once per card and then fetched each candidate's
 * product JSON, which carries no stock flag, so it fetched a .js file as well.
 * Total Cards is a Shopify store, and every set is a collection whose
 * products.json lists all items in pages of 250 with each variant's price and
 * "available" flag. A whole set is two or three requests, cached, and every
 * card after the first in a set is answered from memory.
 *
 * Their titles read "Pokemon - Mega Evolution - Pitch Black - Tropius -
 * 001/084 (Reverse Holo)". Newer sets carry the Cardmarket product id in the
 * SKU (POK-PBL-001-895789-RH), which TCGdex also gives us: when both are
 * known the match is exact and needs no name comparison at all. Older sets
 * sell graded copies as variants (MT, NM, EX, GD, LP, PL, PO); only the NM
 * variant is compared with our Near Mint.
 */

const TOTALCARDS_ORIGIN = 'https://totalcards.net';
const TOTALCARDS_SET_TTL = 1800;       // prices: 30 minutes
const TOTALCARDS_INDEX_TTL = 86400;    // which collection is which set: a day
const TOTALCARDS_MAX_PAGES = 6;

/** Words that every Total Cards collection title shares and that prove nothing. */
const TOTALCARDS_NOISE = ['pokemon', 'pokémon', 'tcg', 'mega', 'evolution', 'scarlet', 'violet', 'sword', 'shield', 'sun', 'moon', 'singles', 'single', 'cards', 'the', 'and', 'of'];

/**
 * Find the collection handle for a set. Prefers a collection whose title ends
 * with the set name, so "Pitch Black" picks "Pokemon - Mega Evolution - Pitch
 * Black" over a themed collection that merely mentions it.
 */
function totalcards_collection_for_set(string $game, string $setName): string
{
    $setName = trim($setName);
    if ($setName === '') return '';
    $cacheKey = 'retailer:tc:collection:v1:' . strtolower($game . '|' . $setName);
    $cached = cache_read_json($cacheKey, TOTALCARDS_INDEX_TTL);
    if (is_array($cached) && array_key_exists('handle', $cached)) return (string) $cached['handle'];

    $handle = '';
    $url = TOTALCARDS_ORIGIN . '/search/suggest.json?q=' . rawurlencode($setName) . '&resources%5Btype%5D=collection&resources%5Blimit%5D=10';
    $response = retailer_http_json($url, [], 6);
    if ($response['ok']) {
        $wanted = retailer_name_tokens($setName);
        $best = -1;
        foreach (($response['json']['resources']['results']['collections'] ?? []) as $collection) {
            if (!is_array($collection) || empty($collection['handle'])) continue;
            $title = (string) ($collection['title'] ?? '');
            $last = trim((string) preg_replace('/^.*\s-\s/', '', $title));
            $score = 0;
            if (retailer_normalize_match_text($last) === retailer_normalize_match_text($setName)) $score += 100;
            $have = retailer_name_tokens($title);
            foreach ($wanted as $token) if (in_array($token, $have, true)) $score += 10;
            if (preg_match('/\b(sealed|booster|deck|promo|graded|slab)\b/i', $title)) $score -= 40;
            if (str_contains(strtolower($game), 'pokemon') && !preg_match('/pok[eé]mon/i', $title)) $score -= 30;
            if ($score > $best) { $best = $score; $handle = (string) $collection['handle']; }
        }
        if ($best < 20) $handle = '';
    }
    cache_write_json($cacheKey, ['handle' => $handle]);
    return $handle;
}

/**
 * Parse a Total Cards title into name, printed number, finish and variant.
 *
 * @return array{name:string,number:string,finish:string,variant:string,single:bool}
 */
function totalcards_parse_title(string $title): array
{
    $parts = array_map('trim', explode(' - ', $title));
    $number = '';
    $name = '';
    foreach ($parts as $i => $part) {
        $bare = trim((string) preg_replace('/\([^)]*\)/', '', $part));
        if (preg_match('/^[A-Z]*\d{1,4}[a-z]?\/[A-Z]*\d{1,4}$/i', $bare) || preg_match('/^[A-Z]{1,6}\d{0,3}-[A-Z]?\d{2,4}$/i', $bare) || preg_match('/^(SWSH|SVP|SM|XY|BW|MEP)\d{2,3}$/i', $bare)) {
            $number = $bare;
            $name = $i > 0 ? (string) preg_replace('/\s*\([^)]*\)\s*$/', '', $parts[$i - 1]) : '';
            break;
        }
    }
    return [
        'name' => $name,
        'number' => $number,
        'finish' => retailer_title_finish_token($title),
        'variant' => retailer_variant_token($title),
        'single' => $number !== '',
    ];
}

/**
 * Every product in a collection, parsed. Cached for half an hour.
 *
 * @return list<array{title:string,url:string,sku:string,name:string,number:string,finish:string,variant:string,nm:?array,any:?array}>
 */
function totalcards_collection_rows(string $handle): array
{
    if ($handle === '' || !preg_match('/^[a-z0-9][a-z0-9\-]*$/i', $handle)) return [];
    $cacheKey = 'retailer:tc:rows:v1:' . $handle;
    $cached = cache_read_json($cacheKey, TOTALCARDS_SET_TTL);
    if (is_array($cached) && isset($cached['rows'])) return $cached['rows'];

    $rows = [];
    $complete = true;
    for ($page = 1; $page <= TOTALCARDS_MAX_PAGES; $page++) {
        $url = TOTALCARDS_ORIGIN . '/collections/' . rawurlencode($handle) . '/products.json?limit=250&page=' . $page;
        $response = retailer_http_json($url, [], 8);
        if (!$response['ok']) { $complete = false; break; }
        $products = $response['json']['products'] ?? [];
        if (!is_array($products) || $products === []) break;
        foreach ($products as $product) {
            if (!is_array($product)) continue;
            $row = totalcards_row($product);
            if ($row !== null) $rows[] = $row;
        }
        if (count($products) < 250) break;
    }
    // A half-read set is not cached: one dropped page must not hide its cards for half an hour.
    if ($complete) cache_write_json($cacheKey, ['rows' => $rows, 'at' => time()]);
    return $rows;
}

function totalcards_row(array $product): ?array
{
    $title = clean_text($product['title'] ?? '', 300);
    if ($title === '') return null;
    $parsed = totalcards_parse_title($title);
    if (!$parsed['single']) return null;
    $variants = is_array($product['variants'] ?? null) ? $product['variants'] : [];
    $nm = null;
    $any = null;
    $sku = '';
    foreach ($variants as $variant) {
        if (!is_array($variant)) continue;
        $label = strtoupper(trim((string) ($variant['title'] ?? $variant['option1'] ?? '')));
        $entry = [
            'condition' => $label,
            'price' => retailer_parse_gbp($variant['price'] ?? null),
            'available' => array_key_exists('available', $variant) ? (bool) $variant['available'] : null,
        ];
        if ($sku === '') $sku = clean_text($variant['sku'] ?? '', 80);
        if ($label === 'DEFAULT TITLE' || $label === 'NM' || $label === 'NEAR MINT') $nm = $entry;
        if ($any === null || ($entry['available'] && !$any['available'])) $any = $entry;
    }
    return [
        'title' => $title,
        'url' => TOTALCARDS_ORIGIN . '/products/' . rawurlencode((string) ($product['handle'] ?? '')),
        'sku' => $sku,
        'name' => $parsed['name'],
        'number' => $parsed['number'],
        'finish' => $parsed['finish'],
        'variant' => $parsed['variant'],
        'nm' => $nm,
        'any' => $any,
    ];
}

/**
 * Pick the listing for one card out of a set's rows.
 *
 * @param array{name:string,number:string,finish:string,cardmarketId?:string} $card
 * @return array{row:?array,confidence:string,evidence:list<string>}
 */
function totalcards_pick(array $rows, array $card): array
{
    $want = retailer_intake_finish_token((string) ($card['finish'] ?? ''));
    $cm = preg_replace('/\D+/', '', (string) ($card['cardmarketId'] ?? '')) ?? '';
    if ($cm !== '') {
        foreach ($rows as $row) {
            if ($row['sku'] !== '' && preg_match('/-' . preg_quote($cm, '/') . '(?:-|$)/', $row['sku'])) {
                if (!retailer_base_printing_compatible($want === '' ? 'normal' : $want, $row['finish'])) continue;
                return ['row' => $row, 'confidence' => 'exact', 'evidence' => ['Cardmarket id in SKU', 'Same printing']];
            }
        }
    }
    $best = null;
    $bestScore = -1;
    foreach ($rows as $row) {
        if (!retailer_title_matches_number($row['number'], (string) $card['number']) && !retailer_text_contains_exact_number($row['number'], (string) $card['number'])) continue;
        $nameScore = retailer_name_score($row['name'] !== '' ? $row['name'] : $row['title'], (string) $card['name']);
        if ($nameScore < 60) continue;
        if (!retailer_base_printing_compatible($want === '' ? 'normal' : $want, $row['finish'])) continue;
        if (!retailer_variant_compatible((string) ($card['variant'] ?? ''), $row['variant'])) continue;
        $score = $nameScore + ($row['nm'] && $row['nm']['available'] ? 5 : 0);
        if ($score > $bestScore) { $bestScore = $score; $best = $row; }
    }
    if ($best === null) return ['row' => null, 'confidence' => 'none', 'evidence' => []];
    return [
        'row' => $best,
        'confidence' => $bestScore >= 100 ? 'strong' : 'likely',
        'evidence' => array_values(array_filter([
            'Same printed number',
            $bestScore >= 100 ? 'Same name' : 'Close name',
            'Same finish',
            'Same set page',
        ])),
    ];
}

/**
 * Total Cards for one card, from its set page. Returns null when the set's
 * collection cannot be found, so the caller can fall back to search.
 */
function retailer_totalcards_set_lookup(array $card, string $game, string $setName): ?array
{
    $handle = totalcards_collection_for_set($game, $setName);
    if ($handle === '') return null;
    $rows = totalcards_collection_rows($handle);
    if ($rows === []) return null;
    $pick = totalcards_pick($rows, $card);
    $base = retailer_source_result('totalcards', 'Total Cards', false, null, null, TOTALCARDS_ORIGIN . '/collections/' . $handle, 'Not stocked in this printing');
    $base['setUrl'] = TOTALCARDS_ORIGIN . '/collections/' . $handle;
    if ($pick['row'] === null) return $base;
    $row = $pick['row'];
    $nm = $row['nm'] ?? $row['any'];
    $available = $nm['available'] ?? null;
    $result = retailer_source_result(
        'totalcards',
        'Total Cards',
        true,
        $available,
        $nm['price'] ?? null,
        $row['url'],
        $available === true ? 'In stock' : ($available === false ? 'Out of stock' : 'Availability unknown')
    );
    $result['title'] = $row['title'];
    $result['condition'] = ($nm['condition'] ?? '') === 'DEFAULT TITLE' ? 'NM' : ($nm['condition'] ?? '');
    $result['confidence'] = $pick['confidence'];
    $result['evidence'] = $pick['evidence'];
    $result['finishFound'] = $row['finish'];
    return $result;
}
