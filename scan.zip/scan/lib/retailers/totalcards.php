<?php
declare(strict_types=1);

require_once __DIR__ . '/../totalcards.php';
require_once __DIR__ . '/match.php';

/**
 * Total Cards adapter — only in-stock (available === true) prices count for compare.
 * Requires card name when provided so number-only collisions are rejected.
 *
 * @return array{id:string,label:string,matched:bool,available:?bool,priceGbp:?float,url:string,note:string,priceGbpRaw:?float,title:string,rarity:string}
 */
function retailer_totalcards_lookup(string $cardNumber, string $game = '', string $cardName = '', string $setName = ''): array
{
    $base = [
        'id' => 'totalcards',
        'label' => 'Total Cards',
        'matched' => false,
        'available' => null,
        'priceGbp' => null,
        'priceGbpRaw' => null,
        'url' => '',
        'note' => 'No match',
        'title' => '',
        'rarity' => '',
    ];

    try {
        $result = totalcards_lookup($cardNumber, $game, $cardName, $setName);
    } catch (Throwable $error) {
        return array_merge($base, [
            'note' => 'Blocked: ' . clean_text($error->getMessage(), 120),
        ]);
    }

    if (!empty($result['error']) && empty($result['matched'])) {
        return array_merge($base, ['note' => clean_text((string) $result['error'], 120) ?: 'No match']);
    }

    if (empty($result['matched'])) {
        $note = 'No match';
        if ($cardName !== '') {
            $note = 'No match for name + number';
        }
        return array_merge($base, ['note' => $note]);
    }

    $available = array_key_exists('available', $result) ? $result['available'] : null;
    $raw = isset($result['priceGbpRaw']) && is_numeric($result['priceGbpRaw'])
        ? round((float) $result['priceGbpRaw'], 2)
        : null;
    $price = $raw;
    if ($price === null && isset($result['priceGbp']) && is_numeric($result['priceGbp'])) {
        $price = round((float) $result['priceGbp'], 2);
    }

    if ($available === false) {
        return array_merge($base, [
            'matched' => true,
            'available' => false,
            'priceGbp' => $price,
            'priceGbpRaw' => $raw,
            'url' => (string) ($result['url'] ?? ''),
            'note' => 'Out of stock (ignored)',
            'title' => (string) ($result['title'] ?? ''),
            'rarity' => (string) ($result['rarity'] ?? ''),
        ]);
    }

    if ($available !== true) {
        return array_merge($base, [
            'matched' => true,
            'available' => $available,
            'priceGbp' => $price,
            'priceGbpRaw' => $raw,
            'url' => (string) ($result['url'] ?? ''),
            'note' => 'Availability unknown (ignored for pricing)',
            'title' => (string) ($result['title'] ?? ''),
            'rarity' => (string) ($result['rarity'] ?? ''),
        ]);
    }

    if ($price === null || $price <= 0) {
        return array_merge($base, [
            'matched' => true,
            'available' => true,
            'url' => (string) ($result['url'] ?? ''),
            'note' => 'Matched in stock but no usable price',
            'title' => (string) ($result['title'] ?? ''),
            'rarity' => (string) ($result['rarity'] ?? ''),
        ]);
    }

    return array_merge($base, [
        'matched' => true,
        'available' => true,
        'priceGbp' => $price,
        'priceGbpRaw' => $raw,
        'url' => (string) ($result['url'] ?? ''),
        'note' => 'In stock',
        'title' => (string) ($result['title'] ?? ''),
        'rarity' => (string) ($result['rarity'] ?? ''),
    ]);
}
