<?php
declare(strict_types=1);

const RETAILER_HTTP_TIMEOUT = 4;
const RETAILER_CACHE_TTL = 720; // 12 minutes

/**
 * @return array{ok:bool,status:int,body:string,error:string}
 */
function retailer_http_get(string $url, array $headers = [], int $timeout = RETAILER_HTTP_TIMEOUT): array
{
    $primed = http_primed_take($url);
    if ($primed !== null) {
        return ['ok' => true, 'status' => 200, 'body' => $primed, 'error' => ''];
    }

    if (!function_exists('curl_init')) {
        return ['ok' => false, 'status' => 0, 'body' => '', 'error' => 'cURL missing'];
    }

    $defaultHeaders = [
        'Accept: text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
        'Accept-Language: en-GB,en;q=0.9',
    ];
    $ua = (string) (app_config()['app_contact'] ?? 'TCG Card Scanner');

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 4,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CONNECTTIMEOUT => 2,
        CURLOPT_HTTPHEADER => array_merge($defaultHeaders, $headers),
        CURLOPT_USERAGENT => $ua,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_ENCODING => '',
    ]);
    $body = curl_exec($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($body === false || $error !== '') {
        return ['ok' => false, 'status' => $status, 'body' => '', 'error' => $error ?: 'Request failed'];
    }
    return ['ok' => true, 'status' => $status, 'body' => (string) $body, 'error' => ''];
}

/**
 * @return array{ok:bool,status:int,json:?array,body:string,error:string}
 */
function retailer_http_json(string $url, array $headers = [], int $timeout = RETAILER_HTTP_TIMEOUT): array
{
    $response = retailer_http_get($url, array_merge(['Accept: application/json'], $headers), $timeout);
    if (!$response['ok']) {
        return ['ok' => false, 'status' => $response['status'], 'json' => null, 'body' => '', 'error' => $response['error']];
    }
    if ($response['status'] >= 400) {
        return ['ok' => false, 'status' => $response['status'], 'json' => null, 'body' => $response['body'], 'error' => "HTTP {$response['status']}"];
    }
    $json = json_decode($response['body'], true);
    if (!is_array($json)) {
        return ['ok' => false, 'status' => $response['status'], 'json' => null, 'body' => $response['body'], 'error' => 'Invalid JSON'];
    }
    return ['ok' => true, 'status' => $response['status'], 'json' => $json, 'body' => $response['body'], 'error' => ''];
}

/**
 * POST JSON body; return decoded JSON on success.
 *
 * @return array{ok:bool,status:int,json:?array,body:string,error:string}
 */
function retailer_http_post_json(string $url, array $payload, array $headers = [], int $timeout = RETAILER_HTTP_TIMEOUT): array
{
    if (!function_exists('curl_init')) {
        return ['ok' => false, 'status' => 0, 'json' => null, 'body' => '', 'error' => 'cURL missing'];
    }

    $ua = (string) (app_config()['app_contact'] ?? 'TCG Card Scanner');
    $body = json_encode($payload, JSON_UNESCAPED_SLASHES);
    if ($body === false) {
        return ['ok' => false, 'status' => 0, 'json' => null, 'body' => '', 'error' => 'JSON encode failed'];
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_HTTPHEADER => array_merge([
            'Accept: application/json',
            'Content-Type: application/json',
            'Accept-Language: en-GB,en;q=0.9',
        ], $headers),
        CURLOPT_USERAGENT => $ua,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_ENCODING => '',
    ]);
    $raw = curl_exec($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($raw === false || $error !== '') {
        return ['ok' => false, 'status' => $status, 'json' => null, 'body' => '', 'error' => $error ?: 'Request failed'];
    }
    if ($status >= 400) {
        return ['ok' => false, 'status' => $status, 'json' => null, 'body' => (string) $raw, 'error' => "HTTP {$status}"];
    }
    $json = json_decode((string) $raw, true);
    if (!is_array($json)) {
        return ['ok' => false, 'status' => $status, 'json' => null, 'body' => (string) $raw, 'error' => 'Invalid JSON'];
    }
    return ['ok' => true, 'status' => $status, 'json' => $json, 'body' => (string) $raw, 'error' => ''];
}

/**
 * Fetch several URLs at once so the lookups that need them do not have to wait
 * in turn.
 *
 * This replaces a retailer_run_parallel() that looped over callbacks one at a
 * time behind a name that promised otherwise, and which nothing ever called.
 *
 * Each retailer's first request is predictable, so those are fetched together
 * here and parked for http_json() and retailer_http_get() to pick up. The
 * lookups themselves are untouched and still work when nothing was primed, so
 * a URL that turns out not to be needed costs one wasted request and a URL
 * that was never primed simply fetches as before.
 *
 * @param array<int,string> $urls
 */
function retailer_http_prime(array $urls, int $timeout = RETAILER_HTTP_TIMEOUT): void
{
    $wanted = [];
    foreach ($urls as $url) {
        $url = trim((string) $url);
        if ($url !== '' && !isset($wanted[$url])) $wanted[$url] = $url;
    }
    if (count($wanted) < 2) return;   // one URL gains nothing from curl_multi

    foreach (retailer_http_get_multi($wanted, $timeout) as $url => $response) {
        if (!empty($response['ok']) && ($response['status'] ?? 0) < 400 && ($response['body'] ?? '') !== '') {
            http_prime_store((string) $url, (string) $response['body']);
        }
    }
}

/**
 * @param array<string,string> $urls id => url
 * @return array<string,array{ok:bool,status:int,body:string,error:string}>
 */
function retailer_http_get_multi(array $urls, int $timeout = RETAILER_HTTP_TIMEOUT): array
{
    if (!function_exists('curl_multi_init') || $urls === []) {
        $out = [];
        foreach ($urls as $id => $url) {
            $out[$id] = retailer_http_get($url, [], $timeout);
        }
        return $out;
    }

    $ua = (string) (app_config()['app_contact'] ?? 'TCG Card Scanner');
    $mh = curl_multi_init();
    $handles = [];
    foreach ($urls as $id => $url) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 4,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => 2,
            CURLOPT_HTTPHEADER => [
                'Accept: text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
                'Accept-Language: en-GB,en;q=0.9',
            ],
            CURLOPT_USERAGENT => $ua,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_ENCODING => '',
        ]);
        curl_multi_add_handle($mh, $ch);
        $handles[$id] = $ch;
    }

    $running = null;
    do {
        $status = curl_multi_exec($mh, $running);
        if ($running) {
            curl_multi_select($mh, 0.2);
        }
    } while ($running && $status === CURLM_OK);

    $out = [];
    foreach ($handles as $id => $ch) {
        $body = curl_multi_getcontent($ch);
        $statusCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_multi_remove_handle($mh, $ch);
        curl_close($ch);
        if ($body === false || $error !== '') {
            $out[$id] = ['ok' => false, 'status' => $statusCode, 'body' => '', 'error' => $error ?: 'Request failed'];
        } else {
            $out[$id] = ['ok' => true, 'status' => $statusCode, 'body' => (string) $body, 'error' => ''];
        }
    }
    curl_multi_close($mh);
    return $out;
}

function retailer_cache_get(string $key): ?array
{
    $cached = cache_read_json('retailer:' . $key, RETAILER_CACHE_TTL);
    return is_array($cached) ? $cached : null;
}

function retailer_cache_set(string $key, array $data): void
{
    cache_write_json('retailer:' . $key, $data);
}
