<?php
declare(strict_types=1);

/**
 * Shared exact card-number match helpers for retailer lookups.
 * Rejects OP16-032a when looking for OP16-032 (and similar suffix variants).
 */

function retailer_normalize_number(string $number): string
{
    $number = strtoupper(clean_text($number, 40));
    $number = str_replace([' ', '_'], '', $number);
    return $number;
}

/**
 * Pokémon-style collector/set numbers: 053/182 ≡ 53/182 ≡ 53-182.
 * Returns [local, denom] without leading zeros, or null when not that shape.
 *
 * @return array{0:string,1:string}|null
 */
function retailer_slash_number_parts(string $number): ?array
{
    $number = retailer_normalize_number($number);
    if ($number === '') return null;
    if (!preg_match('/^0*(\d+)[\/\-]0*(\d+)$/', $number, $match)) {
        return null;
    }
    return [$match[1], $match[2]];
}

/**
 * Regex body (no delimiters) matching a card number with padding/separator variants.
 * Slash numbers: 053/182, 53/182, 053-182, 53-182. Other codes stay literal (OP16-045).
 */
function retailer_number_regex_body(string $number): string
{
    $parts = retailer_slash_number_parts($number);
    if ($parts !== null) {
        return '0*' . preg_quote($parts[0], '/') . '[\\/\\-]' . '0*' . preg_quote($parts[1], '/');
    }
    $number = retailer_normalize_number($number);
    return preg_quote($number, '/');
}

/**
 * Display/search forms for a number (unpadded then padded for slash IDs).
 *
 * @return list<string>
 */
function retailer_number_forms(string $number): array
{
    $normalized = retailer_normalize_number($number);
    $parts = retailer_slash_number_parts($number);
    if ($parts === null) {
        return $normalized !== '' ? [$normalized] : [];
    }

    $unpadded = $parts[0] . '/' . $parts[1];
    $padded = str_pad($parts[0], 3, '0', STR_PAD_LEFT) . '/' . $parts[1];
    $forms = [$unpadded];
    if ($padded !== $unpadded) {
        $forms[] = $padded;
    }
    // Keep original slash/hyphen spelling if it differs (e.g. 53-182).
    if ($normalized !== '' && !in_array($normalized, $forms, true)) {
        $forms[] = $normalized;
    }
    return $forms;
}

function retailer_title_matches_number(string $title, string $number): bool
{
    $number = retailer_normalize_number($number);
    if ($number === '' || $title === '') return false;
    $body = retailer_number_regex_body($number);
    return (bool) preg_match('/(?:^|[\s\-–—])' . $body . '$/iu', trim($title));
}

function retailer_handle_matches_number(string $handle, string $number): bool
{
    $handle = strtolower(clean_text($handle, 180));
    if ($handle === '' || retailer_normalize_number($number) === '') return false;

    $parts = retailer_slash_number_parts($number);
    if ($parts !== null) {
        $body = '0*' . preg_quote($parts[0], '/') . '-' . '0*' . preg_quote($parts[1], '/');
        return (bool) preg_match('/(?:^|-)' . $body . '$/i', $handle);
    }

    $number = strtolower(retailer_normalize_number($number));
    return (bool) preg_match('/(?:^|-)' . preg_quote($number, '/') . '$/i', $handle);
}

function retailer_text_contains_exact_number(string $text, string $number): bool
{
    $number = retailer_normalize_number($number);
    if ($number === '' || $text === '') return false;
    $body = retailer_number_regex_body($number);
    return (bool) preg_match('/(?<![A-Z0-9])' . $body . '(?![A-Z0-9])/iu', $text);
}

function retailer_parse_gbp(mixed $value): ?float
{
    if ($value === null || $value === '') return null;
    if (is_numeric($value)) {
        $price = (float) $value;
        return $price > 0 ? round($price, 2) : null;
    }
    $text = trim((string) $value);
    if (preg_match('/£\s*(\d+(?:\.\d{1,2})?)/u', $text, $match)) {
        return retailer_parse_gbp($match[1]);
    }
    if (preg_match('/(\d+(?:\.\d{1,2})?)/', $text, $match)) {
        return retailer_parse_gbp($match[1]);
    }
    return null;
}

/**
 * @return array{id:string,label:string,matched:bool,available:?bool,priceGbp:?float,url:string,note:string}
 */
function retailer_source_result(
    string $id,
    string $label,
    bool $matched = false,
    ?bool $available = null,
    ?float $priceGbp = null,
    string $url = '',
    string $note = ''
): array {
    return [
        'id' => $id,
        'label' => $label,
        'matched' => $matched,
        'available' => $available,
        'priceGbp' => $priceGbp,
        'url' => $url,
        'note' => $note,
    ];
}

function retailer_source_no_match(string $id, string $label, string $note = 'No match'): array
{
    return retailer_source_result($id, $label, false, null, null, '', $note);
}

function retailer_source_blocked(string $id, string $label, string $note = 'Blocked'): array
{
    return retailer_source_result($id, $label, false, null, null, '', $note);
}

/**
 * Short set hint for search keywords (drops series noise like Scarlet/Violet).
 */
function retailer_search_set_hint(string $setName): string
{
    $setName = trim($setName);
    if ($setName === '') return '';
    $noise = ['scarlet', 'violet', 'pokemon', 'tcg', 'series', 'expansion', 'set'];
    $kept = [];
    foreach (retailer_name_tokens($setName) as $token) {
        if (in_array($token, $noise, true)) continue;
        if (strlen($token) < 4) continue;
        $kept[] = ucfirst($token);
        if (count($kept) >= 3) break;
    }
    if ($kept === []) {
        // Fall back to first two significant tokens of the set name.
        foreach (retailer_name_tokens($setName) as $token) {
            if (strlen($token) < 3) continue;
            $kept[] = ucfirst($token);
            if (count($kept) >= 2) break;
        }
    }
    return implode(' ', $kept);
}

/**
 * Ordered search keywords for retailer APIs (spaces, not hyphen slugs).
 * Tries name+number padding variants, then name+set+number, then number-only.
 *
 * @return list<string>
 */
function retailer_search_keywords(string $number, string $cardName = '', string $setName = ''): array
{
    $cardName = trim($cardName);
    $setHint = retailer_search_set_hint($setName);
    $numberForms = retailer_number_forms($number);
    $keywords = [];

    foreach ($numberForms as $form) {
        if ($cardName !== '') {
            $keywords[] = $cardName . ' ' . $form;
        }
    }
    if ($cardName !== '' && $setHint !== '') {
        foreach ($numberForms as $form) {
            $keywords[] = $cardName . ' ' . $setHint . ' ' . $form;
        }
    }
    foreach ($numberForms as $form) {
        $keywords[] = $form;
    }
    if ($cardName !== '' && $setHint !== '') {
        $keywords[] = $cardName . ' ' . $setHint;
    } elseif ($cardName !== '' && $numberForms === []) {
        $keywords[] = $cardName . ($setHint !== '' ? ' ' . $setHint : '');
    }

    $out = [];
    $seen = [];
    foreach ($keywords as $keyword) {
        $keyword = trim(preg_replace('/\s+/', ' ', $keyword) ?? $keyword);
        if ($keyword === '') continue;
        $key = strtolower($keyword);
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $out[] = $keyword;
    }
    return $out;
}

/**
 * Build a disambiguating search keyword: "Tyranitar 135/193" (not number alone).
 * Prefer unpadded slash form when both padded/unpadded exist.
 */
function retailer_search_keyword(string $number, string $cardName = '', string $setName = ''): string
{
    $keywords = retailer_search_keywords($number, $cardName, $setName);
    return $keywords[0] ?? '';
}

function retailer_normalize_match_text(string $text): string
{
    $text = strtolower(trim($text));
    if ($text === '') return '';
    if (function_exists('iconv')) {
        $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
        if (is_string($converted) && $converted !== '') {
            $text = strtolower($converted);
        }
    }
    $text = preg_replace('/[^a-z0-9]+/', ' ', $text) ?? $text;
    return trim(preg_replace('/\s+/', ' ', $text) ?? $text);
}

/**
 * Significant name tokens for matching (drops tiny filler words).
 *
 * @return list<string>
 */
function retailer_name_tokens(string $name): array
{
    $stop = ['the', 'a', 'an', 'of', 'and', 'or', 'to', 'for', 'with', 'card', 'cards'];
    $tokens = [];
    foreach (explode(' ', retailer_normalize_match_text($name)) as $token) {
        if ($token === '' || strlen($token) < 2) continue;
        if (in_array($token, $stop, true)) continue;
        $tokens[] = $token;
    }
    return array_values(array_unique($tokens));
}

/**
 * 100 = all preferred name tokens found in haystack; 0 = no usable name match.
 * When preferred name is empty, returns -1 (no name constraint).
 */
function retailer_name_score(string $haystack, string $preferredName): int
{
    $preferredName = trim($preferredName);
    if ($preferredName === '') return -1;
    $tokens = retailer_name_tokens($preferredName);
    if ($tokens === []) return -1;
    $hay = ' ' . retailer_normalize_match_text($haystack) . ' ';
    $hit = 0;
    foreach ($tokens as $token) {
        if (str_contains($hay, ' ' . $token . ' ')) {
            $hit += 1;
        }
    }
    if ($hit === count($tokens)) return 100;
    // Allow partial only when many tokens (e.g. long English names); still require majority + longest token.
    $longest = $tokens[0];
    foreach ($tokens as $token) {
        if (strlen($token) > strlen($longest)) $longest = $token;
    }
    if ($hit > 0 && str_contains($hay, ' ' . $longest . ' ') && $hit >= (int) ceil(count($tokens) * 0.75)) {
        return 60;
    }
    return 0;
}

/**
 * Bonus when set name tokens appear in the listing title/handle.
 */
function retailer_set_score(string $haystack, string $setName): int
{
    $setName = trim($setName);
    if ($setName === '') return 0;
    $tokens = retailer_name_tokens($setName);
    if ($tokens === []) return 0;
    $hay = ' ' . retailer_normalize_match_text($haystack) . ' ';
    $hit = 0;
    foreach ($tokens as $token) {
        if (strlen($token) < 3) continue;
        if (str_contains($hay, ' ' . $token . ' ')) $hit += 1;
    }
    if ($hit === 0) return 0;
    if ($hit >= count($tokens)) return 30;
    return 10;
}

/**
 * True when a preferred card name is provided and the listing title/url matches it.
 * Number-only collisions (135/193 Tyranitar vs Tatsugiri) fail this check.
 */
function retailer_identity_matches(string $haystack, string $preferredName, string $preferredSet = ''): bool
{
    $nameScore = retailer_name_score($haystack, $preferredName);
    if ($nameScore === -1) {
        // No name provided — cannot safely disambiguate Pokémon-style numbers.
        return false;
    }
    return $nameScore >= 60;
}
