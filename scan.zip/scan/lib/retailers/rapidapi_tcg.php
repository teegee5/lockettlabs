<?php
declare(strict_types=1);

require_once __DIR__ . '/match.php';
require_once __DIR__ . '/http.php';

/**
 * TCGPlayer Price Data on RapidAPI (market / reference, not UK retail).
 *
 * Product: https://rapidapi.com/lulzasaur9192/api/tcgplayer-price-data
 * Host:    tcgplayer-price-data.p.rapidapi.com (override via rapidapi_tcg_host)
 * Endpoint: GET /search?card={query}&game={slug}&limit=10
 *           (fallback) GET /tcgplayer/search?query={query}&limit=10
 * Headers: X-RapidAPI-Key, X-RapidAPI-Host
 *
 * Covers multi-TCG including One Piece when the catalogue has a match.
 * Prices are USD market/low listings; we convert to GBP via Frankfurter
 * (same path as JustTCG). Treat as market-not-retail: available=true is a
 * listing proxy for the competitor board, not a UK shop stock signal.
 */

const RAPIDAPI_TCG_DEFAULT_HOST = 'tcgplayer-price-data.p.rapidapi.com';
const RAPIDAPI_TCG_LABEL = 'TCGPlayer (RapidAPI)';
const RAPIDAPI_TCG_ID = 'rapidapi_tcg';

function retailer_rapidapi_key(): string
{
    $config = app_config();
    foreach (['rapidapi_key', 'RAPIDAPI_KEY', 'rapidapi_tcg_key'] as $key) {
        $value = trim((string) ($config[$key] ?? ''));
        if ($value !== '') return $value;
    }
    $env = getenv('RAPIDAPI_KEY');
    return is_string($env) ? trim($env) : '';
}

function retailer_rapidapi_tcg_host(): string
{
    $config = app_config();
    foreach (['rapidapi_tcg_host', 'RAPIDAPI_TCG_HOST'] as $key) {
        $host = trim((string) ($config[$key] ?? ''));
        if ($host !== '') {
            $host = preg_replace('#^https?://#i', '', $host) ?? $host;
            return rtrim($host, '/');
        }
    }
    $env = getenv('RAPIDAPI_TCG_HOST');
    if (is_string($env) && trim($env) !== '') {
        $host = preg_replace('#^https?://#i', '', trim($env)) ?? trim($env);
        return rtrim($host, '/');
    }
    return RAPIDAPI_TCG_DEFAULT_HOST;
}

/**
 * Map app game ids to RapidAPI `game` query values.
 */
function retailer_rapidapi_tcg_game_slug(string $game): string
{
    $game = strtolower(trim($game));
    return match (true) {
        $game === '' || str_contains($game, 'one-piece') || str_contains($game, 'onepiece') => 'one-piece',
        str_contains($game, 'pokemon') && str_contains($game, 'japan') => 'pokemon',
        str_contains($game, 'pokemon') => 'pokemon',
        str_contains($game, 'magic') || $game === 'mtg' => 'magic',
        str_contains($game, 'yugioh') || str_contains($game, 'yu-gi-oh') => 'yugioh',
        str_contains($game, 'lorcana') => 'lorcana',
        str_contains($game, 'flesh') => 'flesh-and-blood',
        default => $game,
    };
}

/**
 * @return array{id:string,label:string,matched:bool,available:?bool,priceGbp:?float,url:string,note:string,market?:bool}
 */
function retailer_rapidapi_tcg_lookup(string $cardNumber, string $game = 'one-piece-card-game', string $cardName = '', string $setName = ''): array
{
    $id = RAPIDAPI_TCG_ID;
    $label = RAPIDAPI_TCG_LABEL;
    $number = retailer_normalize_number($cardNumber);
    if ($number === '') {
        return retailer_source_no_match($id, $label);
    }

    $apiKey = retailer_rapidapi_key();
    if ($apiKey === '') {
        return retailer_source_blocked($id, $label, 'Add RAPIDAPI_KEY (or rapidapi_key) in config.php');
    }

    $cacheKey = 'rapidapi_tcg:v1:' . $number . ':' . retailer_rapidapi_tcg_game_slug($game);
    $cached = retailer_cache_get($cacheKey);
    if ($cached !== null) return $cached;

    $host = retailer_rapidapi_tcg_host();
    $query = $number;
    $name = clean_text($cardName, 120);
    $set = clean_text($setName, 120);
    if ($name !== '') {
        $query = $name . ($set !== '' ? ' ' . $set : '') . ' ' . $number;
    }

    $gameSlug = retailer_rapidapi_tcg_game_slug($game);
    // Primary docs use /search?card=&game=; playground also exposes /tcgplayer/search?query=.
    $urls = [
        'https://' . $host . '/search?' . http_build_query([
            'card' => $query,
            'game' => $gameSlug,
            'limit' => 10,
        ], '', '&', PHP_QUERY_RFC3986),
        'https://' . $host . '/tcgplayer/search?' . http_build_query([
            'query' => $query,
            'limit' => 10,
        ], '', '&', PHP_QUERY_RFC3986),
    ];

    $headers = [
        'Accept: application/json',
        'X-RapidAPI-Key: ' . $apiKey,
        'X-RapidAPI-Host: ' . $host,
    ];

    try {
        $response = ['ok' => false, 'status' => 0, 'body' => '', 'error' => 'No request'];
        foreach ($urls as $url) {
            $response = retailer_http_get($url, $headers, 8);
            // Fall through to alternate path on missing route only.
            if ($response['ok'] && !in_array($response['status'], [404, 405], true)) {
                break;
            }
        }
        $result = retailer_rapidapi_tcg_from_response($number, $response, $name);
    } catch (Throwable $error) {
        $result = retailer_source_blocked($id, $label, 'Blocked: ' . clean_text($error->getMessage(), 120));
    }

    retailer_cache_set($cacheKey, $result);
    return $result;
}

/**
 * @param array{ok:bool,status:int,body:string,error:string} $response
 * @return array{id:string,label:string,matched:bool,available:?bool,priceGbp:?float,url:string,note:string,market:bool}
 */
function retailer_rapidapi_tcg_from_response(string $number, array $response, string $preferredName = ''): array
{
    $id = RAPIDAPI_TCG_ID;
    $label = RAPIDAPI_TCG_LABEL;
    $number = retailer_normalize_number($number);

    if (!$response['ok'] || $response['status'] === 0) {
        return retailer_source_blocked($id, $label, 'Blocked');
    }
    if (in_array($response['status'], [401, 403], true)) {
        return retailer_source_blocked($id, $label, 'Blocked: check RAPIDAPI_KEY / plan');
    }
    if ($response['status'] === 429) {
        return retailer_source_blocked($id, $label, 'Blocked: rate limited');
    }
    if ($response['status'] >= 400) {
        return retailer_source_blocked($id, $label, 'Blocked: HTTP ' . $response['status']);
    }

    $json = json_decode($response['body'], true);
    if (!is_array($json)) {
        return retailer_source_no_match($id, $label, 'No match');
    }

    $rows = retailer_rapidapi_tcg_extract_rows($json);
    if ($rows === []) {
        return retailer_source_no_match($id, $label, 'No match');
    }

    $best = retailer_rapidapi_tcg_pick_row($rows, $number, $preferredName);
    if ($best === null) {
        return retailer_source_no_match($id, $label, 'No match');
    }

    $usd = retailer_rapidapi_tcg_extract_usd($best);
    if ($usd === null || $usd <= 0) {
        $url = retailer_rapidapi_tcg_extract_url($best);
        return array_merge(
            retailer_source_result($id, $label, true, null, null, $url, 'Matched (no usable market price)'),
            ['market' => true]
        );
    }

    $gbp = retailer_rapidapi_tcg_usd_to_gbp($usd);
    if ($gbp === null) {
        return array_merge(
            retailer_source_blocked($id, $label, 'Blocked: USD→GBP rate unavailable'),
            ['market' => true]
        );
    }

    $url = retailer_rapidapi_tcg_extract_url($best);
    return array_merge(
        retailer_source_result(
            $id,
            $label,
            true,
            true, // market listing proxy — not UK retail stock
            $gbp,
            $url,
            'Market low (US→GBP, not UK retail)'
        ),
        ['market' => true, 'priceUsd' => round($usd, 2)]
    );
}

/**
 * @return list<array>
 */
function retailer_rapidapi_tcg_extract_rows(array $json): array
{
    foreach (['results', 'data', 'cards', 'items'] as $key) {
        if (isset($json[$key]) && is_array($json[$key])) {
            $rows = [];
            foreach ($json[$key] as $row) {
                if (is_array($row)) $rows[] = $row;
            }
            return $rows;
        }
    }
    // Single card object
    if (isset($json['name']) || isset($json['marketPrice']) || isset($json['lowPrice'])) {
        return [$json];
    }
    return [];
}

/**
 * @param list<array> $rows
 */
function retailer_rapidapi_tcg_pick_row(array $rows, string $number, string $preferredName = ''): ?array
{
    $number = retailer_normalize_number($number);
    $preferred = strtolower(clean_text($preferredName, 120));
    $scored = [];

    foreach ($rows as $index => $row) {
        $hay = strtoupper(clean_text(
            ($row['name'] ?? '') . ' '
            . ($row['cardName'] ?? '') . ' '
            . ($row['number'] ?? '') . ' '
            . ($row['cardNumber'] ?? '') . ' '
            . ($row['extNumber'] ?? '') . ' '
            . ($row['set'] ?? '') . ' '
            . ($row['setName'] ?? '') . ' '
            . ($row['productName'] ?? ''),
            500
        ));
        if ($hay === '') continue;

        $score = 0;
        if ($number !== '' && retailer_text_contains_exact_number($hay, $number)) {
            $score += 100;
        }
        if ($preferred !== '' && str_contains(strtolower($hay), $preferred)) {
            $score += 20;
        }
        // Prefer rows that actually have a price.
        if (retailer_rapidapi_tcg_extract_usd($row) !== null) {
            $score += 5;
        }
        if ($score > 0) {
            $scored[] = ['score' => $score, 'index' => $index, 'row' => $row];
        }
    }

    if ($scored === []) {
        // Fall back to first priced row when number matching is unavailable.
        foreach ($rows as $row) {
            if (retailer_rapidapi_tcg_extract_usd($row) !== null) return $row;
        }
        return $rows[0] ?? null;
    }

    usort($scored, static function ($a, $b) {
        if ($a['score'] !== $b['score']) return $b['score'] <=> $a['score'];
        return $a['index'] <=> $b['index'];
    });
    return $scored[0]['row'];
}

function retailer_rapidapi_tcg_extract_usd(array $row): ?float
{
    // Prefer lowest listing / market floor for competitor undercut reference.
    $keys = [
        'lowPrice', 'lowestPrice', 'lowestListing', 'low', 'marketLow',
        'marketPrice', 'market', 'price', 'midPrice', 'avgPrice',
    ];
    foreach ($keys as $key) {
        if (!array_key_exists($key, $row)) continue;
        $value = $row[$key];
        if (is_array($value)) {
            foreach (['value', 'amount', 'price', 'low', 'market'] as $inner) {
                if (isset($value[$inner]) && is_numeric($value[$inner]) && (float) $value[$inner] > 0) {
                    return round((float) $value[$inner], 2);
                }
            }
            continue;
        }
        if (is_numeric($value) && (float) $value > 0) {
            return round((float) $value, 2);
        }
    }
    // Nested prices / variants
    if (isset($row['prices']) && is_array($row['prices'])) {
        $nested = retailer_rapidapi_tcg_extract_usd($row['prices']);
        if ($nested !== null) return $nested;
    }
    if (isset($row['variants']) && is_array($row['variants'])) {
        foreach ($row['variants'] as $variant) {
            if (!is_array($variant)) continue;
            $condition = strtolower(clean_text($variant['condition'] ?? '', 40));
            if ($condition !== '' && !str_contains($condition, 'near') && !str_contains($condition, 'nm')) {
                continue;
            }
            $nested = retailer_rapidapi_tcg_extract_usd($variant);
            if ($nested !== null) return $nested;
        }
    }
    return null;
}

function retailer_rapidapi_tcg_extract_url(array $row): string
{
    foreach (['url', 'productUrl', 'productURL', 'tcgplayerUrl', 'link', 'href'] as $key) {
        $url = safe_https_url($row[$key] ?? '');
        if ($url !== '') return $url;
    }
    $productId = clean_text((string) ($row['productId'] ?? $row['tcgplayerId'] ?? $row['id'] ?? ''), 40);
    if ($productId !== '' && ctype_digit($productId)) {
        return 'https://www.tcgplayer.com/product/' . $productId;
    }
    return '';
}

function retailer_rapidapi_tcg_usd_to_gbp(float $usd): ?float
{
    if ($usd <= 0) return null;
    try {
        // Same Frankfurter daily USD/GBP reference used by JustTCG in lib/providers.php.
        $rateData = cached_http_json('https://api.frankfurter.dev/v2/rate/USD/GBP', [], 43200);
    } catch (Throwable) {
        return null;
    }
    $rate = is_numeric($rateData['rate'] ?? null) ? (float) $rateData['rate'] : 0.0;
    $base = strtoupper(clean_text($rateData['base'] ?? '', 3));
    $quote = strtoupper(clean_text($rateData['quote'] ?? '', 3));
    if ($rate <= 0 || $base !== 'USD' || $quote !== 'GBP') return null;
    return round($usd * $rate, 2);
}
