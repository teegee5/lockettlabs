<?php
declare(strict_types=1);

/** Never undercut below this GBP amount — match the floor instead. */
const COMPETITOR_PRICE_FLOOR = 0.15;
/** Rare / mid-band cards at the floor are raised to this amount. */
const COMPETITOR_RARE_MIN = 0.19;

/**
 * Demand proxy v1: rarity band + in-stock competitor coverage.
 *
 * @return 'volume'|'mid'|'chase'
 */
function competitor_rarity_band(string $rarity): string
{
    $text = strtolower(trim($rarity));
    if ($text === '') return 'mid';

    // Chase first — overlapping tokens (e.g. "Secret Rare", "Illustration Rare")
    // must win over plain "Rare" / "Ultra Rare".
    $chasePatterns = [
        '/\bsec(ret)?\b/i',
        '/\bsecret\s*rare\b/i',
        '/\bsp\b/i',
        '/\bspecial\s*illustration\b/i',
        '/\bspecial\b/i',
        '/\bmanga\b/i',
        '/\baa\b/i',
        '/\balt(ernate)?(\s*art)?\b/i',
        '/\btreasure\b/i',
        '/\bparallel\b/i',
        '/\bgold\b/i',
        '/\bdon!!?\b/i',
        '/\bleader\b/i',
        '/\bpromo\b/i',
        '/\billustration\b/i',
        '/\bcomic\b/i',
        '/\bhyper\b/i',
        '/\bshiny\b/i',
        '/\bradiant\b/i',
        '/\bace\s*spec\b/i',
    ];
    foreach ($chasePatterns as $pattern) {
        if (preg_match($pattern, $text)) return 'chase';
    }

    if (in_array($text, ['c', 'uc', 'u', 'common', 'uncommon'], true)) return 'volume';
    if (preg_match('/\buncommon\b/i', $text)) return 'volume';
    if (preg_match('/\bcommon\b/i', $text)) return 'volume';

    // Pokémon Ultra Rare / Double Rare and One Piece Super Rare sit in mid.
    if (in_array($text, ['r', 'sr', 'rr', 'rare', 'super rare', 'super-rare', 'ultra rare', 'double rare'], true)) {
        return 'mid';
    }
    if (preg_match('/\bsuper\s*rare\b/i', $text)) return 'mid';
    if (preg_match('/\bultra\s*rare\b/i', $text)) return 'mid';
    if (preg_match('/\bdouble\s*rare\b/i', $text)) return 'mid';
    if (preg_match('/\brare\b/i', $text)) return 'mid';

    return 'mid';
}

/**
 * Beat lowest by 1p with odd pence, but never go below COMPETITOR_PRICE_FLOOR.
 * If the competitor is already at/below the floor, match the floor.
 */
function competitor_undercut_odd_pence(float $lowestInStock): float
{
    $floor = COMPETITOR_PRICE_FLOOR;
    if ($lowestInStock <= $floor + 0.001) {
        return $floor;
    }

    $target = round($lowestInStock - 0.01, 2);
    $pence = (int) round($target * 100);
    if ($pence < 1) {
        return $floor;
    }
    if ($pence % 2 === 0) {
        $pence -= 1;
    }
    $suggested = round(max(1, $pence) / 100, 2);
    return max($floor, $suggested);
}

/**
 * Rare (mid/chase) cards should not sit at the absolute floor — raise 0.15 → 0.19.
 * Commons/uncommons (volume) may match the £0.15 floor.
 */
function competitor_apply_rarity_price_floor(float $suggested, string $band): float
{
    $suggested = round($suggested, 2);
    if ($band === 'volume') {
        return max(COMPETITOR_PRICE_FLOOR, $suggested);
    }
    if (abs($suggested - COMPETITOR_PRICE_FLOOR) < 0.005) {
        return COMPETITOR_RARE_MIN;
    }
    return max(COMPETITOR_PRICE_FLOOR, $suggested);
}

/**
 * @param list<float> $inStockPrices
 */
function competitor_median(array $inStockPrices): ?float
{
    $prices = array_values(array_filter($inStockPrices, static fn ($p) => is_numeric($p) && (float) $p > 0));
    sort($prices, SORT_NUMERIC);
    $n = count($prices);
    if ($n === 0) return null;
    $mid = intdiv($n, 2);
    if ($n % 2 === 1) {
        return round((float) $prices[$mid], 2);
    }
    return round(((float) $prices[$mid - 1] + (float) $prices[$mid]) / 2, 2);
}

/**
 * Build NM suggestion from rarity band + in-stock comps + optional JustTCG NM.
 *
 * @param list<float> $inStockPrices
 * @return array{suggestedNm:?float,action:string,reason:string,autoFill:bool}
 */
function competitor_suggest_nm(string $band, ?float $justTcgNm, array $inStockPrices, ?float $currentNm = null): array
{
    $band = in_array($band, ['volume', 'mid', 'chase'], true) ? $band : 'mid';
    $prices = [];
    foreach ($inStockPrices as $price) {
        if (is_numeric($price) && (float) $price > 0) {
            $prices[] = round((float) $price, 2);
        }
    }
    sort($prices, SORT_NUMERIC);
    $lowest = $prices[0] ?? null;
    $just = ($justTcgNm !== null && $justTcgNm > 0) ? round($justTcgNm, 2) : null;

    // Scarcity: no in-stock competitors → raise toward JustTCG (or hold).
    if ($lowest === null) {
        if ($just === null) {
            return [
                'suggestedNm' => $currentNm,
                'action' => 'hold',
                'reason' => 'No in-stock competitor matches and no JustTCG NM reference.',
                'autoFill' => false,
            ];
        }
        $suggested = competitor_apply_rarity_price_floor($just, $band);
        if ($currentNm !== null && $currentNm >= $suggested) {
            return [
                'suggestedNm' => $currentNm,
                'action' => 'hold',
                'reason' => 'No in-stock comps; your NM is already at or above market (£' . number_format($suggested, 2) . ').',
                'autoFill' => false,
            ];
        }
        return [
            'suggestedNm' => $suggested,
            'action' => 'raise',
            'reason' => 'No in-stock competitor matches — scarcity; raise toward JustTCG NM £' . number_format($suggested, 2) . '.',
            'autoFill' => $band !== 'chase',
        ];
    }

    if ($band === 'volume') {
        $raw = competitor_undercut_odd_pence($lowest);
        $suggested = competitor_apply_rarity_price_floor($raw, $band);
        $matchedFloor = abs($lowest - COMPETITOR_PRICE_FLOOR) < 0.005 || abs($suggested - COMPETITOR_PRICE_FLOOR) < 0.005;
        $action = ($currentNm !== null && abs($currentNm - $suggested) < 0.005)
            ? 'hold'
            : ($matchedFloor && abs($suggested - $lowest) < 0.005 ? 'hold' : 'undercut');
        $reason = $matchedFloor && abs($suggested - COMPETITOR_PRICE_FLOOR) < 0.005
            ? 'Volume: match £' . number_format(COMPETITOR_PRICE_FLOOR, 2) . ' floor (do not go lower). Lowest in-stock was £' . number_format($lowest, 2) . '.'
            : 'Volume: beat lowest in-stock £' . number_format($lowest, 2) . ' → £' . number_format($suggested, 2) . ' (floor £' . number_format(COMPETITOR_PRICE_FLOOR, 2) . ').';
        return [
            'suggestedNm' => $suggested,
            'action' => $action,
            'reason' => $reason,
            'autoFill' => true,
        ];
    }

    if ($band === 'mid') {
        $undercut = competitor_undercut_odd_pence($lowest);
        $suggested = $just !== null ? min($just, $undercut) : $undercut;
        $suggested = competitor_apply_rarity_price_floor(round($suggested, 2), $band);
        $action = 'undercut';
        if (abs($suggested - COMPETITOR_RARE_MIN) < 0.005 && abs($undercut - COMPETITOR_PRICE_FLOOR) < 0.005) {
            $action = 'raise';
        }
        if ($currentNm !== null) {
            if ($currentNm > max($lowest, $suggested) + 0.005) $action = 'lower';
            elseif ($currentNm < $suggested - 0.005) $action = 'raise';
            elseif (abs($currentNm - $suggested) < 0.005) $action = 'hold';
        }
        $reason = abs($suggested - COMPETITOR_RARE_MIN) < 0.005 && $undercut <= COMPETITOR_PRICE_FLOOR + 0.001
            ? 'Mid/Rare: floor would be £' . number_format(COMPETITOR_PRICE_FLOOR, 2) . ' — raise to £' . number_format(COMPETITOR_RARE_MIN, 2) . '.'
            : 'Mid: beat/match toward £' . number_format($suggested, 2) . ' (lowest in-stock £' . number_format($lowest, 2) . ', floor £' . number_format(COMPETITOR_PRICE_FLOOR, 2) . ').';
        return [
            'suggestedNm' => $suggested,
            'action' => $action,
            'reason' => $reason,
            'autoFill' => true,
        ];
    }

    // Chase: do not race to bottom. max(JustTCG, median in-stock) or JustTCG alone.
    $median = competitor_median($prices);
    if ($just !== null && $median !== null) {
        $suggested = max($just, $median);
    } elseif ($just !== null) {
        $suggested = $just;
    } elseif ($median !== null) {
        $suggested = $median;
    } else {
        $suggested = $lowest;
    }
    $suggested = competitor_apply_rarity_price_floor(round($suggested, 2), $band);

    $action = 'hold';
    if ($currentNm !== null) {
        if ($currentNm > $lowest) {
            $action = 'lower';
        } elseif ($currentNm < $suggested - 0.005) {
            $action = 'raise';
        }
    } elseif ($just !== null && $suggested >= $just) {
        $action = 'raise';
    }

    $reason = 'Chase: suggested £' . number_format($suggested, 2)
        . ' (max of JustTCG'
        . ($just !== null ? ' £' . number_format($just, 2) : '')
        . ' and median in-stock'
        . ($median !== null ? ' £' . number_format($median, 2) : '')
        . '). Apply manually — do not race to the bottom.';

    return [
        'suggestedNm' => $suggested,
        'action' => $action,
        'reason' => $reason,
        'autoFill' => false,
    ];
}

/**
 * Compare an existing Shopify NM price to competitor guidance.
 *
 * @return array{action:string,reason:string,yourPrice:?float,lowestInStock:?float,suggestedNm:?float}
 */
function competitor_compare_existing(?float $yourPrice, ?float $lowestInStock, ?float $suggestedNm, string $band): array
{
    if ($yourPrice === null || $yourPrice <= 0) {
        return [
            'action' => 'hold',
            'reason' => 'No Shopify Near Mint price found to compare.',
            'yourPrice' => $yourPrice,
            'lowestInStock' => $lowestInStock,
            'suggestedNm' => $suggestedNm,
        ];
    }
    if ($lowestInStock === null) {
        if ($suggestedNm !== null && $yourPrice < $suggestedNm - 0.005) {
            return [
                'action' => 'raise',
                'reason' => 'Your £' . number_format($yourPrice, 2) . ' is below suggested scarcity price £' . number_format($suggestedNm, 2) . '.',
                'yourPrice' => $yourPrice,
                'lowestInStock' => null,
                'suggestedNm' => $suggestedNm,
            ];
        }
        return [
            'action' => 'hold',
            'reason' => 'No in-stock competitor; your £' . number_format($yourPrice, 2) . ' holds.',
            'yourPrice' => $yourPrice,
            'lowestInStock' => null,
            'suggestedNm' => $suggestedNm,
        ];
    }

    if ($yourPrice > $lowestInStock + 0.005) {
        $msg = $band === 'chase'
            ? 'Your £' . number_format($yourPrice, 2) . ' is above the lowest chase offer £' . number_format($lowestInStock, 2) . ' — lower carefully.'
            : 'Your £' . number_format($yourPrice, 2) . ' is above lowest in-stock £' . number_format($lowestInStock, 2) . ' — lower to compete.';
        return [
            'action' => 'lower',
            'reason' => $msg,
            'yourPrice' => $yourPrice,
            'lowestInStock' => $lowestInStock,
            'suggestedNm' => $suggestedNm,
        ];
    }

    if ($suggestedNm !== null && $yourPrice < $suggestedNm - 0.02) {
        return [
            'action' => 'raise',
            'reason' => 'Your £' . number_format($yourPrice, 2) . ' is well under suggested £' . number_format($suggestedNm, 2) . ' — raise.',
            'yourPrice' => $yourPrice,
            'lowestInStock' => $lowestInStock,
            'suggestedNm' => $suggestedNm,
        ];
    }

    return [
        'action' => 'hold',
        'reason' => 'Your £' . number_format($yourPrice, 2) . ' is competitive vs lowest in-stock £' . number_format($lowestInStock, 2) . '.',
        'yourPrice' => $yourPrice,
        'lowestInStock' => $lowestInStock,
        'suggestedNm' => $suggestedNm,
    ];
}
