<?php
declare(strict_types=1);

return [
    // Use the permanent *.myshopify.com domain, never the public storefront URL.
    'shopify_store' => 'your-store.myshopify.com',

    // Shopify custom app token. Keep this server-side and never commit config.php.
    'shopify_access_token' => 'shpat_replace_with_a_new_token',
    'shopify_api_version' => '2026-07',

    // Protect the staff tool with a long, unique password.
    'admin_password' => 'replace-with-a-long-unique-password',

    // JustTCG server-side API key. It is sent only from PHP in the x-api-key header.
    'justtcg_api_key' => 'tcg_replace_with_your_key',

    // Keep this at 20 for JustTCG Free plans. Starter/Pro can use up to 100.
    'justtcg_search_limit' => 20,

    // Short caching protects your allowance while preserving fresh pricing.
    // Raise toward 900–1800 for high-volume intake days.
    'justtcg_search_cache_seconds' => 900,

    // Shopify setup (collections, taxonomy, channels) changes rarely.
    // Cache it on the server so every page load is not 5 GraphQL round-trips.
    'shopify_meta_cache_seconds' => 3600,

    // Sent as the contact identifier in outbound requests.
    'app_contact' => 'Lockett Labs Card Intake / https://lockett-labs.com',
];
