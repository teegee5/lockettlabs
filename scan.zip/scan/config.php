<?php
declare(strict_types=1);

return [
    // Use the permanent *.myshopify.com domain, never the public storefront URL.
    'shopify_store' => 'lockett-labs.myshopify.com',

    // Shopify custom app token. Keep this server-side and never commit config.php.
    'shopify_access_token' => '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',
    'shopify_api_version' => '2026-07',

    // Protect the staff tool with a long, unique password.
    'admin_password' => '019962000',

    // JustTCG server-side API key. It is sent only from PHP in the x-api-key header.
    'justtcg_api_key' => 'tcg_b31eaadd215c4670bd24c0e0a80c2f76',

    // Keep this at 20 for JustTCG Free plans. Starter/Pro can use up to 100.
    'justtcg_search_limit' => 20,

    // Short caching protects your allowance while preserving fresh pricing.
    // Raise toward 900–1800 for high-volume intake days.
    'justtcg_search_cache_seconds' => 900,

    // Shopify setup changes rarely — avoid 5 GraphQL round-trips on every page load.
    'shopify_meta_cache_seconds' => 3600,

    // Sent as the contact identifier in outbound requests.
    'app_contact' => 'Lockett Labs Card Intake / https://lockett-labs.com',
];
